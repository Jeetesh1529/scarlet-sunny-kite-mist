import { createContext, useContext, useEffect, useState, ReactNode, useCallback, useRef } from 'react';
import { Session, User } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';
import { setSoundEnabled } from '@/lib/sfx';
import { registerOnlineFlush } from '@/lib/offlineQueue';
import { track } from '@/lib/analytics';

export type Presence = 'online' | 'away' | 'busy' | 'offline';

export type Profile = {
  id: string;
  mxit_id: string;
  display_name: string;
  mood: string | null;
  farewell: string | null;
  avatar_url: string | null;
  avatar_seed: string | null;
  gender: string | null;
  age: number | null;
  moola: number;
  theme: string;
  sound_enabled: boolean;
  presence: Presence;
  auto_away_minutes: number;
  hide_offline: boolean;
  low_data_mode: boolean;
  streak_days?: number;
  last_claim_date?: string | null;
  meet_opt_in?: boolean;
  meet_bio?: string | null;
};

type AuthCtx = {
  session: Session | null;
  user: User | null;
  profile: Profile | null;
  loading: boolean;
  refreshProfile: () => Promise<void>;
  setPresence: (p: Presence) => Promise<void>;
  signOut: () => Promise<void>;
};

const Ctx = createContext<AuthCtx | undefined>(undefined);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session | null>(null);
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<Profile | null>(null);
  const [loading, setLoading] = useState(true);
  const manualPresenceRef = useRef<Presence | null>(null);
  const lastActivityRef = useRef<number>(Date.now());

  const loadProfile = useCallback(async (uid: string) => {
    const { data } = await supabase.from('profiles').select('*').eq('id', uid).maybeSingle();
    if (data) {
      setProfile(data as unknown as Profile);
      document.documentElement.setAttribute('data-theme', (data as any).theme || 'black');
      setSoundEnabled((data as any).sound_enabled ?? true);
    } else {
      setProfile(null);
    }
  }, []);

  const refreshProfile = useCallback(async () => {
    if (user) await loadProfile(user.id);
  }, [user, loadProfile]);

  useEffect(() => {
    registerOnlineFlush();
    const { data: sub } = supabase.auth.onAuthStateChange((event, sess) => {
      setSession(sess);
      setUser(sess?.user ?? null);
      if (sess?.user) {
        setTimeout(() => loadProfile(sess.user.id), 0);
        if (event === 'SIGNED_IN') void track('login_completed', { user_id: sess.user.id });
      } else {
        setProfile(null);
      }
    });
    void track('app_open');

    supabase.auth.getSession().then(({ data: { session: s } }) => {
      setSession(s);
      setUser(s?.user ?? null);
      if (s?.user) loadProfile(s.user.id).finally(() => setLoading(false));
      else setLoading(false);
    });

    return () => sub.subscription.unsubscribe();
  }, [loadProfile]);

  // Subscribe to my own profile row so updates from anywhere reflect immediately
  useEffect(() => {
    if (!user) return;
    const ch = supabase
      .channel(`me-profile-${user.id}`)
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'profiles', filter: `id=eq.${user.id}` }, (payload) => {
        const next = payload.new as Profile;
        setProfile(next);
        document.documentElement.setAttribute('data-theme', (next as any).theme || 'black');
        setSoundEnabled((next as any).sound_enabled ?? true);
      })
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [user]);

  const writePresence = useCallback(async (uid: string, p: Presence) => {
    // If user has hidden mode on, always write 'offline' to others.
    const effective: Presence = (profile as any)?.appear_offline ? 'offline' : p;
    await supabase.from('profiles').update({ presence: effective, last_seen: new Date().toISOString() }).eq('id', uid);
  }, [profile]);

  const setPresence = useCallback(async (p: Presence) => {
    if (!user) return;
    // 'online' means resume auto-mode; anything else pins the state so the
    // auto-away loop won't override the user's choice.
    manualPresenceRef.current = p === 'online' ? null : p;
    lastActivityRef.current = Date.now();
    await writePresence(user.id, p);
    await refreshProfile();
  }, [user, writePresence, refreshProfile]);

  // Presence + auto-away loop. Depend ONLY on user.id so we don't tear down
  // and rewrite presence every time the profile row changes (which would
  // create a flip-flop loop with the realtime subscription above).
  const autoAwayMinutesRef = useRef<number>(profile?.auto_away_minutes ?? 5);
  useEffect(() => {
    autoAwayMinutesRef.current = profile?.auto_away_minutes ?? 5;
  }, [profile?.auto_away_minutes]);

  useEffect(() => {
    if (!user) return;
    let cancelled = false;

    const bumpActivity = () => { lastActivityRef.current = Date.now(); };
    ['mousemove', 'keydown', 'touchstart', 'click'].forEach((e) =>
      window.addEventListener(e, bumpActivity, { passive: true }),
    );

    const apply = async () => {
      if (cancelled || !user) return;
      const manual = manualPresenceRef.current;
      if (manual === 'busy' || manual === 'away' || manual === 'offline') return;
      if (document.hidden) {
        await writePresence(user.id, 'away');
        return;
      }
      const idleMs = Date.now() - lastActivityRef.current;
      const limitMs = autoAwayMinutesRef.current * 60_000;
      const target: Presence = idleMs > limitMs ? 'away' : 'online';
      await writePresence(user.id, target);
    };

    apply();
    const onVis = () => apply();
    document.addEventListener('visibilitychange', onVis);
    const interval = window.setInterval(apply, 30_000);

    const goOffline = () => {
      // Best-effort write — fires on tab close, refresh, navigation away,
      // and mobile app backgrounding (pagehide). We use both the supabase
      // client (works most cases) and a beacon fallback so the request
      // survives even if the page is being torn down.
      try { writePresence(user.id, 'offline'); } catch { /* ignore */ }
      try {
        const url = `${import.meta.env.VITE_SUPABASE_URL}/rest/v1/profiles?id=eq.${user.id}`;
        const body = JSON.stringify({ presence: 'offline', last_seen: new Date().toISOString() });
        const blob = new Blob([body], { type: 'application/json' });
        // sendBeacon can't set custom headers, but PostgREST requires the apikey
        // header — fall back to a keepalive fetch which does support headers.
        fetch(url, {
          method: 'PATCH',
          headers: {
            'Content-Type': 'application/json',
            apikey: import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY,
            Authorization: `Bearer ${session?.access_token ?? import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY}`,
            Prefer: 'return=minimal',
          },
          body,
          keepalive: true,
        }).catch(() => { /* ignore */ });
      } catch { /* ignore */ }
    };
    window.addEventListener('beforeunload', goOffline);
    window.addEventListener('pagehide', goOffline);
    const onHide = () => { if (document.visibilityState === 'hidden') goOffline(); };
    document.addEventListener('visibilitychange', onHide);

    return () => {
      cancelled = true;
      ['mousemove', 'keydown', 'touchstart', 'click'].forEach((e) =>
        window.removeEventListener(e, bumpActivity),
      );
      document.removeEventListener('visibilitychange', onVis);
      document.removeEventListener('visibilitychange', onHide);
      window.removeEventListener('beforeunload', goOffline);
      window.removeEventListener('pagehide', goOffline);
      window.clearInterval(interval);
      // NOTE: do NOT write 'offline' on cleanup — this effect only unmounts
      // when the user truly signs out, which is handled by signOut().
    };
  }, [user?.id, writePresence, session?.access_token]);

  const broadcastFarewell = useCallback(async () => {
    if (!user || !profile) return;
    const message = (profile.farewell ?? '').trim();
    if (!message) return;
    // Find all accepted contacts
    const { data: cs } = await supabase
      .from('contacts')
      .select('requester_id, addressee_id, status')
      .or(`requester_id.eq.${user.id},addressee_id.eq.${user.id}`)
      .eq('status', 'accepted');
    if (!cs?.length) return;
    const otherIds = cs.map((c) => (c.requester_id === user.id ? c.addressee_id : c.requester_id));
    // Find existing 1-on-1 conversations with these contacts
    const { data: convs } = await supabase
      .from('conversations')
      .select('id, user_a, user_b')
      .or(`user_a.eq.${user.id},user_b.eq.${user.id}`);
    if (!convs?.length) return;
    const targets = convs.filter((c) => {
      const other = c.user_a === user.id ? c.user_b : c.user_a;
      return otherIds.includes(other);
    });
    if (!targets.length) return;
    const text = `🚪 ${profile.display_name} signed off: ${message}`;
    await supabase.from('messages').insert(
      targets.map((c) => ({
        conversation_id: c.id,
        sender_id: user.id,
        content: text,
      })),
    );
  }, [user, profile]);

  const signOut = async () => {
    if (user) {
      try { await broadcastFarewell(); } catch { /* ignore */ }
      await writePresence(user.id, 'offline');
      void track('logout', { user_id: user.id });
    }
    await supabase.auth.signOut();
  };

  return (
    <Ctx.Provider value={{ session, user, profile, loading, refreshProfile, setPresence, signOut }}>
      {children}
    </Ctx.Provider>
  );
}

export function useAuth() {
  const v = useContext(Ctx);
  if (!v) throw new Error('useAuth must be used within AuthProvider');
  return v;
}
