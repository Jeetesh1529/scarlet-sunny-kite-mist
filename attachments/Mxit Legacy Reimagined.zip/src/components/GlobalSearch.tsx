/**
 * GlobalSearch — keyboard-accessible search dialog (Cmd/Ctrl+K) that finds
 * users by mxit_id/display_name and lets you jump to their profile or chat.
 */
import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { sfx } from '@/lib/sfx';
import { Search, X, MessageCircle, User } from 'lucide-react';
import { PixelAvatar } from './PixelAvatar';

type Hit = {
  id: string;
  mxit_id: string;
  display_name: string;
  avatar_seed: string | null;
  avatar_url: string | null;
  mood: string | null;
};

export function GlobalSearch() {
  const navigate = useNavigate();
  const { profile } = useAuth();
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');
  const [hits, setHits] = useState<Hit[]>([]);
  const [busy, setBusy] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  // Cmd/Ctrl+K to toggle, plus custom event so other UI can open it
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setOpen((o) => !o);
      } else if (e.key === 'Escape') {
        setOpen(false);
      }
    };
    const onOpen = () => setOpen(true);
    window.addEventListener('keydown', onKey);
    window.addEventListener('mxit:open-search', onOpen);
    return () => {
      window.removeEventListener('keydown', onKey);
      window.removeEventListener('mxit:open-search', onOpen);
    };
  }, []);

  useEffect(() => {
    if (open) setTimeout(() => inputRef.current?.focus(), 50);
    if (!open) { setQ(''); setHits([]); }
  }, [open]);

  useEffect(() => {
    const term = q.trim();
    if (term.length < 2) { setHits([]); return; }
    let cancelled = false;
    setBusy(true);
    const t = window.setTimeout(async () => {
      const { data } = await supabase
        .from('profiles')
        .select('id, mxit_id, display_name, avatar_seed, avatar_url, mood')
        .or(`mxit_id.ilike.%${term}%,display_name.ilike.%${term}%`)
        .neq('id', profile?.id ?? '00000000-0000-0000-0000-000000000000')
        .limit(20);
      if (!cancelled) {
        setHits((data ?? []) as Hit[]);
        setBusy(false);
      }
    }, 200);
    return () => { cancelled = true; window.clearTimeout(t); };
  }, [q, profile?.id]);

  const openChat = async (h: Hit) => {
    if (!profile) return;
    sfx.tap();
    const { data: existing } = await supabase
      .from('conversations')
      .select('id')
      .or(`and(user_a.eq.${profile.id},user_b.eq.${h.id}),and(user_a.eq.${h.id},user_b.eq.${profile.id})`)
      .maybeSingle();
    let convId = existing?.id;
    if (!convId) {
      const a = profile.id < h.id ? profile.id : h.id;
      const b = profile.id < h.id ? h.id : profile.id;
      const { data: created } = await supabase.from('conversations').insert({ user_a: a, user_b: b }).select('id').single();
      convId = created?.id;
    }
    if (convId) { setOpen(false); navigate(`/chat/${convId}`); }
  };

  return (
    <>
      {/* Floating trigger removed — opened via softkey bar or Ctrl+K */}
      {open && (
        <div
          className="fixed inset-0 z-[60] flex items-start justify-center pt-16 px-4 bg-black/60 backdrop-blur-sm"
          onClick={() => setOpen(false)}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            className="w-full max-w-md bg-card rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[70vh]"
          >
            <div className="flex items-center gap-2 px-3 py-2 border-b">
              <Search className="w-4 h-4 text-muted-foreground" />
              <input
                ref={inputRef}
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Search users by name or Mxit ID…"
                className="flex-1 bg-transparent text-sm focus:outline-none"
              />
              <button onClick={() => setOpen(false)} aria-label="close">
                <X className="w-4 h-4 text-muted-foreground" />
              </button>
            </div>
            <div className="flex-1 overflow-y-auto">
              {q.trim().length < 2 && (
                <div className="text-xs text-muted-foreground italic px-3 py-4 text-center">
                  Type at least 2 characters. Press <kbd className="px-1 bg-muted rounded">Ctrl</kbd>+<kbd className="px-1 bg-muted rounded">K</kbd> to toggle.
                </div>
              )}
              {q.trim().length >= 2 && busy && (
                <div className="text-xs text-muted-foreground px-3 py-4 text-center">Searching…</div>
              )}
              {q.trim().length >= 2 && !busy && hits.length === 0 && (
                <div className="text-xs text-muted-foreground italic px-3 py-4 text-center">No users found.</div>
              )}
              {hits.map((h) => (
                <div key={h.id} className="flex items-center gap-2 px-3 py-2 hover:bg-secondary border-b border-border">
                  <PixelAvatar seed={h.avatar_seed} url={h.avatar_url} size={32} />
                  <div className="flex-1 min-w-0">
                    <div className="text-sm font-medium truncate">{h.display_name}</div>
                    <div className="text-[11px] text-muted-foreground truncate">@{h.mxit_id}{h.mood ? ` · ${h.mood}` : ''}</div>
                  </div>
                  <button
                    onClick={() => { setOpen(false); navigate(`/u/${h.mxit_id}`); }}
                    className="p-1.5 rounded hover:bg-muted"
                    title="View profile"
                  >
                    <User className="w-4 h-4" />
                  </button>
                  <button
                    onClick={() => openChat(h)}
                    className="p-1.5 rounded bg-mxit-primary text-white hover:opacity-90"
                    title="Open chat"
                  >
                    <MessageCircle className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
