/**
 * Block list — view + unblock people you've blocked.
 */
import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { Shield, X } from 'lucide-react';
import { sfx } from '@/lib/sfx';

type Blocked = { id: string; blocked_id: string; reason: string | null; created_at: string;
  other?: { display_name: string; mxit_id: string };
};

export function BlockListPanel() {
  const { profile } = useAuth();
  const [list, setList] = useState<Blocked[]>([]);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    if (!profile) return;
    setLoading(true);
    const { data } = await supabase.from('user_blocks')
      .select('id, blocked_id, reason, created_at')
      .eq('blocker_id', profile.id)
      .order('created_at', { ascending: false });
    const blocks = (data ?? []) as Blocked[];
    if (blocks.length) {
      const ids = blocks.map((b) => b.blocked_id);
      const { data: ps } = await supabase.from('profiles').select('id, display_name, mxit_id').in('id', ids);
      const map = new Map((ps ?? []).map((p) => [p.id, p]));
      blocks.forEach((b) => { b.other = map.get(b.blocked_id) as any; });
    }
    setList(blocks);
    setLoading(false);
  };

  useEffect(() => { void load(); }, [profile?.id]);

  const unblock = async (id: string) => {
    sfx.tap();
    const { error } = await supabase.from('user_blocks').delete().eq('id', id);
    if (error) return toast.error(error.message);
    toast.success('Unblocked');
    void load();
  };

  return (
    <section className="bg-white/8 border border-white/15 rounded-md p-3 space-y-2">
      <div className="font-medium text-[12px] uppercase opacity-80 flex items-center gap-2">
        <Shield className="w-3.5 h-3.5" /> Blocked users
      </div>
      {loading ? (
        <div className="text-[12px] text-white/60">Loading…</div>
      ) : list.length === 0 ? (
        <div className="text-[12px] text-white/60">You haven't blocked anyone.</div>
      ) : (
        <ul className="space-y-1">
          {list.map((b) => (
            <li key={b.id} className="flex items-center gap-2 px-2 py-1.5 rounded bg-white/5">
              <div className="flex-1 min-w-0">
                <div className="text-[13px] truncate">{b.other?.display_name ?? '…'}</div>
                <div className="text-[10px] text-white/50 truncate">@{b.other?.mxit_id ?? ''} {b.reason ? `· ${b.reason}` : ''}</div>
              </div>
              <button onClick={() => unblock(b.id)} className="text-[11px] px-2 py-1 rounded bg-white/10 hover:bg-white/20 flex items-center gap-1">
                <X className="w-3 h-3" /> Unblock
              </button>
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
