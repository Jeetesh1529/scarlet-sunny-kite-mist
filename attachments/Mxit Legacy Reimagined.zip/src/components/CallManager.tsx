/**
 * Global voice/video call manager.
 * - Listens for incoming calls (callee_id = me) via realtime.
 * - Renders ringing UI + active call overlay with WebRTC streams.
 * - Exposes window.startCall(targetId, kind) for other components.
 */
import { useEffect, useRef, useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { PixelAvatar } from './PixelAvatar';
import { Phone, PhoneOff, Video as VideoIcon, Mic, MicOff, VideoOff } from 'lucide-react';
import { sfx } from '@/lib/sfx';
import { toast } from 'sonner';

type Call = {
  id: string;
  caller_id: string;
  callee_id: string;
  kind: 'voice' | 'video';
  status: 'ringing' | 'accepted' | 'declined' | 'ended' | 'missed';
  offer: any;
  answer: any;
  caller_ice: any[];
  callee_ice: any[];
};

type Peer = { display_name: string; avatar_seed: string | null; avatar_url: string | null };

const ICE_CONFIG: RTCConfiguration = {
  iceServers: [{ urls: ['stun:stun.l.google.com:19302', 'stun:stun1.l.google.com:19302'] }],
};

let manager: { start: (target: string, kind: 'voice' | 'video') => void } | null = null;

export function startCall(targetId: string, kind: 'voice' | 'video' = 'voice') {
  manager?.start(targetId, kind);
}

export function CallManager() {
  const { profile } = useAuth();
  const [call, setCall] = useState<Call | null>(null);
  const [peer, setPeer] = useState<Peer | null>(null);
  const [phase, setPhase] = useState<'idle' | 'ringing-out' | 'ringing-in' | 'active'>('idle');
  const [muted, setMuted] = useState(false);
  const [camOff, setCamOff] = useState(false);
  const pcRef = useRef<RTCPeerConnection | null>(null);
  const localStreamRef = useRef<MediaStream | null>(null);
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideoRef = useRef<HTMLVideoElement>(null);
  const ringRef = useRef<number | null>(null);
  const isCallerRef = useRef(false);

  const cleanup = useCallback(() => {
    pcRef.current?.close(); pcRef.current = null;
    localStreamRef.current?.getTracks().forEach((t) => t.stop());
    localStreamRef.current = null;
    if (ringRef.current) { clearInterval(ringRef.current); ringRef.current = null; }
    setCall(null); setPeer(null); setPhase('idle'); setMuted(false); setCamOff(false);
  }, []);

  const endCall = useCallback(async (status: 'ended' | 'declined' | 'missed' = 'ended') => {
    if (call) {
      await supabase.from('calls').update({ status, ended_at: new Date().toISOString() }).eq('id', call.id);
    }
    cleanup();
  }, [call, cleanup]);

  // Build RTCPeerConnection wired to push ICE to DB
  const buildPC = useCallback((callId: string, isCaller: boolean) => {
    const pc = new RTCPeerConnection(ICE_CONFIG);
    pc.onicecandidate = async (e) => {
      if (!e.candidate) return;
      const col = isCaller ? 'caller_ice' : 'callee_ice';
      const { data } = await supabase.from('calls').select(col).eq('id', callId).maybeSingle();
      const arr = ((data as any)?.[col] ?? []) as any[];
      await supabase.from("calls").update({ [col]: [...arr, e.candidate.toJSON()] } as any).eq("id", callId);
    };
    pc.ontrack = (e) => {
      const [stream] = e.streams;
      if (remoteVideoRef.current) remoteVideoRef.current.srcObject = stream;
    };
    return pc;
  }, []);

  // Outgoing call
  const start = useCallback(async (targetId: string, kind: 'voice' | 'video') => {
    if (!profile) return;
    if (phase !== 'idle') { toast.error('Already in a call'); return; }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: kind === 'video' });
      localStreamRef.current = stream;
      const { data: peerProf } = await supabase.from('profiles').select('display_name, avatar_seed, avatar_url').eq('id', targetId).maybeSingle();
      setPeer(peerProf as Peer);
      const { data: row, error } = await supabase.from('calls').insert({ caller_id: profile.id, callee_id: targetId, kind, status: 'ringing' }).select().single();
      if (error || !row) throw error;
      isCallerRef.current = true;
      setCall(row as Call);
      setPhase('ringing-out');
      const pc = buildPC(row.id, true);
      pcRef.current = pc;
      stream.getTracks().forEach((t) => pc.addTrack(t, stream));
      const offer = await pc.createOffer();
      await pc.setLocalDescription(offer);
      await supabase.from("calls").update({ offer: offer as any }).eq("id", row.id);
      // ringback
      ringRef.current = window.setInterval(() => sfx.tap(), 1500) as any;
      // auto-miss after 35s
      setTimeout(() => { void supabase.from("calls").select("status").eq("id", row.id).maybeSingle().then(({ data }) => { if ((data as any)?.status === "ringing") endCall("missed"); }); }, 35000);
    } catch (e: any) {
      toast.error('Call failed: ' + (e?.message ?? 'mic/cam blocked'));
      cleanup();
    }
  }, [profile, phase, buildPC, cleanup, call?.id, endCall]);

  useEffect(() => { manager = { start }; return () => { manager = null; }; }, [start]);

  useEffect(() => {
    if (localStreamRef.current && localVideoRef.current) {
      localVideoRef.current.srcObject = localStreamRef.current;
    }
  }, [phase, call?.kind]);

  // Incoming-call subscription
  useEffect(() => {
    if (!profile) return;
    const ch = supabase
      .channel('calls-' + profile.id)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'calls', filter: `callee_id=eq.${profile.id}` }, async ({ new: row }) => {
        if (phase !== 'idle') return;
        const c = row as Call;
        const { data: peerProf } = await supabase.from('profiles').select('display_name, avatar_seed, avatar_url').eq('id', c.caller_id).maybeSingle();
        setPeer(peerProf as Peer); setCall(c); setPhase('ringing-in');
        isCallerRef.current = false;
        ringRef.current = window.setInterval(() => sfx.tap(), 900) as any;
        setTimeout(() => { void supabase.from("calls").select("status").eq("id", c.id).maybeSingle().then(({ data }) => { if ((data as any)?.status === "ringing") endCall("missed"); }); }, 35000);
      })
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [profile?.id, phase, endCall]);

  // Subscribe to updates on the active call
  useEffect(() => {
    if (!call) return;
    const ch = supabase
      .channel('call-' + call.id)
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'calls', filter: `id=eq.${call.id}` }, async ({ new: row }) => {
        const c = row as Call;
        const prev = call;
        setCall(c);
        // Caller: receive answer
        if (isCallerRef.current && c.answer && pcRef.current && !pcRef.current.currentRemoteDescription) {
          await pcRef.current.setRemoteDescription(new RTCSessionDescription(c.answer));
        }
        // Both: drain new ICE from the other side
        const pc = pcRef.current;
        if (pc) {
          const otherIceCol = isCallerRef.current ? 'callee_ice' : 'caller_ice';
          const prevArr = ((prev as any)?.[otherIceCol] ?? []) as any[];
          const newArr = ((c as any)?.[otherIceCol] ?? []) as any[];
          for (let i = prevArr.length; i < newArr.length; i++) {
            try { await pc.addIceCandidate(new RTCIceCandidate(newArr[i])); } catch { /* ignore */ }
          }
        }
        if (c.status === 'accepted' && phase !== 'active') {
          if (ringRef.current) { clearInterval(ringRef.current); ringRef.current = null; }
          setPhase('active');
        }
        if (c.status === 'declined' || c.status === 'ended' || c.status === 'missed') {
          if (c.status === 'declined') toast('Call declined');
          if (c.status === 'missed') toast('Missed call');
          cleanup();
        }
      })
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [call?.id, phase, cleanup]);

  // Accept incoming
  const accept = async () => {
    if (!call) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: call.kind === 'video' });
      localStreamRef.current = stream;
      const pc = buildPC(call.id, false);
      pcRef.current = pc;
      stream.getTracks().forEach((t) => pc.addTrack(t, stream));
      await pc.setRemoteDescription(new RTCSessionDescription(call.offer));
      // Drain any caller ICE already stored
      for (const c of (call.caller_ice ?? [])) {
        try { await pc.addIceCandidate(new RTCIceCandidate(c)); } catch { /* ignore */ }
      }
      const answer = await pc.createAnswer();
      await pc.setLocalDescription(answer);
      await supabase.from("calls").update({ answer: answer as any, status: "accepted" }).eq("id", call.id);
      if (ringRef.current) { clearInterval(ringRef.current); ringRef.current = null; }
      setPhase('active');
    } catch (e: any) {
      toast.error('Mic/cam denied');
      endCall('declined');
    }
  };

  const toggleMute = () => {
    const s = localStreamRef.current; if (!s) return;
    s.getAudioTracks().forEach((t) => (t.enabled = !t.enabled));
    setMuted((m) => !m);
  };
  const toggleCam = () => {
    const s = localStreamRef.current; if (!s) return;
    s.getVideoTracks().forEach((t) => (t.enabled = !t.enabled));
    setCamOff((m) => !m);
  };

  if (phase === 'idle' || !call || !peer) return null;

  const isVideo = call.kind === 'video';

  return (
    <div className="fixed inset-0 z-[100] bg-black/95 text-white flex flex-col items-center justify-between p-6 backdrop-blur-md animate-fade-in">
      <div className="text-center mt-6">
        <div className="text-[11px] uppercase tracking-widest text-white/60 mb-3">
          {phase === 'ringing-in' ? 'Incoming ' + (isVideo ? 'video call' : 'voice call')
            : phase === 'ringing-out' ? 'Calling…'
            : (isVideo ? 'Video call' : 'Voice call')}
        </div>
        {!isVideo || phase !== 'active' ? (
          <>
            <div className="mx-auto w-32 h-32 rounded-full overflow-hidden ring-4 ring-emerald-500/40 animate-pulse">
              <PixelAvatar seed={peer.avatar_seed} url={peer.avatar_url} size={128} />
            </div>
            <div className="text-2xl font-semibold mt-4">{peer.display_name}</div>
          </>
        ) : null}
      </div>

      {isVideo && phase === 'active' && (
        <div className="relative w-full flex-1 my-4 rounded-lg overflow-hidden bg-black">
          <video ref={remoteVideoRef} autoPlay playsInline className="absolute inset-0 w-full h-full object-cover" />
          <video ref={localVideoRef} autoPlay playsInline muted className="absolute bottom-3 right-3 w-28 h-40 object-cover rounded-md border border-white/30 bg-black" />
        </div>
      )}
      {!isVideo && phase === 'active' && (
        <audio ref={remoteVideoRef as any} autoPlay />
      )}

      <div className="flex items-center justify-center gap-4 mb-2">
        {phase === 'ringing-in' && (
          <>
            <button onClick={() => endCall('declined')} className="w-16 h-16 rounded-full bg-rose-600 hover:bg-rose-700 flex items-center justify-center">
              <PhoneOff className="w-7 h-7" />
            </button>
            <button onClick={accept} className="w-16 h-16 rounded-full bg-emerald-500 hover:bg-emerald-600 flex items-center justify-center">
              {isVideo ? <VideoIcon className="w-7 h-7" /> : <Phone className="w-7 h-7" />}
            </button>
          </>
        )}
        {phase === 'ringing-out' && (
          <button onClick={() => endCall('ended')} className="w-16 h-16 rounded-full bg-rose-600 hover:bg-rose-700 flex items-center justify-center">
            <PhoneOff className="w-7 h-7" />
          </button>
        )}
        {phase === 'active' && (
          <>
            <button onClick={toggleMute} className={`w-14 h-14 rounded-full flex items-center justify-center ${muted ? 'bg-amber-500' : 'bg-white/15'}`}>
              {muted ? <MicOff className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
            </button>
            <button onClick={() => endCall('ended')} className="w-16 h-16 rounded-full bg-rose-600 hover:bg-rose-700 flex items-center justify-center">
              <PhoneOff className="w-7 h-7" />
            </button>
            {isVideo && (
              <button onClick={toggleCam} className={`w-14 h-14 rounded-full flex items-center justify-center ${camOff ? 'bg-amber-500' : 'bg-white/15'}`}>
                {camOff ? <VideoOff className="w-6 h-6" /> : <VideoIcon className="w-6 h-6" />}
              </button>
            )}
          </>
        )}
      </div>
    </div>
  );
}
