import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { sfx } from '@/lib/sfx';
import { Flag, ShieldOff, ShieldCheck } from 'lucide-react';

const CATEGORIES = [
  { id: 'spam',     label: 'Spam or scam' },
  { id: 'abuse',    label: 'Harassment / hate' },
  { id: 'sexual',   label: 'Sexual content' },
  { id: 'minor',    label: 'Concern about a minor' },
  { id: 'other',    label: 'Something else' },
];

type Props = {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  targetUserId: string;
  targetName: string;
  messageId?: string;
  /** Called after a successful block so parent can refresh contacts. */
  onBlocked?: () => void;
};

export function ReportBlockDialog({ open, onOpenChange, targetUserId, targetName, messageId, onBlocked }: Props) {
  const { profile } = useAuth();
  const [category, setCategory] = useState<string>('spam');
  const [details, setDetails] = useState('');
  const [busy, setBusy] = useState(false);
  const [alsoBlock, setAlsoBlock] = useState(true);
  const [isBlocked, setIsBlocked] = useState(false);

  const close = () => { onOpenChange(false); setDetails(''); setCategory('spam'); setAlsoBlock(true); };

  const submitReport = async () => {
    if (!profile) return;
    setBusy(true);
    try {
      const { error } = await supabase.from('user_reports').insert({
        reporter_id: profile.id,
        reported_user_id: targetUserId,
        message_id: messageId ?? null,
        category,
        details: details.trim() || null,
      });
      if (error) throw error;
      if (alsoBlock) {
        await supabase.from('user_blocks').insert({
          blocker_id: profile.id, blocked_id: targetUserId, reason: category,
        });
        onBlocked?.();
      }
      sfx.tap();
      toast.success('Report submitted. Our team will review it.');
      close();
    } catch (e: any) {
      sfx.error();
      toast.error(e.message || 'Could not submit report');
    } finally { setBusy(false); }
  };

  const blockOnly = async () => {
    if (!profile) return;
    setBusy(true);
    try {
      const { error } = await supabase.from('user_blocks').insert({
        blocker_id: profile.id, blocked_id: targetUserId, reason: 'user_blocked',
      });
      if (error && error.code !== '23505') throw error;
      sfx.tap();
      setIsBlocked(true);
      onBlocked?.();
      toast.success(`${targetName} blocked.`);
      close();
    } catch (e: any) {
      sfx.error();
      toast.error(e.message || 'Could not block user');
    } finally { setBusy(false); }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-sm">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 font-pixel text-xs">
            <Flag className="w-4 h-4 text-destructive" /> Report or block {targetName}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-3">
          <div>
            <Label className="text-xs">Reason</Label>
            <div className="grid grid-cols-1 gap-1 mt-1">
              {CATEGORIES.map((c) => (
                <button
                  key={c.id}
                  onClick={() => { sfx.tap(); setCategory(c.id); }}
                  className={`text-left text-sm px-3 py-2 rounded-md border ${
                    category === c.id ? 'bg-mxit-primary text-white border-mxit-primary' : 'bg-secondary border-border'
                  }`}
                >
                  {c.label}
                </button>
              ))}
            </div>
          </div>

          <div>
            <Label htmlFor="rdet" className="text-xs">More details (optional)</Label>
            <Textarea
              id="rdet" rows={3} maxLength={500}
              value={details} onChange={(e) => setDetails(e.target.value)}
              placeholder="What happened?"
            />
          </div>

          <label className="flex items-center gap-2 text-sm">
            <input
              type="checkbox"
              checked={alsoBlock}
              onChange={(e) => setAlsoBlock(e.target.checked)}
              className="w-4 h-4 accent-mxit-primary"
            />
            Also block {targetName} (you won't see their messages)
          </label>

          <div className="flex flex-col gap-2 pt-1">
            <Button onClick={submitReport} disabled={busy} className="w-full">
              <Flag className="w-4 h-4 mr-2" /> Submit report
            </Button>
            <Button onClick={blockOnly} disabled={busy || isBlocked} variant="secondary" className="w-full">
              <ShieldOff className="w-4 h-4 mr-2" /> Just block, don't report
            </Button>
            <Button onClick={close} disabled={busy} variant="ghost" className="w-full">
              Cancel
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

/** Small helper to unblock a previously blocked user. */
export async function unblockUser(blockerId: string, blockedId: string) {
  const { error } = await supabase
    .from('user_blocks')
    .delete()
    .eq('blocker_id', blockerId)
    .eq('blocked_id', blockedId);
  if (error) { sfx.error(); toast.error(error.message); return false; }
  toast.success('User unblocked');
  return true;
}
