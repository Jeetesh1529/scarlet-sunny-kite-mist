import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { sfx } from '@/lib/sfx';

const STORAGE_KEY = 'mxit:onboarding-seen-v1';

type Step = {
  title: string;
  body: string;
  /** Roughly where on the bottom softkey bar to point. */
  pointer: 'menu' | 'status' | 'search' | 'chat' | 'none';
};

const STEPS: Step[] = [
  {
    title: 'Welcome to Mxit 👋',
    body: "You're back. Quick 30-second tour of the bottom bar, then you're free.",
    pointer: 'none',
  },
  {
    title: 'Menu',
    body: 'Tap Menu to add contacts, set your mood, manage groups, change settings, or log out.',
    pointer: 'menu',
  },
  {
    title: 'Status',
    body: 'Post a status update — text, photo or vibe — for your friends to see.',
    pointer: 'status',
  },
  {
    title: 'Search 🔍',
    body: 'Find anything: contacts, chat rooms, services, games. Or press Ctrl+K on desktop.',
    pointer: 'search',
  },
  {
    title: 'Chat',
    body: 'Jump into your latest conversations. Long-press a contact to move them into a custom group.',
    pointer: 'chat',
  },
];

export function OnboardingTour() {
  const { user, profile } = useAuth();
  const [step, setStep] = useState(0);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    if (!user || !profile) return;
    let seen = false;
    try { seen = localStorage.getItem(STORAGE_KEY) === '1'; } catch { /* ignore */ }
    if (!seen) setOpen(true);
  }, [user, profile]);

  if (!open) return null;

  const s = STEPS[step];
  const isLast = step === STEPS.length - 1;

  const close = () => {
    try { localStorage.setItem(STORAGE_KEY, '1'); } catch { /* ignore */ }
    setOpen(false);
  };

  const next = () => {
    sfx.tap();
    if (isLast) close();
    else setStep((n) => n + 1);
  };

  // Pointer positions roughly match the 4-button softkey bar layout
  // (Menu | Status | 🔍 | Chat)
  const pointerLeft: Record<Step['pointer'], string> = {
    menu: '12%',
    status: '38%',
    search: '58%',
    chat: '82%',
    none: '50%',
  };

  return (
    <div className="fixed inset-0 z-[80] flex items-end justify-center bg-black/55 backdrop-blur-sm animate-fade-in">
      {/* Pointer arrow above the softkey bar */}
      {s.pointer !== 'none' && (
        <div
          className="absolute bottom-12 transition-all duration-300 ease-out"
          style={{ left: pointerLeft[s.pointer], transform: 'translateX(-50%)' }}
        >
          <div className="w-3 h-3 bg-mxit-primary rotate-45 mxit-shadow-pop animate-bounce" />
        </div>
      )}

      <div className="m-4 mb-20 w-full max-w-[400px] bg-card rounded-lg p-4 mxit-shadow-pop border border-mxit-primary/40 animate-fade-up">
        <div className="flex items-center justify-between mb-2">
          <div className="font-pixel text-[10px] text-mxit-primary">
            STEP {step + 1} / {STEPS.length}
          </div>
          <button
            onClick={close}
            className="text-[11px] text-white/60 hover:text-white px-2 py-0.5"
          >
            skip
          </button>
        </div>
        <div className="font-semibold text-[15px] mb-1">{s.title}</div>
        <div className="text-[12px] text-white/80 leading-snug mb-3">{s.body}</div>
        <div className="flex items-center justify-between gap-2">
          <div className="flex gap-1">
            {STEPS.map((_, i) => (
              <span
                key={i}
                className={`w-1.5 h-1.5 rounded-full ${i === step ? 'bg-mxit-primary' : 'bg-white/25'}`}
              />
            ))}
          </div>
          <div className="flex items-center gap-2">
            {step > 0 && (
              <button
                onClick={() => { sfx.tap(); setStep((n) => n - 1); }}
                className="px-3 py-1.5 rounded text-[12px] text-white/80 hover:bg-white/10"
              >
                Back
              </button>
            )}
            <button
              onClick={next}
              className="px-3 py-1.5 rounded bg-mxit-primary hover:bg-mxit-primary/90 text-white text-[12px] font-semibold mxit-shadow-pop"
            >
              {isLast ? 'Got it' : 'Next'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
