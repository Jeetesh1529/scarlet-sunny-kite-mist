import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { sfx } from '@/lib/sfx';
import { Smile, Reply, Forward, Trash2, X, Coins, Languages } from 'lucide-react';
import { toast } from 'sonner';

const QUICK = ['👍', '❤️', '😂', '😮', '😢', '🔥'];

export type Reaction = { id: string; message_id: string; user_id: string; emoji: string };

export function ReactionRow({ reactions, onToggle }: { reactions: Reaction[]; onToggle: (emoji: string) => void }) {
  const { profile } = useAuth();
  if (!reactions.length) return null;
  const grouped = reactions.reduce<Record<string, { count: number; mine: boolean }>>((acc, r) => {
    if (!acc[r.emoji]) acc[r.emoji] = { count: 0, mine: false };
    acc[r.emoji].count++;
    if (r.user_id === profile?.id) acc[r.emoji].mine = true;
    return acc;
  }, {});
  return (
    <div className="flex flex-wrap gap-1 mt-0.5">
      {Object.entries(grouped).map(([emoji, { count, mine }]) => (
        <button
          key={emoji}
          onClick={(e) => { e.stopPropagation(); onToggle(emoji); }}
          className={`text-[11px] px-1.5 py-0.5 rounded-full border ${mine ? 'bg-mxit-primary/20 border-mxit-primary' : 'bg-black/10 border-black/20'}`}
        >
          {emoji} {count}
        </button>
      ))}
    </div>
  );
}

const TRANSLATE_LANGS = ['English', 'Afrikaans', 'Zulu', 'Xhosa', 'Spanish', 'French', 'Portuguese'];

export function MessageActionSheet({
  open, onClose, isMe, onReact, onReply, onForward, onDelete, onTip, onTranslate,
}: {
  open: boolean;
  onClose: () => void;
  isMe: boolean;
  onReact: (emoji: string) => void;
  onReply: () => void;
  onForward: () => void;
  onDelete?: () => void;
  onTip?: (amount: number) => void;
  onTranslate?: (target: string) => void;
}) {
  const [pickLang, setPickLang] = useState(false);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end" onClick={onClose}>
      <div className="absolute inset-0 bg-black/40" />
      <div onClick={(e) => e.stopPropagation()} className="relative w-full bg-card rounded-t-2xl p-4 mxit-shadow-pop animate-fade-up" style={{ paddingBottom: 'calc(env(safe-area-inset-bottom) + 1rem)' }}>
        <div className="flex justify-between items-center mb-3">
          <span className="font-pixel text-[11px] text-mxit-primary">MESSAGE</span>
          <button onClick={onClose}><X className="w-4 h-4" /></button>
        </div>
        <div className="flex justify-around mb-4">
          {QUICK.map((e) => (
            <button
              key={e}
              onClick={() => { sfx.tap(); onReact(e); onClose(); }}
              className="text-2xl tap-scale p-1"
            >
              {e}
            </button>
          ))}
        </div>
        {!isMe && onTip && (
          <div className="mb-3">
            <div className="text-[11px] text-muted-foreground mb-1 flex items-center gap-1"><Coins className="w-3 h-3 text-amber-500" /> Tip Moola</div>
            <div className="flex gap-2">
              {[5, 10, 25, 50].map((n) => (
                <button key={n} onClick={() => { sfx.tap(); onTip(n); onClose(); }} className="flex-1 px-2 py-1.5 rounded bg-amber-100 text-amber-900 text-[12px] font-semibold hover:bg-amber-200">
                  {n}M
                </button>
              ))}
            </div>
          </div>
        )}
        <div className="space-y-1">
          <button onClick={() => { sfx.tap(); onReply(); onClose(); }} className="w-full flex items-center gap-3 px-3 py-2 rounded hover:bg-secondary text-left">
            <Reply className="w-4 h-4" /> Reply
          </button>
          <button onClick={() => { sfx.tap(); onForward(); onClose(); }} className="w-full flex items-center gap-3 px-3 py-2 rounded hover:bg-secondary text-left">
            <Forward className="w-4 h-4" /> Forward
          </button>
          {onTranslate && (
            <div>
              <button onClick={() => { sfx.tap(); setPickLang((v) => !v); }} className="w-full flex items-center gap-3 px-3 py-2 rounded hover:bg-secondary text-left">
                <Languages className="w-4 h-4" /> Translate
              </button>
              {pickLang && (
                <div className="grid grid-cols-3 gap-1 mt-1 px-1">
                  {TRANSLATE_LANGS.map((l) => (
                    <button
                      key={l}
                      onClick={() => { sfx.tap(); onTranslate(l); onClose(); }}
                      className="text-[11px] px-2 py-1.5 rounded bg-secondary hover:bg-secondary/70"
                    >{l}</button>
                  ))}
                </div>
              )}
            </div>
          )}
          {isMe && onDelete && (
            <button onClick={() => { sfx.tap(); onDelete(); onClose(); }} className="w-full flex items-center gap-3 px-3 py-2 rounded hover:bg-secondary text-left text-destructive">
              <Trash2 className="w-4 h-4" /> Delete
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

/** Hook: load + realtime reactions for a set of message IDs. */
export function useReactions(messageIds: string[]) {
  const [reactions, setReactions] = useState<Reaction[]>([]);

  useEffect(() => {
    if (!messageIds.length) { setReactions([]); return; }
    let cancelled = false;
    (async () => {
      const { data } = await supabase.from('message_reactions')
        .select('id, message_id, user_id, emoji')
        .in('message_id', messageIds);
      if (!cancelled && data) setReactions(data as Reaction[]);
    })();
    const ch = supabase
      .channel(`reactions-${messageIds[0]}-${messageIds.length}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'message_reactions' }, (payload) => {
        const r = payload.new as Reaction;
        if (messageIds.includes(r.message_id)) setReactions((cur) => cur.some((x) => x.id === r.id) ? cur : [...cur, r]);
      })
      .on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'message_reactions' }, (payload) => {
        const r = payload.old as Reaction;
        setReactions((cur) => cur.filter((x) => x.id !== r.id));
      })
      .subscribe();
    return () => { cancelled = true; supabase.removeChannel(ch); };
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [messageIds.join(',')]);

  return reactions;
}

export async function toggleReaction(messageId: string, emoji: string, userId: string, current: Reaction[]) {
  const mine = current.find((r) => r.message_id === messageId && r.emoji === emoji && r.user_id === userId);
  if (mine) {
    await supabase.from('message_reactions').delete().eq('id', mine.id);
  } else {
    await supabase.from('message_reactions').insert({ message_id: messageId, emoji, user_id: userId });
  }
}

export function ForwardDialog({
  open, onClose, onPick,
}: { open: boolean; onClose: () => void; onPick: (conversationId: string, displayName: string) => void }) {
  const { profile } = useAuth();
  const [convs, setConvs] = useState<Array<{ id: string; other_id: string; display_name: string }>>([]);

  useEffect(() => {
    if (!open || !profile) return;
    (async () => {
      const { data: cs } = await supabase
        .from('conversations')
        .select('id, user_a, user_b')
        .or(`user_a.eq.${profile.id},user_b.eq.${profile.id}`);
      if (!cs) return;
      const otherIds = cs.map((c) => c.user_a === profile.id ? c.user_b : c.user_a);
      const { data: profs } = await supabase.from('profiles').select('id, display_name').in('id', otherIds);
      const map = new Map((profs ?? []).map((p) => [p.id, p.display_name as string]));
      setConvs(cs.map((c) => {
        const other = c.user_a === profile.id ? c.user_b : c.user_a;
        return { id: c.id, other_id: other, display_name: map.get(other) ?? '…' };
      }));
    })();
  }, [open, profile]);

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4" onClick={onClose}>
      <div className="absolute inset-0 bg-black/50" />
      <div onClick={(e) => e.stopPropagation()} className="relative w-full max-w-sm bg-card rounded-2xl p-4 mxit-shadow-pop max-h-[70vh] flex flex-col">
        <div className="flex justify-between items-center mb-3">
          <span className="font-pixel text-[11px] text-mxit-primary">FORWARD TO</span>
          <button onClick={onClose}><X className="w-4 h-4" /></button>
        </div>
        <div className="flex-1 overflow-y-auto space-y-1">
          {convs.length === 0 && <div className="text-sm text-muted-foreground text-center py-4">No contacts to forward to</div>}
          {convs.map((c) => (
            <button key={c.id} onClick={() => { onPick(c.id, c.display_name); onClose(); }} className="w-full text-left px-3 py-2 rounded hover:bg-secondary">
              {c.display_name}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
