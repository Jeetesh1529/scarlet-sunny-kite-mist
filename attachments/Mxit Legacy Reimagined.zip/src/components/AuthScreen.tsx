import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { lovable } from '@/integrations/lovable';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import logo from '@/assets/mxit-legacy-watermark.png';
import { sfx } from '@/lib/sfx';
import { PixelAvatar } from '@/components/PixelAvatar';
import { AVATAR_SEEDS } from '@/lib/avatars';
import { track } from '@/lib/analytics';

export function AuthScreen({ needsProfile = false }: { needsProfile?: boolean }) {
  const [mode, setMode] = useState<'login' | 'signup'>(needsProfile ? 'signup' : 'login');
  const [step, setStep] = useState<'auth' | 'profile'>(needsProfile ? 'profile' : 'auth');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [mxitId, setMxitId] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [mood, setMood] = useState("Hey there! I'm on Mxit.");
  const [avatarSeed, setAvatarSeed] = useState(AVATAR_SEEDS[0]);
  const [age, setAge] = useState('');
  const [gender, setGender] = useState('');
  const [busy, setBusy] = useState(false);
  const [oauthBusy, setOauthBusy] = useState<'google' | 'apple' | null>(null);

  const oauth = async (provider: 'google' | 'apple') => {
    sfx.tap();
    setOauthBusy(provider);
    void track('signup_started', { method: provider });
    try {
      const result = await lovable.auth.signInWithOAuth(provider, {
        redirect_uri: window.location.origin,
      });
      if (result.error) throw result.error;
      // If redirected, browser navigates away — nothing else to do.
    } catch (e: any) {
      sfx.error();
      toast.error(e?.message ?? `${provider} sign-in failed`);
      setOauthBusy(null);
    }
  };

  // Prefill from OAuth user metadata when finishing profile after Google/Apple sign-in
  useEffect(() => {
    if (!needsProfile) return;
    supabase.auth.getUser().then(({ data: { user } }) => {
      if (!user) return;
      const m = (user.user_metadata ?? {}) as Record<string, any>;
      const name = m.full_name || m.name || (user.email ? user.email.split('@')[0] : '');
      if (name && !displayName) setDisplayName(name);
      const guess =
        (user.email ? user.email.split('@')[0] : 'user')
          .toLowerCase()
          .replace(/[^a-z0-9_]/g, '_')
          .slice(0, 20);
      if (guess && !mxitId) setMxitId(guess);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [needsProfile]);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    sfx.tap();
    setBusy(true);
    try {
      // OAuth user finishing profile — no auth.signUp, just insert profile
      if (needsProfile) {
        const { data: { user } } = await supabase.auth.getUser();
        if (!user) throw new Error('Not signed in');
        const handle = mxitId.trim().toLowerCase();
        if (!/^[a-z0-9_]{3,20}$/.test(handle))
          throw new Error('Mxit ID: 3–20 chars, lowercase letters, numbers, underscores.');
        if (!displayName.trim()) throw new Error('Pick a display name');

        const { error: pErr } = await supabase.from('profiles').insert({
          id: user.id,
          mxit_id: handle,
          display_name: displayName.trim(),
          mood: mood.trim() || 'Hey there!',
          avatar_seed: avatarSeed,
          age: age ? parseInt(age) : null,
          gender: gender || null,
        });
        if (pErr) {
          if (pErr.message.includes('duplicate') || pErr.code === '23505')
            throw new Error('That Mxit ID is taken — pick another');
          throw pErr;
        }
        await supabase
          .from('moola_transactions')
          .insert({ user_id: user.id, amount: 100, reason: 'Welcome bonus' });
        void track('signup_completed', { method: 'oauth', user_id: user.id });
        toast.success(`Welcome to Mxit, ${displayName}! 100 Moola added.`);
        // AuthContext will pick up the new profile via refresh — force a reload of profile
        window.location.reload();
        return;
      }

      if (mode === 'login') {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) throw error;
        toast.success('Welcome back!');
      } else {
        if (step === 'auth') {
          if (password.length < 6) throw new Error('Password must be at least 6 characters');
          void track('signup_started', { method: 'email' });
          setStep('profile');
          setBusy(false);
          return;
        }
        const handle = mxitId.trim().toLowerCase();
        if (!/^[a-z0-9_]{3,20}$/.test(handle))
          throw new Error('Mxit ID: 3–20 chars, lowercase letters, numbers, underscores.');
        if (!displayName.trim()) throw new Error('Pick a display name');

        const redirectUrl = `${window.location.origin}/`;
        const { data, error } = await supabase.auth.signUp({
          email,
          password,
          options: {
            emailRedirectTo: redirectUrl,
            data: { mxit_id: handle, display_name: displayName },
          },
        });
        if (error) throw error;
        if (!data.user) throw new Error('Sign-up failed');

        const { error: pErr } = await supabase.from('profiles').insert({
          id: data.user.id,
          mxit_id: handle,
          display_name: displayName.trim(),
          mood: mood.trim() || 'Hey there!',
          avatar_seed: avatarSeed,
          age: age ? parseInt(age) : null,
          gender: gender || null,
        });
        if (pErr) {
          if (pErr.message.includes('duplicate') || pErr.code === '23505')
            throw new Error('That Mxit ID is taken — pick another');
          throw pErr;
        }
        await supabase
          .from('moola_transactions')
          .insert({ user_id: data.user.id, amount: 100, reason: 'Welcome bonus' });
        void track('signup_completed', { method: 'email', user_id: data.user.id });
        toast.success(`Welcome to Mxit, ${displayName}! 100 Moola added.`);
      }
    } catch (err: any) {
      sfx.error();
      toast.error(err.message || 'Something went wrong');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex-1 relative overflow-hidden bg-black text-white">
      {/* Cinematic backdrop */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_70%_60%_at_50%_30%,hsl(0_0%_18%)_0%,hsl(0_0%_5%)_60%,#000_100%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_75%_22%,hsl(20_90%_75%/0.25),transparent_22%)]" />

      <div className="relative h-full flex flex-col safe-top">
        {/* Header / logo */}
        <div className="px-4 pt-4 pb-2 flex flex-col items-center">
          <img
            src={logo}
            alt="mxit — The Legacy"
            className="w-[88%] max-w-[420px] h-auto mix-blend-screen"
            style={{ filter: 'drop-shadow(0 0 20px hsl(0 0% 100% / 0.12))' }}
          />
        </div>

        <form
          onSubmit={handleAuth}
          className="flex-1 px-6 pb-6 space-y-3 overflow-auto no-scrollbar"
        >
          {step === 'auth' && (
            <>
              {/* Mode toggle */}
              <div className="flex bg-white/5 border border-white/10 rounded-lg p-1">
                {(['login', 'signup'] as const).map((m) => (
                  <button
                    type="button"
                    key={m}
                    onClick={() => {
                      setMode(m);
                      setStep('auth');
                      sfx.tap();
                    }}
                    className={`flex-1 py-2 rounded-md font-pixel text-[10px] transition ${
                      mode === m
                        ? 'bg-white text-black shadow'
                        : 'text-white/70 hover:text-white'
                    }`}
                  >
                    {m === 'login' ? 'sign in' : 'sign up'}
                  </button>
                ))}
              </div>

              {/* Social sign-in */}
              <div className="space-y-2 pt-1">
                <button
                  type="button"
                  disabled={oauthBusy !== null}
                  onClick={() => oauth('google')}
                  className="w-full h-11 rounded-md bg-white text-black font-medium text-sm flex items-center justify-center gap-2.5 hover:bg-white/90 active:scale-[0.98] transition disabled:opacity-60"
                >
                  <GoogleGlyph />
                  {oauthBusy === 'google'
                    ? 'Redirecting…'
                    : `Continue with Google`}
                </button>
                <button
                  type="button"
                  disabled={oauthBusy !== null}
                  onClick={() => oauth('apple')}
                  className="w-full h-11 rounded-md bg-black border border-white/30 text-white font-medium text-sm flex items-center justify-center gap-2.5 hover:bg-white/10 active:scale-[0.98] transition disabled:opacity-60"
                >
                  <AppleGlyph />
                  {oauthBusy === 'apple'
                    ? 'Redirecting…'
                    : `Continue with Apple`}
                </button>
              </div>

              {/* Divider */}
              <div className="flex items-center gap-3 py-1">
                <div className="flex-1 h-px bg-white/15" />
                <span className="text-[10px] tracking-[0.3em] text-white/40 uppercase">
                  or use email
                </span>
                <div className="flex-1 h-px bg-white/15" />
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="email" className="text-white/80 text-xs">Email</Label>
                <Input
                  id="email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@example.com"
                  className="bg-white/5 border-white/15 text-white placeholder:text-white/35 h-11"
                />
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="password" className="text-white/80 text-xs">Password</Label>
                <Input
                  id="password"
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••"
                  minLength={6}
                  className="bg-white/5 border-white/15 text-white placeholder:text-white/35 h-11"
                />
                {mode === 'login' && (
                  <button
                    type="button"
                    onClick={async () => {
                      sfx.tap();
                      const target = email.trim();
                      if (!target) { toast.error('Enter your email first, then tap "Forgot password?"'); return; }
                      const { error } = await supabase.auth.resetPasswordForEmail(target, {
                        redirectTo: `${window.location.origin}/reset-password`,
                      });
                      if (error) { sfx.error(); toast.error(error.message); return; }
                      toast.success('Check your email for a reset link.');
                    }}
                    className="text-[11px] text-white/60 hover:text-white underline underline-offset-2"
                  >
                    Forgot password?
                  </button>
                )}
              </div>
            </>
          )}

          {mode === 'signup' && step === 'profile' && (
            <>
              <div className="text-center mb-2">
                <h2 className="font-pixel text-sm text-white">make your profile</h2>
                <p className="text-xs text-white/60 mt-1">
                  This is how others find you on Mxit.
                </p>
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="mxit_id" className="text-white/80 text-xs">Mxit ID</Label>
                <Input
                  id="mxit_id"
                  required
                  value={mxitId}
                  onChange={(e) => setMxitId(e.target.value)}
                  placeholder="cooldude_92"
                  maxLength={20}
                  className="bg-white/5 border-white/15 text-white placeholder:text-white/35"
                />
                <p className="text-[10px] text-white/50">
                  3–20 chars · letters, numbers, underscores
                </p>
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="dname" className="text-white/80 text-xs">Display name</Label>
                <Input
                  id="dname"
                  required
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  placeholder="Cool Dude"
                  maxLength={40}
                  className="bg-white/5 border-white/15 text-white placeholder:text-white/35"
                />
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="mood" className="text-white/80 text-xs">Mood</Label>
                <Input
                  id="mood"
                  value={mood}
                  onChange={(e) => setMood(e.target.value)}
                  maxLength={80}
                  className="bg-white/5 border-white/15 text-white placeholder:text-white/35"
                />
              </div>

              <div className="space-y-2">
                <Label className="text-white/80 text-xs">Pick an avatar</Label>
                <div className="grid grid-cols-5 gap-2">
                  {AVATAR_SEEDS.map((s) => (
                    <button
                      key={s}
                      type="button"
                      onClick={() => {
                        setAvatarSeed(s);
                        sfx.tap();
                      }}
                      className={`p-1 rounded-lg tap-scale ${
                        avatarSeed === s
                          ? 'bg-white/15 ring-1 ring-white'
                          : 'bg-white/5 border border-white/10'
                      }`}
                    >
                      <PixelAvatar seed={s} size={48} />
                    </button>
                  ))}
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div className="space-y-1.5">
                  <Label htmlFor="age" className="text-white/80 text-xs">Age</Label>
                  <Input
                    id="age"
                    type="number"
                    min={13}
                    max={120}
                    value={age}
                    onChange={(e) => setAge(e.target.value)}
                    className="bg-white/5 border-white/15 text-white"
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="gender" className="text-white/80 text-xs">Gender</Label>
                  <select
                    id="gender"
                    value={gender}
                    onChange={(e) => setGender(e.target.value)}
                    className="flex h-10 w-full rounded-md border border-white/15 bg-white/5 text-white px-3 py-2 text-sm"
                  >
                    <option value="" className="bg-black">Prefer not to say</option>
                    <option value="m" className="bg-black">Male</option>
                    <option value="f" className="bg-black">Female</option>
                    <option value="x" className="bg-black">Other</option>
                  </select>
                </div>
              </div>
            </>
          )}

          <Button
            type="submit"
            disabled={busy}
            className="w-full font-pixel text-[11px] h-11 bg-white text-black hover:bg-white/90"
          >
            {busy
              ? '…'
              : mode === 'login'
                ? 'sign in'
                : step === 'auth'
                  ? 'next'
                  : 'create account'}
          </Button>

          {mode === 'signup' && step === 'profile' && (
            <Button
              type="button"
              variant="ghost"
              onClick={() => setStep('auth')}
              className="w-full text-xs text-white/70 hover:text-white hover:bg-white/5"
            >
              back
            </Button>
          )}

          <p className="pt-2 text-center text-[10px] text-white/35 tracking-widest uppercase leading-relaxed">
            original est. 2005 · this is a fan creation
            <br />
            est. 2026 · mxit the legacy
          </p>
          <p className="text-center text-[10px] text-white/40">
            By continuing you agree to our{' '}
            <a href="/legal/terms" className="underline hover:text-white">Terms</a>
            {' '}and{' '}
            <a href="/legal/privacy" className="underline hover:text-white">Privacy Policy</a>.
          </p>
        </form>
      </div>
    </div>
  );
}

function GoogleGlyph() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" aria-hidden>
      <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92a5.06 5.06 0 0 1-2.2 3.32v2.76h3.56c2.08-1.92 3.28-4.74 3.28-8.09Z"/>
      <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.56-2.76c-.99.66-2.25 1.06-3.72 1.06-2.86 0-5.28-1.93-6.15-4.53H2.18v2.84A11 11 0 0 0 12 23Z"/>
      <path fill="#FBBC05" d="M5.85 14.11A6.6 6.6 0 0 1 5.5 12c0-.74.13-1.45.35-2.11V7.05H2.18A11 11 0 0 0 1 12c0 1.77.42 3.45 1.18 4.95l3.67-2.84Z"/>
      <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.05l3.67 2.84C6.72 7.31 9.14 5.38 12 5.38Z"/>
    </svg>
  );
}

function AppleGlyph() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" aria-hidden fill="currentColor">
      <path d="M16.37 12.62c-.02-2.27 1.85-3.36 1.93-3.41-1.05-1.54-2.69-1.75-3.27-1.78-1.39-.14-2.71.81-3.42.81-.71 0-1.79-.79-2.95-.77-1.51.02-2.92.88-3.7 2.23-1.58 2.74-.4 6.79 1.13 9 .76 1.08 1.66 2.3 2.83 2.26 1.14-.05 1.57-.74 2.95-.74 1.38 0 1.76.74 2.96.71 1.22-.02 2-1.1 2.74-2.19.86-1.25 1.22-2.46 1.24-2.52-.03-.01-2.39-.91-2.42-3.6ZM14.1 5.96c.62-.76 1.05-1.81.93-2.86-.9.04-2 .61-2.65 1.36-.58.66-1.1 1.74-.96 2.77 1.01.08 2.05-.51 2.68-1.27Z"/>
    </svg>
  );
}
