import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { PixelAvatar } from '@/components/PixelAvatar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { toast } from 'sonner';
import { sfx, setSoundEnabled } from '@/lib/sfx';
import { AVATAR_SEEDS } from '@/lib/avatars';
import { getMode, setMode, type DisplayMode } from '@/lib/mode';
import { Coins, Volume2, Palette, Save, Eye, EyeOff, ExternalLink, X } from 'lucide-react';

const THEMES = [
  { id: 'classic', name: 'Classic',  swatch: 'bg-[#1E78D6]' },
  { id: 'black',   name: 'Midnight', swatch: 'bg-[#111111]' },
];

export function ProfileTab() {
  const { profile, refreshProfile } = useAuth();
  const navigate = useNavigate();
  const [displayName, setDisplayName] = useState(profile?.display_name ?? '');
  const [mood, setMood] = useState(profile?.mood ?? '');
  const [avatarSeed, setAvatarSeed] = useState(profile?.avatar_seed ?? AVATAR_SEEDS[0]);
  const [tags, setTags] = useState<string[]>((profile as any)?.tags ?? []);
  const [tagInput, setTagInput] = useState('');
  const [birthday, setBirthday] = useState<string>((profile as any)?.birthday ?? '');
  const [displayMode, setDisplayMode] = useState<DisplayMode>(getMode());
  const [busy, setBusy] = useState(false);

  if (!profile) return null;

  const addTag = () => {
    const t = tagInput.trim().toLowerCase().replace(/[^a-z0-9_]/g, '');
    if (!t || tags.includes(t) || tags.length >= 8) { setTagInput(''); return; }
    setTags([...tags, t]);
    setTagInput('');
  };

  const save = async () => {
    setBusy(true);
    const { error } = await supabase.from('profiles').update({
      display_name: displayName.trim() || profile.display_name,
      mood: mood.trim(),
      avatar_seed: avatarSeed,
      tags,
      birthday: birthday || null,
    } as any).eq('id', profile.id);
    setBusy(false);
    if (error) { sfx.error(); toast.error(error.message); return; }
    toast.success('Profile updated!');
    refreshProfile();
  };

  const setTheme = async (t: string) => {
    sfx.tap();
    document.documentElement.setAttribute('data-theme', t);
    await supabase.from('profiles').update({ theme: t }).eq('id', profile.id);
    refreshProfile();
  };

  const toggleSound = async (on: boolean) => {
    setSoundEnabled(on);
    await supabase.from('profiles').update({ sound_enabled: on }).eq('id', profile.id);
    refreshProfile();
    if (on) sfx.tap();
  };

  return (
    <div className="p-3 space-y-4 animate-fade-up">
      <section className="bg-card rounded-lg p-4 mxit-shadow-pop flex items-center gap-3">
        <PixelAvatar seed={profile.avatar_seed} url={profile.avatar_url} size={64} />
        <div className="flex-1 min-w-0">
          <div className="font-pixel text-xs text-mxit-deep">@{profile.mxit_id}</div>
          <div className="font-medium mt-1">{profile.display_name}</div>
          <div className="flex items-center gap-1 mt-1 text-mxit-moola font-pixel text-[10px]">
            <Coins className="w-3.5 h-3.5" /> {profile.moola} Moola
          </div>
        </div>
      </section>

      <button
        onClick={() => navigate(`/u/${profile.mxit_id}`)}
        className="w-full bg-card rounded-lg p-3 mxit-shadow-pop flex items-center justify-between text-sm hover:bg-secondary"
      >
        <span className="font-pixel text-[10px] text-mxit-primary">VIEW MY PUBLIC PROFILE</span>
        <ExternalLink className="w-4 h-4" />
      </button>
      <section className="bg-card rounded-lg p-4 mxit-shadow-pop space-y-3">
        <h3 className="font-pixel text-[10px] text-mxit-primary">EDIT PROFILE</h3>
        <div className="space-y-2"><Label>Display name</Label><Input value={displayName} onChange={(e) => setDisplayName(e.target.value)} /></div>
        <div className="space-y-2"><Label>Mood</Label><Input value={mood} onChange={(e) => setMood(e.target.value)} maxLength={80} /></div>
        <div className="space-y-2">
          <Label>Avatar</Label>
          <div className="grid grid-cols-5 gap-2">
            {AVATAR_SEEDS.map((s) => (
              <button
                key={s}
                onClick={() => { setAvatarSeed(s); sfx.tap(); }}
                className={`p-1 rounded-lg tap-scale ${avatarSeed === s ? 'bg-mxit-primary mxit-shadow-pop' : 'bg-secondary'}`}
              >
                <PixelAvatar seed={s} size={44} />
              </button>
            ))}
          </div>
        </div>
        <div className="space-y-2">
          <Label>Birthday</Label>
          <Input type="date" value={birthday} onChange={(e) => setBirthday(e.target.value)} />
          <p className="text-[10px] text-muted-foreground">Contacts get a 🎂 reminder on your day.</p>
        </div>
        <div className="space-y-2">
          <Label>Tagz (interests)</Label>
          <div className="flex flex-wrap gap-1.5 min-h-[28px]">
            {tags.map((t) => (
              <span key={t} className="inline-flex items-center gap-1 text-xs px-2 py-1 rounded-full bg-mxit-primary/15 text-mxit-primary border border-mxit-primary/30">
                #{t}
                <button onClick={() => setTags(tags.filter((x) => x !== t))} aria-label={`remove ${t}`}><X className="w-3 h-3" /></button>
              </span>
            ))}
          </div>
          <div className="flex gap-2">
            <Input
              value={tagInput}
              onChange={(e) => setTagInput(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addTag(); } }}
              placeholder="music, gaming, soccer…"
              maxLength={20}
              disabled={tags.length >= 8}
            />
            <Button type="button" onClick={addTag} disabled={tags.length >= 8}>add</Button>
          </div>
          <p className="text-[10px] text-muted-foreground">{tags.length}/8 tags · letters, numbers, underscore</p>
        </div>
        <Button onClick={save} disabled={busy} className="w-full font-pixel text-[10px] mxit-shadow-inset">
          <Save className="w-4 h-4 mr-2" /> save
        </Button>
      </section>

      <section className="bg-card rounded-lg p-4 mxit-shadow-pop space-y-3">
        <h3 className="font-pixel text-[10px] text-mxit-primary flex items-center gap-2"><Palette className="w-3.5 h-3.5" /> THEME</h3>
        <div className="grid grid-cols-2 gap-2">
          {THEMES.map((t) => (
            <button
              key={t.id}
              onClick={() => setTheme(t.id)}
              className={`p-2 rounded-lg flex flex-col items-center gap-1 tap-scale ${profile.theme === t.id ? 'ring-2 ring-mxit-primary' : 'bg-secondary'}`}
            >
              <div className={`w-8 h-8 rounded-full ${t.swatch} mxit-shadow-pop`} />
              <div className="text-[10px]">{t.name}</div>
            </button>
          ))}
        </div>
        <div className="pt-2 border-t border-border space-y-2">
          <div className="font-pixel text-[10px] text-mxit-primary">DISPLAY MODE</div>
          <div className="grid grid-cols-2 gap-2">
            {(['normal', 'dark'] as const).map((m) => {
              const active = displayMode === m;
              return (
                <button
                  key={m}
                  onClick={() => { sfx.tap(); setMode(m); setDisplayMode(m); }}
                  className={`p-2 rounded-lg text-[10px] font-pixel tap-scale ${active ? 'ring-2 ring-mxit-primary bg-mxit-primary/10' : 'bg-secondary'}`}
                >
                  {m === 'normal' ? 'NORMAL' : 'DARK'}
                </button>
              );
            })}
          </div>
        </div>
      </section>

      <section className="bg-card rounded-lg p-4 mxit-shadow-pop space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Volume2 className="w-4 h-4 text-mxit-primary" />
            <span className="font-pixel text-[10px]">SOUND</span>
          </div>
          <Switch checked={profile.sound_enabled} onCheckedChange={toggleSound} />
        </div>
        <div className="flex items-center justify-between">
          <div className="flex flex-col">
            <span className="font-pixel text-[10px]">LOW DATA MODE</span>
            <span className="text-[10px] text-muted-foreground">Hide images & uploads — Mxit classic</span>
          </div>
          <Switch
            checked={!!profile.low_data_mode}
            onCheckedChange={async (on) => {
              sfx.tap();
              await supabase.from('profiles').update({ low_data_mode: on }).eq('id', profile.id);
              refreshProfile();
            }}
          />
        </div>
        <div className="flex items-center justify-between">
          <div className="flex flex-col">
            <span className="font-pixel text-[10px] flex items-center gap-1">
              {(profile as any).appear_offline ? <EyeOff className="w-3 h-3" /> : <Eye className="w-3 h-3" />} HIDDEN MODE
            </span>
            <span className="text-[10px] text-muted-foreground">Appear offline to others, still chat normally.</span>
          </div>
          <Switch
            checked={!!(profile as any).appear_offline}
            onCheckedChange={async (on) => {
              sfx.tap();
              await supabase.from('profiles').update({ appear_offline: on } as any).eq('id', profile.id);
              refreshProfile();
            }}
          />
        </div>
      </section>

      <p className="text-center text-[10px] text-muted-foreground py-4">mxit reborn · est. 2005 · since 2026</p>
    </div>
  );
}
