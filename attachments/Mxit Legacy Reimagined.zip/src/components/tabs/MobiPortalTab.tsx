import { useNavigate } from 'react-router-dom';
import { Calculator, Sparkles, Brain, Coins, ShoppingBag, Banknote, Wallet } from 'lucide-react';
import { sfx } from '@/lib/sfx';

type App = {
  id: string;
  name: string;
  icon: any;
  color: string;
  desc: string;
  route?: string;
};

const APPS: App[] = [
  { id: 'joebanker', name: 'Banker Bot', icon: Banknote,    color: 'bg-emerald-600',   desc: 'Top up Moola' },
  { id: 'moola',     name: 'Moola Hub',  icon: Wallet,      color: 'bg-amber-600',     desc: 'Daily spin · send · leaderboard', route: '/moola' },
  { id: 'tradepost', name: 'Tradepost',  icon: ShoppingBag, color: 'bg-amber-500',     desc: 'Skins, emoticards, games' },
  { id: 'drmath',    name: 'Dr Math',    icon: Calculator,  color: 'bg-mxit-primary',  desc: 'Ask any math question' },
  { id: 'horoscope', name: 'Horoscope',  icon: Sparkles,    color: 'bg-purple-500',    desc: 'Your daily fortune' },
  { id: 'trivia',    name: 'Trivit',     icon: Brain,       color: 'bg-mxit-online',   desc: 'Test your knowledge' },
  { id: 'shop',      name: 'Moola Shop', icon: Coins,       color: 'bg-mxit-moola',    desc: 'Quick spend' },
];

export function MobiPortalTab() {
  const navigate = useNavigate();
  return (
    <div className="p-3 animate-fade-up">
      <div className="text-center mb-4 px-2 py-3 bg-card rounded-lg mxit-shadow-pop">
        <div className="font-pixel text-[10px] text-mxit-primary">JOE BANKER</div>
        <div className="text-xs text-muted-foreground mt-1">apps & services</div>
      </div>
      <div className="grid grid-cols-2 gap-3">
        {APPS.map((a) => {
          const Icon = a.icon;
          return (
            <button
              key={a.id}
              onClick={() => { sfx.tap(); navigate(a.route ?? `/portal/${a.id}`); }}
              className="bg-card rounded-lg p-4 flex flex-col items-center gap-2 mxit-shadow-pop tap-scale"
            >
              <div className={`w-14 h-14 rounded-lg ${a.color} flex items-center justify-center text-white mxit-shadow-inset`}>
                <Icon className="w-7 h-7" />
              </div>
              <div className="font-pixel text-[10px] text-center">{a.name}</div>
              <div className="text-[10px] text-muted-foreground text-center">{a.desc}</div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
