import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth, Presence } from '@/contexts/AuthContext';
import { Mail, MailOpen, Plus, Minus, ChevronDown, X, Check, Coins, Store, Smile, Pencil, Gift, Flame, Search, FolderPlus, Trash2, FolderTree } from 'lucide-react';
import { toast } from 'sonner';
import { sfx } from '@/lib/sfx';
import { Emoticon } from '@/components/Emoticon';
import { useNicknames, setNickname, nameWithNickname } from '@/lib/nicknames';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import moodHappy from '@/assets/mood/happy.png';
import moodSad from '@/assets/mood/sad.png';
import moodExcited from '@/assets/mood/excited.png';
import moodInvincible from '@/assets/mood/invincible.png';
import moodHot from '@/assets/mood/hot.png';
import moodAngry from '@/assets/mood/angry.png';
import moodGrumpy from '@/assets/mood/grumpy.png';
import moodSick from '@/assets/mood/sick.png';
import moodInLove from '@/assets/mood/inlove.png';
import moodSleepy from '@/assets/mood/sleepy.png';

const MOOD_ICONS: Record<string, string> = {
  ':)':       moodHappy,
  ':(':       moodSad,
  ':D':       moodExcited,
  '(cool)':   moodInvincible,
  '(blush)':  moodHot,
  '(rage)':   moodAngry,
  '(evil)':   moodGrumpy,
  '(dizzy)':  moodSick,
  '<3':       moodInLove,
  ':|':       moodSleepy,
};

type Other = {
  id: string;
  mxit_id: string;
  display_name: string;
  mood: string | null;
  avatar_seed: string | null;
  avatar_url: string | null;
  presence: string;
  birthday?: string | null;
};

type Contact = {
  id: string;
  status: 'pending' | 'accepted' | 'blocked';
  requester_id: string;
  addressee_id: string;
  unread?: boolean;
  other: Other;
};

type RowKind = 'online' | 'away' | 'busy' | 'offline' | 'invite';

function orbClass(kind: RowKind) {
  return `status-orb orb-${kind}`;
}

function presenceToKind(p: string): Exclude<RowKind, 'invite'> {
  if (p === 'online') return 'online';
  if (p === 'away') return 'away';
  if (p === 'busy') return 'busy';
  return 'offline';
}

// Mood / status emoticon picker
const MOOD_OPTIONS: { code: string; label: string }[] = [
  { code: ':)',       label: 'Happy' },
  { code: ':(',       label: 'Sad' },
  { code: ':D',       label: 'Excited' },
  { code: '(cool)',   label: 'Invincible' },
  { code: '(blush)',  label: 'Hot' },
  { code: '(rage)',   label: 'Angry' },
  { code: '(evil)',   label: 'Grumpy' },
  { code: '(dizzy)',  label: 'Sick' },
  { code: '<3',       label: 'In love' },
  { code: ':|',       label: 'Sleepy' },
];

// System contacts that always appear in the Mxit group, like Joe Banker did.
const MXIT_SYSTEM = [
  { id: 'sys-mobi',    name: 'Joe Banker', sub: 'Apps · Banker Bot · Moola Hub',         route: '/portal/portal',    mood: ':D' },
  { id: 'sys-trade',   name: 'Tradepost',   sub: 'Chat zones · games · music · more',    route: '/tradepost',        mood: '(blush)' },
  { id: 'sys-multimx', name: 'MultiMx',     sub: 'Private group chat with friends',      route: '/multimx',          mood: ':)' },
];

type ContactsTabProps = {
  onViewChange?: (v: 'contacts' | 'profile' | 'multimx' | 'settings' | 'help') => void;
};

export function ContactsTab({ onViewChange }: ContactsTabProps = {}) {
  const { profile, signOut, setPresence } = useAuth();
  const navigate = useNavigate();
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [unreadMap, setUnreadMap] = useState<Record<string, boolean>>({});
  const [openGroups, setOpenGroups] = useState<Record<string, boolean>>({
    Mxit: true,
    Friends: true,
    Invites: true,
    Offline: false,
    Sent: true,
  });
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const hideOffline = !!profile?.hide_offline;
  const [addOpen, setAddOpen] = useState(false);
  const [addId, setAddId] = useState('');
  const [moodOpen, setMoodOpen] = useState(false);
  const [busy, setBusy] = useState(false);
  const nicknames = useNicknames();
  const [renameFor, setRenameFor] = useState<Other | null>(null);
  const [renameVal, setRenameVal] = useState('');
  const [giftFor, setGiftFor] = useState<Other | null>(null);
  const [giftAmt, setGiftAmt] = useState(50);
  const [giftBusy, setGiftBusy] = useState(false);
  const [streak, setStreak] = useState<{ days: number; canClaim: boolean }>({ days: 0, canClaim: false });
  // Custom contact groups
  const [customGroups, setCustomGroups] = useState<{ id: string; name: string; position: number }[]>([]);
  const [groupAssign, setGroupAssign] = useState<Record<string, string>>({});
  const [manageGroupsOpen, setManageGroupsOpen] = useState(false);
  const [newGroupName, setNewGroupName] = useState('');
  const [moveFor, setMoveFor] = useState<Other | null>(null);
  const [searchTipSeen, setSearchTipSeen] = useState<boolean>(() => {
    try { return localStorage.getItem('mxit:search-tip-seen') === '1'; } catch { return true; }
  });

  const loadGroups = async () => {
    if (!profile) return;
    const { data: gs } = await supabase
      .from('contact_groups')
      .select('id, name, position')
      .eq('owner_id', profile.id)
      .order('position', { ascending: true });
    setCustomGroups((gs ?? []) as any);
    const { data: gm } = await supabase
      .from('contact_group_members')
      .select('contact_user_id, group_id')
      .eq('owner_id', profile.id);
    const m: Record<string, string> = {};
    (gm ?? []).forEach((r: any) => { m[r.contact_user_id] = r.group_id; });
    setGroupAssign(m);
  };

  const createGroup = async () => {
    if (!profile) return;
    const name = newGroupName.trim();
    if (!name) return;
    const { error } = await supabase.from('contact_groups')
      .insert({ owner_id: profile.id, name, position: customGroups.length });
    if (error) { toast.error(error.message); return; }
    setNewGroupName('');
    setOpenGroups((g) => ({ ...g, [name]: true }));
    loadGroups();
  };

  const renameGroupRow = async (id: string, name: string) => {
    const trimmed = name.trim();
    if (!trimmed) return;
    const { error } = await supabase.from('contact_groups').update({ name: trimmed }).eq('id', id);
    if (error) { toast.error(error.message); return; }
    loadGroups();
  };

  const deleteGroup = async (id: string) => {
    const { error } = await supabase.from('contact_groups').delete().eq('id', id);
    if (error) { toast.error(error.message); return; }
    loadGroups();
  };

  const assignContactToGroup = async (contactUserId: string, groupId: string | null) => {
    if (!profile) return;
    if (!groupId) {
      await supabase.from('contact_group_members')
        .delete().eq('owner_id', profile.id).eq('contact_user_id', contactUserId);
    } else {
      await supabase.from('contact_group_members')
        .upsert({ owner_id: profile.id, contact_user_id: contactUserId, group_id: groupId },
          { onConflict: 'owner_id,contact_user_id' });
    }
    loadGroups();
    setMoveFor(null);
  };

  const loadUnread = async () => {
    if (!profile) return;
    // Get all conversations involving me
    const { data: convs } = await supabase
      .from('conversations')
      .select('id, user_a, user_b')
      .or(`user_a.eq.${profile.id},user_b.eq.${profile.id}`);
    if (!convs?.length) { setUnreadMap({}); return; }
    const convToOther = new Map<string, string>();
    convs.forEach((c) => {
      convToOther.set(c.id, c.user_a === profile.id ? c.user_b : c.user_a);
    });
    const { data: msgs } = await supabase
      .from('messages')
      .select('conversation_id, sender_id, delivery')
      .in('conversation_id', Array.from(convToOther.keys()))
      .neq('sender_id', profile.id)
      .neq('delivery', 'read');
    const map: Record<string, boolean> = {};
    (msgs ?? []).forEach((m) => {
      if (m.sender_id) map[m.sender_id] = true;
    });
    setUnreadMap(map);
  };

  const load = async () => {
    if (!profile) return;
    const { data } = await supabase
      .from('contacts')
      .select('id, status, requester_id, addressee_id')
      .or(`requester_id.eq.${profile.id},addressee_id.eq.${profile.id}`);
    if (!data) return;
    const otherIds = data.map((c) =>
      c.requester_id === profile.id ? c.addressee_id : c.requester_id,
    );
    if (otherIds.length === 0) {
      setContacts([]);
      return;
    }
    const { data: profs } = await supabase
      .from('profiles')
      .select('id, mxit_id, display_name, mood, avatar_seed, avatar_url, presence, birthday')
      .in('id', otherIds);
    const map = new Map((profs ?? []).map((p) => [p.id, p]));
    setContacts(
      data
        .map((c) => ({
          ...(c as any),
          other: map.get(c.requester_id === profile.id ? c.addressee_id : c.requester_id),
        }))
        .filter((c) => c.other) as Contact[],
    );
  };

  useEffect(() => {
    load();
    loadUnread();
    loadGroups();
    if (!profile) return;
    const ch = supabase
      .channel('contacts-tab')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'contacts' }, load)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'profiles' }, load)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'contact_groups', filter: `owner_id=eq.${profile.id}` }, loadGroups)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'contact_group_members', filter: `owner_id=eq.${profile.id}` }, loadGroups)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'messages' }, (payload) => {
        const m: any = payload.new;
        if (m?.sender_id && m.sender_id !== profile.id) {
          sfx.receive();
        }
        loadUnread();
      })
      .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'messages' }, loadUnread)
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [profile?.id]);

  // Daily login streak
  useEffect(() => {
    if (!profile) return;
    const today = new Date().toISOString().slice(0, 10);
    (async () => {
      const { data } = await supabase.from('moola_daily_claims')
        .select('amount').eq('user_id', profile.id).eq('claim_date', today).maybeSingle();
      setStreak({ days: (profile as any).streak_days ?? 0, canClaim: !data });
    })();
  }, [profile?.id]);

  const claimDaily = async () => {
    sfx.tap();
    const { data, error } = await (supabase as any).rpc('claim_daily_moola');
    if (error) { toast.error(error.message); return; }
    if (data?.ok) {
      toast.success(`+${data.amount}M! 🔥 ${data.streak}-day streak`);
      setStreak({ days: data.streak, canClaim: false });
    } else {
      toast.info('Already claimed today');
      setStreak((s) => ({ ...s, canClaim: false }));
    }
  };

  const openRename = (other: Other) => {
    setRenameFor(other);
    setRenameVal(nicknames[other.id] ?? '');
  };
  const saveRename = async () => {
    if (!profile || !renameFor) return;
    await setNickname(profile.id, renameFor.id, renameVal);
    toast.success(renameVal.trim() ? `Renamed to "${renameVal.trim()}"` : 'Nickname cleared');
    setRenameFor(null);
  };

  const openGift = (other: Other) => { setGiftFor(other); setGiftAmt(50); };
  const sendGift = async () => {
    if (!giftFor) return;
    setGiftBusy(true);
    const { data, error } = await (supabase as any).rpc('send_moola', {
      _to: giftFor.id, _amount: giftAmt, _note: `🎂 Happy birthday ${giftFor.display_name}!`,
    });
    setGiftBusy(false);
    if (error) { toast.error(error.message); return; }
    if (data?.ok) { toast.success(`Sent ${giftAmt}M 🎁`); setGiftFor(null); }
  };

  const sendRequest = async () => {
    if (!profile) return;
    const handle = addId.trim().toLowerCase();
    if (!handle) return;
    setBusy(true);
    try {
      const { data: target } = await supabase
        .from('profiles')
        .select('id')
        .eq('mxit_id', handle)
        .maybeSingle();
      if (!target) throw new Error('No user with that Mxit ID');
      if (target.id === profile.id) throw new Error("That's you :)");
      const { error } = await supabase.from('contacts').insert({
        requester_id: profile.id,
        addressee_id: target.id,
      });
      if (error) {
        if (error.code === '23505') throw new Error('Already in your contacts');
        throw error;
      }
      sfx.tap();
      toast.success('Invite sent');
      setAddId('');
      setAddOpen(false);
      load();
    } catch (e: any) {
      sfx.error();
      toast.error(e.message);
    } finally {
      setBusy(false);
    }
  };

  const accept = async (c: Contact) => {
    sfx.tap();
    await supabase.from('contacts').update({ status: 'accepted' }).eq('id', c.id);
    load();
  };
  const reject = async (c: Contact) => {
    sfx.tap();
    await supabase.from('contacts').delete().eq('id', c.id);
    load();
  };

  const openChat = async (other: Other) => {
    if (!profile) return;
    sfx.tap();
    const [a, b] = [profile.id, other.id].sort();
    const { data: existing } = await supabase
      .from('conversations')
      .select('id')
      .eq('user_a', a)
      .eq('user_b', b)
      .maybeSingle();
    let convId = existing?.id;
    if (!convId) {
      const { data: created, error } = await supabase
        .from('conversations')
        .insert({ user_a: a, user_b: b })
        .select('id')
        .single();
      if (error) {
        toast.error(error.message);
        return;
      }
      convId = created.id;
    }
    setUnreadMap((m) => ({ ...m, [other.id]: false }));
    navigate(`/chat/${convId}`);
  };

  const setMood = async (code: string) => {
    if (!profile) return;
    sfx.tap();
    await supabase.from('profiles').update({ mood: code }).eq('id', profile.id);
    setMoodOpen(false);
  };

  // Group contacts: invites, custom-groups (online), Friends (online ungrouped), Offline
  const groups = useMemo(() => {
    const incoming = contacts.filter(
      (c) => c.status === 'pending' && c.addressee_id === profile?.id,
    );
    const sentOut = contacts.filter(
      (c) => c.status === 'pending' && c.requester_id === profile?.id,
    );
    const accepted = contacts.filter((c) => c.status === 'accepted');
    const onlineAll = accepted.filter((c) => c.other.presence !== 'offline');
    const offline = accepted.filter((c) => c.other.presence === 'offline');

    // Bucket online contacts into custom groups vs ungrouped
    const byGroup: Record<string, Contact[]> = {};
    customGroups.forEach((g) => { byGroup[g.id] = []; });
    const friends: Contact[] = [];
    onlineAll.forEach((c) => {
      const gid = groupAssign[c.other.id];
      if (gid && byGroup[gid]) byGroup[gid].push(c);
      else friends.push(c);
    });

    return { incoming, sentOut, accepted, friends, offline, byGroup };
  }, [contacts, profile?.id, customGroups, groupAssign]);

  // Today's birthdays among accepted contacts
  const birthdaysToday = useMemo(() => {
    const now = new Date();
    return contacts
      .filter((c) => c.status === 'accepted' && c.other.birthday)
      .filter((c) => {
        const d = new Date(c.other.birthday as string);
        return d.getMonth() === now.getMonth() && d.getDate() === now.getDate();
      });
  }, [contacts]);

  const toggleGroup = (k: string) => {
    sfx.tap();
    setOpenGroups((g) => ({ ...g, [k]: !g[k] }));
  };

  const totalUnread = Object.values(unreadMap).filter(Boolean).length;

  // ---------- Renderers ----------

  const SystemRow = ({ s }: { s: typeof MXIT_SYSTEM[number] }) => (
    <button
      onClick={() => {
        sfx.tap();
        if (s.route) navigate(s.route);
      }}
      className="w-full text-left flex items-center gap-3 pl-7 pr-3 py-1.5"
    >
      <span className="status-orb orb-online" aria-hidden />
      <span className="flex-1 min-w-0 truncate text-white font-medium tracking-wide" style={{ textShadow: '0 1px 0 hsl(220 80% 8% / 0.6)' }}>
        {s.name}
        <span className="block text-[11px] font-normal text-white/60 truncate inline-flex items-center gap-1">
          {MOOD_ICONS[s.mood] ? (
            <img src={MOOD_ICONS[s.mood]} alt="" width={14} height={14} className="w-3.5 h-3.5 object-contain inline-block align-text-bottom" />
          ) : (
            <Emoticon code={s.mood} size={12} />
          )} {s.sub}
        </span>
      </span>
      <MailOpen className="w-4 h-4 envelope-read" aria-hidden />
    </button>
  );

  const ContactRow = ({
    c,
    kind,
    label,
    sub,
    rightAction,
  }: {
    c: Contact;
    kind: RowKind;
    label: string;
    sub?: string;
    rightAction?: React.ReactNode;
  }) => {
    const selected = selectedId === c.id;
    const unread = !!unreadMap[c.other.id];
    let pressTimer: number | null = null;
    const onPressStart = () => {
      pressTimer = window.setTimeout(() => {
        sfx.tap();
        if (c.status === 'accepted') openRename(c.other);
        else navigate(`/u/${c.other.mxit_id}`);
      }, 500);
    };
    const onPressEnd = () => { if (pressTimer) { window.clearTimeout(pressTimer); pressTimer = null; } };
    return (
      <button
        onClick={() => {
          sfx.tap();
          setSelectedId(c.id);
          if (c.status === 'accepted') openChat(c.other);
        }}
        onContextMenu={(e) => {
          e.preventDefault();
          if (c.status === 'accepted') setMoveFor(c.other);
          else navigate(`/u/${c.other.mxit_id}`);
        }}
        onTouchStart={onPressStart}
        onTouchEnd={onPressEnd}
        onTouchMove={onPressEnd}
        onMouseDown={onPressStart}
        onMouseUp={onPressEnd}
        onMouseLeave={onPressEnd}
        className={`w-full text-left flex items-center gap-3 pl-7 pr-3 py-1.5 ${
          selected ? 'mxit-row-active' : ''
        }`}
      >
        <span className={orbClass(kind)} aria-hidden />
        <span className="flex-1 min-w-0 truncate text-white font-medium tracking-wide" style={{ textShadow: '0 1px 0 hsl(220 80% 8% / 0.6)' }}>
          {label}
          {sub && (
            <span className="block text-[11px] font-normal text-white/60 truncate">
              <EmoLine text={sub} />
            </span>
          )}
        </span>
        {rightAction ?? (
          unread ? (
            <Mail className="w-4 h-4 envelope-unread" aria-label="unread" />
          ) : (
            <MailOpen className="w-4 h-4 envelope-read" aria-hidden />
          )
        )}
      </button>
    );
  };

  const GroupHeader = ({
    name,
    count,
    color = 'text-white',
  }: {
    name: string;
    count: number;
    color?: string;
  }) => {
    const open = !!openGroups[name];
    return (
      <button
        onClick={() => toggleGroup(name)}
        className={`w-full text-left flex items-center gap-2 px-3 py-1.5 ${color}`}
        style={{ textShadow: '0 1px 0 hsl(220 80% 8% / 0.6)' }}
      >
        <span className="inline-flex items-center justify-center w-4 h-4 border border-white/40 bg-white/5 text-white text-[10px] leading-none">
          {open ? <Minus className="w-2.5 h-2.5" /> : <Plus className="w-2.5 h-2.5" />}
        </span>
        <span className="font-medium tracking-wide">
          {name} <span className="opacity-80">({count})</span>
        </span>
      </button>
    );
  };

  const myKind: RowKind = profile ? presenceToKind(profile.presence) : 'offline';

  return (
    <div className="flex-1 min-h-0 flex flex-col mxit-classic-bg">
      {/* Title bar — left: my status orb (was 3G), center: Contacts, right: mood emoticon */}
      <div className="mxit-titlebar h-9 flex items-center px-3 gap-2 shrink-0">
        <button
          onClick={() => {
            sfx.tap();
            const next: Presence =
              profile?.presence === 'online' ? 'away' :
              profile?.presence === 'away'   ? 'busy' :
              profile?.presence === 'busy'   ? 'offline' : 'online';
            setPresence(next);
          }}
          aria-label="cycle status"
          className="flex items-center gap-1"
        >
          <span className={orbClass(myKind)} />
          {(totalUnread > 0 || groups.incoming.length > 0) && (
            <span
              className="status-orb orb-away animate-pulse"
              aria-label={`${totalUnread + groups.incoming.length} new`}
              title="New messages or invites"
            />
          )}
        </button>
        <div className="flex-1 text-center font-semibold text-[15px] tracking-wide">
          Contacts
        </div>
        <button
          onClick={() => { sfx.tap(); setMoodOpen(true); }}
          aria-label="set mood"
          className="flex items-center justify-center w-7 h-7 rounded-md bg-white/10 border border-white/20 active:bg-white/20"
        >
          {profile?.mood && MOOD_ICONS[profile.mood] ? (
            <img src={MOOD_ICONS[profile.mood]} alt="" width={18} height={18} className="w-[18px] h-[18px] object-contain" />
          ) : profile?.mood ? (
            <Emoticon code={profile.mood} size={16} />
          ) : (
            <Smile className="w-4 h-4" />
          )}
        </button>
      </div>

      {/* List */}
      <div className="relative flex-1 overflow-y-auto mxit-watermark min-h-0">
        <div className="relative z-10 py-2">
          {/* Info — first row */}
          <button
            onClick={() => { sfx.tap(); onViewChange?.('help'); }}
            className="w-full text-left flex items-center gap-3 pl-3 pr-3 py-1.5"
          >
            <span className="status-orb orb-online" aria-hidden />
            <span className="flex-1 text-white font-medium" style={{ textShadow: '0 1px 0 hsl(220 80% 8% / 0.6)' }}>
              Info
            </span>
            <MailOpen className="w-4 h-4 envelope-read" aria-hidden />
          </button>

          {streak.canClaim && (
            <button
              onClick={claimDaily}
              className="mx-3 my-2 w-[calc(100%-1.5rem)] px-3 py-2 rounded bg-amber-500/20 border border-amber-400/40 text-amber-50 text-[12px] flex items-center gap-2 hover:bg-amber-500/30"
            >
              <Flame className="w-4 h-4 text-amber-300" />
              <span className="flex-1 text-left">
                <span className="font-semibold">Daily login bonus ready!</span>
                {streak.days > 0 && <span className="ml-1 text-amber-200/80">· {streak.days}-day streak</span>}
              </span>
              <span className="font-pixel text-[10px] text-amber-200">CLAIM</span>
            </button>
          )}

          {!streak.canClaim && streak.days > 0 && (
            <div className="mx-3 my-1 px-3 py-1 rounded bg-white/5 border border-white/10 text-[11px] text-amber-200/80 flex items-center gap-1.5">
              <Flame className="w-3 h-3 text-amber-300" />
              <span className="font-semibold">{streak.days}-day streak</span>
              <span className="text-white/50">· come back tomorrow for more Moola</span>
            </div>
          )}

          {groups.incoming.length > 0 && (
            <button
              onClick={() => { sfx.tap(); setOpenGroups((g) => ({ ...g, Invites: true })); }}
              className="mx-3 my-2 w-[calc(100%-1.5rem)] px-3 py-2 rounded bg-emerald-500/15 border border-emerald-400/40 text-emerald-50 text-[12px] flex items-center gap-2 hover:bg-emerald-500/25"
            >
              <Mail className="w-4 h-4 text-emerald-300" />
              <span className="flex-1 text-left">
                <span className="font-semibold">{groups.incoming.length} invite{groups.incoming.length > 1 ? 's' : ''} waiting</span>
              </span>
              <span className="font-pixel text-[10px] text-emerald-200">REVIEW</span>
            </button>
          )}

          {birthdaysToday.length > 0 && (
            <div className="mx-3 my-2 px-3 py-2 rounded bg-yellow-500/20 border border-yellow-400/40 text-yellow-50 text-[12px] flex items-start gap-2">
              <span className="text-base">🎂</span>
              <div className="flex-1">
                <div className="font-semibold">Birthdays today</div>
                {birthdaysToday.map((c) => (
                  <div key={c.id} className="flex items-center justify-between gap-2 mt-0.5">
                    <button
                      onClick={(e) => { e.stopPropagation(); navigate(`/u/${c.other.mxit_id}`); }}
                      className="underline hover:text-yellow-200 text-left flex-1 truncate"
                    >
                      {nameWithNickname(nicknames, c.other.id, c.other.display_name)} (@{c.other.mxit_id})
                    </button>
                    <button
                      onClick={(e) => { e.stopPropagation(); openGift(c.other); }}
                      className="px-2 py-0.5 rounded bg-yellow-400/30 hover:bg-yellow-400/50 text-yellow-50 text-[11px] flex items-center gap-1"
                    >
                      <Gift className="w-3 h-3" /> gift
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Mxit system contacts (Joe Banker, Tradepost, ...) */}
          <GroupHeader name="Mxit" count={MXIT_SYSTEM.length} />
          {openGroups.Mxit && MXIT_SYSTEM.map((s) => <SystemRow key={s.id} s={s} />)}

          {/* Empty state — first-time user with no friends yet */}
          {groups.accepted.length === 0 && groups.incoming.length === 0 && groups.sentOut.length === 0 && (
            <div className="mx-3 my-3 px-4 py-5 rounded-lg bg-mxit-primary/15 border border-mxit-primary/40 text-white text-center">
              <div className="text-3xl mb-1">👋</div>
              <div className="font-semibold text-[14px] mb-1">Welcome to Mxit!</div>
              <div className="text-[12px] text-white/70 mb-3 leading-snug">
                You don't have any friends yet. Add them by their Mxit ID and start chatting.
              </div>
              <button
                onClick={() => { sfx.tap(); setAddOpen(true); }}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded bg-mxit-primary hover:bg-mxit-primary/90 text-white text-[12px] font-semibold mxit-shadow-pop"
              >
                <Plus className="w-3.5 h-3.5" /> Add your first friend
              </button>
              <div className="mt-2 text-[11px] text-white/50">
                or tap <span className="font-pixel">Tradepost</span> above to explore public Chat Rooms
              </div>
            </div>
          )}

          {/* Invites group */}
          {groups.incoming.length > 0 && (
            <>
              <GroupHeader name="Invites" count={groups.incoming.length} />
              {openGroups.Invites &&
                groups.incoming.map((c) => (
                  <ContactRow
                    key={c.id}
                    c={c}
                    kind="invite"
                    label={c.other.display_name}
                    sub={`@${c.other.mxit_id} · invite`}
                    rightAction={
                      <span className="flex items-center gap-1">
                        <span
                          role="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            accept(c);
                          }}
                          className="p-1 rounded bg-emerald-600/80 hover:bg-emerald-500 text-white"
                          aria-label="accept"
                        >
                          <Check className="w-3.5 h-3.5" />
                        </span>
                        <span
                          role="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            reject(c);
                          }}
                          className="p-1 rounded bg-red-700/80 hover:bg-red-600 text-white"
                          aria-label="reject"
                        >
                          <X className="w-3.5 h-3.5" />
                        </span>
                      </span>
                    }
                  />
                ))}
            </>
          )}

          {/* Custom user-defined groups (online contacts only) */}
          {customGroups.map((g) => {
            const list = groups.byGroup[g.id] ?? [];
            return (
              <div key={g.id}>
                <GroupHeader name={g.name} count={list.length} />
                {openGroups[g.name] && (list.length === 0 ? (
                  <div className="px-7 py-2 text-[12px] text-white/50 italic">
                    Empty. Right-click / long-press a contact to move them here.
                  </div>
                ) : list.map((c) => (
                  <ContactRow
                    key={c.id}
                    c={c}
                    kind={presenceToKind(c.other.presence)}
                    label={nameWithNickname(nicknames, c.other.id, c.other.display_name)}
                    sub={c.other.mood ?? `@${c.other.mxit_id}`}
                  />
                )))}
              </div>
            );
          })}

          {/* Friends (online, ungrouped) */}
          <GroupHeader name="Friends" count={groups.friends.length} />
          {openGroups.Friends &&
            (groups.friends.length === 0 ? (
              <div className="px-7 py-2 text-[12px] text-white/50 italic">
                {customGroups.length > 0 ? 'All online contacts are in groups.' : 'No friends online. Tap Menu → Add contact.'}
              </div>
            ) : (
              groups.friends.map((c) => (
                <ContactRow
                  key={c.id}
                  c={c}
                  kind={presenceToKind(c.other.presence)}
                  label={nameWithNickname(nicknames, c.other.id, c.other.display_name)}
                  sub={c.other.mood ?? `@${c.other.mxit_id}`}
                />
              ))
            ))}

          {/* Sent invites */}
          {groups.sentOut.length > 0 && (
            <>
              <GroupHeader name="Sent" count={groups.sentOut.length} />
              {openGroups.Sent &&
                groups.sentOut.map((c) => (
                  <ContactRow
                    key={c.id}
                    c={c}
                    kind="invite"
                    label={c.other.display_name}
                    sub="waiting…"
                    rightAction={
                      <span
                        role="button"
                        onClick={(e) => {
                          e.stopPropagation();
                          reject(c);
                        }}
                        className="text-[11px] text-white/60 hover:text-white px-1"
                      >
                        cancel
                      </span>
                    }
                  />
                ))}
            </>
          )}

          {/* Offline */}
          {!hideOffline && (
            <>
              <GroupHeader name="Offline" count={groups.offline.length} />
              {openGroups.Offline &&
                groups.offline.map((c) => (
                  <ContactRow
                    key={c.id}
                    c={c}
                    kind="offline"
                    label={nameWithNickname(nicknames, c.other.id, c.other.display_name)}
                    sub={c.other.mood ?? `@${c.other.mxit_id}`}
                  />
                ))}
            </>
          )}
        </div>
      </div>

      {/* Soft keys — Menu / Chat — pinned to bottom of viewport */}
      <div className="mxit-softkeys h-11 flex items-stretch text-sm font-medium select-none shrink-0">
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button className="flex-1 flex items-center justify-start pl-4 gap-1 active:bg-black/30">
              Menu <ChevronDown className="w-3.5 h-3.5 opacity-70" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="start" side="top" className="font-medium">
            <DropdownMenuItem onClick={() => setAddOpen(true)}>Add contact…</DropdownMenuItem>
            <DropdownMenuItem onClick={() => setManageGroupsOpen(true)}>Manage groups…</DropdownMenuItem>
            <DropdownMenuItem onClick={() => setMoodOpen(true)}>Set mood…</DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => onViewChange?.('profile')}>My profile</DropdownMenuItem>
            <DropdownMenuItem onClick={() => onViewChange?.('settings')}>Settings</DropdownMenuItem>
            <DropdownMenuItem onClick={async () => {
              if (!profile) return;
              await supabase.from('profiles').update({ hide_offline: !profile.hide_offline }).eq('id', profile.id);
            }}>
              {hideOffline ? 'Show offline contacts' : 'Hide offline contacts'}
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onViewChange?.('help')}>Help</DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => signOut()}>Logout</DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        <button
          onClick={() => { sfx.tap(); navigate('/status'); }}
          className="px-2 flex items-center justify-center gap-1 active:bg-black/30 border-l border-white/10 text-[12px] font-semibold"
          aria-label="Status"
          title="Mxit Status"
        >
          <span className="inline-block w-2 h-2 rounded-full bg-emerald-400" /> Status
        </button>

        <button
          onClick={() => {
            sfx.tap();
            try { localStorage.setItem('mxit:search-tip-seen', '1'); } catch { /* ignore */ }
            setSearchTipSeen(true);
            window.dispatchEvent(new Event('mxit:open-search'));
          }}
          className="relative px-2 flex items-center justify-center active:bg-black/30 border-l border-r border-white/10"
          aria-label="Search"
          title="Search (Ctrl+K)"
        >
          <Search className="w-4 h-4" />
          {!searchTipSeen && (
            <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-amber-400 animate-pulse" aria-hidden />
          )}
        </button>

        <button
          onClick={() => {
            const sel = contacts.find((c) => c.id === selectedId);
            if (sel && sel.status === 'accepted') openChat(sel.other);
            else toast.message('Select a contact to chat');
          }}
          className="flex-1 flex items-center justify-end pr-4 active:bg-black/30 relative"
        >
          {totalUnread > 0 && (
            <span className="absolute right-12 top-1/2 -translate-y-1/2 bg-amber-400 text-black text-[10px] font-bold rounded-full min-w-[16px] h-4 px-1 flex items-center justify-center">
              {totalUnread}
            </span>
          )}
          Chat
        </button>
      </div>

      {/* Add-contact dialog */}
      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="font-pixel text-sm">add contact</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground">
            Enter the person's Mxit ID to send them an invite.
          </p>
          <Input
            value={addId}
            onChange={(e) => setAddId(e.target.value)}
            placeholder="cooldude_92"
            autoFocus
          />
          <Button onClick={sendRequest} disabled={busy} className="font-pixel text-[10px]">
            send invite
          </Button>
        </DialogContent>
      </Dialog>

      {/* Classic Mxit "Presence" mood picker */}
      <Dialog open={moodOpen} onOpenChange={setMoodOpen}>
        <DialogContent
          aria-describedby={undefined}
          className="mxit-presence-dialog p-0 overflow-hidden max-w-xs gap-0 border border-[#0a2a5e] rounded-md text-white"
        >
          <DialogHeader className="space-y-0">
            <DialogTitle asChild>
              <div className="mxit-titlebar h-9 flex items-center px-3 gap-2">
                <span className="inline-flex items-center justify-center w-5 h-5 bg-white/10 border border-white/20 rounded-sm">
                  <Smile className="w-3 h-3" />
                </span>
                <span className="flex-1 text-center font-semibold text-[15px] tracking-wide text-white">
                  Presence
                </span>
                <span className="status-orb orb-online" />
              </div>
            </DialogTitle>
          </DialogHeader>
          <div className="py-2">
            <div className="px-3 pb-1 text-[13px] font-semibold text-sky-300">Mood</div>
            <ul className="max-h-[60vh] overflow-y-auto">
              {MOOD_OPTIONS.map((m) => {
                const active = profile?.mood === m.code;
                const icon = MOOD_ICONS[m.code];
                return (
                  <li key={m.code}>
                    <button
                      onClick={() => setMood(m.code)}
                      className={`w-full text-left flex items-center gap-3 px-3 py-1.5 text-[16px] ${
                        active ? 'bg-white/20 text-white' : 'text-white hover:bg-white/10'
                      }`}
                    >
                      <img
                        src={icon}
                        alt={m.label}
                        loading="lazy"
                        width={28}
                        height={28}
                        className="w-7 h-7 object-contain shrink-0"
                      />
                      <span style={{ textShadow: '0 1px 0 hsl(220 80% 8% / 0.6)' }}>{m.label}</span>
                    </button>
                  </li>
                );
              })}
              <li>
                <button
                  onClick={() => setMood('')}
                  className={`w-full text-left flex items-center gap-3 px-3 py-1.5 text-[16px] ${
                    !profile?.mood ? 'bg-white/20 text-white' : 'text-white/60 hover:bg-white/10'
                  }`}
                >
                  <span className="inline-block w-[28px] h-[28px]" aria-hidden />
                  <span>None</span>
                </button>
              </li>
            </ul>
          </div>
        </DialogContent>
      </Dialog>

      {/* Rename contact (local nickname) */}
      <Dialog open={!!renameFor} onOpenChange={(o) => !o && setRenameFor(null)}>
        <DialogContent className="max-w-xs">
          <DialogHeader>
            <DialogTitle className="font-pixel text-sm flex items-center gap-2">
              <Pencil className="w-3.5 h-3.5" /> rename
            </DialogTitle>
          </DialogHeader>
          <p className="text-xs text-muted-foreground">
            Set a local nickname for <strong>{renameFor?.display_name}</strong>. Only you'll see it.
          </p>
          <Input
            value={renameVal}
            onChange={(e) => setRenameVal(e.target.value.slice(0, 40))}
            placeholder={renameFor?.display_name ?? ''}
            autoFocus
            onKeyDown={(e) => { if (e.key === 'Enter') saveRename(); }}
          />
          <div className="flex gap-2">
            <Button variant="ghost" onClick={() => { setRenameVal(''); }} className="flex-1">clear</Button>
            <Button onClick={saveRename} className="flex-1 font-pixel text-[10px]">save</Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Birthday gift */}
      <Dialog open={!!giftFor} onOpenChange={(o) => !o && setGiftFor(null)}>
        <DialogContent className="max-w-xs">
          <DialogHeader>
            <DialogTitle className="font-pixel text-sm flex items-center gap-2">
              <Gift className="w-3.5 h-3.5" /> birthday gift
            </DialogTitle>
          </DialogHeader>
          <p className="text-xs text-muted-foreground">
            Send Moola to <strong>{giftFor?.display_name}</strong> 🎂
          </p>
          <div className="flex gap-2">
            {[20, 50, 100, 200].map((n) => (
              <button key={n} onClick={() => setGiftAmt(n)}
                className={`flex-1 py-2 rounded border text-sm ${giftAmt === n ? 'bg-mxit-primary text-white border-mxit-primary' : 'bg-secondary border-border'}`}>
                {n}M
              </button>
            ))}
          </div>
          <Button onClick={sendGift} disabled={giftBusy} className="w-full font-pixel text-[10px]">
            {giftBusy ? 'sending…' : `send ${giftAmt}M 🎁`}
          </Button>
        </DialogContent>
      </Dialog>

      {/* Manage groups */}
      <Dialog open={manageGroupsOpen} onOpenChange={setManageGroupsOpen}>
        <DialogContent className="max-w-xs">
          <DialogHeader>
            <DialogTitle className="font-pixel text-sm flex items-center gap-2">
              <FolderTree className="w-3.5 h-3.5" /> contact groups
            </DialogTitle>
          </DialogHeader>
          <p className="text-xs text-muted-foreground">
            Create custom groups (e.g. Family, Crew) and sort online contacts into them. Right-click / long-press a contact to move them.
          </p>
          <div className="space-y-1 max-h-60 overflow-y-auto">
            {customGroups.length === 0 && (
              <div className="text-xs italic text-muted-foreground">No groups yet.</div>
            )}
            {customGroups.map((g) => (
              <div key={g.id} className="flex items-center gap-2">
                <Input
                  defaultValue={g.name}
                  onBlur={(e) => { if (e.target.value !== g.name) renameGroupRow(g.id, e.target.value); }}
                  className="flex-1 h-8 text-sm"
                />
                <button
                  onClick={() => deleteGroup(g.id)}
                  className="p-1.5 rounded hover:bg-destructive/20 text-destructive"
                  aria-label="delete group"
                  title="Delete group"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
          <div className="flex gap-2 pt-2 border-t">
            <Input
              value={newGroupName}
              onChange={(e) => setNewGroupName(e.target.value.slice(0, 30))}
              placeholder="New group name"
              onKeyDown={(e) => { if (e.key === 'Enter') createGroup(); }}
              className="flex-1 h-8 text-sm"
            />
            <Button onClick={createGroup} disabled={!newGroupName.trim()} size="sm" className="font-pixel text-[10px]">
              <FolderPlus className="w-3.5 h-3.5 mr-1" /> add
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      {/* Move contact into group */}
      <Dialog open={!!moveFor} onOpenChange={(o) => !o && setMoveFor(null)}>
        <DialogContent className="max-w-xs">
          <DialogHeader>
            <DialogTitle className="font-pixel text-sm flex items-center gap-2">
              <FolderTree className="w-3.5 h-3.5" /> move contact
            </DialogTitle>
          </DialogHeader>
          <p className="text-xs text-muted-foreground">
            Move <strong>{moveFor?.display_name}</strong> into a group.
          </p>
          <div className="space-y-1 max-h-60 overflow-y-auto">
            <button
              onClick={() => moveFor && assignContactToGroup(moveFor.id, null)}
              className={`w-full text-left px-3 py-2 rounded text-sm border ${moveFor && !groupAssign[moveFor.id] ? 'bg-mxit-primary text-white border-mxit-primary' : 'bg-secondary border-border hover:bg-secondary/70'}`}
            >
              Friends (no group)
            </button>
            {customGroups.map((g) => {
              const active = moveFor && groupAssign[moveFor.id] === g.id;
              return (
                <button
                  key={g.id}
                  onClick={() => moveFor && assignContactToGroup(moveFor.id, g.id)}
                  className={`w-full text-left px-3 py-2 rounded text-sm border ${active ? 'bg-mxit-primary text-white border-mxit-primary' : 'bg-secondary border-border hover:bg-secondary/70'}`}
                >
                  {g.name}
                </button>
              );
            })}
            {customGroups.length === 0 && (
              <Button onClick={() => { setMoveFor(null); setManageGroupsOpen(true); }} variant="outline" className="w-full mt-2">
                <FolderPlus className="w-3.5 h-3.5 mr-1" /> Create a group first
              </Button>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

/** Inline render text + emoticons */
function EmoLine({ text }: { text: string }) {
  // simple split: if string equals a known mood code, render as icon
  const opt = MOOD_OPTIONS.find((m) => m.code === text);
  if (opt) {
    return (
      <span className="inline-flex items-center gap-1">
        <Emoticon code={opt.code} size={12} /> {opt.label}
      </span>
    );
  }
  return <>{text}</>;
}
