import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Hash, Plus, Users } from 'lucide-react';
import { toast } from 'sonner';
import { sfx } from '@/lib/sfx';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';

type Room = { id: string; name: string; topic: string | null; is_official: boolean; member_count: number; joined: boolean };

export function ChatroomsTab() {
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [rooms, setRooms] = useState<Room[]>([]);
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [topic, setTopic] = useState('');

  const load = async () => {
    if (!profile) return;
    const { data: rs } = await supabase.from('chatrooms').select('id, name, topic, is_official').order('is_official', { ascending: false }).order('name');
    const { data: ms } = await supabase.from('room_members').select('room_id, user_id');
    const counts = new Map<string, number>();
    const mine = new Set<string>();
    (ms ?? []).forEach((m) => {
      counts.set(m.room_id, (counts.get(m.room_id) ?? 0) + 1);
      if (m.user_id === profile.id) mine.add(m.room_id);
    });
    setRooms((rs ?? []).map((r) => ({ ...r, member_count: counts.get(r.id) ?? 0, joined: mine.has(r.id) })));
  };

  useEffect(() => {
    load();
    const ch = supabase.channel('rooms-tab')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'room_members' }, load)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'chatrooms' }, load)
      .subscribe();
    return () => { supabase.removeChannel(ch); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [profile?.id]);

  const enter = async (r: Room) => {
    if (!profile) return;
    sfx.tap();
    if (!r.joined) {
      const { error } = await supabase.from('room_members').insert({ room_id: r.id, user_id: profile.id });
      if (error && error.code !== '23505') { toast.error(error.message); return; }
    }
    navigate(`/room/${r.id}`);
  };

  const create = async () => {
    if (!profile || !name.trim()) return;
    const { data, error } = await supabase.from('chatrooms').insert({
      name: name.trim(), topic: topic.trim() || null, created_by: profile.id,
    }).select('id').single();
    if (error) { sfx.error(); toast.error(error.message.includes('duplicate') ? 'A room with that name exists' : error.message); return; }
    await supabase.from('room_members').insert({ room_id: data.id, user_id: profile.id });
    setOpen(false); setName(''); setTopic('');
    toast.success('Chatroom created!');
    navigate(`/room/${data.id}`);
  };

  return (
    <div className="p-3 space-y-3 animate-fade-up">
      <div className="flex justify-between items-center px-1">
        <h3 className="font-pixel text-[9px] text-mxit-deep/60 uppercase">chatrooms</h3>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button size="sm" variant="ghost" className="font-pixel text-[10px]"><Plus className="w-4 h-4 mr-1" /> new room</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader><DialogTitle className="font-pixel text-sm">create chatroom</DialogTitle></DialogHeader>
            <Input value={name} onChange={(e) => setName(e.target.value)} placeholder="Room name" maxLength={40} />
            <Input value={topic} onChange={(e) => setTopic(e.target.value)} placeholder="Topic (optional)" maxLength={120} />
            <Button onClick={create} className="font-pixel text-[10px]">create</Button>
          </DialogContent>
        </Dialog>
      </div>

      <div className="space-y-2">
        {rooms.map((r) => (
          <button
            key={r.id}
            onClick={() => enter(r)}
            className="w-full bg-card rounded-lg p-3 flex items-center gap-3 mxit-shadow-pop tap-scale text-left"
          >
            <div className="w-11 h-11 bg-mxit-primary/10 rounded-md flex items-center justify-center text-mxit-primary">
              <Hash className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="font-medium truncate flex items-center gap-2">
                {r.name}
                {r.is_official && <span className="font-pixel text-[7px] bg-mxit-moola text-white px-1.5 py-0.5 rounded">OFFICIAL</span>}
                {r.joined && <span className="font-pixel text-[7px] bg-mxit-online text-white px-1.5 py-0.5 rounded">JOINED</span>}
              </div>
              <div className="text-xs text-muted-foreground truncate">{r.topic || 'No topic'}</div>
            </div>
            <div className="flex items-center gap-1 text-xs text-muted-foreground">
              <Users className="w-3.5 h-3.5" /> {r.member_count}
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
