/** Phone-shaped frame on desktop, fullscreen on mobile. Provides safe-area + max-width. */
import { ReactNode } from 'react';
import { OfflineBanner } from './OfflineBanner';
import { AnnouncementBanner } from './AnnouncementBanner';
import { CallManager } from './CallManager';
import { GlobalSearch } from './GlobalSearch';
import { OnboardingTour } from './OnboardingTour';
import { useAuth } from '@/contexts/AuthContext';

export function MxitShell({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  return (
    <div className="h-[100dvh] w-full flex items-stretch justify-center mxit-classic-bg overflow-hidden">
      <div
        className="w-full max-w-[480px] flex flex-col relative overflow-hidden mxit-classic-bg"
        style={{
          height: '100dvh',
          paddingTop: 'env(safe-area-inset-top)',
          paddingBottom: 'env(safe-area-inset-bottom)',
        }}
      >
        <OfflineBanner />
        <AnnouncementBanner />
        {children}
        <CallManager />
        {user && <GlobalSearch />}
        {user && <OnboardingTour />}
      </div>
    </div>
  );
}
