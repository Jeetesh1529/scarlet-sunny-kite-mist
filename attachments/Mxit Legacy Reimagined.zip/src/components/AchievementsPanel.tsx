/**
 * AchievementsPanel — shown inside ProfileView. Lists all achievements with
 * lock state, tier badges, and Moola rewards.
 */
import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';

type Achievement = {
  id: string; name: string; description: string;
  icon: string; tier: string; moola_reward: number; position: number;
};

type Unlock = { achievement_id: string; unlocked_at: string };

const TIER_COLORS: Record<string, string> = {
  bronze: 'bg-amber-700/20 text-amber-700 border-amber-700/40',
  silver: 'bg-slate-400/20 text-slate-600 border-slate-400/50',
  gold:   'bg-yellow-500/20 text-yellow-700 border-yellow-500/60',
};

export function AchievementsPanel({ userId }: { userId: string }) {
  const [list, setList] = useState<Achievement[]>([]);
  const [unlocked, setUnlocked] = useState<Map<string, string>>(new Map());

  useEffect(() => {
    (async () => {
      const [{ data: ach }, { data: ua }] = await Promise.all([
        supabase.from('achievements').select('*').order('position'),
        supabase.from('user_achievements').select('achievement_id, unlocked_at').eq('user_id', userId),
      ]);
      setList((ach ?? []) as Achievement[]);
      setUnlocked(new Map(((ua ?? []) as Unlock[]).map((u) => [u.achievement_id, u.unlocked_at])));
    })();
  }, [userId]);

  const total = list.length;
  const got = unlocked.size;

  return (
    <div className="space-y-2">
      <div className="text-[11px] text-muted-foreground">
        🏆 {got} / {total} unlocked
      </div>
      <div className="grid grid-cols-2 gap-2">
        {list.map((a) => {
          const isLocked = !unlocked.has(a.id);
          return (
            <div
              key={a.id}
              className={`rounded-md border p-2 ${isLocked ? 'bg-muted/30 border-border opacity-60' : 'bg-secondary/40 border-border'}`}
              title={a.description}
            >
              <div className="flex items-center gap-2">
                <span className="text-xl">{isLocked ? '🔒' : a.icon}</span>
                <div className="flex-1 min-w-0">
                  <div className="text-[12px] font-semibold text-foreground truncate">{a.name}</div>
                  <span className={`inline-block text-[9px] uppercase tracking-wider px-1 py-0.5 rounded border ${TIER_COLORS[a.tier] ?? TIER_COLORS.bronze}`}>
                    {a.tier}
                  </span>
                </div>
              </div>
              <div className="text-[10px] text-muted-foreground mt-1 line-clamp-2">{a.description}</div>
              {a.moola_reward > 0 && (
                <div className="text-[10px] text-amber-600 mt-1">+{a.moola_reward}M reward</div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
