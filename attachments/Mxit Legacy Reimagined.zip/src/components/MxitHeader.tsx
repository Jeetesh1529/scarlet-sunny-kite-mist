import { Signal, Battery } from 'lucide-react';
import { useEffect, useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { PixelAvatar } from './PixelAvatar';

interface Props {
  title?: string;
  subtitle?: string;
  left?: React.ReactNode;
  right?: React.ReactNode;
  showStatusBar?: boolean;
  showProfile?: boolean;
}

export function MxitHeader({ title, subtitle, left, right, showStatusBar = true, showProfile = false }: Props) {
  const { profile } = useAuth();
  const [time, setTime] = useState('');

  useEffect(() => {
    const update = () => {
      const d = new Date();
      setTime(`${d.getHours().toString().padStart(2, '0')}:${d.getMinutes().toString().padStart(2, '0')}`);
    };
    update();
    const id = setInterval(update, 30_000);
    return () => clearInterval(id);
  }, []);

  return (
    <header className="mxit-header-gradient text-white safe-top sticky top-0 z-30">
      {showStatusBar && (
        <div className="flex items-center justify-between px-3 py-1 text-[10px] font-mono-pixel opacity-90">
          <span>{time}</span>
          <span className="font-pixel text-[8px] tracking-widest">M X I T</span>
          <span className="flex items-center gap-1">
            <Signal className="w-3 h-3" />
            <Battery className="w-3.5 h-3.5" />
          </span>
        </div>
      )}
      <div className="flex items-center gap-2 px-3 py-2 min-h-[52px]">
        {left}
        {showProfile && profile && (
          <PixelAvatar seed={profile.avatar_seed} url={profile.avatar_url} size={36} ring />
        )}
        <div className="flex-1 min-w-0">
          {title && <div className="font-pixel text-[11px] truncate leading-tight">{title}</div>}
          {subtitle && <div className="text-[11px] opacity-80 truncate">{subtitle}</div>}
        </div>
        {right}
      </div>
    </header>
  );
}
