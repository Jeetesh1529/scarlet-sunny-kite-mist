/**
 * Announcement banner — shows active admin announcements at top of app.
 * Dismissable per-user.
 */
import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { Megaphone, X } from 'lucide-react';

type Ann = { id: string; title: string; body: string; severity: string };

export function AnnouncementBanner() {
  const { user } = useAuth();
  const [ann, setAnn] = useState<Ann | null>(null);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data } = await supabase
        .from('announcements')
        .select('id, title, body, severity')
        .order('created_at', { ascending: false })
        .limit(10);
      if (!data?.length) return;
      const { data: dismissed } = await supabase
        .from('announcement_dismissals')
        .select('announcement_id')
        .eq('user_id', user.id);
      const dset = new Set((dismissed ?? []).map((d) => d.announcement_id));
      const next = data.find((a) => !dset.has(a.id)) as Ann | undefined;
      setAnn(next ?? null);
    })();
  }, [user]);

  const dismiss = async () => {
    if (!ann || !user) return;
    await supabase.from('announcement_dismissals').insert({ user_id: user.id, announcement_id: ann.id });
    setAnn(null);
  };

  if (!ann) return null;
  const tone = ann.severity === 'critical' ? 'bg-red-600' : ann.severity === 'warning' ? 'bg-amber-500' : 'bg-mxit-primary';
  return (
    <div className={`${tone} text-white text-[12px] px-3 py-2 flex items-start gap-2 shrink-0`}>
      <Megaphone className="w-4 h-4 mt-0.5 shrink-0" />
      <div className="flex-1 min-w-0">
        <div className="font-semibold truncate">{ann.title}</div>
        <div className="opacity-90">{ann.body}</div>
      </div>
      <button onClick={dismiss} className="shrink-0"><X className="w-4 h-4" /></button>
    </div>
  );
}
