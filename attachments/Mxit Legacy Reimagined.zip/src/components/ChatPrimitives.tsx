/** Shared chat composer + bubbles — used by 1-on-1 and chatroom. */
import { useEffect, useRef, useState } from 'react';
import { Send, Smile, Trash2, ImagePlus, Mic, Square } from 'lucide-react';
import { EmoText } from './Emoticon';
import { EmoticonPicker } from './EmoticonPicker';
import { PixelAvatar } from './PixelAvatar';
import { sfx } from '@/lib/sfx';
import { cn } from '@/lib/utils';
import { Check, CheckCheck, Clock } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { CHAT_FILE_ACCEPT, isImageMessage, uploadChatImage } from '@/lib/chatMedia';
import {
  isVoiceMessage, buildVoiceMessage, uploadToBucket,
  VOICE_BUCKET, MAX_VOICE_BYTES,
} from '@/lib/statusMedia';
import { toast } from 'sonner';

export type ChatMessage = {
  id: string;
  sender_id: string;
  content: string;
  delivery: 'sending' | 'queued' | 'sent' | 'delivered' | 'read';
  created_at: string;
  reply_to_id?: string | null;
  forwarded_from?: string | null;
  expires_at?: string | null;
};

export type Sender = {
  id: string;
  display_name: string;
  avatar_seed: string | null;
  avatar_url: string | null;
};

interface MessageBubbleProps {
  msg: ChatMessage;
  isMe: boolean;
  sender?: Sender;
  showAvatar?: boolean;
  showName?: boolean;
  onDelete?: () => void;
  lowData?: boolean;
}

export function MessageBubble({ msg, isMe, sender, showAvatar, showName, onDelete, lowData }: MessageBubbleProps) {
  const [open, setOpen] = useState(false);
  const [revealed, setRevealed] = useState(false);
  const time = new Date(msg.created_at).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  const imgUrl = isImageMessage(msg.content);
  const voiceUrl = isVoiceMessage(msg.content);
  const isMedia = !!(imgUrl || voiceUrl);
  return (
    <div className={cn('flex gap-2 animate-fade-up', isMe ? 'justify-end' : 'justify-start')}>
      {!isMe && showAvatar && sender && (
        <PixelAvatar seed={sender.avatar_seed} url={sender.avatar_url} size={32} className="mt-auto" idle />
      )}
      {!isMe && !showAvatar && <div className="w-8 shrink-0" />}
      <div className={cn('max-w-[78%] flex flex-col', isMe ? 'items-end' : 'items-start')}>
        {showName && !isMe && sender && (
          <div className="text-[10px] text-mxit-primary font-pixel mb-0.5 px-1">{sender.display_name}</div>
        )}
        <button
          onClick={() => isMe && setOpen((o) => !o)}
          className={cn(
            'rounded-2xl text-sm leading-snug pixel-corner relative break-words',
            isMedia ? 'p-1 bg-transparent' : 'px-3 py-2',
            !isMedia && (isMe
              ? 'bg-mxit-bubble-me text-white rounded-br-md mxit-shadow-pop'
              : 'bg-mxit-bubble-them text-foreground rounded-bl-md mxit-shadow-pop')
          )}
        >
          {(() => {
            // [reply-status:kind]preview[/reply-status]\nbody
            const replyMatch = msg.content.match(/^\[reply-status:([a-z]+)\]([\s\S]*?)\[\/reply-status\]\n?([\s\S]*)$/);
            if (replyMatch) {
              const [, kind, preview, body] = replyMatch;
              return (
                <div className="space-y-1">
                  <div className="text-[10px] uppercase tracking-wider opacity-70 border-l-2 border-current/50 pl-2 italic">
                    Replying to status · {kind}{preview ? ` — ${preview}` : ''}
                  </div>
                  <EmoText text={body} size={20} />
                </div>
              );
            }
            if (voiceUrl) {
              return <audio controls src={voiceUrl} className="block h-10 max-w-[260px]" />;
            }
            if (!imgUrl) return <EmoText text={msg.content} size={20} />;
            if (lowData && !revealed) {
              return (
                <span
                  onClick={(e) => { e.stopPropagation(); setRevealed(true); }}
                  className="inline-flex items-center gap-1 text-[12px] px-2 py-1 rounded bg-black/10 border border-black/20 text-foreground/70"
                >
                  📷 Tap to load image
                </span>
              );
            }
            return (
              <a href={imgUrl} target="_blank" rel="noreferrer" onClick={(e) => e.stopPropagation()}>
                <img src={imgUrl} alt="shared" className="max-h-56 max-w-full rounded-xl block" loading="lazy" />
              </a>
            );
          })()}
        </button>
        <div className={cn('flex items-center gap-1 mt-0.5 px-1 text-[10px] text-muted-foreground', isMe ? 'flex-row-reverse' : '')}>
          <span>{time}</span>
          {isMe && (
            msg.delivery === 'sending' || msg.delivery === 'queued' ? <Clock className="w-3 h-3" /> :
            msg.delivery === 'sent' ? <Check className="w-3 h-3" /> :
            msg.delivery === 'delivered' ? <CheckCheck className="w-3 h-3" /> :
            <CheckCheck className="w-3 h-3 text-mxit-glow" />
          )}
        </div>
        {open && isMe && onDelete && (
          <button onClick={() => { sfx.tap(); onDelete(); setOpen(false); }}
            className="mt-1 text-xs text-destructive flex items-center gap-1 hover:underline">
            <Trash2 className="w-3 h-3" /> delete
          </button>
        )}
      </div>
    </div>
  );
}

export function TypingIndicator({ name }: { name: string }) {
  return (
    <div className="flex items-end gap-2 animate-fade-up px-1">
      <div className="bg-mxit-bubble-them rounded-2xl rounded-bl-md px-3 py-2 mxit-shadow-pop flex items-center gap-1">
        <span className="w-1.5 h-1.5 bg-muted-foreground rounded-full animate-typing-1" />
        <span className="w-1.5 h-1.5 bg-muted-foreground rounded-full animate-typing-2" />
        <span className="w-1.5 h-1.5 bg-muted-foreground rounded-full animate-typing-3" />
      </div>
      <span className="text-[10px] text-muted-foreground">{name} is typing…</span>
    </div>
  );
}

interface ComposerProps {
  onSend: (text: string) => void;
  onTyping?: () => void;
  disabled?: boolean;
}

export function Composer({ onSend, onTyping, disabled }: ComposerProps) {
  const { profile } = useAuth();
  const lowData = !!profile?.low_data_mode;
  const [text, setText] = useState('');
  const [picker, setPicker] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [recording, setRecording] = useState(false);
  const [recSecs, setRecSecs] = useState(0);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const recRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const recTimerRef = useRef<number | null>(null);

  const submit = () => {
    const t = text.trim();
    if (!t || disabled) return;
    onSend(t);
    setText('');
    sfx.send();
    inputRef.current?.focus();
  };

  const handleFile = async (file: File | null) => {
    if (!file || !profile) return;
    setUploading(true);
    const res = await uploadChatImage(file, profile.id);
    setUploading(false);
    if ('error' in res) { sfx.error(); toast.error(res.error); return; }
    onSend(`[img]${res.url}[/img]`);
    sfx.send();
  };

  const startRecording = async () => {
    if (!profile || disabled || recording) return;
    sfx.tap();
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const rec = new MediaRecorder(stream);
      chunksRef.current = [];
      rec.ondataavailable = (e) => { if (e.data.size > 0) chunksRef.current.push(e.data); };
      rec.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        if (recTimerRef.current) { window.clearInterval(recTimerRef.current); recTimerRef.current = null; }
        setRecSecs(0);
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
        if (blob.size === 0) return;
        if (blob.size > MAX_VOICE_BYTES) { toast.error('Voice note too long (max ~8 MB)'); return; }
        setUploading(true);
        const res = await uploadToBucket(VOICE_BUCKET, blob, profile.id, 'webm', 'audio/webm');
        setUploading(false);
        if ('error' in res) { sfx.error(); toast.error(res.error); return; }
        onSend(buildVoiceMessage(res.url));
        sfx.send();
      };
      rec.start();
      recRef.current = rec;
      setRecording(true);
      recTimerRef.current = window.setInterval(() => setRecSecs((s) => s + 1), 1000);
    } catch (e: any) {
      sfx.error();
      toast.error(e.message || 'Microphone permission denied');
    }
  };

  const stopRecording = () => {
    sfx.tap();
    recRef.current?.stop();
    recRef.current = null;
    setRecording(false);
  };

  return (
    <div className="relative bg-card border-t border-border safe-bottom">
      {picker && <EmoticonPicker onPick={(c) => { setText((t) => t + c); setPicker(false); inputRef.current?.focus(); }} onClose={() => setPicker(false)} />}
      <input
        ref={fileRef}
        type="file"
        accept={CHAT_FILE_ACCEPT}
        className="hidden"
        onChange={(e) => { handleFile(e.target.files?.[0] ?? null); e.target.value = ''; }}
      />
      <div className="flex items-end gap-2 p-2">
        <button onClick={() => { sfx.tap(); setPicker((p) => !p); }} className="p-2 text-mxit-primary hover:bg-mxit-primary/10 rounded-lg tap-scale" aria-label="emoticons">
          <Smile className="w-5 h-5" />
        </button>
        {!lowData && (
          <button
            onClick={() => { sfx.tap(); fileRef.current?.click(); }}
            disabled={disabled || uploading || recording}
            className="p-2 text-mxit-primary hover:bg-mxit-primary/10 rounded-lg tap-scale disabled:opacity-40"
            aria-label="attach image"
            title="Send image or GIF"
          >
            <ImagePlus className="w-5 h-5" />
          </button>
        )}
        <button
          onClick={recording ? stopRecording : startRecording}
          disabled={disabled || uploading}
          className={cn(
            'p-2 rounded-lg tap-scale disabled:opacity-40',
            recording ? 'bg-destructive text-white animate-pulse-soft' : 'text-mxit-primary hover:bg-mxit-primary/10',
          )}
          aria-label={recording ? 'stop recording' : 'record voice note'}
          title={recording ? 'Stop & send' : 'Record voice note'}
        >
          {recording ? <Square className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
        </button>
        {recording ? (
          <div className="flex-1 flex items-center gap-2 bg-destructive/10 rounded-2xl px-3 py-2 text-sm text-destructive">
            <span className="w-2 h-2 bg-destructive rounded-full animate-pulse-soft" />
            Recording… {Math.floor(recSecs / 60)}:{String(recSecs % 60).padStart(2, '0')}
          </div>
        ) : (
          <textarea
            ref={inputRef}
            value={text}
            onChange={(e) => { setText(e.target.value); onTyping?.(); }}
            onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); submit(); } }}
            placeholder={uploading ? 'Sending…' : 'Type a message…'}
            rows={1}
            disabled={disabled || uploading}
            className="flex-1 bg-secondary rounded-2xl px-4 py-2 text-sm resize-none max-h-32 focus:outline-none focus:ring-2 focus:ring-mxit-primary/30"
            style={{ minHeight: '40px' }}
          />
        )}
        <button
          onClick={recording ? stopRecording : submit}
          disabled={disabled || (!recording && !text.trim())}
          className="p-2 bg-mxit-primary text-white rounded-full tap-scale mxit-shadow-inset disabled:opacity-50"
          aria-label="send"
        >
          <Send className="w-5 h-5" />
        </button>
      </div>
    </div>
  );
}
