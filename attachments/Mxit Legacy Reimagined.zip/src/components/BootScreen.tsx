import { useEffect, useState } from 'react';
import logo from '@/assets/mxit-legacy-watermark.png';
import { sfx } from '@/lib/sfx';

export function BootScreen({ onDone }: { onDone: () => void }) {
  const [phase, setPhase] = useState<'logo' | 'loading' | 'gone'>('logo');

  useEffect(() => {
    sfx.boot();
    const t1 = setTimeout(() => setPhase('loading'), 900);
    const t2 = setTimeout(() => setPhase('gone'), 3200);
    const t3 = setTimeout(onDone, 3500);
    return () => { clearTimeout(t1); clearTimeout(t2); clearTimeout(t3); };
  }, [onDone]);

  return (
    <div
      onClick={onDone}
      className={`fixed inset-0 z-50 overflow-hidden bg-black transition-opacity duration-500 ${
        phase === 'gone' ? 'opacity-0 pointer-events-none' : 'opacity-100'
      }`}
    >
      {/* Cinematic vignette + lens flare */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_60%_50%_at_55%_45%,hsl(0_0%_18%)_0%,hsl(0_0%_4%)_55%,#000_100%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_72%_38%,hsl(20_90%_75%/0.35),transparent_18%)] animate-pulse-soft" />

      {/* Sweeping ribbon scratches */}
      <div className="absolute inset-0 opacity-80">
        <div className="absolute left-[-10%] right-[-10%] top-1/2 -translate-y-1/2 h-[60%] rotate-[-12deg] [mask-image:radial-gradient(ellipse_at_center,black_40%,transparent_75%)]">
          <div className="absolute inset-x-0 top-[28%] h-px bg-gradient-to-r from-transparent via-white/60 to-transparent blur-[0.5px]" />
          <div className="absolute inset-x-0 top-[42%] h-px bg-gradient-to-r from-transparent via-white/30 to-transparent blur-[1px]" />
          <div className="absolute inset-x-0 top-[58%] h-px bg-gradient-to-r from-transparent via-white/50 to-transparent" />
          <div className="absolute inset-x-0 top-[70%] h-px bg-gradient-to-r from-transparent via-white/20 to-transparent blur-[1.5px]" />
        </div>
      </div>

      {/* JOIN THE EVOLUTION ticker — typographic stripe */}
      <div className="absolute inset-x-0 top-1/2 -translate-y-1/2 h-12 overflow-hidden opacity-30 select-none">
        <div className="whitespace-nowrap font-pixel text-white text-[18px] tracking-[0.3em] animate-[boot-scan_8s_linear_infinite]">
          {'JOIN·THE·EVOLUTION·'.repeat(20)}
        </div>
      </div>

      {/* Logo */}
      <div className="relative h-full w-full flex flex-col items-center justify-center px-6">
        <img
          src={logo}
          alt="mxit — The Legacy"
          className="w-[92%] max-w-[560px] h-auto animate-fade-up mix-blend-screen"
          style={{ filter: 'drop-shadow(0 0 30px hsl(0 0% 100% / 0.15))' }}
        />

        {/* Loading bar appears in phase 2 */}
        <div className={`mt-12 transition-opacity duration-500 ${phase === 'logo' ? 'opacity-0' : 'opacity-100'}`}>
          <div className="w-56 h-[3px] bg-white/10 rounded overflow-hidden">
            <div className="h-full bg-gradient-to-r from-white/40 via-white to-white/40 animate-boot-scan" />
          </div>
          <div className="mt-4 text-center font-mono-pixel text-white/50 text-xs tracking-[0.3em] uppercase">
            connecting
          </div>
        </div>
      </div>

      <div className="absolute bottom-6 inset-x-0 text-center text-[10px] text-white/30 font-mono-pixel tracking-widest">
        TAP TO SKIP · EST. 2005
      </div>
    </div>
  );
}
