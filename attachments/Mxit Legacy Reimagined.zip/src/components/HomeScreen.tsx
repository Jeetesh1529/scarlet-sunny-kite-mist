import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth, Presence } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { sfx, setSoundEnabled } from '@/lib/sfx';
import { ContactsTab } from './tabs/ContactsTab';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Textarea } from '@/components/ui/textarea';
import { PixelAvatar } from '@/components/PixelAvatar';
import { AVATAR_SEEDS } from '@/lib/avatars';
import { toast } from 'sonner';
import { ChevronRight, Coins, LogOut, Palette, Save, Sun, Moon, Monitor, Volume2, Camera, X } from 'lucide-react';
import { getMode, setMode as applyDisplayMode, type DisplayMode } from '@/lib/mode';
import { uploadToBucket, AVATAR_BUCKET, MAX_AVATAR_BYTES } from '@/lib/statusMedia';
import { BlockListPanel } from '@/components/BlockListPanel';
import { AchievementsPanel } from '@/components/AchievementsPanel';

type View = 'contacts' | 'profile' | 'multimx' | 'settings' | 'help';

const PRESENCES: { p: Presence; label: string; orb: string }[] = [
  { p: 'online',  label: 'Available', orb: 'orb-online' },
  { p: 'away',    label: 'Away',      orb: 'orb-away' },
  { p: 'busy',    label: 'Busy',      orb: 'orb-busy' },
  { p: 'offline', label: 'Invisible', orb: 'orb-offline' },
];

/** Classic Mxit "Presence" mood list. Each mood maps to an online status. */
const MOODS: { label: string; emoticon: string; presence: Presence }[] = [
  { label: 'Happy',      emoticon: ':)',       presence: 'online' },
  { label: 'Sad',        emoticon: ':(',       presence: 'online' },
  { label: 'Excited',    emoticon: ':D',       presence: 'online' },
  { label: 'Invincible', emoticon: '(cool)',   presence: 'online' },
  { label: 'Hot',        emoticon: '(blush)',  presence: 'online' },
  { label: 'Angry',      emoticon: '(rage)',   presence: 'busy'   },
  { label: 'Grumpy',     emoticon: '(evil)',   presence: 'busy'   },
  { label: 'Sick',       emoticon: '(dizzy)',  presence: 'away'   },
  { label: 'In love',    emoticon: '<3',       presence: 'online' },
  { label: 'Sleepy',     emoticon: ':|',       presence: 'away'   },
  { label: 'None',       emoticon: '',         presence: 'online' },
];

const THEMES = [
  { id: 'classic', name: 'Classic Blue', swatch: '#1E78D6' },
  { id: 'green',   name: 'Lime',         swatch: '#2E9F4D' },
  { id: 'pink',    name: 'Bubble',       swatch: '#E04B98' },
  { id: 'black',   name: 'Midnight',     swatch: '#111111' },
];

export function HomeScreen() {
  const { profile, signOut, setPresence, refreshProfile } = useAuth();
  const navigate = useNavigate();
  const [view, setView] = useState<View>('contacts');

  useEffect(() => {
    if (!profile) return;
    const ch = supabase
      .channel('home-contacts')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'contacts', filter: `addressee_id=eq.${profile.id}` }, () => {})
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [profile?.id]);

  if (!profile) return null;

  const open = (v: View) => { sfx.tap(); setView(v); };

  return (
    <div className="flex-1 min-h-0 flex flex-col relative overflow-hidden">
      {view === 'contacts' && <ContactsTab onViewChange={open} />}
      {view === 'profile' && <ProfileView onBack={() => setView('contacts')} />}
      {view === 'multimx' && <MultiMxView onBack={() => setView('contacts')} />}
      {view === 'settings' && <SettingsView onBack={() => setView('contacts')} />}
      {view === 'help' && <HelpView onBack={() => setView('contacts')} />}
    </div>
  );
}

/* ============== PROFILE ============== */

function ChromeFrame({
  title, onBack, children,
}: { title: string; onBack: () => void; children: React.ReactNode }) {
  return (
    <div className="flex-1 min-h-0 flex flex-col mxit-classic-bg">
      <div className="mxit-titlebar h-9 flex items-center px-3 gap-2 shrink-0">
        <button onClick={() => { sfx.tap(); onBack(); }} className="text-[11px] px-2 py-0.5 rounded-sm bg-white/10 border border-white/20">‹ Back</button>
        <div className="flex-1 text-center font-semibold text-[15px] tracking-wide">{title}</div>
        <span className="status-orb orb-online" />
      </div>
      <div className="relative flex-1 overflow-y-auto mxit-watermark min-h-0">
        <div className="relative z-10 p-3 space-y-3 text-white">{children}</div>
      </div>
      <div className="mxit-softkeys h-10 flex items-stretch text-sm font-medium shrink-0">
        <button onClick={() => { sfx.tap(); onBack(); }} className="flex-1 text-left pl-4 active:bg-black/30">Back</button>
        <button onClick={() => { sfx.tap(); onBack(); }} className="flex-1 text-right pr-4 active:bg-black/30">OK</button>
      </div>
    </div>
  );
}

function Card({ children }: { children: React.ReactNode }) {
  return (
    <section className="bg-white/8 border border-white/15 rounded-md p-3 backdrop-blur-sm space-y-2">
      {children}
    </section>
  );
}

function ProfileView({ onBack }: { onBack: () => void }) {
  const { profile, refreshProfile, setPresence } = useAuth();
  const [displayName, setDisplayName] = useState(profile?.display_name ?? '');
  const [mood, setMood] = useState(profile?.mood ?? '');
  const [farewell, setFarewell] = useState(profile?.farewell ?? '');
  const [avatarSeed, setAvatarSeed] = useState(profile?.avatar_seed ?? AVATAR_SEEDS[0]);
  const [busy, setBusy] = useState(false);
  if (!profile) return null;

  const save = async () => {
    setBusy(true);
    const { error } = await supabase.from('profiles').update({
      display_name: displayName.trim() || profile.display_name,
      mood: mood.trim(),
      farewell: farewell.trim() || null,
      avatar_seed: avatarSeed,
    }).eq('id', profile.id);
    setBusy(false);
    if (error) { sfx.error(); toast.error(error.message); return; }
    toast.success('Profile saved');
    refreshProfile();
  };

  return (
    <ChromeFrame title="My profile" onBack={onBack}>
      <Card>
        <div className="flex items-center gap-3">
          <PixelAvatar seed={avatarSeed} url={profile.avatar_url} size={56} />
          <div className="flex-1 min-w-0">
            <div className="font-pixel text-[10px] text-white/80">@{profile.mxit_id}</div>
            <div className="font-medium truncate">{displayName || profile.display_name}</div>
            <div className="text-[11px] text-amber-300 flex items-center gap-1">
              <Coins className="w-3 h-3" /> {profile.moola} Moola
            </div>
          </div>
        </div>
      </Card>

      <Card>
        <div className="font-medium text-[12px] uppercase opacity-80">Status</div>
        <div className="grid grid-cols-2 gap-2">
          {PRESENCES.map(({ p, label, orb }) => (
            <button
              key={p}
              onClick={async () => { sfx.tap(); await setPresence(p); }}
              className={`flex items-center gap-2 px-2 py-1.5 rounded border ${
                profile.presence === p
                  ? 'bg-white/15 border-white/40'
                  : 'border-white/10 hover:bg-white/5'
              }`}
            >
              <span className={`status-orb ${orb}`} />
              <span className="text-[13px]">{label}</span>
            </button>
          ))}
        </div>
      </Card>

      <Card>
        <Label className="text-white/80 text-[12px]">Display name</Label>
        <Input value={displayName} onChange={(e) => setDisplayName(e.target.value)} className="bg-white/10 border-white/20 text-white placeholder:text-white/40" />

        <Label className="text-white/80 text-[12px] pt-1">Mood message</Label>
        <Input value={mood} onChange={(e) => setMood(e.target.value)} maxLength={80} placeholder="Hey there! I'm on Mxit." className="bg-white/10 border-white/20 text-white placeholder:text-white/40" />

        <Label className="text-white/80 text-[12px] pt-1">Farewell message (sent on logout)</Label>
        <Textarea value={farewell} onChange={(e) => setFarewell(e.target.value)} maxLength={140} rows={2} placeholder="Catch ya later! ✌️" className="bg-white/10 border-white/20 text-white placeholder:text-white/40" />
      </Card>

      <Card>
        <div className="font-medium text-[12px] uppercase opacity-80">Profile picture</div>
        <ProfilePicUpload />
        <div className="font-medium text-[12px] uppercase opacity-80 pt-2">Or pick a pixel avatar</div>
        <div className="grid grid-cols-5 gap-2">
          {AVATAR_SEEDS.map((s) => (
            <button
              key={s}
              onClick={() => { setAvatarSeed(s); sfx.tap(); }}
              className={`p-1 rounded ${avatarSeed === s ? 'bg-amber-400/30 ring-1 ring-amber-300' : 'bg-white/5'}`}
            >
              <PixelAvatar seed={s} size={40} />
            </button>
          ))}
        </div>
      </Card>

      <Button onClick={save} disabled={busy} className="w-full">
        <Save className="w-4 h-4 mr-2" /> Save profile
      </Button>

      <Card>
        <div className="font-medium text-[12px] uppercase opacity-80">Achievements</div>
        <AchievementsPanel userId={profile.id} />
      </Card>
    </ChromeFrame>
  );
}

function ProfilePicUpload() {
  const { profile, refreshProfile } = useAuth();
  const fileRef = useRef<HTMLInputElement>(null);
  const [busy, setBusy] = useState(false);
  if (!profile) return null;

  const onPick = async (file: File | null) => {
    if (!file) return;
    if (file.size > MAX_AVATAR_BYTES) { toast.error('Image too large (max 4 MB)'); return; }
    setBusy(true);
    const ext = (file.name.split('.').pop() || 'jpg').toLowerCase();
    const res = await uploadToBucket(AVATAR_BUCKET, file, profile.id, ext);
    if ('error' in res) { setBusy(false); toast.error(res.error); return; }
    const { error } = await supabase.from('profiles').update({ avatar_url: res.url }).eq('id', profile.id);
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    toast.success('Profile picture updated');
    refreshProfile();
  };

  const removePhoto = async () => {
    setBusy(true);
    await supabase.from('profiles').update({ avatar_url: null }).eq('id', profile.id);
    setBusy(false);
    refreshProfile();
  };

  return (
    <div className="flex items-center gap-3">
      <PixelAvatar seed={profile.avatar_seed} url={profile.avatar_url} size={56} />
      <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={(e) => { onPick(e.target.files?.[0] ?? null); e.target.value = ''; }} />
      <Button size="sm" onClick={() => fileRef.current?.click()} disabled={busy}>
        <Camera className="w-4 h-4 mr-1" /> {profile.avatar_url ? 'Change photo' : 'Upload photo'}
      </Button>
      {profile.avatar_url && (
        <Button size="sm" variant="secondary" onClick={removePhoto} disabled={busy}>
          <X className="w-4 h-4 mr-1" /> Remove
        </Button>
      )}
    </div>
  );
}


function MultiMxView({ onBack }: { onBack: () => void }) {
  const navigate = useNavigate();
  const [rooms, setRooms] = useState<{ id: string; name: string; topic: string | null }[]>([]);
  useEffect(() => { (async () => {
    const { data } = await supabase.from('chatrooms').select('id, name, topic').order('name');
    setRooms(data ?? []);
  })(); }, []);
  return (
    <ChromeFrame title="MultiMx" onBack={onBack}>
      <Card>
        <div className="text-[12px] opacity-80">Public chatrooms — jump in and chat with anyone.</div>
      </Card>
      {rooms.length === 0 && <div className="text-white/60 text-sm italic">No rooms yet.</div>}
      {rooms.map((r) => (
        <button
          key={r.id}
          onClick={() => { sfx.tap(); navigate(`/room/${r.id}`); }}
          className="w-full bg-white/8 border border-white/15 rounded-md p-3 flex items-center gap-3 hover:bg-white/12"
        >
          <span className="status-orb orb-online" />
          <div className="flex-1 text-left">
            <div className="font-medium">{r.name}</div>
            {r.topic && <div className="text-[11px] text-white/60">{r.topic}</div>}
          </div>
          <ChevronRight className="w-4 h-4 text-white/60" />
        </button>
      ))}
    </ChromeFrame>
  );
}

/* ============== SETTINGS (skin, sound, auto-away, hide offline) ============== */

function SettingsView({ onBack }: { onBack: () => void }) {
  const { profile, refreshProfile, signOut } = useAuth();
  const [mode, setModeState] = useState<DisplayMode>(getMode());
  const [confirmDelete, setConfirmDelete] = useState(false);
  const [confirmText, setConfirmText] = useState('');
  const [deleting, setDeleting] = useState(false);
  if (!profile) return null;

  const changeMode = (m: DisplayMode) => {
    sfx.tap();
    applyDisplayMode(m);
    setModeState(m);
  };

  const setTheme = async (t: string) => {
    sfx.tap();
    document.documentElement.setAttribute('data-theme', t);
    await supabase.from('profiles').update({ theme: t }).eq('id', profile.id);
    refreshProfile();
  };
  const toggleSound = async (on: boolean) => {
    setSoundEnabled(on);
    await supabase.from('profiles').update({ sound_enabled: on }).eq('id', profile.id);
    refreshProfile();
    if (on) sfx.tap();
  };
  const toggleHideOffline = async (on: boolean) => {
    sfx.tap();
    await supabase.from('profiles').update({ hide_offline: on }).eq('id', profile.id);
    refreshProfile();
  };
  const setAutoAway = async (n: number) => {
    await supabase.from('profiles').update({ auto_away_minutes: n }).eq('id', profile.id);
    refreshProfile();
  };

  const deleteAccount = async () => {
    if (confirmText.trim().toLowerCase() !== 'delete') {
      toast.error('Type DELETE to confirm.');
      return;
    }
    setDeleting(true);
    try {
      const { error } = await supabase.rpc('delete_my_account');
      if (error) throw error;
      toast.success('Your account has been deleted.');
      await supabase.auth.signOut();
      window.location.href = '/';
    } catch (e: any) {
      sfx.error();
      toast.error(e.message || 'Could not delete account');
      setDeleting(false);
    }
  };

  return (
    <ChromeFrame title="Settings" onBack={onBack}>
      <Card>
        <div className="font-medium text-[12px] uppercase opacity-80 flex items-center gap-2"><Palette className="w-3.5 h-3.5" /> Skin</div>
        <div className="grid grid-cols-4 gap-2">
          {THEMES.map((t) => (
            <button
              key={t.id}
              onClick={() => setTheme(t.id)}
              className={`p-2 rounded flex flex-col items-center gap-1 ${profile.theme === t.id ? 'bg-white/15 ring-1 ring-amber-300' : 'bg-white/5'}`}
            >
              <div className="w-8 h-8 rounded-full border border-white/30" style={{ background: t.swatch }} />
              <div className="text-[10px]">{t.name}</div>
            </button>
          ))}
        </div>
      </Card>

      <Card>
        <div className="font-medium text-[12px] uppercase opacity-80">Display mode</div>
        <div className="grid grid-cols-3 gap-2">
          {([
            { id: 'normal', label: 'Normal', Icon: Monitor },
            { id: 'light',  label: 'Light',  Icon: Sun },
            { id: 'dark',   label: 'Dark',   Icon: Moon },
          ] as const).map(({ id, label, Icon }) => (
            <button
              key={id}
              onClick={() => changeMode(id)}
              className={`p-2 rounded flex flex-col items-center gap-1 ${mode === id ? 'bg-white/15 ring-1 ring-amber-300' : 'bg-white/5'}`}
            >
              <Icon className="w-5 h-5" />
              <div className="text-[10px]">{label}</div>
            </button>
          ))}
        </div>
      </Card>

      <Card>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2"><Volume2 className="w-4 h-4" /><span className="text-[13px]">Sound effects</span></div>
          <Switch checked={profile.sound_enabled} onCheckedChange={toggleSound} />
        </div>
      </Card>

      <Card>
        <div className="flex items-center justify-between">
          <span className="text-[13px]">Hide offline contacts</span>
          <Switch checked={profile.hide_offline} onCheckedChange={toggleHideOffline} />
        </div>
        <div className="flex items-center justify-between pt-1">
          <span className="text-[13px]">Read receipts</span>
          <Switch
            checked={(profile as any).read_receipts_enabled ?? true}
            onCheckedChange={async (on) => {
              sfx.tap();
              await supabase.from('profiles').update({ read_receipts_enabled: on } as any).eq('id', profile.id);
              refreshProfile();
            }}
          />
        </div>
      </Card>

      <Card>
        <div className="text-[13px]">Auto-away after</div>
        <div className="flex gap-2">
          {[2, 5, 10, 30].map((n) => (
            <button
              key={n}
              onClick={() => { sfx.tap(); setAutoAway(n); }}
              className={`flex-1 py-1.5 rounded text-[12px] border ${profile.auto_away_minutes === n ? 'bg-white/15 border-white/40' : 'border-white/10 bg-white/5'}`}
            >
              {n} min
            </button>
          ))}
        </div>
      </Card>

      <BlockListPanel />

      <Card>
        <div className="font-medium text-[12px] uppercase opacity-80">Legal</div>
        <div className="flex flex-col gap-1.5 text-[13px]">
          <a href="/legal/privacy" className="underline text-white/85 hover:text-white">Privacy Policy</a>
          <a href="/legal/terms" className="underline text-white/85 hover:text-white">Terms of Service</a>
        </div>
      </Card>

      <Card>
        <div className="font-medium text-[12px] uppercase opacity-80">Account</div>
        <Button
          variant="secondary"
          onClick={async () => { sfx.tap(); await signOut(); window.location.href = '/'; }}
          className="w-full"
        >
          <LogOut className="w-4 h-4 mr-2" /> Sign out
        </Button>
      </Card>

      <section className="bg-red-900/30 border border-red-500/40 rounded-md p-3 space-y-2">
        <div className="font-pixel text-[10px] text-red-300">DANGER ZONE</div>
        {!confirmDelete ? (
          <>
            <p className="text-[12px] text-white/85">
              Permanently delete your account, profile, contacts, messages, and Moola balance. This cannot be undone.
            </p>
            <Button
              variant="destructive"
              onClick={() => { sfx.tap(); setConfirmDelete(true); }}
              className="w-full"
            >
              Delete my account
            </Button>
          </>
        ) : (
          <>
            <p className="text-[12px] text-white/85">
              Type <b>DELETE</b> below to confirm. Your data will be erased immediately.
            </p>
            <Input
              value={confirmText}
              onChange={(e) => setConfirmText(e.target.value)}
              placeholder="DELETE"
              className="bg-white/10 border-white/20 text-white"
            />
            <div className="flex gap-2">
              <Button
                variant="destructive"
                onClick={deleteAccount}
                disabled={deleting || confirmText.trim().toLowerCase() !== 'delete'}
                className="flex-1"
              >
                {deleting ? 'Deleting…' : 'Confirm delete'}
              </Button>
              <Button
                variant="secondary"
                onClick={() => { setConfirmDelete(false); setConfirmText(''); }}
                disabled={deleting}
                className="flex-1"
              >
                Cancel
              </Button>
            </div>
          </>
        )}
      </section>
    </ChromeFrame>
  );
}

/* ============== HELP ============== */

function HelpView({ onBack }: { onBack: () => void }) {
  return (
    <ChromeFrame title="Help" onBack={onBack}>
      <Card>
        <div className="font-medium">Status orbs</div>
        <ul className="text-[12px] space-y-1 text-white/85">
          <li className="flex items-center gap-2"><span className="status-orb orb-online" /> Available</li>
          <li className="flex items-center gap-2"><span className="status-orb orb-away" /> Away</li>
          <li className="flex items-center gap-2"><span className="status-orb orb-busy" /> Busy</li>
          <li className="flex items-center gap-2"><span className="status-orb orb-offline" /> Offline / Invisible</li>
          <li className="flex items-center gap-2"><span className="status-orb orb-invite" /> Pending invite</li>
        </ul>
      </Card>
      <Card>
        <div className="font-medium">Tips</div>
        <ul className="text-[12px] space-y-1 text-white/80 list-disc list-inside">
          <li>Tap a contact to chat one-on-one. Long-press to move them into a custom group.</li>
          <li>Add friends by their Mxit ID — they'll appear as a blue dot until they accept.</li>
          <li><strong>MultiMx</strong> = private group chat. Create a room, invite your contacts — free.</li>
          <li><strong>Tradepost</strong> = the mall. Skinz, Emoticards, Horoscopes, Weather, Games and public Chat Rooms.</li>
          <li><strong>Joe Banker</strong> = your apps hub: Banker Bot (top up Moola), Moola Hub, Dr Math, Trivit, Horoscope and more.</li>
          <li>Tap the <strong>🔍</strong> in the bottom bar to search contacts, rooms, services and games.</li>
          <li>Set a farewell message that auto-broadcasts to all contacts when you log out.</li>
          <li>Earn <strong>Achievements</strong> as you chat, send Moola and play — view them on your profile.</li>
        </ul>
      </Card>

      <Card>
        <div className="font-medium">Everything Mxit has to offer</div>
        <ul className="text-[12px] space-y-1 text-white/80 list-disc list-inside">
          <li><strong>1-on-1 chat</strong> with read receipts, typing dots, translate, reply &amp; reactions.</li>
          <li><strong>MultiMx</strong> private group chats with admins, invites and shared media.</li>
          <li><strong>Chat Rooms</strong> — public zones, numbered rooms, max 7 people, 2 Moola/msg.</li>
          <li><strong>Status</strong> updates with mood, message and seen-by counter.</li>
          <li><strong>Confessions</strong> — anonymous wall, upvotes &amp; comments.</li>
          <li><strong>Polls</strong> — quick community votes.</li>
          <li><strong>Meet</strong> — discover nearby Mxit users.</li>
          <li><strong>Leaderboards</strong> — top chatters, top Moola, top games.</li>
          <li><strong>Achievements</strong> — unlock badges as you use the app.</li>
          <li><strong>Joe Banker</strong> apps: Banker Bot, Moola Hub (daily spin · send · receive), Dr Math, Horoscope, Trivit, Moola Shop.</li>
          <li><strong>Tradepost</strong>: Skinz, Emoticards, Horoscopes, Weather, Games (incl. Moonbase, TicTacToe), Music Room.</li>
          <li><strong>Moola</strong> economy — daily bonus, send Moola to friends, gift in chat.</li>
          <li><strong>Custom contact groups</strong> — make your own folders and move contacts in.</li>
          <li><strong>Skinz</strong> — buy &amp; apply themes app-wide.</li>
          <li><strong>Global search</strong> across contacts, rooms, services &amp; games.</li>
          <li><strong>Settings</strong> — mood, theme, read receipts, notifications, privacy.</li>
        </ul>
      </Card>

      <Card>
        <div className="font-medium">Version</div>
        <div className="text-[12px] text-white/80 mt-1 space-y-0.5">
          <div>Mxit · The Legacy</div>
          <div>Build <span className="font-pixel">{(import.meta.env.VITE_BUILD_ID as string | undefined) ?? new Date().toISOString().slice(0, 10)}</span></div>
          <div className="text-white/60">v1.0.0 · web edition</div>
        </div>
      </Card>
    </ChromeFrame>
  );
}
