import { useState } from 'react';
import { EMOTICONS } from '@/lib/emoticons';
import { Emoticon } from './Emoticon';
import { sfx } from '@/lib/sfx';

interface Props {
  onPick: (code: string) => void;
  onClose: () => void;
}

// Themed sticker packs — large emoji used as one-shot stickers.
const PACKS: { id: string; label: string; stickers: string[] }[] = [
  {
    id: 'classic', label: 'Classic',
    stickers: ['🎉', '🔥', '💯', '👀', '🤣', '😍', '🥺', '😎', '🙌', '👏', '🤝', '💪', '🫶', '🫡', '🤗', '🤔'],
  },
  {
    id: 'mzansi', label: 'Mzansi',
    stickers: ['🇿🇦', '🦓', '🦁', '🐘', '🦏', '🦒', '🌍', '☀️', '🌅', '🌵', '🥩', '🍖', '🥬', '🍌', '⚽', '🏉'],
  },
  {
    id: 'love', label: 'Love',
    stickers: ['❤️', '💔', '💖', '💘', '💝', '💞', '💕', '💓', '😘', '😍', '🥰', '😻', '🌹', '💐', '🌷', '✨'],
  },
  {
    id: 'animals', label: 'Animals',
    stickers: ['🐶', '🐱', '🐭', '🐹', '🐰', '🦊', '🐻', '🐼', '🐨', '🐯', '🦁', '🐮', '🐷', '🐸', '🐵', '🦄'],
  },
  {
    id: 'party', label: 'Party',
    stickers: ['🥳', '🎂', '🎁', '🎈', '🎊', '🍾', '🥂', '🍻', '🍕', '🍔', '🍟', '🍩', '🍦', '🍫', '☕', '🚀'],
  },
  {
    id: 'mood', label: 'Mood',
    stickers: ['😴', '🤯', '😵', '😬', '😅', '😭', '😡', '🥵', '🥶', '🤒', '🤧', '🤤', '🤐', '🙄', '😏', '🌚'],
  },
];

export function EmoticonPicker({ onPick, onClose }: Props) {
  const [tab, setTab] = useState<'emo' | string>('emo');
  const pack = PACKS.find((p) => p.id === tab);

  return (
    <div className="absolute bottom-full left-0 right-0 mb-2 mx-2 bg-card border border-border rounded-xl mxit-shadow-pop p-3 animate-fade-up z-20 max-h-72 overflow-y-auto">
      <div className="flex gap-1 mb-2 border-b border-border overflow-x-auto no-scrollbar">
        <button
          onClick={() => { sfx.tap(); setTab('emo'); }}
          className={`px-3 py-1.5 text-[11px] font-pixel whitespace-nowrap ${tab === 'emo' ? 'text-mxit-primary border-b-2 border-mxit-primary' : 'text-muted-foreground'}`}
        >
          EMO
        </button>
        {PACKS.map((p) => (
          <button
            key={p.id}
            onClick={() => { sfx.tap(); setTab(p.id); }}
            className={`px-3 py-1.5 text-[11px] font-pixel whitespace-nowrap uppercase ${tab === p.id ? 'text-mxit-primary border-b-2 border-mxit-primary' : 'text-muted-foreground'}`}
          >
            {p.label}
          </button>
        ))}
      </div>
      {tab === 'emo' ? (
        <div className="grid grid-cols-6 gap-2">
          {EMOTICONS.map((e) => (
            <button
              key={e.code}
              type="button"
              onClick={() => { sfx.tap(); onPick(e.code); }}
              className="aspect-square flex items-center justify-center rounded-md hover:bg-muted tap-scale"
              aria-label={e.label}
            >
              <Emoticon code={e.code} size={40} />
            </button>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-8 gap-1">
          {(pack?.stickers ?? []).map((s, i) => (
            <button
              key={`${pack?.id}-${i}`}
              type="button"
              onClick={() => { sfx.tap(); onPick(s); }}
              className="aspect-square flex items-center justify-center rounded-md hover:bg-muted tap-scale text-2xl"
            >
              {s}
            </button>
          ))}
        </div>
      )}
      <button type="button" onClick={onClose} className="mt-2 w-full text-xs text-muted-foreground py-1 hover:text-foreground">close</button>
    </div>
  );
}
