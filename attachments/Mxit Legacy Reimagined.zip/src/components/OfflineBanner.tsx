import { useEffect, useRef, useState } from 'react';
import { toast } from 'sonner';

export function OfflineBanner() {
  const [online, setOnline] = useState(typeof navigator === 'undefined' ? true : navigator.onLine);
  const wasOffline = useRef(false);
  useEffect(() => {
    const on = () => {
      setOnline(true);
      if (wasOffline.current) {
        toast.success('Back online', { duration: 2000 });
        wasOffline.current = false;
      }
    };
    const off = () => {
      setOnline(false);
      wasOffline.current = true;
      toast.error('You are offline', { description: 'Messages will send when you reconnect.', duration: 4000 });
    };
    window.addEventListener('online', on);
    window.addEventListener('offline', off);
    return () => {
      window.removeEventListener('online', on);
      window.removeEventListener('offline', off);
    };
  }, []);
  if (online) return null;
  return (
    <div className="w-full bg-yellow-400 text-black text-[12px] font-medium text-center py-1 px-2 border-b border-black/20">
      Offline — messages will send when you reconnect
    </div>
  );
}
