import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Calculator, Sparkles, Brain, Coins, ShoppingBag, Banknote, Grid3x3 } from 'lucide-react';
import { MxitHeader } from '@/components/MxitHeader';
import { Composer, MessageBubble, TypingIndicator } from '@/components/ChatPrimitives';
import { sfx } from '@/lib/sfx';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { PixelAvatar } from '@/components/PixelAvatar';
import { Button } from '@/components/ui/button';
import { MobiPortalTab } from '@/components/tabs/MobiPortalTab';

const APPS: Record<string, { name: string; icon: any; color: string; system: string; greeting: string }> = {
  drmath: {
    name: 'Dr Math', icon: Calculator, color: 'bg-mxit-primary',
    system: 'You are Dr Math, a friendly maths tutor on the original Mxit app from 2005, helping South African school kids. Explain step by step, keep it short and clear, use simple language. Use plain text only — no markdown. End with a quick encouraging line.',
    greeting: "Howzit! I'm Dr Math 8) Send me a maths problem and I'll work through it with you. Algebra, geometry, fractions — bring it on!",
  },
  horoscope: {
    name: 'Horoscope', icon: Sparkles, color: 'bg-purple-500',
    system: 'You are a playful astrologer for the Mxit Horoscope app. The user will tell you their star sign or birth date. Give a short, fun daily horoscope (3-4 sentences). Plain text only.',
    greeting: 'Welcome to your daily fortune ;) Tell me your star sign and I\'ll read what the stars say for you today.',
  },
  trivia: {
    name: 'Trivia', icon: Brain, color: 'bg-mxit-online',
    system: 'You are a fun trivia bot. Ask the user one trivia question at a time across mixed categories. After they answer, tell them if they\'re right and give a short fun fact, then ask the next one. Plain text only.',
    greeting: 'Trivia time! :D Type "go" and I\'ll fire off a question. Get 5 right in a row and I\'ll be impressed!',
  },
};

export default function MobiApp() {
  const { app: appId } = useParams();
  const navigate = useNavigate();
  const { profile, refreshProfile } = useAuth();
  const scrollRef = useRef<HTMLDivElement>(null);

  const app = appId ? APPS[appId] : null;
  const [messages, setMessages] = useState<{ id: string; role: 'user' | 'assistant'; content: string }[]>(
    app ? [{ id: 'g', role: 'assistant', content: app.greeting }] : []
  );
  const [thinking, setThinking] = useState(false);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages, thinking]);

  if (appId === 'shop') return <MoolaShop onBack={() => navigate('/')} />;
  if (appId === 'tradepost') return <Tradepost onBack={() => navigate('/')} />;
  if (appId === 'joebanker') return <JoeBanker onBack={() => navigate('/')} />;
  if (appId === 'portal') return (
    <div className="flex-1 min-h-0 flex flex-col">
      <MxitHeader
        left={<button onClick={() => { sfx.tap(); navigate('/'); }} className="p-2 hover:bg-white/10 rounded-md tap-scale"><ArrowLeft className="w-5 h-5" /></button>}
        title="Joe Banker"
        subtitle="apps & services"
        right={<Grid3x3 className="w-5 h-5 mr-2" />}
      />
      <div className="flex-1 overflow-y-auto mxit-screen-bg">
        <MobiPortalTab />
      </div>
    </div>
  );

  if (!app) {
    return (
      <div className="flex-1 flex items-center justify-center">
        <div className="text-center">
          <p>App not found</p>
          <Button onClick={() => navigate('/')} className="mt-4">Back</Button>
        </div>
      </div>
    );
  }

  const send = async (text: string) => {
    const userMsg = { id: `u-${Date.now()}`, role: 'user' as const, content: text };
    const next = [...messages, userMsg];
    setMessages(next);
    setThinking(true);
    try {
      const { data, error } = await supabase.functions.invoke('mobi-chat', {
        body: {
          system: app.system,
          messages: next.map(({ role, content }) => ({ role, content })),
        },
      });
      if (error) throw error;
      if (data?.error) throw new Error(data.error);
      sfx.receive();
      setMessages((m) => [...m, { id: `a-${Date.now()}`, role: 'assistant', content: data.reply }]);
    } catch (e: any) {
      sfx.error();
      toast.error(e.message || 'Something went wrong');
    } finally { setThinking(false); }
  };

  const Icon = app.icon;

  return (
    <div className="flex-1 flex flex-col">
      <MxitHeader
        left={<button onClick={() => { sfx.tap(); navigate('/'); }} className="p-2 hover:bg-white/10 rounded-md tap-scale"><ArrowLeft className="w-5 h-5" /></button>}
        right={<div className={`w-9 h-9 ${app.color} rounded-md flex items-center justify-center mxit-shadow-inset`}><Icon className="w-5 h-5 text-white" /></div>}
        title={app.name}
        subtitle="Joe Banker app"
      />
      <div ref={scrollRef} className="flex-1 min-h-0 overflow-y-auto overscroll-contain mxit-screen-bg p-3 pb-5 space-y-2 no-scrollbar [-webkit-overflow-scrolling:touch]">
        {messages.map((m) => (
          <MessageBubble
            key={m.id}
            msg={{ id: m.id, sender_id: m.role === 'user' ? (profile?.id ?? 'me') : 'bot', content: m.content, delivery: 'read', created_at: new Date().toISOString() }}
            isMe={m.role === 'user'}
            sender={m.role === 'assistant' ? { id: 'bot', display_name: app.name, avatar_seed: appId, avatar_url: null } : undefined}
            showAvatar={m.role === 'assistant'}
          />
        ))}
        {thinking && <TypingIndicator name={app.name} />}
      </div>
      <Composer onSend={send} disabled={thinking} />
    </div>
  );
}

function MoolaShop({ onBack }: { onBack: () => void }) {
  const { profile, refreshProfile } = useAuth();
  const items = [
    { id: 't_classic', name: 'Classic theme', cost: 0, owned: true },
    { id: 't_green', name: 'Lime theme', cost: 50 },
    { id: 't_pink', name: 'Bubble theme', cost: 50 },
    { id: 't_black', name: 'Midnight theme', cost: 100 },
    { id: 'mood_star', name: 'Mood: ⭐ I am a Mxit OG', cost: 30 },
    { id: 'avatar_pack', name: 'Bonus avatar pack', cost: 200 },
  ];
  const buy = async (item: typeof items[number]) => {
    if (!profile) return;
    if (profile.moola < item.cost) { sfx.error(); toast.error('Not enough Moola!'); return; }
    sfx.tap();
    const newBal = profile.moola - item.cost;
    await supabase.from('profiles').update({ moola: newBal }).eq('id', profile.id);
    await supabase.from('moola_transactions').insert({ user_id: profile.id, amount: -item.cost, reason: `Bought ${item.name}` });
    if (item.id.startsWith('t_')) {
      const t = item.id.replace('t_', '');
      document.documentElement.setAttribute('data-theme', t);
      await supabase.from('profiles').update({ theme: t }).eq('id', profile.id);
    }
    if (item.id.startsWith('mood_')) {
      await supabase.from('profiles').update({ mood: '⭐ I am a Mxit OG' }).eq('id', profile.id);
    }
    refreshProfile();
    toast.success(`You got "${item.name}"!`);
  };
  return (
    <div className="flex-1 flex flex-col">
      <MxitHeader
        left={<button onClick={() => { sfx.tap(); onBack(); }} className="p-2 hover:bg-white/10 rounded-md tap-scale"><ArrowLeft className="w-5 h-5" /></button>}
        title="Moola Shop"
        subtitle={`${profile?.moola ?? 0} Moola available`}
        right={<div className="flex items-center gap-1 bg-mxit-moola/90 text-white px-2 py-1 rounded-md font-pixel text-[9px]"><Coins className="w-3 h-3" /> {profile?.moola}</div>}
      />
      <div className="flex-1 overflow-y-auto mxit-screen-bg p-3 space-y-2">
        {items.map((it) => (
          <div key={it.id} className="bg-card p-3 rounded-lg flex items-center gap-3 mxit-shadow-pop">
            <div className="flex-1">
              <div className="font-medium text-sm">{it.name}</div>
              <div className="text-xs text-mxit-moola font-pixel">{it.cost === 0 ? 'FREE' : `${it.cost} M`}</div>
            </div>
            <Button size="sm" disabled={!!it.owned} onClick={() => buy(it)} className="font-pixel text-[10px]">
              {it.owned ? 'owned' : 'buy'}
            </Button>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ====================== TRADEPOST ====================== */

const TRADEPOST_CATALOG: { id: string; name: string; cost: number; kind: 'theme' | 'mood' | 'badge' | 'service'; payload?: any; desc: string }[] = [
  // Skins
  { id: 't_classic', name: 'Skin: Classic Blue', cost: 0,   kind: 'theme', payload: 'classic', desc: 'The original Mxit blue look' },
  { id: 't_green',   name: 'Skin: Lime',         cost: 50,  kind: 'theme', payload: 'green',   desc: 'Fresh green theme' },
  { id: 't_pink',    name: 'Skin: Bubble',       cost: 50,  kind: 'theme', payload: 'pink',    desc: 'Pink bubble theme' },
  { id: 't_black',   name: 'Skin: Midnight',     cost: 100, kind: 'theme', payload: 'black',   desc: 'Sleek dark mode' },
  // Mood/badges
  { id: 'm_og',      name: 'Mood: ⭐ Mxit OG',     cost: 30,  kind: 'mood', payload: '⭐ I am a Mxit OG', desc: 'Show your veteran status' },
  { id: 'm_love',    name: 'Mood: 💖 In love',    cost: 20,  kind: 'mood', payload: '💖 In love',  desc: '' },
  { id: 'm_chill',   name: 'Mood: 😎 Just chilling', cost: 15, kind: 'mood', payload: '😎 Just chilling', desc: '' },
  // Services (flavour)
  { id: 's_news',    name: 'Daily News feed',    cost: 25,  kind: 'service', desc: 'Headlines delivered to your chat' },
  { id: 's_horo',    name: 'Premium Horoscope',  cost: 40,  kind: 'service', desc: 'Detailed daily reading' },
  { id: 's_movies',  name: 'Movie reviews',      cost: 35,  kind: 'service', desc: 'Latest cinema reviews' },
];

function Tradepost({ onBack }: { onBack: () => void }) {
  const { profile, refreshProfile } = useAuth();
  const [busy, setBusy] = useState<string | null>(null);

  const buy = async (item: typeof TRADEPOST_CATALOG[number]) => {
    if (!profile) return;
    if (item.cost > 0 && profile.moola < item.cost) {
      sfx.error();
      toast.error('Not enough Moola — top up via Banker Bot');
      return;
    }
    setBusy(item.id);
    try {
      sfx.tap();
      const newBal = profile.moola - item.cost;
      await supabase.from('profiles').update({ moola: newBal }).eq('id', profile.id);
      if (item.cost > 0) {
        await supabase.from('moola_transactions').insert({
          user_id: profile.id, amount: -item.cost, reason: `Tradepost: ${item.name}`,
        });
      }
      if (item.kind === 'theme') {
        document.documentElement.setAttribute('data-theme', item.payload);
        await supabase.from('profiles').update({ theme: item.payload }).eq('id', profile.id);
      } else if (item.kind === 'mood') {
        await supabase.from('profiles').update({ mood: item.payload }).eq('id', profile.id);
      }
      await refreshProfile();
      toast.success(`Got "${item.name}"!`);
    } catch (e: any) {
      sfx.error();
      toast.error(e.message ?? 'Purchase failed');
    } finally {
      setBusy(null);
    }
  };

  return (
    <div className="flex-1 flex flex-col">
      <MxitHeader
        left={<button onClick={() => { sfx.tap(); onBack(); }} className="p-2 hover:bg-white/10 rounded-md tap-scale"><ArrowLeft className="w-5 h-5" /></button>}
        title="Tradepost"
        subtitle="Spend Moola on skins, moods & services"
        right={
          <div className="flex items-center gap-1 bg-mxit-moola/90 text-white px-2 py-1 rounded-md font-pixel text-[9px] mxit-shadow-pop">
            <Coins className="w-3 h-3" /> {profile?.moola ?? 0}
          </div>
        }
      />
      <div className="flex-1 overflow-y-auto mxit-screen-bg p-3 space-y-2">
        <div className="bg-card rounded-lg p-3 mxit-shadow-pop">
          <div className="font-pixel text-[10px] text-mxit-primary">WELCOME TO TRADEPOST</div>
          <div className="text-xs text-muted-foreground mt-1">
            Browse premium content. 1 Moola = R0.10. Need more? Tap Banker Bot.
          </div>
        </div>
        {TRADEPOST_CATALOG.map((it) => (
          <div key={it.id} className="bg-card p-3 rounded-lg flex items-center gap-3 mxit-shadow-pop">
            <ShoppingBag className="w-6 h-6 text-mxit-primary shrink-0" />
            <div className="flex-1 min-w-0">
              <div className="font-medium text-sm truncate">{it.name}</div>
              {it.desc && <div className="text-[11px] text-muted-foreground truncate">{it.desc}</div>}
              <div className="text-[11px] text-mxit-moola font-pixel mt-0.5">
                {it.cost === 0 ? 'FREE' : `${it.cost} M`}
              </div>
            </div>
            <Button
              size="sm"
              disabled={busy === it.id}
              onClick={() => buy(it)}
              className="font-pixel text-[10px]"
            >
              {busy === it.id ? '…' : 'buy'}
            </Button>
          </div>
        ))}
      </div>
    </div>
  );
}

/* ====================== JOE BANKER ====================== */

type MoolaProduct = {
  id: string;
  product_id: string;
  label: string;
  moola_amount: number;
  zar_value: number;
  bonus_moola: number;
  position: number;
};

type LedgerRow = {
  id: string;
  amount: number;
  reason: string;
  created_at: string;
  type?: string | null;
  balance_after?: number | null;
};

type BotMsg =
  | { id: string; kind: 'bot'; content: React.ReactNode }
  | { id: string; kind: 'me'; content: string };

function fmtZar(n: number) {
  return `R${n.toFixed(2)}`;
}

function JoeBanker({ onBack }: { onBack: () => void }) {
  const { profile, refreshProfile } = useAuth();
  const scrollRef = useRef<HTMLDivElement>(null);
  const [products, setProducts] = useState<MoolaProduct[]>([]);
  const [history, setHistory] = useState<LedgerRow[]>([]);
  const [view, setView] = useState<'menu' | 'buy' | 'history' | 'about' | 'help'>('menu');
  const [thread, setThread] = useState<BotMsg[]>([]);
  const [claiming, setClaiming] = useState(false);
  const [claimedToday, setClaimedToday] = useState(false);

  // Check if user already claimed today
  useEffect(() => {
    if (!profile) return;
    (async () => {
      const today = new Date().toISOString().slice(0, 10);
      const { data } = await supabase
        .from('moola_daily_claims')
        .select('id')
        .eq('user_id', profile.id)
        .eq('claim_date', today)
        .maybeSingle();
      setClaimedToday(!!data);
    })();
  }, [profile?.id]);

  const claimDaily = async () => {
    if (!profile || claiming || claimedToday) return;
    setClaiming(true);
    sfx.tap();
    try {
      const { data, error } = await supabase.rpc('claim_daily_moola');
      if (error) throw error;
      const res = data as { ok: boolean; reason?: string; amount?: number; balance?: number };
      if (!res.ok) {
        if (res.reason === 'already_claimed') {
          setClaimedToday(true);
          sayBot(<>You've already claimed today's bonus 👍 Come back tomorrow!</>);
        } else {
          throw new Error(res.reason || 'Could not claim');
        }
      } else {
        setClaimedToday(true);
        await refreshProfile();
        toast.success(`+${res.amount} Moola added!`);
        sayBot(<>🎁 Boom — <b>+{res.amount} Moola</b> added! New balance: <b>{res.balance} M</b>. Spend it well 😎</>);
      }
    } catch (e: any) {
      sfx.error();
      toast.error(e.message || 'Claim failed');
    } finally { setClaiming(false); }
  };

  // Load catalog + history
  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from('moola_products')
        .select('*')
        .eq('enabled', true)
        .order('position', { ascending: true });
      setProducts((data ?? []) as MoolaProduct[]);
    })();
  }, []);

  useEffect(() => {
    if (!profile) return;
    (async () => {
      const { data } = await supabase
        .from('moola_transactions')
        .select('id, amount, reason, created_at, type, balance_after')
        .eq('user_id', profile.id)
        .order('created_at', { ascending: false })
        .limit(25);
      setHistory((data ?? []) as LedgerRow[]);
    })();
  }, [profile?.id, view]);

  // Greeting
  useEffect(() => {
    if (!profile) return;
    const balZar = (profile.moola ?? 0) * 0.10;
    setThread([
      {
        id: 'g1',
        kind: 'bot',
        content: (
          <>
            Howzit <b>{profile.display_name}</b>! 🟢<br />
            Your balance is <b>{profile.moola ?? 0} Moola</b> ({fmtZar(balZar)} in-app value).<br />
            <span className="text-muted-foreground">1 Moola = R0.10 · in-app currency only · cannot be cashed out.</span>
          </>
        ),
      },
      {
        id: 'g2',
        kind: 'bot',
        content: (
          <>
            What can I help you with?<br />
            <span className="text-mxit-primary">1.</span> Buy Moola{'  '}
            <span className="text-mxit-primary">2.</span> Transactions<br />
            <span className="text-mxit-primary">3.</span> What can I use Moola for?<br />
            <span className="text-mxit-primary">4.</span> Missing purchase{'  '}
            <span className="text-mxit-primary">5.</span> Help
          </>
        ),
      },
    ]);
  }, [profile?.id]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [thread, view]);

  const sayMe = (text: string) =>
    setThread((t) => [...t, { id: `m-${Date.now()}`, kind: 'me', content: text }]);
  const sayBot = (content: React.ReactNode) =>
    setThread((t) => [...t, { id: `b-${Date.now()}-${Math.random()}`, kind: 'bot', content }]);

  const choose = (n: 1 | 2 | 3 | 4 | 5) => {
    sfx.tap();
    if (n === 1) { sayMe('1 · Buy Moola'); setView('buy'); sayBot('Pick a pack below 👇'); return; }
    if (n === 2) { sayMe('2 · Transactions'); setView('history'); sayBot('Here are your last transactions 👇'); return; }
    if (n === 3) {
      sayMe('3 · What can I use Moola for?');
      setView('about');
      sayBot(
        <>
          You can spend Moola on:<br />
          • Chatroom messages (~2M each)<br />
          • Tradepost: skinz, moods, emoticards<br />
          • Premium Joe Banker apps<br />
          • Profile boosts & gifts<br />
          <span className="text-muted-foreground">Moola never expires.</span>
        </>,
      );
      return;
    }
    if (n === 4) {
      sayMe('4 · Missing purchase');
      sayBot(
        <>
          No stress 👌 Real top-ups happen via the App Store / Google Play in the mobile app.<br />
          If a payment went through and Moola wasn't credited, send your store order ID to support and we'll sort it.
        </>,
      );
      return;
    }
    if (n === 5) {
      sayMe('5 · Help');
      setView('help');
      sayBot(
        <>
          Banker Bot is your in-app wallet 🪙<br />
          • <b>1 Moola = R0.10</b> of in-app value<br />
          • Moola is virtual currency, used inside Mxit only<br />
          • Cannot be exchanged for cash, transferred or withdrawn<br />
          • Refunds follow Apple / Google policy
        </>,
      );
      return;
    }
  };

  return (
    <div className="flex-1 flex flex-col">
      <MxitHeader
        left={<button onClick={() => { sfx.tap(); onBack(); }} className="p-2 hover:bg-white/10 rounded-md tap-scale"><ArrowLeft className="w-5 h-5" /></button>}
        title="Banker Bot"
        subtitle="Wallet · top-up · history"
        right={
          <div className="flex items-center gap-1 bg-emerald-600 text-white px-2 py-1 rounded-md font-pixel text-[9px] mxit-shadow-pop">
            <Banknote className="w-3 h-3" /> {profile?.moola ?? 0}
          </div>
        }
      />

      {/* Scrollable area: balance card + chat */}
      <div ref={scrollRef} className="flex-1 overflow-y-auto mxit-screen-bg p-3 space-y-2 no-scrollbar">
        <div className="bg-gradient-to-br from-emerald-600 to-emerald-800 text-white rounded-lg p-4 mxit-shadow-pop">
          <div className="font-pixel text-[10px] opacity-90">CURRENT BALANCE</div>
          <div className="text-3xl font-bold tracking-tight mt-1">{profile?.moola ?? 0} M</div>
          <div className="text-[11px] opacity-80 mt-1">
            ≈ {fmtZar((profile?.moola ?? 0) * 0.10)} in-app value · 1 Moola = R0.10
          </div>
          <Button
            onClick={claimDaily}
            disabled={claiming || claimedToday}
            className="w-full mt-3 bg-amber-400 hover:bg-amber-300 text-black font-pixel text-[10px] disabled:bg-white/20 disabled:text-white/60"
          >
            <Coins className="w-3.5 h-3.5 mr-1.5" />
            {claimedToday ? 'daily bonus claimed ✓' : claiming ? '…' : 'claim +20M daily bonus'}
          </Button>
        </div>

        {thread.map((m) => (
          m.kind === 'bot' ? (
            <div key={m.id} className="flex items-start gap-2 max-w-[88%]">
              <div className="w-8 h-8 rounded-full bg-emerald-600 text-white flex items-center justify-center mxit-shadow-pop shrink-0">
                <Banknote className="w-4 h-4" />
              </div>
              <div className="bg-card rounded-lg rounded-tl-sm px-3 py-2 text-sm mxit-shadow-pop">
                <div className="font-pixel text-[9px] text-emerald-700 mb-0.5">BANKER BOT</div>
                <div className="leading-snug">{m.content}</div>
              </div>
            </div>
          ) : (
            <div key={m.id} className="flex justify-end">
              <div className="bg-mxit-primary text-white rounded-lg rounded-tr-sm px-3 py-1.5 text-sm max-w-[80%] mxit-shadow-pop">
                {m.content}
              </div>
            </div>
          )
        ))}

        {/* Inline panels under the thread */}
        {view === 'buy' && (
          <div className="bg-card rounded-lg p-3 mxit-shadow-pop space-y-2">
            <div className="font-pixel text-[10px] text-mxit-primary">MOOLA PACKS</div>
            <div className="grid grid-cols-2 gap-2">
              {products.map((p) => (
                <div key={p.id} className="rounded-lg border border-border p-2.5 flex flex-col">
                  <div className="font-pixel text-[10px] text-emerald-700">{fmtZar(Number(p.zar_value))}</div>
                  <div className="text-sm font-semibold mt-1">+{p.moola_amount} M</div>
                  {p.bonus_moola > 0 && (
                    <div className="text-[10px] text-mxit-moola font-pixel">+{p.bonus_moola} bonus</div>
                  )}
                  <Button
                    size="sm"
                    variant="secondary"
                    onClick={() => { sfx.tap(); toast.info('Top-ups available in the mobile app via Apple / Google.'); }}
                    className="font-pixel text-[10px] mt-2"
                  >
                    buy
                  </Button>
                </div>
              ))}
            </div>
            <CustomMoolaAmount />
            <div className="text-[10px] text-muted-foreground">
              Real money top-ups go through Apple In-App Purchase / Google Play Billing in the mobile app. The web version is preview-only.
            </div>
          </div>
        )}

        {view === 'history' && (
          <div className="bg-card rounded-lg mxit-shadow-pop divide-y divide-border">
            {history.length === 0 ? (
              <div className="p-4 text-center text-xs text-muted-foreground">No transactions yet.</div>
            ) : history.map((h) => (
              <div key={h.id} className="px-3 py-2 flex items-center gap-3 text-sm">
                <div className="flex-1 min-w-0">
                  <div className="truncate">{h.reason}</div>
                  <div className="text-[10px] text-muted-foreground">
                    {new Date(h.created_at).toLocaleString()}
                    {h.type ? ` · ${h.type}` : ''}
                  </div>
                </div>
                <div className={`font-pixel text-[10px] ${h.amount >= 0 ? 'text-emerald-600' : 'text-destructive'}`}>
                  {h.amount >= 0 ? '+' : ''}{h.amount} M
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Quick replies / menu buttons */}
      <div className="border-t border-border bg-card/80 p-2 grid grid-cols-5 gap-1">
        {([
          [1, 'Buy'],
          [2, 'History'],
          [3, 'Uses'],
          [4, 'Missing'],
          [5, 'Help'],
        ] as const).map(([n, label]) => (
          <button
            key={n}
            onClick={() => choose(n as 1 | 2 | 3 | 4 | 5)}
            className="font-pixel text-[9px] py-2 rounded-md bg-secondary hover:bg-mxit-primary hover:text-white tap-scale"
          >
            {n}·{label}
          </button>
        ))}
      </div>
    </div>
  );
}


function CustomMoolaAmount() {
  const [zar, setZar] = useState('');
  const n = parseFloat(zar);
  const valid = !isNaN(n) && n >= 1;
  const moola = valid ? Math.floor(n * 10) : 0;
  return (
    <div className="rounded-lg border border-border p-2.5 space-y-2">
      <div className="font-pixel text-[10px] text-mxit-primary">CUSTOM AMOUNT</div>
      <div className="flex items-center gap-2">
        <span className="text-xs text-muted-foreground">R</span>
        <input
          type="number"
          inputMode="decimal"
          min={1}
          step="0.10"
          value={zar}
          onChange={(e) => setZar(e.target.value)}
          placeholder="e.g. 15"
          className="flex-1 h-9 rounded-md border border-input bg-background px-2 text-sm focus:outline-none focus:ring-2 focus:ring-ring"
        />
        <div className="text-xs whitespace-nowrap">= <b>{moola} M</b></div>
      </div>
      <Button
        size="sm"
        variant="secondary"
        disabled={!valid}
        onClick={() => { sfx.tap(); toast.info('Top-ups available in the mobile app via Apple / Google.'); }}
        className="w-full font-pixel text-[10px]"
      >
        buy {valid ? `R${n.toFixed(2)}` : ''}
      </Button>
    </div>
  );
}
