import { useEffect, useMemo, useState } from 'react';
import { Navigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { ReportsPanel } from './admin/ReportsPanel';
import { AnnouncementsPanel } from './admin/AnnouncementsPanel';
import { AnalyticsExtras } from './admin/AnalyticsExtras';

type Row = { event: string; created_at: string; user_id: string | null; session_id: string | null };

const DAYS = 14;

export default function AdminAnalytics() {
  const { user, loading } = useAuth();
  const [isAdmin, setIsAdmin] = useState<boolean | null>(null);
  const [rows, setRows] = useState<Row[] | null>(null);
  const [signupsTotal, setSignupsTotal] = useState<number>(0);
  const [openReports, setOpenReports] = useState<number>(0);

  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data } = await supabase.from('user_roles').select('role').eq('user_id', user.id).in('role', ['admin', 'moderator']);
      setIsAdmin(!!(data && data.length));
    })();
  }, [user]);

  useEffect(() => {
    if (!isAdmin) return;
    (async () => {
      const since = new Date(Date.now() - DAYS * 86400_000).toISOString();
      const { data } = await supabase
        .from('analytics_events')
        .select('event, created_at, user_id, session_id')
        .gte('created_at', since)
        .order('created_at', { ascending: false })
        .limit(10000);
      setRows((data ?? []) as Row[]);
      const { count } = await supabase.from('profiles').select('*', { count: 'exact', head: true });
      setSignupsTotal(count ?? 0);
      const { count: oc } = await supabase.from('user_reports').select('*', { count: 'exact', head: true }).eq('status', 'open');
      setOpenReports(oc ?? 0);
    })();
  }, [isAdmin]);

  const stats = useMemo(() => {
    if (!rows) return null;
    const today = new Date(); today.setHours(0, 0, 0, 0);
    const todayMs = today.getTime();
    const dayKey = (iso: string) => { const d = new Date(iso); d.setHours(0, 0, 0, 0); return d.toISOString().slice(0, 10); };

    const signupsToday = rows.filter(r => r.event === 'signup_completed' && new Date(r.created_at).getTime() >= todayMs).length;
    const messagesToday = rows.filter(r => r.event === 'message_sent' && new Date(r.created_at).getTime() >= todayMs).length;
    const dauToday = new Set(rows.filter(r => new Date(r.created_at).getTime() >= todayMs && r.user_id).map(r => r.user_id)).size;

    const byDay = new Map<string, { signups: number; messages: number; dau: Set<string>; sessions: Set<string> }>();
    for (let i = 0; i < DAYS; i++) {
      const d = new Date(today.getTime() - i * 86400_000);
      byDay.set(d.toISOString().slice(0, 10), { signups: 0, messages: 0, dau: new Set(), sessions: new Set() });
    }
    rows.forEach(r => {
      const k = dayKey(r.created_at);
      const b = byDay.get(k); if (!b) return;
      if (r.event === 'signup_completed') b.signups++;
      if (r.event === 'message_sent') b.messages++;
      if (r.user_id) b.dau.add(r.user_id);
      if (r.session_id) b.sessions.add(r.session_id);
    });
    const series = Array.from(byDay.entries())
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([date, v]) => ({ date, signups: v.signups, messages: v.messages, dau: v.dau.size, sessions: v.sessions.size }));

    // 1-day retention: of users whose first event was on day D-1, % with any event on day D
    const firstSeen = new Map<string, string>();
    [...rows].sort((a, b) => a.created_at.localeCompare(b.created_at)).forEach(r => {
      if (r.user_id && !firstSeen.has(r.user_id)) firstSeen.set(r.user_id, dayKey(r.created_at));
    });
    const yesterday = new Date(todayMs - 86400_000).toISOString().slice(0, 10);
    const cohort = [...firstSeen.entries()].filter(([, d]) => d === yesterday).map(([u]) => u);
    const todayKey = new Date(todayMs).toISOString().slice(0, 10);
    const returned = new Set(rows.filter(r => r.user_id && dayKey(r.created_at) === todayKey).map(r => r.user_id));
    const retention = cohort.length ? Math.round((cohort.filter(u => returned.has(u)).length / cohort.length) * 100) : null;

    return { signupsToday, messagesToday, dauToday, series, retention, cohortSize: cohort.length };
  }, [rows]);

  if (loading) return <div className="p-8"><Skeleton className="h-8 w-40" /></div>;
  if (!user) return <Navigate to="/" replace />;
  if (isAdmin === null) return <div className="p-8 text-sm text-muted-foreground">Checking access…</div>;
  if (!isAdmin) return <div className="p-8 text-sm text-destructive">403 — admins only.</div>;

  return (
    <div className="mx-auto max-w-5xl p-4 md:p-8 space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Mxit Admin</h1>
        <p className="text-sm text-muted-foreground">Analytics & moderation · admin only</p>
      </div>

      <Tabs defaultValue="overview">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="trends">Trends</TabsTrigger>
          <TabsTrigger value="reports" className="gap-2">
            Reports
            {openReports > 0 && <Badge variant="destructive">{openReports}</Badge>}
          </TabsTrigger>
          <TabsTrigger value="announcements">Announcements</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6 mt-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
            <Stat label="Signups today" value={stats?.signupsToday ?? '—'} />
            <Stat label="DAU today" value={stats?.dauToday ?? '—'} />
            <Stat label="Messages today" value={stats?.messagesToday ?? '—'} />
            <Stat label="Total users" value={signupsTotal} />
          </div>

          <Card>
            <CardHeader><CardTitle className="text-base">Day-1 retention</CardTitle></CardHeader>
            <CardContent className="text-sm">
              {stats?.retention === null ? (
                <span className="text-muted-foreground">No new users yesterday.</span>
              ) : (
                <span><b className="text-2xl">{stats?.retention}%</b> · {stats?.cohortSize} new users yesterday returned today</span>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader><CardTitle className="text-base">Daily breakdown · last {DAYS} days</CardTitle></CardHeader>
            <CardContent>
              {!rows ? <Skeleton className="h-40" /> : (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead className="text-right">Signups</TableHead>
                      <TableHead className="text-right">DAU</TableHead>
                      <TableHead className="text-right">Sessions</TableHead>
                      <TableHead className="text-right">Messages</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {[...(stats?.series ?? [])].reverse().map(d => (
                      <TableRow key={d.date}>
                        <TableCell className="font-mono text-xs">{d.date}</TableCell>
                        <TableCell className="text-right">{d.signups}</TableCell>
                        <TableCell className="text-right">{d.dau}</TableCell>
                        <TableCell className="text-right">{d.sessions}</TableCell>
                        <TableCell className="text-right">{d.messages}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="trends">
          <AnalyticsExtras />
        </TabsContent>

        <TabsContent value="reports" className="mt-4">
          <ReportsPanel onCount={setOpenReports} />
        </TabsContent>

        <TabsContent value="announcements" className="mt-4">
          <AnnouncementsPanel />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function Stat({ label, value }: { label: string; value: number | string }) {
  return (
    <Card>
      <CardContent className="p-4">
        <div className="text-xs uppercase tracking-wide text-muted-foreground">{label}</div>
        <div className="text-3xl font-bold mt-1">{value}</div>
      </CardContent>
    </Card>
  );
}
