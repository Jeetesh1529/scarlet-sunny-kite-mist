/**
 * Confessions — anonymous public wall. Post, like, scroll.
 * Author identity is hidden in UI; stored server-side for moderation only.
 */
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { sfx } from '@/lib/sfx';
import { toast } from 'sonner';
import { MessageSquare, Heart, Send } from 'lucide-react';
import { awardAchievement } from '@/lib/achievements';

type Confession = {
  id: string;
  body: string;
  likes_count: number;
  created_at: string;
};

export default function Confessions() {
  const navigate = useNavigate();
  const { profile } = useAuth();
  const [items, setItems] = useState<Confession[]>([]);
  const [body, setBody] = useState('');
  const [posting, setPosting] = useState(false);
  const [liked, setLiked] = useState<Record<string, boolean>>({});

  useEffect(() => { void load(); }, []);

  async function load() {
    const { data } = await (supabase as any)
      .from('confessions')
      .select('id,body,likes_count,created_at')
      .eq('is_hidden', false)
      .order('created_at', { ascending: false })
      .limit(100);
    setItems((data ?? []) as Confession[]);

    if (profile) {
      const { data: likes } = await (supabase as any)
        .from('confession_likes').select('confession_id').eq('user_id', profile.id);
      const m: Record<string, boolean> = {};
      (likes ?? []).forEach((r: any) => { m[r.confession_id] = true; });
      setLiked(m);
    }
  }

  async function post() {
    if (!profile || !body.trim()) return;
    setPosting(true);
    const { error } = await (supabase as any).from('confessions').insert({
      author_id: profile.id, body: body.trim(),
    });
    setPosting(false);
    if (error) { toast.error(error.message); return; }
    setBody(''); sfx.tap();
    toast.success('Posted anonymously');
    void awardAchievement('confession');
    void load();
  }

  async function toggleLike(c: Confession) {
    if (!profile) return;
    sfx.tap();
    if (liked[c.id]) {
      await (supabase as any).from('confession_likes')
        .delete().eq('confession_id', c.id).eq('user_id', profile.id);
      setLiked({ ...liked, [c.id]: false });
      setItems(items.map(i => i.id === c.id ? { ...i, likes_count: Math.max(0, i.likes_count - 1) } : i));
    } else {
      const { error } = await (supabase as any).from('confession_likes')
        .insert({ confession_id: c.id, user_id: profile.id });
      if (!error) {
        setLiked({ ...liked, [c.id]: true });
        setItems(items.map(i => i.id === c.id ? { ...i, likes_count: i.likes_count + 1 } : i));
      }
    }
  }

  return (
    <div className="flex-1 min-h-0 flex flex-col mxit-classic-bg">
      <div className="mxit-titlebar h-9 flex items-center px-3 gap-2 shrink-0">
        <button onClick={() => { sfx.tap(); navigate('/'); }} className="text-[11px] px-2 py-0.5 rounded-sm bg-white/10 border border-white/20">‹ Back</button>
        <div className="flex-1 text-center font-semibold text-[15px] tracking-wide flex items-center justify-center gap-2">
          <MessageSquare className="w-4 h-4" /> Confessions
        </div>
        <span className="w-12" />
      </div>

      <div className="relative flex-1 overflow-y-auto mxit-watermark min-h-0">
        <div className="relative z-10 p-4 space-y-3">
          {/* Composer */}
          <div className="bg-white/5 border border-white/10 rounded-lg p-3">
            <div className="text-[11px] text-white/60 mb-1">Post anonymously · 500 chars</div>
            <textarea
              value={body}
              onChange={(e) => setBody(e.target.value.slice(0, 500))}
              placeholder="Spill the tea…"
              rows={3}
              className="w-full bg-black/30 text-white placeholder:text-white/40 rounded p-2 text-sm outline-none border border-white/10 resize-none"
            />
            <div className="flex items-center justify-between mt-2">
              <span className="text-[10px] text-white/40">{body.length}/500</span>
              <button
                onClick={post}
                disabled={posting || !body.trim()}
                className="flex items-center gap-1.5 px-3 py-1 rounded bg-pink-500/80 hover:bg-pink-500 text-white text-sm disabled:opacity-50"
              >
                <Send className="w-3.5 h-3.5" /> Post
              </button>
            </div>
          </div>

          {/* List */}
          {items.length === 0 && (
            <div className="text-center text-white/50 text-sm py-8">No confessions yet. Be the first 👀</div>
          )}
          {items.map(c => (
            <div key={c.id} className="bg-white/5 border border-white/10 rounded-lg p-3">
              <div className="text-white text-sm whitespace-pre-wrap">{c.body}</div>
              <div className="mt-2 flex items-center justify-between">
                <span className="text-[10px] text-white/40">{new Date(c.created_at).toLocaleString()}</span>
                <button onClick={() => toggleLike(c)} className={`flex items-center gap-1 text-[12px] ${liked[c.id] ? 'text-pink-300' : 'text-white/60 hover:text-pink-200'}`}>
                  <Heart className={`w-3.5 h-3.5 ${liked[c.id] ? 'fill-pink-400' : ''}`} /> {c.likes_count}
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
