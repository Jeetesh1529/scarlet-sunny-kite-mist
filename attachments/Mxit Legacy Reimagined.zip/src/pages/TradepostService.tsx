/**
 * Tradepost > placeholder for services that aren't built yet
 * (Games, Emoticards, Skinz, Horoscopes, Weather, etc.).
 */
import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { sfx } from '@/lib/sfx';
import { Construction, Coins } from 'lucide-react';

type Service = { name: string; description: string | null; cost_moola: number };

export default function TradepostService() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const [svc, setSvc] = useState<Service | null>(null);

  useEffect(() => {
    (async () => {
      if (!slug) return;
      const { data } = await supabase
        .from('tradepost_services')
        .select('name, description, cost_moola')
        .eq('slug', slug)
        .maybeSingle();
      setSvc((data as Service) ?? { name: slug, description: null, cost_moola: 0 });
    })();
  }, [slug]);

  return (
    <div className="flex-1 min-h-0 flex flex-col mxit-classic-bg">
      <div className="mxit-titlebar h-9 flex items-center px-3 gap-2 shrink-0">
        <button
          onClick={() => { sfx.tap(); navigate('/tradepost'); }}
          className="text-[11px] px-2 py-0.5 rounded-sm bg-white/10 border border-white/20"
        >
          ‹ Back
        </button>
        <div className="flex-1 text-center font-semibold text-[15px] tracking-wide truncate">
          {svc?.name ?? '…'}
        </div>
        {svc && svc.cost_moola > 0 && (
          <span className="text-[10px] text-amber-200 flex items-center gap-1">
            <Coins className="w-3 h-3" /> {svc.cost_moola}M
          </span>
        )}
      </div>

      <div className="relative flex-1 overflow-y-auto mxit-watermark min-h-0">
        <div className="relative z-10 flex flex-col items-center justify-center h-full px-6 text-center text-white/80 gap-3">
          <Construction className="w-10 h-10 text-amber-200" />
          <div className="font-semibold text-lg">{svc?.name ?? 'Coming soon'}</div>
          <div className="text-[12px] text-white/60 max-w-xs">
            {svc?.description ?? 'This Tradepost service is on the way.'}
          </div>
          <div className="text-[11px] text-white/40 italic mt-2">
            Under construction — check back soon.
          </div>
        </div>
      </div>

      <div className="mxit-softkeys h-10 flex items-stretch text-sm font-medium shrink-0">
        <button onClick={() => { sfx.tap(); navigate('/tradepost'); }} className="flex-1 text-left pl-4 active:bg-black/30">Back</button>
        <button onClick={() => { sfx.tap(); navigate('/'); }} className="flex-1 text-right pr-4 active:bg-black/30">Home</button>
      </div>
    </div>
  );
}
