/**
 * Tradepost > Horoscopes — pick a star sign, see today's reading.
 * Free to view your own, 2 Moola to "unlock" any other sign for a day (just toast/UI feedback).
 * Reading is deterministic per (sign, date) so it stays the same all day.
 */
import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { spendMoola } from '@/lib/moola';
import { sfx } from '@/lib/sfx';
import { toast } from 'sonner';
import { Coins, Stars, Sparkles } from 'lucide-react';

type Sign = { name: string; symbol: string; range: string };

const SIGNS: Sign[] = [
  { name: 'Aries',       symbol: '♈', range: 'Mar 21 – Apr 19' },
  { name: 'Taurus',      symbol: '♉', range: 'Apr 20 – May 20' },
  { name: 'Gemini',      symbol: '♊', range: 'May 21 – Jun 20' },
  { name: 'Cancer',      symbol: '♋', range: 'Jun 21 – Jul 22' },
  { name: 'Leo',         symbol: '♌', range: 'Jul 23 – Aug 22' },
  { name: 'Virgo',       symbol: '♍', range: 'Aug 23 – Sep 22' },
  { name: 'Libra',       symbol: '♎', range: 'Sep 23 – Oct 22' },
  { name: 'Scorpio',     symbol: '♏', range: 'Oct 23 – Nov 21' },
  { name: 'Sagittarius', symbol: '♐', range: 'Nov 22 – Dec 21' },
  { name: 'Capricorn',   symbol: '♑', range: 'Dec 22 – Jan 19' },
  { name: 'Aquarius',    symbol: '♒', range: 'Jan 20 – Feb 18' },
  { name: 'Pisces',      symbol: '♓', range: 'Feb 19 – Mar 20' },
];

const READINGS = [
  'A surprise message lands in your inbox today — say yes to coffee.',
  'Your energy is magnetic. Use it to finish what you started yesterday.',
  'A friend needs you more than they let on. Reach out first.',
  'Money matters look up — keep an eye on small wins, not jackpots.',
  'Old plans resurface. Trust your gut, not your group chat.',
  'A creative spark hits you mid-afternoon. Write it down immediately.',
  'Don\'t let one rude comment ruin a great day — laugh it off.',
  'Romance is in the small gestures today. Send the emoticard.',
  'Take the long route home. The walk will clear your head.',
  'Numbers matter today: double-check before you tap "send".',
  'A new contact will become important. Be open to strangers.',
  'You\'re due for a treat — buy yourself something tiny and joyful.',
];

const LUCKY = ['Crimson', 'Cobalt', 'Mint', 'Lemon', 'Lilac', 'Charcoal', 'Sand', 'Coral'];

function hash(str: string) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
  return Math.abs(h);
}

export default function TradepostHoroscopes() {
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [picked, setPicked] = useState<Sign | null>(null);
  const today = useMemo(() => new Date().toISOString().slice(0, 10), []);

  const reading = useMemo(() => {
    if (!picked) return null;
    const h = hash(`${picked.name}-${today}`);
    return {
      text: READINGS[h % READINGS.length],
      lucky_number: (h % 99) + 1,
      lucky_color: LUCKY[h % LUCKY.length],
      love: (h % 5) + 1,
      money: ((h >> 3) % 5) + 1,
      energy: ((h >> 6) % 5) + 1,
    };
  }, [picked, today]);

  const pick = async (s: Sign) => {
    if (!profile) return;
    sfx.tap();
    // Free for everyone in this build (was: 2M for non-own sign).
    setPicked(s);
  };

  const tip = async () => {
    if (!profile) return;
    const ok = await spendMoola({
      userId: profile.id,
      currentBalance: profile.moola,
      amount: 2,
      reason: 'Horoscopes — extra reading tip',
      type: 'spend',
    });
    if (ok) toast.success('Bonus reading: a small risk pays off this week ✨');
  };

  return (
    <div className="flex-1 min-h-0 flex flex-col mxit-classic-bg">
      <div className="mxit-titlebar h-9 flex items-center px-3 gap-2 shrink-0">
        <button onClick={() => { sfx.tap(); picked ? setPicked(null) : navigate('/tradepost'); }}
          className="text-[11px] px-2 py-0.5 rounded-sm bg-white/10 border border-white/20">‹ Back</button>
        <div className="flex-1 text-center font-semibold text-[15px] tracking-wide flex items-center justify-center gap-2">
          <Stars className="w-4 h-4" /> Horoscopes
        </div>
        <span className="text-[10px] text-amber-200 flex items-center gap-1">
          <Coins className="w-3 h-3" /> {profile?.moola ?? 0}
        </span>
      </div>

      <div className="relative flex-1 overflow-y-auto mxit-watermark min-h-0">
        <div className="relative z-10 p-3">
          {!picked ? (
            <>
              <div className="text-[11px] text-white/60 italic mb-2">Pick your sign for today's reading.</div>
              <div className="grid grid-cols-3 gap-2">
                {SIGNS.map((s) => (
                  <button
                    key={s.name}
                    onClick={() => pick(s)}
                    className="aspect-square rounded-md p-2 flex flex-col items-center justify-center gap-1 bg-white/5 border border-white/15 hover:bg-white/10 active:bg-white/15 text-white"
                  >
                    <span className="text-3xl">{s.symbol}</span>
                    <span className="text-[10px] font-semibold">{s.name}</span>
                    <span className="text-[8px] text-white/50">{s.range}</span>
                  </button>
                ))}
              </div>
            </>
          ) : reading && (
            <div className="space-y-3">
              <div className="text-center text-white">
                <div className="text-6xl">{picked.symbol}</div>
                <div className="font-semibold text-lg">{picked.name}</div>
                <div className="text-[10px] text-white/50">{today}</div>
              </div>
              <div className="rounded-md p-3 bg-white/5 border border-white/15 text-white text-sm leading-relaxed">
                "{reading.text}"
              </div>
              <div className="grid grid-cols-3 gap-2 text-center text-white">
                <div className="rounded-md p-2 bg-white/5 border border-white/15">
                  <div className="text-[9px] text-white/50 uppercase">Love</div>
                  <div className="text-amber-300">{'★'.repeat(reading.love)}{'☆'.repeat(5 - reading.love)}</div>
                </div>
                <div className="rounded-md p-2 bg-white/5 border border-white/15">
                  <div className="text-[9px] text-white/50 uppercase">Money</div>
                  <div className="text-amber-300">{'★'.repeat(reading.money)}{'☆'.repeat(5 - reading.money)}</div>
                </div>
                <div className="rounded-md p-2 bg-white/5 border border-white/15">
                  <div className="text-[9px] text-white/50 uppercase">Energy</div>
                  <div className="text-amber-300">{'★'.repeat(reading.energy)}{'☆'.repeat(5 - reading.energy)}</div>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-2 text-white text-[12px]">
                <div className="rounded-md p-2 bg-white/5 border border-white/15">
                  <div className="text-[9px] text-white/50 uppercase">Lucky number</div>
                  <div className="font-semibold">{reading.lucky_number}</div>
                </div>
                <div className="rounded-md p-2 bg-white/5 border border-white/15">
                  <div className="text-[9px] text-white/50 uppercase">Lucky colour</div>
                  <div className="font-semibold">{reading.lucky_color}</div>
                </div>
              </div>
              <button
                onClick={tip}
                className="w-full rounded-md py-2 text-[12px] flex items-center justify-center gap-2 bg-amber-300/15 border border-amber-300/40 text-white hover:bg-amber-300/25"
              >
                <Sparkles className="w-3.5 h-3.5 text-amber-200" /> Bonus tip — 2 Moola
              </button>
            </div>
          )}
        </div>
      </div>

      <div className="mxit-softkeys h-10 flex items-stretch text-sm font-medium shrink-0">
        <button onClick={() => { sfx.tap(); picked ? setPicked(null) : navigate('/tradepost'); }} className="flex-1 text-left pl-4 active:bg-black/30">Back</button>
        <button onClick={() => { sfx.tap(); navigate('/'); }} className="flex-1 text-right pr-4 active:bg-black/30">Home</button>
      </div>
    </div>
  );
}
