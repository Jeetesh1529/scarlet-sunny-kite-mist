/**
 * Moola Hub — daily spin-the-wheel, weekly leaderboard, send Moola to a contact.
 */
import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { sfx } from '@/lib/sfx';
import { toast } from 'sonner';
import { Coins, Gift, Trophy, Send, ChevronRight, X } from 'lucide-react';

type LeaderRow = {
  user_id: string; display_name: string; mxit_id: string;
  avatar_url: string | null; avatar_seed: string | null;
  earned: number; spins: number; transfers: number;
};
type Contact = { id: string; display_name: string; mxit_id: string; avatar_url: string | null };

const WEDGES = [5, 10, 50, 15, 100, 20, 25, 30];

export default function MoolaHub() {
  const navigate = useNavigate();
  const { profile, refreshProfile } = useAuth();
  const [leaders, setLeaders] = useState<LeaderRow[]>([]);
  const [spunToday, setSpunToday] = useState<number | null>(null);
  const [spinning, setSpinning] = useState(false);
  const [angle, setAngle] = useState(0);
  const [sendOpen, setSendOpen] = useState(false);

  useEffect(() => {
    if (!profile) return;
    void loadLeaders();
    void loadTodaySpin();
  }, [profile]);

  async function loadLeaders() {
    const { data } = await (supabase as any).from('moola_weekly_leaderboard').select('*').limit(20);
    setLeaders((data ?? []) as LeaderRow[]);
  }
  async function loadTodaySpin() {
    if (!profile) return;
    const today = new Date().toISOString().slice(0, 10);
    const { data } = await (supabase as any).from('moola_spin_claims')
      .select('amount').eq('user_id', profile.id).eq('claim_date', today).maybeSingle();
    setSpunToday(data?.amount ?? null);
  }

  async function spin() {
    if (spinning || spunToday !== null) return;
    setSpinning(true);
    sfx.tap();
    const { data, error } = await (supabase as any).rpc('spin_daily_wheel');
    if (error) { toast.error(error.message); setSpinning(false); return; }
    if (!data?.ok) { toast.info('You already spun today — come back tomorrow!'); setSpinning(false); setSpunToday(0); return; }
    const amount = data.amount as number;
    // Land on the wedge for that amount
    const idx = Math.max(0, WEDGES.indexOf(amount));
    const slice = 360 / WEDGES.length;
    const target = 360 * 6 + (360 - idx * slice - slice / 2);
    setAngle(target);
    setTimeout(async () => {
      setSpinning(false);
      setSpunToday(amount);
      toast.success(`🎉 You won ${amount}M!`);
      await refreshProfile?.();
      void loadLeaders();
    }, 3200);
  }

  return (
    <div className="flex-1 min-h-0 flex flex-col mxit-classic-bg">
      <div className="mxit-titlebar h-9 flex items-center px-3 gap-2 shrink-0">
        <button onClick={() => { sfx.tap(); navigate('/'); }} className="text-[11px] px-2 py-0.5 rounded-sm bg-white/10 border border-white/20">‹ Back</button>
        <div className="flex-1 text-center font-semibold text-[15px] tracking-wide flex items-center justify-center gap-2">
          <Coins className="w-4 h-4" /> Moola Hub
        </div>
        <span className="text-[11px] flex items-center gap-1 text-amber-200">
          <Coins className="w-3 h-3" /> {profile?.moola ?? 0}
        </span>
      </div>

      <div className="relative flex-1 overflow-y-auto mxit-watermark min-h-0">
        <div className="relative z-10 p-4 space-y-6">
          {/* Spin wheel */}
          <section className="bg-white/5 border border-white/10 rounded-lg p-4">
            <h2 className="text-white font-semibold flex items-center gap-2 mb-3"><Gift className="w-4 h-4 text-amber-200" /> Daily Spin</h2>
            <div className="flex flex-col items-center">
              <div className="relative w-48 h-48">
                <div className="absolute -top-2 left-1/2 -translate-x-1/2 w-0 h-0 border-l-[8px] border-l-transparent border-r-[8px] border-r-transparent border-t-[14px] border-t-amber-300 z-10" />
                <div
                  className="w-full h-full rounded-full border-4 border-amber-300 shadow-[0_0_30px_rgba(252,211,77,.5)]"
                  style={{
                    transform: `rotate(${angle}deg)`,
                    transition: spinning ? 'transform 3s cubic-bezier(.18,.74,.18,1)' : 'none',
                    background: `conic-gradient(${WEDGES.map((w, i) => {
                      const slice = 360 / WEDGES.length;
                      const colors = ['#1d4ed8', '#7c3aed', '#db2777', '#059669', '#d97706', '#0891b2', '#dc2626', '#65a30d'];
                      return `${colors[i % colors.length]} ${i * slice}deg ${(i + 1) * slice}deg`;
                    }).join(',')})`,
                  }}
                >
                  {WEDGES.map((w, i) => {
                    const slice = 360 / WEDGES.length;
                    const a = i * slice + slice / 2;
                    return (
                      <div
                        key={i}
                        className="absolute left-1/2 top-1/2 origin-bottom text-white text-xs font-bold"
                        style={{ transform: `translate(-50%, -100%) rotate(${a}deg) translateY(8px)` }}
                      >
                        {w}M
                      </div>
                    );
                  })}
                </div>
                <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                  <div className="w-10 h-10 rounded-full bg-amber-300 border-2 border-white shadow flex items-center justify-center text-[10px] font-bold text-amber-900">SPIN</div>
                </div>
              </div>
              <button
                onClick={spin}
                disabled={spinning || spunToday !== null}
                className="mt-4 px-6 py-2 rounded-lg bg-amber-300 text-amber-900 font-bold disabled:opacity-50"
              >
                {spunToday !== null ? `Today: +${spunToday}M` : spinning ? 'Spinning…' : 'Spin'}
              </button>
            </div>
          </section>

          {/* Send Moola */}
          <section className="bg-white/5 border border-white/10 rounded-lg p-4">
            <h2 className="text-white font-semibold flex items-center gap-2 mb-3"><Send className="w-4 h-4 text-amber-200" /> Send Moola</h2>
            <button onClick={() => setSendOpen(true)} className="w-full text-left px-3 py-2 rounded bg-white/5 hover:bg-white/10 text-white flex items-center justify-between">
              <span>Send Moola to a contact</span><ChevronRight className="w-4 h-4 text-white/60" />
            </button>
          </section>

          {/* Leaderboard */}
          <section className="bg-white/5 border border-white/10 rounded-lg p-4">
            <h2 className="text-white font-semibold flex items-center gap-2 mb-3"><Trophy className="w-4 h-4 text-amber-200" /> This Week's Top Earners</h2>
            {leaders.length === 0 && <div className="text-[12px] text-white/60">No earnings yet this week.</div>}
            <ol className="space-y-1">
              {leaders.map((l, i) => (
                <li key={l.user_id} className="flex items-center gap-2 px-2 py-1 rounded hover:bg-white/5">
                  <span className={`w-6 text-center font-bold ${i === 0 ? 'text-amber-300' : i === 1 ? 'text-zinc-300' : i === 2 ? 'text-orange-400' : 'text-white/40'}`}>#{i + 1}</span>
                  <button onClick={() => navigate(`/u/${l.mxit_id}`)} className="flex-1 text-left text-white truncate">{l.display_name}</button>
                  <span className="text-amber-200 text-[12px] flex items-center gap-1"><Coins className="w-3 h-3" /> {l.earned}</span>
                </li>
              ))}
            </ol>
          </section>
        </div>
      </div>

      <SendMoolaSheet open={sendOpen} onClose={() => { setSendOpen(false); void refreshProfile?.(); void loadLeaders(); }} />

      <div className="mxit-softkeys h-10 flex items-stretch text-sm font-medium shrink-0">
        <button onClick={() => { sfx.tap(); navigate('/'); }} className="flex-1 text-left pl-4 active:bg-black/30">Back</button>
        <button onClick={() => { sfx.tap(); navigate('/portal/portal'); }} className="flex-1 text-right pr-4 active:bg-black/30">Top up</button>
      </div>
    </div>
  );
}

function SendMoolaSheet({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { profile } = useAuth();
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [picked, setPicked] = useState<Contact | null>(null);
  const [amount, setAmount] = useState(10);
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!open || !profile) return;
    (async () => {
      const { data: cs } = await supabase.from('contacts')
        .select('requester_id, addressee_id, status')
        .eq('status', 'accepted')
        .or(`requester_id.eq.${profile.id},addressee_id.eq.${profile.id}`);
      const otherIds = (cs ?? []).map((c) => c.requester_id === profile.id ? c.addressee_id : c.requester_id);
      if (!otherIds.length) { setContacts([]); return; }
      const { data: profs } = await supabase.from('profiles').select('id, display_name, mxit_id, avatar_url').in('id', otherIds);
      setContacts((profs ?? []) as Contact[]);
    })();
  }, [open, profile]);

  async function send() {
    if (!picked || amount <= 0) return;
    setBusy(true);
    const { data, error } = await (supabase as any).rpc('send_moola', { _to: picked.id, _amount: amount, _note: note || null });
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    if (data?.ok) { toast.success(`Sent ${amount}M to ${picked.display_name}`); setPicked(null); setNote(''); setAmount(10); onClose(); }
  }

  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end" onClick={onClose}>
      <div className="absolute inset-0 bg-black/50" />
      <div onClick={(e) => e.stopPropagation()} className="relative w-full bg-card rounded-t-2xl p-4 max-h-[80vh] flex flex-col" style={{ paddingBottom: 'calc(env(safe-area-inset-bottom) + 1rem)' }}>
        <div className="flex justify-between items-center mb-3">
          <span className="font-pixel text-[11px] text-mxit-primary">SEND MOOLA</span>
          <button onClick={onClose}><X className="w-4 h-4" /></button>
        </div>
        {!picked ? (
          <div className="flex-1 overflow-y-auto space-y-1">
            {contacts.length === 0 && <div className="text-sm text-muted-foreground text-center py-6">No contacts yet</div>}
            {contacts.map((c) => (
              <button key={c.id} onClick={() => setPicked(c)} className="w-full text-left px-3 py-2 rounded hover:bg-secondary flex items-center justify-between">
                <span>{c.display_name}</span>
                <span className="text-xs text-muted-foreground">@{c.mxit_id}</span>
              </button>
            ))}
          </div>
        ) : (
          <div className="space-y-3">
            <div className="text-sm">Sending to <strong>{picked.display_name}</strong></div>
            <div>
              <label className="text-xs text-muted-foreground">Amount (Moola)</label>
              <input type="number" min={1} value={amount} onChange={(e) => setAmount(Math.max(1, parseInt(e.target.value || '1')))} className="w-full mt-1 px-3 py-2 rounded bg-secondary border border-border" />
            </div>
            <div>
              <label className="text-xs text-muted-foreground">Note (optional)</label>
              <input value={note} onChange={(e) => setNote(e.target.value.slice(0, 80))} placeholder="Thanks!" className="w-full mt-1 px-3 py-2 rounded bg-secondary border border-border" />
            </div>
            <div className="flex gap-2">
              <button onClick={() => setPicked(null)} className="flex-1 px-3 py-2 rounded bg-secondary">Back</button>
              <button onClick={send} disabled={busy} className="flex-1 px-3 py-2 rounded bg-mxit-primary text-white disabled:opacity-50">
                {busy ? 'Sending…' : `Send ${amount}M`}
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
