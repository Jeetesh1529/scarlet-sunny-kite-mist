import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import { MxitHeader } from '@/components/MxitHeader';
import { sfx } from '@/lib/sfx';

const APP = 'Mxit — The Legacy';
const CONTACT = 'support@mxit-the-legacy.lovable.app';
const UPDATED = 'May 2026';

const PRIVACY = (
  <>
    <h2>1. Who we are</h2>
    <p>{APP} is a fan revival of the classic 2005 Mxit chat experience. We collect the minimum amount of information needed to run the app.</p>

    <h2>2. What we collect</h2>
    <ul>
      <li><b>Account info</b> — email, password (hashed), Mxit ID, display name, age, gender (optional), avatar.</li>
      <li><b>Chat content</b> — your messages, contact list, group memberships, mood, presence.</li>
      <li><b>Wallet</b> — your Moola balance and transaction history.</li>
      <li><b>Device basics</b> — anonymous analytics about pageviews and approximate country.</li>
    </ul>

    <h2>3. How we use it</h2>
    <p>To deliver chats, store your profile, prevent abuse, and improve the app. We do not sell your data.</p>

    <h2>4. Sharing</h2>
    <p>Other users can see your public profile (Mxit ID, display name, mood, avatar, presence) and any messages you send to them. We share data with:</p>
    <ul>
      <li>Our backend host (Lovable Cloud / Supabase) for storage.</li>
      <li>Apple App Store / Google Play for in-app purchases (Moola top-ups).</li>
      <li>Law enforcement when legally required.</li>
    </ul>

    <h2>5. Your rights</h2>
    <p>You can edit your profile any time. You can <b>permanently delete your account and all associated data</b> from Settings → Delete account, or by emailing us.</p>

    <h2>6. Children</h2>
    <p>You must be 14 or older to use {APP}. If you are under 18, please have a parent's permission.</p>

    <h2>7. Security</h2>
    <p>We use industry-standard encryption in transit (HTTPS) and at rest. No system is 100% secure — please use a unique password.</p>

    <h2>8. Contact</h2>
    <p>Questions? Email <a href={`mailto:${CONTACT}`}>{CONTACT}</a>.</p>

    <p className="text-xs opacity-70 mt-6">Last updated: {UPDATED}</p>
  </>
);

const TERMS = (
  <>
    <h2>1. Acceptance</h2>
    <p>By using {APP} you agree to these terms. If you don't agree, please don't use the app.</p>

    <h2>2. Eligibility</h2>
    <p>You must be at least 14 years old. Accounts found to belong to under-14 users will be removed.</p>

    <h2>3. Acceptable use</h2>
    <p>You agree not to:</p>
    <ul>
      <li>Harass, threaten, or impersonate other users.</li>
      <li>Post sexual content involving minors, hate speech, illegal content, or spam.</li>
      <li>Attempt to break, scrape, reverse-engineer, or overload the service.</li>
      <li>Use automated tools to send messages or create accounts.</li>
    </ul>
    <p>We may suspend or delete accounts that violate these rules without notice.</p>

    <h2>4. Moola (in-app currency)</h2>
    <p>Moola is virtual currency for use inside {APP} only. It cannot be exchanged for cash, transferred between users, or withdrawn. Refunds are governed by Apple's and Google's store policies. Any unused Moola is forfeited if your account is deleted.</p>

    <h2>5. Reporting & moderation</h2>
    <p>You can report abusive content or block other users at any time. We review reports and may take action including warnings, removing content, or banning accounts.</p>

    <h2>6. Disclaimer</h2>
    <p>{APP} is provided "as is" without warranty of any kind. We are not liable for messages sent by other users or for any losses arising from use of the service.</p>

    <h2>7. Termination</h2>
    <p>You may delete your account at any time from Settings. We may terminate accounts that violate these terms.</p>

    <h2>8. Changes</h2>
    <p>We may update these terms. Material changes will be announced in-app.</p>

    <h2>9. Contact</h2>
    <p>Email <a href={`mailto:${CONTACT}`}>{CONTACT}</a>.</p>

    <p className="text-xs opacity-70 mt-6">Last updated: {UPDATED}</p>
  </>
);

export default function Legal() {
  const { kind } = useParams();
  const navigate = useNavigate();
  const isPrivacy = kind === 'privacy';
  const title = isPrivacy ? 'Privacy Policy' : 'Terms of Service';

  return (
    <div className="flex-1 flex flex-col">
      <MxitHeader
        left={
          <button
            onClick={() => { sfx.tap(); navigate(-1); }}
            className="p-2 hover:bg-white/10 rounded-md tap-scale"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
        }
        title={title}
        subtitle={APP}
      />
      <div className="flex-1 overflow-y-auto mxit-screen-bg p-4">
        <article className="prose prose-sm max-w-none bg-card rounded-lg p-4 mxit-shadow-pop
          [&_h2]:font-pixel [&_h2]:text-[11px] [&_h2]:text-mxit-primary [&_h2]:mt-4 [&_h2]:mb-1
          [&_p]:text-sm [&_p]:leading-relaxed [&_ul]:list-disc [&_ul]:pl-5 [&_ul]:text-sm [&_ul]:space-y-0.5
          [&_a]:text-mxit-primary [&_a]:underline">
          <h1 className="font-pixel text-sm text-mxit-deep mb-2">{title}</h1>
          {isPrivacy ? PRIVACY : TERMS}
        </article>
      </div>
    </div>
  );
}
