import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';
import { sfx } from '@/lib/sfx';
import logo from '@/assets/mxit-legacy-watermark.png';

export default function ResetPassword() {
  const navigate = useNavigate();
  const [ready, setReady] = useState(false);
  const [password, setPassword] = useState('');
  const [confirm, setConfirm] = useState('');
  const [busy, setBusy] = useState(false);

  // Supabase places ?type=recovery&access_token=… in the URL hash on the
  // password-reset link. The auth client picks that up automatically and emits
  // a PASSWORD_RECOVERY event — we just need to wait for the session.
  useEffect(() => {
    const { data: sub } = supabase.auth.onAuthStateChange((event) => {
      if (event === 'PASSWORD_RECOVERY' || event === 'SIGNED_IN') setReady(true);
    });
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session) setReady(true);
    });
    return () => sub.subscription.unsubscribe();
  }, []);

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    sfx.tap();
    if (password.length < 6) { toast.error('Password must be at least 6 characters'); return; }
    if (password !== confirm) { toast.error('Passwords do not match'); return; }
    setBusy(true);
    try {
      const { error } = await supabase.auth.updateUser({ password });
      if (error) throw error;
      toast.success('Password updated — you are signed in.');
      navigate('/', { replace: true });
    } catch (err: any) {
      sfx.error();
      toast.error(err.message || 'Could not update password');
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="flex-1 relative overflow-hidden bg-black text-white">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_70%_60%_at_50%_30%,hsl(0_0%_18%)_0%,hsl(0_0%_5%)_60%,#000_100%)]" />
      <div className="relative h-full flex flex-col safe-top px-6">
        <div className="pt-6 pb-4 flex justify-center">
          <img src={logo} alt="" className="w-[60%] max-w-[260px] mix-blend-screen" />
        </div>
        <h1 className="font-pixel text-sm text-center mb-1">reset password</h1>
        <p className="text-xs text-white/60 text-center mb-5">Pick a new password for your account.</p>

        {!ready ? (
          <div className="text-center text-white/70 text-sm py-8">Loading reset link…</div>
        ) : (
          <form onSubmit={submit} className="space-y-3">
            <div className="space-y-1.5">
              <Label htmlFor="pw" className="text-white/80 text-xs">New password</Label>
              <Input
                id="pw" type="password" required minLength={6}
                value={password} onChange={(e) => setPassword(e.target.value)}
                className="bg-white/5 border-white/15 text-white"
              />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="pw2" className="text-white/80 text-xs">Confirm password</Label>
              <Input
                id="pw2" type="password" required minLength={6}
                value={confirm} onChange={(e) => setConfirm(e.target.value)}
                className="bg-white/5 border-white/15 text-white"
              />
            </div>
            <Button type="submit" disabled={busy} className="w-full bg-white text-black hover:bg-white/90 font-pixel text-[11px] h-11">
              {busy ? '…' : 'update password'}
            </Button>
            <Button type="button" variant="ghost" onClick={() => navigate('/')} className="w-full text-xs text-white/70 hover:bg-white/5">
              cancel
            </Button>
          </form>
        )}
      </div>
    </div>
  );
}
