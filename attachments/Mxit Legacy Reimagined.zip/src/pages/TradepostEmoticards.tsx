/**
 * Tradepost > Emoticards — pick a card design and send as a DM to a contact.
 * Costs 1 Moola per send. Posts a message into the existing 1-to-1 conversation.
 */
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { spendMoola } from '@/lib/moola';
import { sfx } from '@/lib/sfx';
import { toast } from 'sonner';
import { Coins, Sparkles, Send } from 'lucide-react';
import { Emoticon } from '@/components/Emoticon';

type Card = { id: string; title: string; emote: string; color: string; message: string };

const CARDS: Card[] = [
  { id: 'love',   title: 'I ♥ You',     emote: '<3',   color: 'from-pink-500 to-rose-600',     message: 'Sending you all my love <3' },
  { id: 'happy',  title: 'You make me smile', emote: ':)', color: 'from-amber-400 to-orange-500', message: 'You make me smile :)' },
  { id: 'rose',   title: 'A rose',      emote: '@>--', color: 'from-rose-400 to-fuchsia-600',  message: 'A rose for you @>--' },
  { id: 'cool',   title: 'Stay cool',   emote: '8-)',  color: 'from-cyan-400 to-blue-600',     message: 'Stay cool 8-)' },
  { id: 'rock',   title: 'Rock on',     emote: '\\m/', color: 'from-zinc-700 to-zinc-900',     message: 'Rock on \\m/' },
  { id: 'angel',  title: 'Thinking of you', emote: 'O:)', color: 'from-sky-300 to-indigo-500', message: 'Thinking of you O:)' },
];

type Contact = { id: string; display_name: string; mxit_id: string };

export default function TradepostEmoticards() {
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [picked, setPicked] = useState<Card | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!profile) return;
    (async () => {
      const { data } = await supabase
        .from('contacts')
        .select('requester_id, addressee_id, status')
        .or(`requester_id.eq.${profile.id},addressee_id.eq.${profile.id}`)
        .eq('status', 'accepted');
      const ids = Array.from(new Set(
        (data ?? []).map((r: any) => r.requester_id === profile.id ? r.addressee_id : r.requester_id),
      ));
      if (!ids.length) { setContacts([]); return; }
      const { data: ps } = await supabase
        .from('profiles').select('id, display_name, mxit_id').in('id', ids);
      setContacts((ps ?? []) as Contact[]);
    })();
  }, [profile]);

  const send = async (toUserId: string) => {
    if (!profile || !picked || busy) return;
    setBusy(true);
    sfx.tap();
    const ok = await spendMoola({
      userId: profile.id,
      currentBalance: profile.moola,
      amount: 1,
      reason: `Emoticard: ${picked.title}`,
      type: 'spend',
    });
    if (!ok) { setBusy(false); return; }

    // find or create conversation
    const a = profile.id < toUserId ? profile.id : toUserId;
    const b = profile.id < toUserId ? toUserId : profile.id;
    let { data: conv } = await supabase
      .from('conversations').select('id').eq('user_a', a).eq('user_b', b).maybeSingle();
    if (!conv) {
      const { data: created, error } = await supabase
        .from('conversations').insert({ user_a: a, user_b: b }).select('id').single();
      if (error) { toast.error(error.message); setBusy(false); return; }
      conv = created;
    }
    await supabase.from('messages').insert({
      conversation_id: conv!.id,
      sender_id: profile.id,
      content: `🎴 ${picked.title} — ${picked.message}`,
    });
    toast.success('Emoticard sent!');
    setBusy(false);
    setPicked(null);
  };

  return (
    <div className="flex-1 min-h-0 flex flex-col mxit-classic-bg">
      <div className="mxit-titlebar h-9 flex items-center px-3 gap-2 shrink-0">
        <button onClick={() => { sfx.tap(); picked ? setPicked(null) : navigate('/tradepost'); }}
          className="text-[11px] px-2 py-0.5 rounded-sm bg-white/10 border border-white/20">‹ Back</button>
        <div className="flex-1 text-center font-semibold text-[15px] tracking-wide flex items-center justify-center gap-2">
          <Sparkles className="w-4 h-4" /> Emoticards
        </div>
        <span className="text-[10px] text-amber-200 flex items-center gap-1">
          <Coins className="w-3 h-3" /> {profile?.moola ?? 0}
        </span>
      </div>

      <div className="relative flex-1 overflow-y-auto mxit-watermark min-h-0">
        <div className="relative z-10 p-3">
          {!picked ? (
            <>
              <div className="text-[11px] text-white/60 italic mb-2">
                Pick a card to send to a friend. 1 Moola per send.
              </div>
              <div className="grid grid-cols-2 gap-2">
                {CARDS.map((c) => (
                  <button
                    key={c.id}
                    onClick={() => { sfx.tap(); setPicked(c); }}
                    className={`aspect-[4/3] rounded-md p-3 flex flex-col items-center justify-center gap-2 text-white border border-white/30 bg-gradient-to-br ${c.color} hover:scale-[1.02] active:scale-[0.98] transition-transform`}
                  >
                    <Emoticon code={c.emote} size={36} />
                    <div className="text-[11px] font-semibold drop-shadow">{c.title}</div>
                  </button>
                ))}
              </div>
            </>
          ) : (
            <>
              <div className={`rounded-md p-6 mb-3 flex flex-col items-center gap-2 text-white border border-white/30 bg-gradient-to-br ${picked.color}`}>
                <Emoticon code={picked.emote} size={64} />
                <div className="font-semibold">{picked.title}</div>
                <div className="text-[11px] text-white/90 italic">{picked.message}</div>
              </div>
              <div className="text-[11px] text-white/60 mb-2">Send to:</div>
              {contacts.length === 0 ? (
                <div className="text-[11px] text-white/50 italic">No contacts yet — add friends from the Contacts tab.</div>
              ) : (
                <div className="space-y-1">
                  {contacts.map((c) => (
                    <button
                      key={c.id}
                      onClick={() => send(c.id)}
                      disabled={busy}
                      className="w-full flex items-center gap-2 px-3 py-2 rounded-md bg-white/10 border border-white/20 hover:bg-white/15 active:bg-white/20 text-white disabled:opacity-50"
                    >
                      <span className="status-orb orb-online" />
                      <span className="flex-1 text-left text-sm font-medium">{c.display_name}</span>
                      <span className="text-[10px] text-white/60">@{c.mxit_id}</span>
                      <Send className="w-3.5 h-3.5 text-amber-200" />
                    </button>
                  ))}
                </div>
              )}
            </>
          )}
        </div>
      </div>

      <div className="mxit-softkeys h-10 flex items-stretch text-sm font-medium shrink-0">
        <button onClick={() => { sfx.tap(); picked ? setPicked(null) : navigate('/tradepost'); }} className="flex-1 text-left pl-4 active:bg-black/30">Back</button>
        <button onClick={() => { sfx.tap(); navigate('/'); }} className="flex-1 text-right pr-4 active:bg-black/30">Home</button>
      </div>
    </div>
  );
}
