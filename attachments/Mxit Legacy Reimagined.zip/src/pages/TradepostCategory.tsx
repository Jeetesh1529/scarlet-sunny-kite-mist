/**
 * Tradepost > Category — list of zones inside a category.
 * Tapping a zone navigates to /tradepost/zone/:slug to pick or quick-join a room.
 */
import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { sfx } from '@/lib/sfx';
import { toast } from 'sonner';
import { ChevronRight, ShieldAlert } from 'lucide-react';

type Category = { id: string; name: string; description: string | null; min_age: number };
type Zone = { id: string; slug: string; name: string; description: string | null; min_age: number; position: number };

export default function TradepostCategory() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const [cat, setCat] = useState<Category | null>(null);
  const [zones, setZones] = useState<Zone[]>([]);

  useEffect(() => {
    (async () => {
      if (!slug) return;
      const { data: c } = await supabase
        .from('chat_categories')
        .select('id, name, description, min_age')
        .eq('slug', slug)
        .maybeSingle();
      if (!c) { toast.error('Category not found'); navigate('/tradepost/chatrooms'); return; }
      setCat(c as Category);
      const { data: zs } = await supabase
        .from('chatroom_zones')
        .select('id, slug, name, description, min_age, position')
        .eq('category_id', (c as Category).id)
        .order('position');
      setZones((zs ?? []) as Zone[]);
    })();
  }, [slug, navigate]);

  return (
    <div className="flex-1 min-h-0 flex flex-col mxit-classic-bg">
      <div className="mxit-titlebar h-9 flex items-center px-3 gap-2 shrink-0">
        <button
          onClick={() => { sfx.tap(); navigate('/tradepost/chatrooms'); }}
          className="text-[11px] px-2 py-0.5 rounded-sm bg-white/10 border border-white/20"
        >
          ‹ Back
        </button>
        <div className="flex-1 text-center font-semibold text-[15px] tracking-wide truncate">
          {cat?.name ?? '…'}
        </div>
        <span className="text-[10px] text-amber-200">30 / room</span>
      </div>

      <div className="relative flex-1 overflow-y-auto mxit-watermark min-h-0">
        <div className="relative z-10 py-2">
          {cat?.description && (
            <div className="px-3 pb-2 text-[11px] text-white/60 italic">{cat.description}</div>
          )}
          {zones.map((z) => (
            <button
              key={z.id}
              onClick={() => { sfx.tap(); navigate(`/tradepost/zone/${z.slug}`); }}
              className="w-full text-left flex items-center gap-3 pl-3 pr-3 py-2 hover:bg-white/5 active:bg-white/10"
            >
              <span className="status-orb orb-online" />
              <span
                className="flex-1 min-w-0 truncate text-white font-medium tracking-wide"
                style={{ textShadow: '0 1px 0 hsl(220 80% 8% / 0.6)' }}
              >
                {z.name}
                <span className="block text-[11px] font-normal text-white/60 truncate">
                  {z.description}
                </span>
              </span>
              {z.min_age >= 18 && (
                <span className="text-[9px] text-red-300 flex items-center gap-0.5 mr-1">
                  <ShieldAlert className="w-3 h-3" /> 18+
                </span>
              )}
              <ChevronRight className="w-4 h-4 text-white/60" />
            </button>
          ))}
        </div>
      </div>

      <div className="mxit-softkeys h-10 flex items-stretch text-sm font-medium shrink-0">
        <button onClick={() => { sfx.tap(); navigate('/tradepost/chatrooms'); }} className="flex-1 text-left pl-4 active:bg-black/30">Back</button>
        <button onClick={() => { sfx.tap(); navigate('/'); }} className="flex-1 text-right pr-4 active:bg-black/30">Home</button>
      </div>
    </div>
  );
}
