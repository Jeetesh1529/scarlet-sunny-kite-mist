import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { Trash2 } from 'lucide-react';

type Ann = {
  id: string;
  author_id: string;
  title: string;
  body: string;
  severity: string;
  starts_at: string;
  ends_at: string | null;
  created_at: string;
};

export function AnnouncementsPanel() {
  const { user } = useAuth();
  const [list, setList] = useState<Ann[]>([]);
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [severity, setSeverity] = useState<'info' | 'warning' | 'critical'>('info');
  const [hours, setHours] = useState(24);
  const [busy, setBusy] = useState(false);

  const load = async () => {
    const { data } = await supabase.from('announcements').select('*').order('created_at', { ascending: false }).limit(50);
    setList((data ?? []) as Ann[]);
  };
  useEffect(() => { void load(); }, []);

  const post = async () => {
    if (!user || !title.trim() || !body.trim()) return;
    setBusy(true);
    const ends_at = hours > 0 ? new Date(Date.now() + hours * 3600_000).toISOString() : null;
    const { error } = await supabase.from('announcements').insert({
      author_id: user.id, title: title.trim(), body: body.trim(), severity, ends_at,
    });
    setBusy(false);
    if (error) return toast.error(error.message);
    toast.success('Announcement posted');
    setTitle(''); setBody('');
    void load();
  };

  const remove = async (id: string) => {
    if (!confirm('Delete this announcement?')) return;
    const { error } = await supabase.from('announcements').delete().eq('id', id);
    if (error) return toast.error(error.message);
    void load();
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardContent className="p-4 space-y-3">
          <div className="text-sm font-semibold">Broadcast a new announcement</div>
          <Input placeholder="Title" value={title} onChange={(e) => setTitle(e.target.value)} maxLength={120} />
          <Textarea placeholder="Body" value={body} onChange={(e) => setBody(e.target.value)} maxLength={1000} rows={3} />
          <div className="flex flex-wrap gap-2 items-center">
            <select value={severity} onChange={(e) => setSeverity(e.target.value as any)} className="px-2 py-1 rounded border bg-background">
              <option value="info">Info</option>
              <option value="warning">Warning</option>
              <option value="critical">Critical</option>
            </select>
            <label className="text-xs text-muted-foreground">Visible for</label>
            <Input type="number" min={0} value={hours} onChange={(e) => setHours(parseInt(e.target.value) || 0)} className="w-20" />
            <span className="text-xs text-muted-foreground">hours (0 = no expiry)</span>
            <Button onClick={post} disabled={busy || !title || !body} className="ml-auto">Post</Button>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-2">
        {list.length === 0 && <p className="text-sm text-muted-foreground">No announcements yet.</p>}
        {list.map((a) => {
          const active = (!a.ends_at || new Date(a.ends_at) > new Date()) && new Date(a.starts_at) <= new Date();
          return (
            <Card key={a.id}>
              <CardContent className="p-3 flex items-start gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <Badge variant={a.severity === 'critical' ? 'destructive' : a.severity === 'warning' ? 'default' : 'secondary'}>{a.severity}</Badge>
                    {active ? <Badge variant="outline">active</Badge> : <Badge variant="outline" className="opacity-50">expired</Badge>}
                    <span className="text-xs text-muted-foreground">{new Date(a.created_at).toLocaleString()}</span>
                  </div>
                  <div className="font-semibold">{a.title}</div>
                  <div className="text-sm text-muted-foreground whitespace-pre-wrap">{a.body}</div>
                </div>
                <Button size="icon" variant="ghost" onClick={() => remove(a.id)}><Trash2 className="w-4 h-4" /></Button>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
