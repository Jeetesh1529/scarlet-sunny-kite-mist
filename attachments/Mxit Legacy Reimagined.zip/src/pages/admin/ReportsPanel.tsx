import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';

type Report = {
  id: string;
  reporter_id: string;
  reported_user_id: string;
  message_id: string | null;
  category: string;
  details: string | null;
  status: string;
  created_at: string;
};
type Profile = { id: string; mxit_id: string; display_name: string; is_suspended: boolean };
type Msg = { id: string; content: string; sender_id: string };

type Filter = 'open' | 'reviewed' | 'dismissed' | 'all';

export function ReportsPanel({ onCount }: { onCount?: (n: number) => void }) {
  const [filter, setFilter] = useState<Filter>('open');
  const [reports, setReports] = useState<Report[] | null>(null);
  const [profiles, setProfiles] = useState<Record<string, Profile>>({});
  const [messages, setMessages] = useState<Record<string, Msg>>({});
  const [working, setWorking] = useState<string | null>(null);

  const load = useCallback(async () => {
    setReports(null);
    let q = supabase.from('user_reports').select('*').order('created_at', { ascending: false }).limit(200);
    if (filter !== 'all') q = q.eq('status', filter);
    const { data: rs, error } = await q;
    if (error) { toast.error(error.message); return; }
    const list = (rs ?? []) as Report[];
    setReports(list);

    const userIds = Array.from(new Set(list.flatMap(r => [r.reporter_id, r.reported_user_id])));
    const msgIds = list.map(r => r.message_id).filter(Boolean) as string[];
    if (userIds.length) {
      const { data: ps } = await supabase.from('profiles').select('id, mxit_id, display_name, is_suspended').in('id', userIds);
      setProfiles(Object.fromEntries((ps ?? []).map(p => [p.id, p as Profile])));
    }
    if (msgIds.length) {
      const { data: ms } = await supabase.from('messages').select('id, content, sender_id').in('id', msgIds);
      setMessages(Object.fromEntries((ms ?? []).map(m => [m.id, m as Msg])));
    }

    // open count for the badge
    const { count } = await supabase.from('user_reports').select('*', { count: 'exact', head: true }).eq('status', 'open');
    onCount?.(count ?? 0);
  }, [filter, onCount]);

  useEffect(() => { void load(); }, [load]);

  const setStatus = async (id: string, status: 'reviewed' | 'dismissed') => {
    setWorking(id);
    const { error } = await supabase.from('user_reports').update({ status }).eq('id', id);
    setWorking(null);
    if (error) return toast.error(error.message);
    toast.success(`Marked ${status}`);
    void load();
  };

  const deleteMessage = async (msgId: string, reportId: string) => {
    if (!confirm('Delete this message permanently?')) return;
    setWorking(reportId);
    const { error } = await supabase.from('messages').delete().eq('id', msgId);
    setWorking(null);
    if (error) return toast.error(error.message);
    toast.success('Message deleted');
    void load();
  };

  const toggleSuspend = async (userId: string, currentlySuspended: boolean, reportId: string) => {
    const reason = currentlySuspended
      ? null
      : prompt('Reason for suspension (shown to admins only):') ?? undefined;
    if (!currentlySuspended && reason === undefined) return;
    setWorking(reportId);
    const { error } = await supabase.from('profiles').update({
      is_suspended: !currentlySuspended,
      suspended_at: !currentlySuspended ? new Date().toISOString() : null,
      suspended_reason: !currentlySuspended ? (reason ?? null) : null,
    }).eq('id', userId);
    setWorking(null);
    if (error) return toast.error(error.message);
    toast.success(currentlySuspended ? 'User unsuspended' : 'User suspended');
    void load();
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-2 flex-wrap">
        {(['open', 'reviewed', 'dismissed', 'all'] as Filter[]).map(f => (
          <Button
            key={f}
            size="sm"
            variant={filter === f ? 'default' : 'outline'}
            onClick={() => setFilter(f)}
          >
            {f}
          </Button>
        ))}
      </div>

      {!reports ? (
        <Skeleton className="h-40" />
      ) : reports.length === 0 ? (
        <p className="text-sm text-muted-foreground">No reports in this view.</p>
      ) : (
        <div className="space-y-3">
          {reports.map(r => {
            const reporter = profiles[r.reporter_id];
            const reported = profiles[r.reported_user_id];
            const msg = r.message_id ? messages[r.message_id] : null;
            const isWorking = working === r.id;
            return (
              <Card key={r.id}>
                <CardContent className="p-4 space-y-3">
                  <div className="flex items-start justify-between gap-2 flex-wrap">
                    <div className="text-sm">
                      <Badge variant="outline" className="mr-2">{r.category}</Badge>
                      <Badge variant={r.status === 'open' ? 'destructive' : 'secondary'}>{r.status}</Badge>
                      <span className="ml-2 text-muted-foreground text-xs">
                        {new Date(r.created_at).toLocaleString()}
                      </span>
                    </div>
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                    <div>
                      <div className="text-xs uppercase text-muted-foreground">Reporter</div>
                      <div>{reporter ? `${reporter.display_name} (@${reporter.mxit_id})` : r.reporter_id.slice(0, 8)}</div>
                    </div>
                    <div>
                      <div className="text-xs uppercase text-muted-foreground">Reported user</div>
                      <div>
                        {reported ? `${reported.display_name} (@${reported.mxit_id})` : r.reported_user_id.slice(0, 8)}
                        {reported?.is_suspended && <Badge variant="destructive" className="ml-2">suspended</Badge>}
                      </div>
                    </div>
                  </div>

                  {r.details && (
                    <div className="text-sm bg-muted p-2 rounded">
                      <div className="text-xs uppercase text-muted-foreground mb-1">Reason given</div>
                      {r.details}
                    </div>
                  )}

                  {msg && (
                    <div className="text-sm bg-muted p-2 rounded">
                      <div className="text-xs uppercase text-muted-foreground mb-1">Reported message</div>
                      <div className="font-mono whitespace-pre-wrap break-words">{msg.content}</div>
                    </div>
                  )}
                  {r.message_id && !msg && (
                    <div className="text-xs text-muted-foreground italic">Message no longer exists.</div>
                  )}

                  <div className="flex gap-2 flex-wrap pt-1">
                    {r.status === 'open' && (
                      <>
                        <Button size="sm" disabled={isWorking} onClick={() => setStatus(r.id, 'reviewed')}>
                          Mark reviewed
                        </Button>
                        <Button size="sm" variant="outline" disabled={isWorking} onClick={() => setStatus(r.id, 'dismissed')}>
                          Dismiss
                        </Button>
                      </>
                    )}
                    {msg && (
                      <Button size="sm" variant="destructive" disabled={isWorking} onClick={() => deleteMessage(msg.id, r.id)}>
                        Delete message
                      </Button>
                    )}
                    {reported && (
                      <Button
                        size="sm"
                        variant={reported.is_suspended ? 'outline' : 'destructive'}
                        disabled={isWorking}
                        onClick={() => toggleSuspend(reported.id, reported.is_suspended, r.id)}
                      >
                        {reported.is_suspended ? 'Unsuspend user' : 'Suspend user'}
                      </Button>
                    )}
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
