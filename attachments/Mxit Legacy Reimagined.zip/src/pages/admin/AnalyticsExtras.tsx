import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';

type DAU = { day: string; dau: number; events: number };
type Room = { room_id: string; room_name: string; messages: number; unique_senders: number };
type Retention = { active_today: number; cohort_size: number; retention_pct: number };

export function AnalyticsExtras() {
  const [dau, setDau] = useState<DAU[] | null>(null);
  const [rooms, setRooms] = useState<Room[] | null>(null);
  const [ret, setRet] = useState<Retention | null>(null);

  useEffect(() => {
    (async () => {
      const [d, r, x] = await Promise.all([
        (supabase as any).from('analytics_dau').select('*'),
        (supabase as any).from('analytics_top_rooms').select('*'),
        (supabase as any).from('analytics_retention_d7').select('*').maybeSingle(),
      ]);
      setDau((d.data ?? []) as DAU[]);
      setRooms((r.data ?? []) as Room[]);
      setRet((x.data ?? null) as Retention | null);
    })();
  }, []);

  const max = dau ? Math.max(1, ...dau.map((d) => d.dau)) : 1;
  const mau = dau ? new Set(dau.flatMap((d) => Array(d.dau).fill(d.day))).size : 0; // approx
  const totalDau30 = dau ? dau.reduce((a, b) => a + b.dau, 0) : 0;

  return (
    <div className="space-y-4 mt-4">
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        <Card><CardContent className="p-4">
          <div className="text-xs uppercase text-muted-foreground">DAU events (30d)</div>
          <div className="text-3xl font-bold">{totalDau30}</div>
        </CardContent></Card>
        <Card><CardContent className="p-4">
          <div className="text-xs uppercase text-muted-foreground">D7 retention</div>
          <div className="text-3xl font-bold">{ret ? `${ret.retention_pct}%` : '—'}</div>
          <div className="text-xs text-muted-foreground">{ret?.active_today ?? 0} of {ret?.cohort_size ?? 0} returned</div>
        </CardContent></Card>
        <Card><CardContent className="p-4">
          <div className="text-xs uppercase text-muted-foreground">Top room (7d)</div>
          <div className="text-base font-bold truncate">{rooms?.[0]?.room_name ?? '—'}</div>
          <div className="text-xs text-muted-foreground">{rooms?.[0]?.messages ?? 0} messages</div>
        </CardContent></Card>
      </div>

      <Card>
        <CardHeader><CardTitle className="text-base">DAU · last 30 days</CardTitle></CardHeader>
        <CardContent>
          {!dau ? <Skeleton className="h-32" /> : (
            <div className="flex items-end gap-1 h-32">
              {dau.map((d) => (
                <div key={d.day} className="flex-1 flex flex-col items-center gap-1" title={`${d.day}: ${d.dau}`}>
                  <div className="w-full bg-primary rounded-t" style={{ height: `${(d.dau / max) * 100}%`, minHeight: 2 }} />
                  <div className="text-[8px] text-muted-foreground">{d.day.slice(5)}</div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader><CardTitle className="text-base">Top rooms · last 7 days</CardTitle></CardHeader>
        <CardContent>
          {!rooms ? <Skeleton className="h-32" /> : rooms.length === 0 ? (
            <p className="text-sm text-muted-foreground">No room activity.</p>
          ) : (
            <ol className="space-y-1">
              {rooms.map((r, i) => (
                <li key={r.room_id} className="flex items-center gap-2 text-sm">
                  <span className="w-6 text-center font-bold text-muted-foreground">#{i + 1}</span>
                  <span className="flex-1 truncate">{r.room_name}</span>
                  <span className="text-xs text-muted-foreground">{r.unique_senders} users</span>
                  <span className="font-mono w-12 text-right">{r.messages}</span>
                </li>
              ))}
            </ol>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
