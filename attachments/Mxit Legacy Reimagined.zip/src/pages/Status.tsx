import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { PixelAvatar } from '@/components/PixelAvatar';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { ChevronLeft, Camera, Type, Eye, Send, X, Plus, Trash2, Lock, Heart, MessageCircle } from 'lucide-react';
import { sfx } from '@/lib/sfx';
import { toast } from 'sonner';
import { uploadToBucket, STATUS_BUCKET, MAX_STATUS_MEDIA_BYTES } from '@/lib/statusMedia';
import { awardAchievement } from '@/lib/achievements';

type Status = {
  id: string;
  author_id: string;
  kind: 'text' | 'image' | 'video';
  media_url: string | null;
  caption: string | null;
  background: string | null;
  audience_mode: 'everyone' | 'contacts' | 'contacts_except' | 'only_share_with';
  created_at: string;
  expires_at: string;
};

type AuthorRow = { id: string; display_name: string; avatar_seed: string | null; avatar_url: string | null };

const BG_COLORS = ['#0A2A5E', '#1E78D6', '#2E9F4D', '#E04B98', '#111111', '#7C3AED', '#F59E0B', '#DC2626'];

export default function StatusPage() {
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [statuses, setStatuses] = useState<Status[]>([]);
  const [authors, setAuthors] = useState<Record<string, AuthorRow>>({});
  const [composerOpen, setComposerOpen] = useState(false);
  const [viewer, setViewer] = useState<{ authorId: string; index: number } | null>(null);

  const refresh = async () => {
    const { data } = await supabase
      .from('statuses')
      .select('*')
      .gt('expires_at', new Date().toISOString())
      .order('created_at', { ascending: false });
    const list = (data ?? []) as Status[];
    setStatuses(list);
    const ids = Array.from(new Set(list.map((s) => s.author_id)));
    if (ids.length) {
      const { data: profs } = await supabase
        .from('profiles')
        .select('id, display_name, avatar_seed, avatar_url')
        .in('id', ids);
      const map: Record<string, AuthorRow> = {};
      (profs ?? []).forEach((p: any) => { map[p.id] = p; });
      setAuthors(map);
    }
  };

  useEffect(() => {
    if (!profile) return;
    refresh();
    const ch = supabase
      .channel('statuses-feed')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'statuses' }, refresh)
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [profile?.id]);

  if (!profile) return null;

  // Group by author
  const myStatuses = statuses.filter((s) => s.author_id === profile.id);
  const others = statuses.filter((s) => s.author_id !== profile.id);
  const grouped = others.reduce<Record<string, Status[]>>((acc, s) => {
    (acc[s.author_id] ||= []).push(s);
    return acc;
  }, {});

  const openAuthorViewer = (authorId: string) => {
    sfx.tap();
    setViewer({ authorId, index: 0 });
  };

  return (
    <div className="flex-1 min-h-0 flex flex-col mxit-classic-bg">
      <div className="mxit-titlebar h-9 flex items-center px-3 gap-2 shrink-0">
        <button onClick={() => navigate('/')} className="text-[11px] px-2 py-0.5 rounded-sm bg-white/10 border border-white/20 flex items-center gap-1">
          <ChevronLeft className="w-3 h-3" /> Back
        </button>
        <div className="flex-1 text-center font-semibold text-[15px]">Mxit Status</div>
        <span className="status-orb orb-online" />
      </div>

      <div className="flex-1 overflow-y-auto p-3 space-y-3 text-white">
        {/* My status */}
        <button
          onClick={() => setComposerOpen(true)}
          className="w-full flex items-center gap-3 bg-white/8 border border-white/15 rounded-md p-3 hover:bg-white/12"
        >
          <div className="relative">
            <PixelAvatar seed={profile.avatar_seed} url={profile.avatar_url} size={48} />
            <span className="absolute -bottom-1 -right-1 bg-emerald-500 rounded-full w-5 h-5 flex items-center justify-center border-2 border-[#0A2A5E]">
              <Plus className="w-3 h-3 text-white" />
            </span>
          </div>
          <div className="flex-1 text-left">
            <div className="font-semibold">My status</div>
            <div className="text-[11px] text-white/60">
              {myStatuses.length === 0 ? 'Tap to add status update' : `${myStatuses.length} update${myStatuses.length > 1 ? 's' : ''}`}
            </div>
          </div>
          {myStatuses.length > 0 && (
            <button
              onClick={(e) => { e.stopPropagation(); openAuthorViewer(profile.id); }}
              className="text-[11px] underline text-white/70"
            >
              View
            </button>
          )}
        </button>

        {/* Recent updates */}
        <div className="text-[11px] uppercase opacity-70 px-1">Recent updates</div>
        {Object.keys(grouped).length === 0 ? (
          <div className="text-white/60 text-[13px] italic px-1">No status updates from your contacts yet.</div>
        ) : (
          Object.entries(grouped).map(([authorId, items]) => {
            const author = authors[authorId];
            const newest = items[0];
            return (
              <button
                key={authorId}
                onClick={() => openAuthorViewer(authorId)}
                className="w-full flex items-center gap-3 bg-white/8 border border-white/15 rounded-md p-3 hover:bg-white/12"
              >
                <div className="ring-2 ring-emerald-400 rounded-md p-0.5">
                  <PixelAvatar seed={author?.avatar_seed} url={author?.avatar_url} size={44} />
                </div>
                <div className="flex-1 text-left min-w-0">
                  <div className="font-semibold truncate">{author?.display_name ?? '…'}</div>
                  <div className="text-[11px] text-white/60">
                    {timeAgo(newest.created_at)} · {items.length} update{items.length > 1 ? 's' : ''}
                  </div>
                </div>
              </button>
            );
          })
        )}
      </div>

      {composerOpen && (
        <StatusComposer
          onClose={() => setComposerOpen(false)}
          onPosted={() => { setComposerOpen(false); refresh(); }}
        />
      )}

      {viewer && (
        <StatusViewer
          authorId={viewer.authorId}
          startIndex={viewer.index}
          allStatuses={statuses}
          authors={authors}
          isOwn={viewer.authorId === profile.id}
          onClose={() => setViewer(null)}
          onDeleted={() => { setViewer(null); refresh(); }}
        />
      )}
    </div>
  );
}

/* --------- Composer --------- */
function StatusComposer({ onClose, onPosted }: { onClose: () => void; onPosted: () => void }) {
  const { profile } = useAuth();
  const [tab, setTab] = useState<'text' | 'image' | 'video'>('text');
  const [caption, setCaption] = useState('');
  const [background, setBackground] = useState(BG_COLORS[0]);
  const [file, setFile] = useState<File | null>(null);
  const [audienceMode, setAudienceMode] = useState<Status['audience_mode']>('contacts');
  const [audienceList, setAudienceList] = useState<string[]>([]);
  const [contacts, setContacts] = useState<{ id: string; display_name: string; mxit_id: string }[]>([]);
  const [showPrivacy, setShowPrivacy] = useState(false);
  const [busy, setBusy] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!profile) return;
    (async () => {
      const { data } = await supabase
        .from('contacts')
        .select('requester_id, addressee_id, status')
        .or(`requester_id.eq.${profile.id},addressee_id.eq.${profile.id}`)
        .eq('status', 'accepted');
      const otherIds = (data ?? []).map((c: any) => c.requester_id === profile.id ? c.addressee_id : c.requester_id);
      if (otherIds.length === 0) return;
      const { data: profs } = await supabase
        .from('profiles')
        .select('id, display_name, mxit_id')
        .in('id', otherIds);
      setContacts((profs ?? []) as any);
    })();
  }, [profile?.id]);

  if (!profile) return null;

  const post = async () => {
    if (busy) return;
    if (tab === 'text' && !caption.trim()) { toast.error('Write something'); return; }
    if (tab !== 'text' && !file) { toast.error('Pick a file'); return; }
    setBusy(true);
    let mediaUrl: string | null = null;
    if (file) {
      if (file.size > MAX_STATUS_MEDIA_BYTES) { toast.error('File too large (max 25 MB)'); setBusy(false); return; }
      const ext = (file.name.split('.').pop() || 'bin').toLowerCase();
      const res = await uploadToBucket(STATUS_BUCKET, file, profile.id, ext);
      if ('error' in res) { toast.error(res.error); setBusy(false); return; }
      mediaUrl = res.url;
    }
    const { data: inserted, error } = await supabase
      .from('statuses')
      .insert({
        author_id: profile.id,
        kind: tab,
        media_url: mediaUrl,
        caption: caption.trim() || null,
        background: tab === 'text' ? background : null,
        audience_mode: audienceMode,
      })
      .select('id')
      .single();
    if (error || !inserted) { toast.error(error?.message ?? 'Failed'); setBusy(false); return; }
    if ((audienceMode === 'contacts_except' || audienceMode === 'only_share_with') && audienceList.length) {
      await supabase.from('status_audience').insert(
        audienceList.map((uid) => ({ status_id: inserted.id, user_id: uid })),
      );
    }
    toast.success('Mxit Status posted!');
    sfx.send();
    void awardAchievement('first_status');
    onPosted();
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/95 flex flex-col">
      <div className="flex items-center justify-between p-3 text-white shrink-0">
        <button onClick={onClose} className="p-2"><X className="w-5 h-5" /></button>
        <div className="font-semibold">New Mxit Status</div>
        <button onClick={() => setShowPrivacy(true)} className="p-2 flex items-center gap-1 text-[12px]">
          <Lock className="w-4 h-4" /> {audienceLabel(audienceMode, audienceList.length)}
        </button>
      </div>

      <div className="flex gap-2 px-3 mb-2 shrink-0">
        {(['text', 'image', 'video'] as const).map((t) => (
          <button
            key={t}
            onClick={() => { setTab(t); setFile(null); }}
            className={`flex-1 py-2 rounded text-[12px] uppercase font-semibold ${tab === t ? 'bg-emerald-500 text-black' : 'bg-white/10 text-white'}`}
          >
            {t === 'text' ? <Type className="w-4 h-4 inline" /> : t === 'image' ? '📷' : '🎬'} {t}
          </button>
        ))}
      </div>

      <div className="flex-1 min-h-0 overflow-y-auto p-3">
        {tab === 'text' ? (
          <div
            className="rounded-lg flex items-center justify-center p-6 min-h-[260px]"
            style={{ background }}
          >
            <Textarea
              autoFocus
              value={caption}
              onChange={(e) => setCaption(e.target.value)}
              maxLength={200}
              placeholder="Type a status…"
              className="bg-transparent border-0 text-white text-center text-2xl font-semibold placeholder:text-white/50 resize-none focus-visible:ring-0 min-h-[180px]"
            />
          </div>
        ) : (
          <div className="space-y-3">
            <input
              ref={fileRef}
              type="file"
              accept={tab === 'image' ? 'image/*' : 'video/*'}
              className="hidden"
              onChange={(e) => setFile(e.target.files?.[0] ?? null)}
            />
            {!file ? (
              <button
                onClick={() => fileRef.current?.click()}
                className="w-full min-h-[260px] rounded-lg border-2 border-dashed border-white/30 text-white/70 flex flex-col items-center justify-center gap-2"
              >
                <Camera className="w-8 h-8" />
                <div>Tap to pick a {tab}</div>
              </button>
            ) : tab === 'image' ? (
              <img src={URL.createObjectURL(file)} alt="" className="w-full max-h-[60vh] rounded-lg object-contain bg-black" />
            ) : (
              <video src={URL.createObjectURL(file)} controls className="w-full max-h-[60vh] rounded-lg bg-black" />
            )}
            <Input
              value={caption}
              onChange={(e) => setCaption(e.target.value)}
              maxLength={140}
              placeholder="Add a caption…"
              className="bg-white/10 border-white/20 text-white placeholder:text-white/40"
            />
          </div>
        )}

        {tab === 'text' && (
          <div className="flex gap-2 mt-3 flex-wrap justify-center">
            {BG_COLORS.map((c) => (
              <button
                key={c}
                onClick={() => setBackground(c)}
                className={`w-8 h-8 rounded-full border-2 ${background === c ? 'border-white' : 'border-white/30'}`}
                style={{ background: c }}
              />
            ))}
          </div>
        )}
      </div>

      <div className="p-3 shrink-0">
        <Button onClick={post} disabled={busy} className="w-full bg-emerald-500 hover:bg-emerald-600 text-black font-semibold">
          <Send className="w-4 h-4 mr-2" /> {busy ? 'Posting…' : 'Share status'}
        </Button>
      </div>

      <Dialog open={showPrivacy} onOpenChange={setShowPrivacy}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle>Mxit Status privacy</DialogTitle>
          </DialogHeader>
          <div className="space-y-2">
            {([
              ['contacts', 'My contacts', 'All your contacts can see'],
              ['contacts_except', 'My contacts except…', 'Hide from selected'],
              ['only_share_with', 'Only share with…', 'Only selected can see'],
              ['everyone', 'Everyone on Mxit', 'Anyone can find'],
            ] as const).map(([m, label, desc]) => (
              <button
                key={m}
                onClick={() => { setAudienceMode(m); if (m === 'contacts' || m === 'everyone') setAudienceList([]); }}
                className={`w-full text-left p-2 rounded border ${audienceMode === m ? 'bg-emerald-500/20 border-emerald-500' : 'border-border'}`}
              >
                <div className="font-medium">{label}</div>
                <div className="text-[11px] text-muted-foreground">{desc}</div>
              </button>
            ))}
            {(audienceMode === 'contacts_except' || audienceMode === 'only_share_with') && (
              <div className="space-y-1 max-h-60 overflow-y-auto border rounded p-2">
                {contacts.length === 0 && <div className="text-[12px] text-muted-foreground">No contacts yet.</div>}
                {contacts.map((c) => {
                  const checked = audienceList.includes(c.id);
                  return (
                    <label key={c.id} className="flex items-center gap-2 text-[13px] py-1 cursor-pointer">
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={() => setAudienceList((cur) => checked ? cur.filter((x) => x !== c.id) : [...cur, c.id])}
                      />
                      <span>{c.display_name} <span className="text-muted-foreground text-[11px]">@{c.mxit_id}</span></span>
                    </label>
                  );
                })}
              </div>
            )}
            <Button onClick={() => setShowPrivacy(false)} className="w-full">Done</Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function audienceLabel(mode: Status['audience_mode'], n: number) {
  if (mode === 'everyone') return 'Everyone';
  if (mode === 'contacts') return 'Contacts';
  if (mode === 'contacts_except') return `Except (${n})`;
  return `Only (${n})`;
}

/* --------- Viewer --------- */
function StatusViewer({
  authorId, startIndex, allStatuses, authors, isOwn, onClose, onDeleted,
}: {
  authorId: string;
  startIndex: number;
  allStatuses: Status[];
  authors: Record<string, AuthorRow>;
  isOwn: boolean;
  onClose: () => void;
  onDeleted: () => void;
}) {
  const { profile: me } = useAuth();
  const navigate = useNavigate();
  const items = allStatuses.filter((s) => s.author_id === authorId).sort((a, b) => +new Date(a.created_at) - +new Date(b.created_at));
  const [idx, setIdx] = useState(startIndex);
  const [viewers, setViewers] = useState<{ id: string; display_name: string; viewed_at: string }[]>([]);
  const [showViewers, setShowViewers] = useState(false);
  const [reactions, setReactions] = useState<{ emoji: string; count: number; mine: boolean }[]>([]);
  const [replyText, setReplyText] = useState('');
  const [replying, setReplying] = useState(false);
  const cur = items[idx];
  const author = authors[authorId];

  // Load reactions for current status
  useEffect(() => {
    if (!cur || !me) return;
    (async () => {
      const { data } = await supabase.from('status_reactions').select('emoji, user_id').eq('status_id', cur.id);
      const rows = (data ?? []) as { emoji: string; user_id: string }[];
      const map = new Map<string, { count: number; mine: boolean }>();
      for (const r of rows) {
        const cur = map.get(r.emoji) ?? { count: 0, mine: false };
        cur.count++;
        if (r.user_id === me.id) cur.mine = true;
        map.set(r.emoji, cur);
      }
      setReactions(Array.from(map, ([emoji, v]) => ({ emoji, ...v })));
    })();
  }, [cur?.id, me?.id]);

  const react = async (emoji: string) => {
    if (!cur || !me) return;
    sfx.tap();
    const mine = reactions.find((r) => r.emoji === emoji)?.mine;
    if (mine) {
      await supabase.from('status_reactions').delete().eq('status_id', cur.id).eq('user_id', me.id).eq('emoji', emoji);
    } else {
      // remove any other emoji from me first
      await supabase.from('status_reactions').delete().eq('status_id', cur.id).eq('user_id', me.id);
      await supabase.from('status_reactions').insert({ status_id: cur.id, user_id: me.id, emoji });
    }
    const { data } = await supabase.from('status_reactions').select('emoji, user_id').eq('status_id', cur.id);
    const rows = (data ?? []) as { emoji: string; user_id: string }[];
    const map = new Map<string, { count: number; mine: boolean }>();
    for (const r of rows) {
      const c = map.get(r.emoji) ?? { count: 0, mine: false };
      c.count++; if (r.user_id === me.id) c.mine = true; map.set(r.emoji, c);
    }
    setReactions(Array.from(map, ([emoji, v]) => ({ emoji, ...v })));
  };

  const sendReply = async () => {
    if (!cur || !me || !replyText.trim() || replying) return;
    setReplying(true);
    try {
      // find or create direct conversation with author
      const a = me.id < authorId ? me.id : authorId;
      const b = me.id < authorId ? authorId : me.id;
      let convId: string | null = null;
      const { data: existing } = await supabase.from('conversations').select('id').or(`and(user_a.eq.${a},user_b.eq.${b}),and(user_a.eq.${b},user_b.eq.${a})`).maybeSingle();
      if (existing) convId = (existing as any).id;
      if (!convId) {
        const { data: created } = await supabase.from('conversations').insert({ user_a: a, user_b: b }).select('id').single();
        convId = (created as any).id;
      }
      const tag = `[reply-status:${cur.kind}]${cur.caption ? cur.caption.slice(0, 80) : ''}[/reply-status]\n${replyText.trim()}`;
      await supabase.from('messages').insert({ conversation_id: convId, sender_id: me.id, content: tag });
      toast.success('Reply sent');
      setReplyText('');
      sfx.send();
      onClose();
      navigate(`/chat/${convId}`);
    } finally { setReplying(false); }
  };

  useEffect(() => {
    if (!cur) return;
    // Record view (ignored if own)
    if (!isOwn) {
      supabase.from('status_views').insert({ status_id: cur.id, viewer_id: undefined as any })
        .then(() => { /* RLS uses auth.uid via insert default? No — set explicit */ });
      // actually use auth user
      supabase.auth.getUser().then(({ data }) => {
        if (data.user) {
          supabase.from('status_views').upsert({ status_id: cur.id, viewer_id: data.user.id }, { onConflict: 'status_id,viewer_id' });
        }
      });
    }
    // Auto-advance after 6s for non-video
    if (cur.kind === 'video') return;
    const t = setTimeout(() => {
      if (idx + 1 < items.length) setIdx(idx + 1);
      else onClose();
    }, 6000);
    return () => clearTimeout(t);
  }, [cur?.id, idx, items.length, isOwn]);

  useEffect(() => {
    if (!isOwn || !cur) return;
    (async () => {
      const { data } = await supabase
        .from('status_views')
        .select('viewer_id, viewed_at')
        .eq('status_id', cur.id)
        .order('viewed_at', { ascending: false });
      const ids = (data ?? []).map((v: any) => v.viewer_id);
      if (ids.length) {
        const { data: profs } = await supabase.from('profiles').select('id, display_name').in('id', ids);
        const map = new Map((profs ?? []).map((p: any) => [p.id, p.display_name]));
        setViewers((data ?? []).map((v: any) => ({ id: v.viewer_id, display_name: map.get(v.viewer_id) ?? '?', viewed_at: v.viewed_at })));
      } else setViewers([]);
    })();
  }, [cur?.id, isOwn]);

  const del = async () => {
    if (!cur) return;
    if (!confirm('Delete this status?')) return;
    await supabase.from('statuses').delete().eq('id', cur.id);
    onDeleted();
  };

  if (!cur) { onClose(); return null; }

  return (
    <div className="fixed inset-0 z-50 bg-black flex flex-col text-white">
      {/* Progress bars */}
      <div className="flex gap-1 p-2 shrink-0">
        {items.map((_, i) => (
          <div key={i} className="flex-1 h-1 bg-white/30 rounded overflow-hidden">
            <div className={`h-full bg-white ${i < idx ? 'w-full' : i === idx ? 'w-1/2' : 'w-0'}`} />
          </div>
        ))}
      </div>
      <div className="flex items-center gap-2 px-3 pb-2 shrink-0">
        <PixelAvatar seed={author?.avatar_seed} url={author?.avatar_url} size={32} />
        <div className="flex-1 min-w-0">
          <div className="font-semibold truncate">{author?.display_name ?? '…'}</div>
          <div className="text-[10px] text-white/60">{timeAgo(cur.created_at)}</div>
        </div>
        {isOwn && (
          <button onClick={del} className="p-2"><Trash2 className="w-4 h-4" /></button>
        )}
        <button onClick={onClose} className="p-2"><X className="w-5 h-5" /></button>
      </div>

      <div
        className="flex-1 flex items-center justify-center relative cursor-pointer"
        onClick={(e) => {
          const r = (e.currentTarget as HTMLElement).getBoundingClientRect();
          const x = e.clientX - r.left;
          if (x < r.width / 3) {
            if (idx > 0) setIdx(idx - 1);
          } else {
            if (idx + 1 < items.length) setIdx(idx + 1);
            else onClose();
          }
        }}
      >
        {cur.kind === 'text' && (
          <div
            className="absolute inset-0 flex items-center justify-center p-8 text-center text-2xl font-semibold"
            style={{ background: cur.background ?? '#0A2A5E' }}
          >
            {cur.caption}
          </div>
        )}
        {cur.kind === 'image' && cur.media_url && (
          <img src={cur.media_url} alt="" className="max-h-full max-w-full object-contain" />
        )}
        {cur.kind === 'video' && cur.media_url && (
          <video src={cur.media_url} controls autoPlay className="max-h-full max-w-full" onEnded={() => idx + 1 < items.length ? setIdx(idx + 1) : onClose()} />
        )}
      </div>

      {cur.caption && cur.kind !== 'text' && (
        <div className="p-3 text-center bg-black/60">{cur.caption}</div>
      )}

      {/* Reactions row (visible to everyone). For own status, also show view count. */}
      <div className="bg-black/80 border-t border-white/10 shrink-0">
        <div className="flex items-center justify-center gap-2 p-2">
          {['❤️','😂','😮','😢','🔥','👏'].map((e) => {
            const r = reactions.find((x) => x.emoji === e);
            const mine = !!r?.mine;
            return (
              <button
                key={e}
                onClick={(ev) => { ev.stopPropagation(); react(e); }}
                className={`px-2 py-1 rounded-full text-base transition ${mine ? 'bg-emerald-500/30 ring-1 ring-emerald-400' : 'bg-white/10 hover:bg-white/20'}`}
              >
                {e}{r?.count ? <span className="text-[10px] ml-1 text-white/80">{r.count}</span> : null}
              </button>
            );
          })}
        </div>
        {!isOwn && (
          <div className="flex gap-2 px-3 pb-2" onClick={(e) => e.stopPropagation()}>
            <Input
              value={replyText}
              onChange={(e) => setReplyText(e.target.value)}
              onKeyDown={(e) => { if (e.key === 'Enter') sendReply(); }}
              placeholder={`Reply to ${author?.display_name ?? '…'}…`}
              className="bg-white/10 border-white/20 text-white placeholder:text-white/40 h-9"
            />
            <Button onClick={sendReply} disabled={replying || !replyText.trim()} size="sm" className="bg-emerald-500 hover:bg-emerald-600 text-black">
              <Send className="w-4 h-4" />
            </Button>
          </div>
        )}
        {isOwn && (
          <button
            onClick={(e) => { e.stopPropagation(); setShowViewers(true); }}
            className="w-full p-2 flex items-center justify-center gap-2 border-t border-white/10 text-[12px]"
          >
            <Eye className="w-4 h-4" /> {viewers.length} view{viewers.length === 1 ? '' : 's'}
          </button>
        )}
      </div>

      <Dialog open={showViewers} onOpenChange={setShowViewers}>
        <DialogContent>
          <DialogHeader><DialogTitle>Viewed by</DialogTitle></DialogHeader>
          {viewers.length === 0 ? (
            <div className="text-sm text-muted-foreground">No views yet.</div>
          ) : (
            <ul className="space-y-2 max-h-80 overflow-y-auto">
              {viewers.map((v) => (
                <li key={v.id} className="flex items-center justify-between text-sm">
                  <span>{v.display_name}</span>
                  <span className="text-muted-foreground text-[11px]">{timeAgo(v.viewed_at)}</span>
                </li>
              ))}
            </ul>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}

function timeAgo(iso: string) {
  const s = Math.floor((Date.now() - +new Date(iso)) / 1000);
  if (s < 60) return 'just now';
  if (s < 3600) return `${Math.floor(s / 60)}m ago`;
  if (s < 86400) return `${Math.floor(s / 3600)}h ago`;
  return `${Math.floor(s / 86400)}d ago`;
}
