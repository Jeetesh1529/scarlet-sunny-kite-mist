/**
 * Tic-Tac-Toe vs the computer. Simple minimax-ish (random-blocking) AI.
 */
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { sfx } from '@/lib/sfx';
import { Gamepad2, RotateCcw } from 'lucide-react';

type Cell = 'X' | 'O' | null;

const LINES = [
  [0,1,2],[3,4,5],[6,7,8],
  [0,3,6],[1,4,7],[2,5,8],
  [0,4,8],[2,4,6],
];

function winner(b: Cell[]): Cell | 'draw' | null {
  for (const [a,bI,c] of LINES) {
    if (b[a] && b[a] === b[bI] && b[a] === b[c]) return b[a];
  }
  if (b.every(Boolean)) return 'draw';
  return null;
}

function bestMove(b: Cell[], me: Cell): number {
  // Win if possible
  for (let i = 0; i < 9; i++) if (!b[i]) {
    const t = [...b]; t[i] = me;
    if (winner(t) === me) return i;
  }
  // Block opponent
  const opp: Cell = me === 'O' ? 'X' : 'O';
  for (let i = 0; i < 9; i++) if (!b[i]) {
    const t = [...b]; t[i] = opp;
    if (winner(t) === opp) return i;
  }
  // Take centre
  if (!b[4]) return 4;
  // Corner
  const corners = [0,2,6,8].filter(i => !b[i]);
  if (corners.length) return corners[Math.floor(Math.random() * corners.length)];
  // Anything
  const empty = b.map((c,i) => c ? -1 : i).filter(i => i >= 0);
  return empty[Math.floor(Math.random() * empty.length)];
}

export default function TicTacToe() {
  const navigate = useNavigate();
  const [board, setBoard] = useState<Cell[]>(Array(9).fill(null));
  const [turn, setTurn] = useState<'X' | 'O'>('X');
  const [score, setScore] = useState({ you: 0, ai: 0, draw: 0 });

  const w = winner(board);

  useEffect(() => {
    if (w) return;
    if (turn === 'O') {
      const t = setTimeout(() => {
        const i = bestMove(board, 'O');
        const nb = [...board]; nb[i] = 'O';
        setBoard(nb); setTurn('X'); sfx.tap();
      }, 400);
      return () => clearTimeout(t);
    }
  }, [turn, board, w]);

  useEffect(() => {
    if (w === 'X') setScore(s => ({ ...s, you: s.you + 1 }));
    else if (w === 'O') setScore(s => ({ ...s, ai: s.ai + 1 }));
    else if (w === 'draw') setScore(s => ({ ...s, draw: s.draw + 1 }));
  }, [w]);

  function play(i: number) {
    if (board[i] || w || turn !== 'X') return;
    sfx.tap();
    const nb = [...board]; nb[i] = 'X';
    setBoard(nb); setTurn('O');
  }
  function reset() {
    sfx.tap();
    setBoard(Array(9).fill(null));
    setTurn('X');
  }

  return (
    <div className="flex-1 min-h-0 flex flex-col mxit-classic-bg">
      <div className="mxit-titlebar h-9 flex items-center px-3 gap-2 shrink-0">
        <button onClick={() => { sfx.tap(); navigate('/'); }} className="text-[11px] px-2 py-0.5 rounded-sm bg-white/10 border border-white/20">‹ Back</button>
        <div className="flex-1 text-center font-semibold text-[15px] tracking-wide flex items-center justify-center gap-2">
          <Gamepad2 className="w-4 h-4" /> Tic-Tac-Toe
        </div>
        <span className="w-12" />
      </div>

      <div className="relative flex-1 overflow-y-auto mxit-watermark min-h-0">
        <div className="relative z-10 p-4 flex flex-col items-center gap-4">
          <div className="text-white/80 text-sm flex gap-4">
            <span>You (X): <b className="text-emerald-300">{score.you}</b></span>
            <span>AI (O): <b className="text-rose-300">{score.ai}</b></span>
            <span>Draws: <b className="text-white/60">{score.draw}</b></span>
          </div>

          <div className="grid grid-cols-3 gap-1.5 w-72 max-w-full aspect-square">
            {board.map((c, i) => (
              <button
                key={i}
                onClick={() => play(i)}
                className="bg-white/10 hover:bg-white/15 rounded text-4xl font-bold flex items-center justify-center border border-white/10"
                style={{ color: c === 'X' ? 'hsl(150 80% 70%)' : 'hsl(350 90% 75%)' }}
              >
                {c}
              </button>
            ))}
          </div>

          <div className="text-center text-white">
            {w === 'X' && <div className="text-emerald-300 font-bold">🎉 You win!</div>}
            {w === 'O' && <div className="text-rose-300 font-bold">💀 AI wins</div>}
            {w === 'draw' && <div className="text-white/70">It's a draw</div>}
            {!w && <div className="text-white/60 text-sm">{turn === 'X' ? 'Your turn' : 'AI thinking…'}</div>}
          </div>

          <button onClick={reset} className="flex items-center gap-1.5 px-4 py-1.5 rounded bg-white/15 hover:bg-white/25 text-white text-sm">
            <RotateCcw className="w-4 h-4" /> New round
          </button>
        </div>
      </div>
    </div>
  );
}
