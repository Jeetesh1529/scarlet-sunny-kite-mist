import { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { BootScreen } from '@/components/BootScreen';
import { AuthScreen } from '@/components/AuthScreen';
import { HomeScreen } from '@/components/HomeScreen';

// Module-level flag — persists across route remounts within the same page load.
let hasBooted = false;

export default function Index() {
  const { user, profile, loading } = useAuth();
  const [booted, setBooted] = useState(hasBooted);

  if (!booted) return <BootScreen onDone={() => { hasBooted = true; setBooted(true); }} />;
  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center mxit-screen-bg">
        <div className="font-mono-pixel text-muted-foreground animate-pulse-soft">loading…</div>
      </div>
    );
  }
  if (!user) return <AuthScreen />;
  if (!profile) return <AuthScreen needsProfile />;
  return <HomeScreen />;
}
