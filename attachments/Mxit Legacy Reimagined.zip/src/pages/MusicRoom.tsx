/**
 * Music Room — AERAKII radio playing alongside a public chatroom.
 * Everyone joins the same official "Music Room" chatroom (free, no Moola cost)
 * while the AERAKII playlist auto-cycles in the background.
 */
import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { sfx } from '@/lib/sfx';
import { Music, SkipForward, Play, Pause, Youtube, Send, Users } from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';
import { PixelAvatar } from '@/components/PixelAvatar';

type Track = { id: string; title: string };

const ARTIST = 'AERAKII';
const TRACKS: Track[] = [
  { id: 'EAOohdHwAoU', title: 'Easy Money' },
  { id: 'HqI2Mt_uYlI', title: 'Haaieyo Ha' },
  { id: '1uxHv0dJU5M', title: 'This Is My Curse' },
  { id: 'jIJg67MXGUk', title: 'This Is Who I Am' },
  { id: 'nbhhJM5XwvQ', title: 'Just a Fool' },
  { id: '-Hfmhpafsw4', title: "Don't Let Me Walk Away" },
  { id: 'hhK0Cwu9i68', title: 'Rum Ta Na Num' },
  { id: '_jH6Kn4Hwik', title: 'Dum da Dum' },
  { id: 'i097lGdG0oM', title: 'Aum Namo' },
];

type Sender = { id: string; display_name: string; avatar_seed: string | null; avatar_url: string | null };
type Msg = { id: string; sender_id: string; content: string; created_at: string };

export default function MusicRoom() {
  const navigate = useNavigate();
  const { profile } = useAuth();

  // Player state
  const [idx, setIdx] = useState(0);
  const [playing, setPlaying] = useState(true);
  const playerRef = useRef<any>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const current = TRACKS[idx];

  // Chat state
  const [roomId, setRoomId] = useState<string | null>(null);
  const [messages, setMessages] = useState<Msg[]>([]);
  const [text, setText] = useState('');
  const senderMap = useRef<Map<string, Sender>>(new Map());
  const [, force] = useState(0);
  const scrollRef = useRef<HTMLDivElement>(null);
  const [memberCount, setMemberCount] = useState(0);

  // YouTube IFrame setup
  useEffect(() => {
    const existing = document.querySelector('script[src="https://www.youtube.com/iframe_api"]');
    if (!existing) {
      const tag = document.createElement('script');
      tag.src = 'https://www.youtube.com/iframe_api';
      document.head.appendChild(tag);
    }
    const init = () => {
      const YT = (window as any).YT;
      if (!YT?.Player || !containerRef.current) return;
      playerRef.current = new YT.Player(containerRef.current, {
        videoId: current.id,
        playerVars: { autoplay: 1, controls: 0, modestbranding: 1, rel: 0, playsinline: 1 },
        events: {
          onReady: (e: any) => { try { e.target.playVideo(); } catch {} },
          onStateChange: (e: any) => {
            if (e.data === 0) next();
            if (e.data === 1) setPlaying(true);
            if (e.data === 2) setPlaying(false);
          },
          onError: () => { next(); },
        },
      });
    };
    if ((window as any).YT?.Player) init();
    else (window as any).onYouTubeIframeAPIReady = init;
    return () => { try { playerRef.current?.destroy?.(); } catch {} };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (playerRef.current?.loadVideoById) {
      try { playerRef.current.loadVideoById(current.id); } catch {}
    }
  }, [idx, current.id]);

  function next() { setIdx((i) => (i + 1) % TRACKS.length); }
  function toggle() {
    sfx.tap();
    const p = playerRef.current; if (!p) return;
    if (playing) p.pauseVideo?.(); else p.playVideo?.();
  }

  // Load Music Room chatroom + join
  useEffect(() => {
    if (!profile) return;
    let cancelled = false;
    (async () => {
      const { data: room } = await supabase
        .from('chatrooms').select('id').eq('name', 'Music Room').maybeSingle();
      if (!room) { toast.error('Music Room not available'); return; }
      if (cancelled) return;
      setRoomId(room.id);
      // join (idempotent)
      await supabase.from('room_members').insert({ room_id: room.id, user_id: profile.id }).then(() => {}, () => {});
      // load history
      const { data: msgs } = await supabase
        .from('messages').select('id, sender_id, content, created_at')
        .eq('room_id', room.id).order('created_at').limit(100);
      if (!cancelled && msgs) setMessages(msgs as Msg[]);
      // member count
      const { count } = await supabase
        .from('room_members').select('id', { count: 'exact', head: true }).eq('room_id', room.id);
      if (!cancelled) setMemberCount(count ?? 0);
      // hydrate senders
      const ids = Array.from(new Set((msgs ?? []).map((m: any) => m.sender_id)));
      if (ids.length) {
        const { data: ps } = await supabase.from('profiles')
          .select('id, display_name, avatar_seed, avatar_url').in('id', ids);
        (ps ?? []).forEach((p: any) => senderMap.current.set(p.id, p));
        force((n) => n + 1);
      }
    })();
    return () => { cancelled = true; };
  }, [profile?.id]);

  // Realtime
  useEffect(() => {
    if (!roomId || !profile) return;
    const ch = supabase.channel(`musicroom-${roomId}`)
      .on('postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'messages', filter: `room_id=eq.${roomId}` },
        async (payload) => {
          const m = payload.new as Msg;
          setMessages((cur) => cur.some((x) => x.id === m.id) ? cur : [...cur, m]);
          if (m.sender_id !== profile.id) sfx.receive();
          if (!senderMap.current.has(m.sender_id)) {
            const { data } = await supabase.from('profiles')
              .select('id, display_name, avatar_seed, avatar_url').eq('id', m.sender_id).maybeSingle();
            if (data) { senderMap.current.set(data.id, data as Sender); force((n) => n + 1); }
          }
        })
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [roomId, profile?.id]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages]);

  const send = async () => {
    const t = text.trim();
    if (!t || !roomId || !profile) return;
    setText('');
    sfx.tap();
    const { error } = await supabase.from('messages').insert({
      room_id: roomId, sender_id: profile.id, content: t, delivery: 'sent',
    });
    if (error) { sfx.error(); toast.error(error.message); }
  };

  return (
    <div className="flex-1 min-h-0 flex flex-col mxit-classic-bg">
      <div className="mxit-titlebar h-9 flex items-center px-3 gap-2 shrink-0">
        <button onClick={() => { sfx.tap(); navigate('/tradepost'); }} className="text-[11px] px-2 py-0.5 rounded-sm bg-white/10 border border-white/20">‹ Back</button>
        <div className="flex-1 text-center font-semibold text-[15px] tracking-wide flex items-center justify-center gap-2">
          <Music className="w-4 h-4" /> Music Room
        </div>
        <span className="text-[11px] text-white/70 flex items-center gap-1"><Users className="w-3 h-3" /> {memberCount}</span>
      </div>

      <div className="relative flex-1 overflow-hidden mxit-watermark min-h-0 flex flex-col">
        {/* Now Playing strip */}
        <section className="relative z-10 mx-3 mt-3 bg-gradient-to-br from-purple-700/40 via-pink-600/30 to-amber-500/20 border border-white/10 rounded-lg p-3 shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-24 h-14 rounded-md overflow-hidden bg-black/40 shrink-0">
              <div ref={containerRef} className="w-full h-full" />
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-[9px] uppercase tracking-[0.2em] text-pink-200/80">Now playing on AERAKII Radio</div>
              <div className="text-white font-bold text-sm leading-tight truncate">{current.title}</div>
              <div className="text-pink-100/90 text-[11px]">{ARTIST}</div>
            </div>
            <div className="flex items-center gap-1 shrink-0">
              <button onClick={toggle} className="px-2 py-1 rounded bg-white/15 hover:bg-white/25 text-white" aria-label={playing ? 'Pause' : 'Play'}>
                {playing ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              </button>
              <button onClick={() => { sfx.tap(); next(); }} className="px-2 py-1 rounded bg-white/10 hover:bg-white/20 text-white" aria-label="Next">
                <SkipForward className="w-4 h-4" />
              </button>
              <a href="https://www.youtube.com/@A-erakii" target="_blank" rel="noreferrer" className="px-2 py-1 rounded bg-white/10 hover:bg-white/20 text-white" aria-label="Channel">
                <Youtube className="w-4 h-4" />
              </a>
            </div>
          </div>
        </section>

        {/* Public chat */}
        <div className="relative z-10 flex-1 min-h-0 overflow-y-auto p-3" ref={scrollRef}>
          {messages.length === 0 && (
            <div className="text-center text-white/50 text-[12px] py-6">
              Be the first to say something while AERAKII plays 🎶
            </div>
          )}
          <ul className="space-y-2">
            {messages.map((m) => {
              const s = senderMap.current.get(m.sender_id);
              const isMe = m.sender_id === profile?.id;
              return (
                <li key={m.id} className={`flex items-start gap-2 ${isMe ? 'justify-end' : ''}`}>
                  {!isMe && <PixelAvatar seed={s?.avatar_seed} url={s?.avatar_url} size={22} />}
                  <div className={`max-w-[75%] px-2.5 py-1.5 rounded-md text-[13px] ${isMe ? 'bg-pink-500/30 text-white' : 'bg-white/10 text-white'}`}>
                    {!isMe && <div className="text-[10px] text-pink-200/90 mb-0.5">{s?.display_name ?? 'someone'}</div>}
                    <div className="whitespace-pre-wrap break-words">{m.content}</div>
                  </div>
                </li>
              );
            })}
          </ul>
        </div>

        {/* Composer */}
        <div className="relative z-10 p-2 border-t border-white/10 bg-black/30 shrink-0">
          <form
            onSubmit={(e) => { e.preventDefault(); send(); }}
            className="flex items-center gap-2"
          >
            <input
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Say something to the room…"
              className="flex-1 bg-white/10 border border-white/15 rounded px-3 py-2 text-sm text-white placeholder:text-white/40 focus:outline-none focus:border-pink-400/60"
              maxLength={300}
            />
            <button type="submit" className="px-3 py-2 rounded bg-pink-500/40 hover:bg-pink-500/60 text-white text-sm flex items-center gap-1">
              <Send className="w-4 h-4" /> Send
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
