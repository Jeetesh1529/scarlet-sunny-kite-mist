import { useEffect, useRef, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, Hash, LogOut, Users } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { MxitHeader } from '@/components/MxitHeader';
import { ChatMessage, Composer, MessageBubble, Sender, TypingIndicator } from '@/components/ChatPrimitives';
import { sfx } from '@/lib/sfx';
import { toast } from 'sonner';
import { cacheKey, cacheMessages, getCachedMessages, getOutboxFor, enqueueOutbox } from '@/lib/offlineDb';
import { flushOutbox } from '@/lib/offlineQueue';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { PixelAvatar } from '@/components/PixelAvatar';

export default function ChatRoom() {
  const { id: roomId } = useParams();
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [room, setRoom] = useState<{ name: string; topic: string | null; cost_per_message: number; max_users: number } | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [members, setMembers] = useState<Sender[]>([]);
  const [typers, setTypers] = useState<Map<string, string>>(new Map());
  const scrollRef = useRef<HTMLDivElement>(null);
  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);
  const senderMap = useRef<Map<string, Sender>>(new Map());

  useEffect(() => {
    if (!roomId || !profile) return;
    let cancelled = false;
    (async () => {
      const ck = cacheKey('room', roomId);
      const cached = await getCachedMessages(ck);
      const queued = await getOutboxFor('room', roomId);
      const queuedAsMsgs: ChatMessage[] = queued.map((q) => ({
        id: q.tmp_id, sender_id: q.sender_id, content: q.content,
        delivery: 'queued' as ChatMessage['delivery'], created_at: q.created_at,
      }));
      if (!cancelled && (cached.length || queuedAsMsgs.length)) setMessages([...cached, ...queuedAsMsgs]);
      if (!navigator.onLine) return;

      const { data: r } = await supabase.from('chatrooms').select('name, topic, cost_per_message, max_users').eq('id', roomId).maybeSingle();
      if (!r) { if (!cached.length) { toast.error('Room not found'); navigate('/'); } return; }
      if (!cancelled) setRoom(r);

      const { data: ms } = await supabase.from('room_members').select('user_id').eq('room_id', roomId);
      const userIds = (ms ?? []).map((m) => m.user_id);
      if (userIds.length) {
        const { data: ps } = await supabase.from('profiles').select('id, display_name, avatar_seed, avatar_url').in('id', userIds);
        const list = (ps ?? []) as Sender[];
        if (!cancelled) setMembers(list);
        list.forEach((p) => senderMap.current.set(p.id, p));
      }

      const { data: msgs } = await supabase.from('messages').select('id, sender_id, content, delivery, created_at')
        .eq('room_id', roomId).order('created_at').limit(200);
      if (msgs && !cancelled) {
        const remote = msgs as ChatMessage[];
        await cacheMessages(ck, remote);
        const stillQueued = await getOutboxFor('room', roomId);
        const queuedTail: ChatMessage[] = stillQueued.map((q) => ({
          id: q.tmp_id, sender_id: q.sender_id, content: q.content,
          delivery: 'queued' as ChatMessage['delivery'], created_at: q.created_at,
        }));
        setMessages([...remote, ...queuedTail]);
      }
      void flushOutbox();
    })();
    return () => { cancelled = true; };
  }, [roomId, profile, navigate]);

  useEffect(() => {
    if (!roomId || !profile) return;
    const ch = supabase
      .channel(`room-${roomId}`)
      .on('postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'messages', filter: `room_id=eq.${roomId}` },
        async (payload) => {
          const m = payload.new as ChatMessage;
          setMessages((cur) => {
            if (cur.some((x) => x.id === m.id)) return cur;
            const filtered = cur.filter((x) => !(x.id.startsWith('tmp-') && x.sender_id === m.sender_id && x.content === m.content));
            return [...filtered, m];
          });
          if (roomId) await cacheMessages(cacheKey('room', roomId), [m]);
          if (m.sender_id !== profile.id) sfx.receive();
          if (!senderMap.current.has(m.sender_id)) {
            const { data } = await supabase.from('profiles').select('id, display_name, avatar_seed, avatar_url').eq('id', m.sender_id).maybeSingle();
            if (data) senderMap.current.set(data.id, data as Sender);
          }
        })
      .on('postgres_changes',
        { event: 'DELETE', schema: 'public', table: 'messages', filter: `room_id=eq.${roomId}` },
        (payload) => setMessages((cur) => cur.filter((x) => x.id !== (payload.old as any).id)))
      .on('broadcast', { event: 'typing' }, (payload) => {
        const { user_id, name } = payload.payload as { user_id: string; name: string };
        if (user_id === profile.id) return;
        setTypers((m) => { const n = new Map(m); n.set(user_id, name); return n; });
        window.clearTimeout((channelRef as any)[`t_${user_id}`]);
        (channelRef as any)[`t_${user_id}`] = window.setTimeout(() => {
          setTypers((m) => { const n = new Map(m); n.delete(user_id); return n; });
        }, 2500);
      })
      .subscribe();
    channelRef.current = ch;
    return () => { supabase.removeChannel(ch); };
  }, [roomId, profile]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages, typers]);

  const send = async (text: string) => {
    if (!profile || !roomId) return;
    const cost = room?.cost_per_message ?? 0;
    if (cost > 0 && (profile.moola ?? 0) < cost) {
      sfx.error();
      toast.error(`Not enough Moola. ${cost}M needed per message.`);
      return;
    }
    const tmpId = `tmp-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const nowIso = new Date().toISOString();
    const offline = !navigator.onLine;
    const optimistic: ChatMessage = {
      id: tmpId, sender_id: profile.id, content: text,
      delivery: offline ? 'queued' : 'sending', created_at: nowIso,
    };
    setMessages((c) => [...c, optimistic]);
    if (offline) {
      await enqueueOutbox({ tmp_id: tmpId, target_kind: 'room', target_id: roomId, sender_id: profile.id, content: text, created_at: nowIso });
      return;
    }
    const { data, error } = await supabase.from('messages').insert({
      room_id: roomId, sender_id: profile.id, content: text, delivery: 'sent',
    }).select('id, sender_id, content, delivery, created_at').single();
    if (error) {
      await enqueueOutbox({ tmp_id: tmpId, target_kind: 'room', target_id: roomId, sender_id: profile.id, content: text, created_at: nowIso });
      setMessages((c) => c.map((m) => m.id === tmpId ? { ...m, delivery: 'queued' } : m));
      toast.message('Saved — will send when reconnected');
      return;
    }
    setMessages((c) => c.map((m) => m.id === tmpId ? (data as ChatMessage) : m));
    void import('@/lib/analytics').then(({ track }) => track('message_sent', { kind: 'room', room_id: roomId, cost }));
    // Deduct Moola (best-effort) and log transaction
    if (cost > 0) {
      await supabase.from('profiles').update({ moola: (profile.moola ?? 0) - cost }).eq('id', profile.id);
      await supabase.from('moola_transactions').insert({
        user_id: profile.id, amount: -cost, reason: `Chatroom message: ${room?.name ?? 'room'}`,
      });
    }
  };

  const sendTyping = () => {
    channelRef.current?.send({ type: 'broadcast', event: 'typing', payload: { user_id: profile?.id, name: profile?.display_name } });
  };

  const leave = async () => {
    if (!profile || !roomId) return;
    sfx.tap();
    await supabase.from('room_members').delete().eq('room_id', roomId).eq('user_id', profile.id);
    toast.success('Left the room');
    navigate('/');
  };

  const remove = async (id: string) => { await supabase.from('messages').delete().eq('id', id); };

  const typingNames = Array.from(typers.values());

  return (
    <div className="flex-1 flex flex-col">
      <MxitHeader
        left={
          <button onClick={() => { sfx.tap(); navigate('/'); }} className="p-2 hover:bg-white/10 rounded-md tap-scale">
            <ArrowLeft className="w-5 h-5" />
          </button>
        }
        right={
          <Sheet>
            <SheetTrigger asChild>
              <button onClick={() => sfx.tap()} className="p-2 hover:bg-white/10 rounded-md tap-scale flex items-center gap-1">
                <Users className="w-4 h-4" /> <span className="text-xs">{members.length}</span>
              </button>
            </SheetTrigger>
            <SheetContent side="right" className="w-72">
              <SheetHeader><SheetTitle className="font-pixel text-sm">members</SheetTitle></SheetHeader>
              <div className="mt-4 space-y-2">
                {members.map((m) => (
                  <div key={m.id} className="flex items-center gap-2 p-2 bg-secondary/50 rounded-md">
                    <PixelAvatar seed={m.avatar_seed} url={m.avatar_url} size={32} />
                    <span className="text-sm">{m.display_name}{m.id === profile?.id ? ' (you)' : ''}</span>
                  </div>
                ))}
                <button onClick={leave} className="w-full mt-4 p-3 bg-destructive/10 text-destructive rounded-md text-sm flex items-center justify-center gap-2 tap-scale">
                  <LogOut className="w-4 h-4" /> leave room
                </button>
              </div>
            </SheetContent>
          </Sheet>
        }
        title={room?.name || '…'}
        subtitle={
          room
            ? `${members.length}/${room.max_users} · ${room.cost_per_message ? room.cost_per_message + 'M/msg' : 'free'}`
            : ''
        }
      />

      <div ref={scrollRef} className="flex-1 overflow-y-auto mxit-screen-bg p-3 space-y-2 no-scrollbar">
        {messages.map((m, i) => {
          const isMe = m.sender_id === profile?.id;
          const prev = messages[i - 1];
          const newSender = !prev || prev.sender_id !== m.sender_id;
          return (
            <MessageBubble
              key={m.id}
              msg={m}
              isMe={isMe}
              sender={isMe ? undefined : senderMap.current.get(m.sender_id)}
              showAvatar={!isMe && newSender}
              showName={!isMe && newSender}
              onDelete={isMe ? () => remove(m.id) : undefined}
              lowData={!!profile?.low_data_mode}
            />
          );
        })}
        {typingNames.length > 0 && <TypingIndicator name={typingNames.join(', ')} />}
      </div>

      <Composer onSend={send} onTyping={sendTyping} />
    </div>
  );
}
