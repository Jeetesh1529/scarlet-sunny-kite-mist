import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { EmoText } from '@/components/Emoticon';
import { EmoticonPicker } from '@/components/EmoticonPicker';
import { sfx } from '@/lib/sfx';
import { toast } from 'sonner';
import { Smile, ImagePlus, ChevronLeft, MoreVertical, Mic, Video, Square, Timer, X, Reply } from 'lucide-react';
import { ReportBlockDialog } from '@/components/ReportBlockDialog';
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';
import type { ChatMessage } from '@/components/ChatPrimitives';
import { CHAT_FILE_ACCEPT, buildImageMessage, isImageMessage, uploadChatImage } from '@/lib/chatMedia';
import { uploadToBucket, VOICE_BUCKET, VIDEO_BUCKET, MAX_VOICE_BYTES, MAX_VIDEO_BYTES, buildVoiceMessage, buildVideoMessage, isVoiceMessage, isVideoMessage } from '@/lib/statusMedia';
import { cacheMessages, cacheProfile, getCachedMessages, getCachedProfile, enqueueOutbox, getOutboxFor, cacheKey } from '@/lib/offlineDb';
import { flushOutbox } from '@/lib/offlineQueue';
import { track } from '@/lib/analytics';
import { awardAchievement } from '@/lib/achievements';
import { ReactionRow, MessageActionSheet, useReactions, toggleReaction, ForwardDialog } from '@/components/MessageActions';

type OtherProfile = {
  id: string;
  display_name: string;
  mood: string | null;
  presence: string;
};

function presenceOrb(p?: string) {
  const cls =
    p === 'online' ? 'orb-online' :
    p === 'away'   ? 'orb-away'   :
    p === 'busy'   ? 'orb-busy'   : 'orb-offline';
  return <span className={`status-orb ${cls}`} aria-hidden />;
}

function presenceLabel(p?: string) {
  if (p === 'online') return 'online';
  if (p === 'away')   return 'away';
  if (p === 'busy')   return 'busy';
  return 'offline';
}

export default function Chat() {
  const { id: convId } = useParams();
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [other, setOther] = useState<OtherProfile | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [othersTyping, setOthersTyping] = useState(false);
  const [text, setText] = useState('');
  const [picker, setPicker] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const videoRef = useRef<HTMLInputElement>(null);
  const [uploading, setUploading] = useState(false);
  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);
  const lowData = !!profile?.low_data_mode;
  const [revealedImgs, setRevealedImgs] = useState<Set<string>>(new Set());
  const [reportOpen, setReportOpen] = useState(false);
  const mediaRecRef = useRef<MediaRecorder | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const [recording, setRecording] = useState(false);
  const [actionFor, setActionFor] = useState<ChatMessage | null>(null);
  const [replyTo, setReplyTo] = useState<ChatMessage | null>(null);
  const [forwardMsg, setForwardMsg] = useState<ChatMessage | null>(null);
  const [disappearing, setDisappearing] = useState<number>(0);
  const messageIds = useMemo(() => messages.filter((m) => !m.id.startsWith('tmp-')).map((m) => m.id), [messages]);
  const reactions = useReactions(messageIds);

  // Load conversation + other user + messages (cache-first, then sync)
  useEffect(() => {
    if (!convId || !profile) return;
    let cancelled = false;
    (async () => {
      // 1) Hydrate from cache immediately so chat opens with no network
      const ck = cacheKey('direct', convId);
      const cached = await getCachedMessages(ck);
      const queued = await getOutboxFor('direct', convId);
      const queuedAsMsgs: ChatMessage[] = queued.map((q) => ({
        id: q.tmp_id, sender_id: q.sender_id, content: q.content,
        delivery: 'queued' as ChatMessage['delivery'], created_at: q.created_at,
      }));
      if (!cancelled && (cached.length || queuedAsMsgs.length)) {
        setMessages([...cached, ...queuedAsMsgs]);
      }
      const cachedOther = await getCachedProfile<OtherProfile>(`other:${convId}`);
      if (!cancelled && cachedOther) setOther(cachedOther);

      // 2) Try server (skip if offline)
      if (!navigator.onLine) return;
      const { data: conv } = await supabase.from('conversations').select('user_a, user_b, disappearing_seconds').eq('id', convId).maybeSingle();
      if (!conv) {
        if (!cached.length) { toast.error('Conversation not found'); navigate('/'); }
        return;
      }
      if (!cancelled) setDisappearing((conv as any).disappearing_seconds ?? 0);
      const otherId = conv.user_a === profile.id ? conv.user_b : conv.user_a;
      const { data: o } = await supabase.from('profiles').select('id, display_name, mood, presence').eq('id', otherId).maybeSingle();
      if (o && !cancelled) {
        setOther(o as OtherProfile);
        await cacheProfile({ id: `other:${convId}`, ...(o as object) });
      }

      const { data: msgs } = await supabase.from('messages').select('id, sender_id, content, delivery, created_at, reply_to_id, forwarded_from, expires_at')
        .eq('conversation_id', convId).order('created_at');
      if (msgs && !cancelled) {
        const remote = msgs as ChatMessage[];
        await cacheMessages(ck, remote);
        const stillQueued = await getOutboxFor('direct', convId);
        const queuedTail: ChatMessage[] = stillQueued.map((q) => ({
          id: q.tmp_id, sender_id: q.sender_id, content: q.content,
          delivery: 'queued' as ChatMessage['delivery'], created_at: q.created_at,
        }));
        setMessages([...remote, ...queuedTail]);
      }

      if ((profile as any).read_receipts_enabled !== false) {
        await supabase.from('messages').update({ delivery: 'read' })
          .eq('conversation_id', convId).neq('sender_id', profile.id).neq('delivery', 'read');
      }

      // Try to flush any queued sends
      void flushOutbox().then(() => { /* realtime will receive new rows */ });
    })();
    return () => { cancelled = true; };
  }, [convId, profile, navigate]);

  // Realtime
  useEffect(() => {
    if (!convId || !profile) return;
    const ch = supabase
      .channel(`conv-${convId}`)
      .on('postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'messages', filter: `conversation_id=eq.${convId}` },
        async (payload) => {
          const m = payload.new as ChatMessage;
          setMessages((cur) => {
            if (cur.some((x) => x.id === m.id)) return cur;
            // Remove any matching queued/sending tmp from same sender + content
            const filtered = cur.filter((x) =>
              !(x.id.startsWith('tmp-') && x.sender_id === m.sender_id && x.content === m.content),
            );
            return [...filtered, m];
          });
          // Persist to cache
          if (convId) await cacheMessages(cacheKey('direct', convId), [m]);
          if (m.sender_id !== profile.id) {
            sfx.receive();
            if ((profile as any).read_receipts_enabled !== false) {
              await supabase.from('messages').update({ delivery: 'read' }).eq('id', m.id);
            }
          }
        })
      .on('postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'messages', filter: `conversation_id=eq.${convId}` },
        (payload) => setMessages((cur) => cur.map((x) => x.id === (payload.new as any).id ? { ...x, ...(payload.new as any) } : x)))
      .on('postgres_changes',
        { event: 'DELETE', schema: 'public', table: 'messages', filter: `conversation_id=eq.${convId}` },
        (payload) => setMessages((cur) => cur.filter((x) => x.id !== (payload.old as any).id)))
      .on('broadcast', { event: 'typing' }, (payload) => {
        if ((payload.payload as any).user_id !== profile.id) {
          setOthersTyping(true);
          window.clearTimeout((channelRef as any).typingTimeout);
          (channelRef as any).typingTimeout = window.setTimeout(() => setOthersTyping(false), 2500);
        }
      })
      .subscribe();
    channelRef.current = ch;
    return () => { supabase.removeChannel(ch); };
  }, [convId, profile]);

  // Subscribe to the other user's profile so presence updates live
  useEffect(() => {
    if (!other?.id) return;
    const ch = supabase
      .channel(`other-profile-${other.id}`)
      .on('postgres_changes',
        { event: 'UPDATE', schema: 'public', table: 'profiles', filter: `id=eq.${other.id}` },
        (payload) => setOther((cur) => cur ? { ...cur, ...(payload.new as any) } : cur))
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [other?.id]);

  // Auto scroll
  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages, othersTyping]);

  // Client-side hide of expired messages (server cron does final delete every 5m)
  useEffect(() => {
    const t = window.setInterval(() => {
      const now = Date.now();
      setMessages((cur) => cur.filter((m) => !m.expires_at || new Date(m.expires_at).getTime() > now));
    }, 5000);
    return () => window.clearInterval(t);
  }, []);

  const computeExpiry = () => disappearing > 0 ? new Date(Date.now() + disappearing * 1000).toISOString() : null;

  const send = async () => {
    const body = text.trim();
    if (!body || !profile || !convId) return;
    setText('');
    const tmpId = `tmp-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const nowIso = new Date().toISOString();
    const offline = !navigator.onLine;
    const replyId = replyTo?.id ?? null;
    const expiry = computeExpiry();
    const optimistic: ChatMessage = {
      id: tmpId, sender_id: profile.id, content: body,
      delivery: offline ? 'queued' : 'sending', created_at: nowIso,
      reply_to_id: replyId, expires_at: expiry,
    };
    setMessages((c) => [...c, optimistic]);
    setReplyTo(null);
    sfx.send();
    if (offline) {
      await enqueueOutbox({ tmp_id: tmpId, target_kind: 'direct', target_id: convId, sender_id: profile.id, content: body, created_at: nowIso });
      inputRef.current?.focus();
      return;
    }
    const { data, error } = await supabase.from('messages').insert({
      conversation_id: convId, sender_id: profile.id, content: body, delivery: 'sent',
      reply_to_id: replyId, expires_at: expiry,
    }).select('id, sender_id, content, delivery, created_at, reply_to_id, forwarded_from, expires_at').single();
    if (error) {
      await enqueueOutbox({ tmp_id: tmpId, target_kind: 'direct', target_id: convId, sender_id: profile.id, content: body, created_at: nowIso });
      setMessages((c) => c.map((m) => m.id === tmpId ? { ...m, delivery: 'queued' } : m));
      toast.message('Saved — will send when reconnected');
      return;
    }
    setMessages((c) => c.map((m) => m.id === tmpId ? (data as ChatMessage) : m));
    void track('message_sent', { kind: 'direct', conversation_id: convId });
    void awardAchievement('first_message');
    inputRef.current?.focus();
  };

  const sendTyping = () => {
    channelRef.current?.send({ type: 'broadcast', event: 'typing', payload: { user_id: profile?.id } });
  };

  const handleFile = async (file: File | null) => {
    if (!file || !profile || !convId) return;
    setUploading(true);
    const res = await uploadChatImage(file, profile.id);
    setUploading(false);
    if ('error' in res) { sfx.error(); toast.error(res.error); return; }
    const body = buildImageMessage(res.url);
    const optimistic: ChatMessage = {
      id: `tmp-${Date.now()}`, sender_id: profile.id, content: body, delivery: 'sending',
      created_at: new Date().toISOString(),
    };
    setMessages((c) => [...c, optimistic]);
    sfx.send();
    const { data, error } = await supabase.from('messages').insert({
      conversation_id: convId, sender_id: profile.id, content: body, delivery: 'sent',
    }).select('id, sender_id, content, delivery, created_at').single();
    if (error) {
      sfx.error(); toast.error(error.message);
      setMessages((c) => c.filter((m) => m.id !== optimistic.id));
      return;
    }
    setMessages((c) => c.map((m) => m.id === optimistic.id ? (data as ChatMessage) : m));
  };

  const sendMediaMsg = async (body: string) => {
    if (!profile || !convId) return;
    const expiry = computeExpiry();
    const optimistic: ChatMessage = {
      id: `tmp-${Date.now()}`, sender_id: profile.id, content: body, delivery: 'sending',
      created_at: new Date().toISOString(), expires_at: expiry,
    };
    setMessages((c) => [...c, optimistic]);
    sfx.send();
    const { data, error } = await supabase.from('messages').insert({
      conversation_id: convId, sender_id: profile.id, content: body, delivery: 'sent', expires_at: expiry,
    }).select('id, sender_id, content, delivery, created_at, reply_to_id, forwarded_from, expires_at').single();
    if (error) {
      sfx.error(); toast.error(error.message);
      setMessages((c) => c.filter((m) => m.id !== optimistic.id));
      return;
    }
    setMessages((c) => c.map((m) => m.id === optimistic.id ? (data as ChatMessage) : m));
  };

  const deleteMessage = async (m: ChatMessage) => {
    if (m.id.startsWith('tmp-')) return;
    const { error } = await supabase.from('messages').delete().eq('id', m.id);
    if (error) { toast.error(error.message); return; }
    setMessages((c) => c.filter((x) => x.id !== m.id));
  };

  const forwardTo = async (targetConvId: string, displayName: string) => {
    if (!profile || !forwardMsg) return;
    const { error } = await supabase.from('messages').insert({
      conversation_id: targetConvId, sender_id: profile.id, content: forwardMsg.content,
      delivery: 'sent', forwarded_from: forwardMsg.id,
    });
    if (error) { toast.error(error.message); return; }
    toast.success(`Forwarded to ${displayName}`);
    setForwardMsg(null);
  };

  const updateDisappearing = async (secs: number) => {
    if (!convId) return;
    setDisappearing(secs);
    await supabase.from('conversations').update({ disappearing_seconds: secs }).eq('id', convId);
    toast.success(secs === 0 ? 'Disappearing messages off' : `Messages disappear after ${formatDur(secs)}`);
  };

  const handleVideo = async (file: File | null) => {
    if (!file || !profile) return;
    if (file.size > MAX_VIDEO_BYTES) { toast.error('Video too large (max 25 MB)'); return; }
    setUploading(true);
    const ext = (file.name.split('.').pop() || 'mp4').toLowerCase();
    const res = await uploadToBucket(VIDEO_BUCKET, file, profile.id, ext);
    setUploading(false);
    if ('error' in res) { sfx.error(); toast.error(res.error); return; }
    await sendMediaMsg(buildVideoMessage(res.url));
  };

  const startRecording = async () => {
    if (!profile) return;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const rec = new MediaRecorder(stream);
      chunksRef.current = [];
      rec.ondataavailable = (e) => { if (e.data.size > 0) chunksRef.current.push(e.data); };
      rec.onstop = async () => {
        stream.getTracks().forEach((t) => t.stop());
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' });
        if (blob.size > MAX_VOICE_BYTES) { toast.error('Voice note too long'); return; }
        setUploading(true);
        const res = await uploadToBucket(VOICE_BUCKET, blob, profile.id, 'webm', 'audio/webm');
        setUploading(false);
        if ('error' in res) { toast.error(res.error); return; }
        await sendMediaMsg(buildVoiceMessage(res.url));
        void awardAchievement('voice_note');
      };
      rec.start();
      mediaRecRef.current = rec;
      setRecording(true);
    } catch (e: any) {
      toast.error(e.message || 'Microphone permission denied');
    }
  };

  const stopRecording = () => {
    mediaRecRef.current?.stop();
    mediaRecRef.current = null;
    setRecording(false);
  };

  const fmtTime = (iso: string) =>
    new Date(iso).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });

  const formatDur = (s: number) => {
    if (s < 60) return `${s}s`;
    if (s < 3600) return `${Math.round(s / 60)}m`;
    if (s < 86400) return `${Math.round(s / 3600)}h`;
    return `${Math.round(s / 86400)}d`;
  };

  const messageById = useMemo(() => new Map(messages.map((m) => [m.id, m])), [messages]);

  return (
    <div className="flex-1 min-h-0 flex flex-col mxit-classic-bg">
      {/* Title bar — orb + contact name + presence text */}
      <div className="mxit-titlebar h-9 flex items-center px-3 gap-2 shrink-0">
        {presenceOrb(other?.presence)}
        <div className="flex-1 text-left font-semibold text-[15px] tracking-wide truncate">
          {other?.display_name ?? '…'}
          {other && (
            <span className="ml-2 font-normal text-[12px] text-white/70 lowercase">
              — {presenceLabel(other.presence)}
            </span>
          )}
        </div>
        {other && (
          <>
            <button
              aria-label="voice call"
              onClick={() => { sfx.tap(); import('@/components/CallManager').then((m) => m.startCall(other.id, 'voice')); }}
              className="flex items-center justify-center w-7 h-7 rounded bg-white/10 border border-white/20 active:bg-white/20"
            ><Mic className="w-4 h-4" /></button>
            <button
              aria-label="video call"
              onClick={() => { sfx.tap(); import('@/components/CallManager').then((m) => m.startCall(other.id, 'video')); }}
              className="flex items-center justify-center w-7 h-7 rounded bg-white/10 border border-white/20 active:bg-white/20"
            ><Video className="w-4 h-4" /></button>
          </>
        )}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <button
              aria-label="more"
              className="flex items-center justify-center w-7 h-7 rounded bg-white/10 border border-white/20 active:bg-white/20"
            >
              <MoreVertical className="w-4 h-4" />
            </button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="z-50 bg-popover">
            <DropdownMenuItem onClick={() => updateDisappearing(0)}>
              <Timer className="w-4 h-4 mr-2" /> Disappearing: Off {disappearing === 0 && '✓'}
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => updateDisappearing(60)}>
              1 minute {disappearing === 60 && '✓'}
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => updateDisappearing(3600)}>
              1 hour {disappearing === 3600 && '✓'}
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => updateDisappearing(86400)}>
              24 hours {disappearing === 86400 && '✓'}
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => updateDisappearing(7 * 86400)}>
              7 days {disappearing === 7 * 86400 && '✓'}
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem onClick={() => other && setReportOpen(true)} className="text-destructive">
              Report / Block {other?.display_name ?? 'user'}
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
        <button
          onClick={() => { sfx.tap(); navigate('/'); }}
          aria-label="back"
          className="flex items-center gap-1 px-2 h-7 rounded bg-white/10 border border-white/20 active:bg-white/20 text-[12px] font-medium"
        >
          <ChevronLeft className="w-4 h-4" />
          Back
        </button>
      </div>

      {other && (
        <ReportBlockDialog
          open={reportOpen}
          onOpenChange={setReportOpen}
          targetUserId={other.id}
          targetName={other.display_name}
          onBlocked={() => navigate('/')}
        />
      )}

      {/* Message log — classic white scroll */}
      <div
        ref={scrollRef}
        className="mxit-chatlog flex-1 overflow-y-auto px-3 py-2 text-[13px] leading-snug no-scrollbar"
      >
        {messages.map((m) => {
          const isMe = m.sender_id === profile?.id;
          const name = isMe ? 'You' : (other?.display_name ?? '…');
          const nameColor = isMe ? 'text-[#1a6f1a]' : 'text-[#b91c1c]';
          const imgUrl = isImageMessage(m.content);
          const voiceUrl = isVoiceMessage(m.content);
          const videoUrl = isVideoMessage(m.content);
          const myReactions = reactions.filter((r) => r.message_id === m.id);
          const replied = m.reply_to_id ? messageById.get(m.reply_to_id) : null;
          let pressTimer: number | null = null;
          const onPressStart = () => {
            if (m.id.startsWith('tmp-')) return;
            pressTimer = window.setTimeout(() => setActionFor(m), 400);
          };
          const onPressEnd = () => { if (pressTimer) { window.clearTimeout(pressTimer); pressTimer = null; } };
          return (
            <div
              key={m.id}
              className="border-b border-black/10 py-1.5 select-none"
              onTouchStart={onPressStart}
              onTouchEnd={onPressEnd}
              onTouchMove={onPressEnd}
              onMouseDown={onPressStart}
              onMouseUp={onPressEnd}
              onMouseLeave={onPressEnd}
              onContextMenu={(e) => { e.preventDefault(); if (!m.id.startsWith('tmp-')) setActionFor(m); }}
            >
              <span className={`font-semibold ${nameColor}`}>{name}</span>
              <span className="text-black/50"> ({fmtTime(m.created_at)}) </span>
              {m.forwarded_from && <span className="text-[10px] text-black/50 italic"> · forwarded</span>}
              {m.expires_at && <span className="text-[10px] text-black/50 italic"> · ⏱</span>}
              {replied && (
                <div className="border-l-2 border-mxit-primary pl-2 my-1 text-[11px] text-black/70 bg-black/5 rounded-sm py-0.5">
                  <span className="font-semibold">{replied.sender_id === profile?.id ? 'You' : (other?.display_name ?? '…')}: </span>
                  {(isImageMessage(replied.content) || isVoiceMessage(replied.content) || isVideoMessage(replied.content)) ? '📎 media' : replied.content.slice(0, 80)}
                </div>
              )}
              {voiceUrl ? (
                <audio controls src={voiceUrl} className="block mt-1 max-w-full h-10" />
              ) : videoUrl ? (
                <video controls src={videoUrl} className="block mt-1 max-h-56 max-w-full rounded border border-black/20" />
              ) : imgUrl ? (
                lowData && !revealedImgs.has(m.id) ? (
                  <button
                    onClick={() => setRevealedImgs((s) => new Set(s).add(m.id))}
                    className="mt-1 inline-flex items-center gap-1 text-[12px] px-2 py-1 rounded bg-black/10 hover:bg-black/20 border border-black/20 text-black/70"
                  >
                    📷 Tap to load image (low data mode)
                  </button>
                ) : (
                  <a href={imgUrl} target="_blank" rel="noreferrer" className="block mt-1">
                    <img src={imgUrl} alt="shared" className="max-h-56 max-w-full rounded border border-black/20" loading="lazy" />
                  </a>
                )
              ) : (
                <span className="text-black"><EmoText text={m.content} size={20} /></span>
              )}
              <ReactionRow
                reactions={myReactions}
                onToggle={(emoji) => profile && toggleReaction(m.id, emoji, profile.id, myReactions)}
              />
            </div>
          );
        })}
        {othersTyping && other && (
          <div className="py-1 text-black/50 italic text-[12px]">{other.display_name} is typing…</div>
        )}
      </div>

      <MessageActionSheet
        open={!!actionFor}
        onClose={() => setActionFor(null)}
        isMe={actionFor?.sender_id === profile?.id}
        onReact={(emoji) => actionFor && profile && toggleReaction(actionFor.id, emoji, profile.id, reactions.filter((r) => r.message_id === actionFor.id))}
        onReply={() => { if (actionFor) setReplyTo(actionFor); inputRef.current?.focus(); }}
        onForward={() => actionFor && setForwardMsg(actionFor)}
        onDelete={actionFor?.sender_id === profile?.id ? () => actionFor && deleteMessage(actionFor) : undefined}
        onTranslate={actionFor ? async (target) => {
          const src = actionFor.content;
          if (isImageMessage(src) || isVoiceMessage(src) || isVideoMessage(src)) { toast.error('Cannot translate media'); return; }
          const tid = toast.loading(`Translating to ${target}…`);
          const { data, error } = await supabase.functions.invoke('translate-message', { body: { text: src, target } });
          toast.dismiss(tid);
          if (error || (data as any)?.error) { toast.error((data as any)?.error || error?.message || 'Translate failed'); return; }
          toast.success(`${target}: ${(data as any).translation}`, { duration: 8000 });
        } : undefined}
        onTip={actionFor && actionFor.sender_id !== profile?.id ? async (amount) => {
          const { data, error } = await (supabase as any).rpc('send_moola', { _to: actionFor.sender_id, _amount: amount, _note: 'Tip', _message_id: actionFor.id });
          if (error) { toast.error(error.message); return; }
          if (data?.ok) { toast.success(`Tipped ${amount}M to ${other?.display_name ?? 'them'}`); void awardAchievement('moola_tip'); }
        } : undefined}
      />
      <ForwardDialog
        open={!!forwardMsg}
        onClose={() => setForwardMsg(null)}
        onPick={forwardTo}
      />

      {/* Bottom black input bar — emoticon + field + Send */}
      <div className="bg-black text-white shrink-0 relative" style={{ paddingBottom: 'env(safe-area-inset-bottom)' }}>
        {disappearing > 0 && (
          <div className="px-3 py-1 text-[10px] text-yellow-300 bg-yellow-500/10 border-t border-yellow-500/30 flex items-center gap-1">
            <Timer className="w-3 h-3" /> Messages disappear after {formatDur(disappearing)}
          </div>
        )}
        {replyTo && (
          <div className="px-3 py-1.5 text-[11px] bg-white/5 border-t border-white/20 flex items-start gap-2">
            <Reply className="w-3.5 h-3.5 mt-0.5 text-mxit-primary shrink-0" />
            <div className="flex-1 min-w-0">
              <div className="font-semibold text-mxit-primary">{replyTo.sender_id === profile?.id ? 'You' : (other?.display_name ?? '…')}</div>
              <div className="truncate text-white/70">{(isImageMessage(replyTo.content) || isVoiceMessage(replyTo.content) || isVideoMessage(replyTo.content)) ? '📎 media' : replyTo.content}</div>
            </div>
            <button onClick={() => setReplyTo(null)}><X className="w-4 h-4" /></button>
          </div>
        )}
        {picker && (
          <EmoticonPicker
            onPick={(c) => { setText((t) => t + c); setPicker(false); inputRef.current?.focus(); }}
            onClose={() => setPicker(false)}
          />
        )}
        <div className="flex items-stretch gap-2 p-2">
          <input
            ref={fileRef}
            type="file"
            accept={CHAT_FILE_ACCEPT}
            className="hidden"
            onChange={(e) => { handleFile(e.target.files?.[0] ?? null); e.target.value = ''; }}
          />
          <input
            ref={videoRef}
            type="file"
            accept="video/*"
            className="hidden"
            onChange={(e) => { handleVideo(e.target.files?.[0] ?? null); e.target.value = ''; }}
          />
          <button
            onClick={() => { sfx.tap(); setPicker((p) => !p); }}
            aria-label="emoticons"
            className="w-10 h-10 flex items-center justify-center rounded bg-yellow-400 text-black active:scale-95"
          >
            <Smile className="w-6 h-6" />
          </button>
          {!lowData && (
            <button
              onClick={() => { sfx.tap(); fileRef.current?.click(); }}
              disabled={uploading}
              aria-label="attach image"
              title="Send image or GIF"
              className="w-10 h-10 flex items-center justify-center rounded bg-white/10 text-white active:scale-95 disabled:opacity-40"
            >
              <ImagePlus className="w-5 h-5" />
            </button>
          )}
          {!lowData && (
            <button
              onClick={() => { sfx.tap(); videoRef.current?.click(); }}
              disabled={uploading || recording}
              aria-label="attach video"
              title="Send video"
              className="w-10 h-10 flex items-center justify-center rounded bg-white/10 text-white active:scale-95 disabled:opacity-40"
            >
              <Video className="w-5 h-5" />
            </button>
          )}
          <button
            onClick={() => { sfx.tap(); recording ? stopRecording() : startRecording(); }}
            disabled={uploading}
            aria-label={recording ? 'stop recording' : 'record voice note'}
            title={recording ? 'Stop recording' : 'Hold to record voice note'}
            className={`w-10 h-10 flex items-center justify-center rounded active:scale-95 disabled:opacity-40 ${recording ? 'bg-red-500 text-white animate-pulse' : 'bg-white/10 text-white'}`}
          >
            {recording ? <Square className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
          </button>
          <textarea
            ref={inputRef}
            value={text}
            onChange={(e) => { setText(e.target.value); sendTyping(); }}
            onKeyDown={(e) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); send(); } }}
            rows={1}
            className="flex-1 bg-white text-black rounded px-2 py-1 text-sm resize-none max-h-24 focus:outline-none"
            style={{ minHeight: '40px' }}
          />
          <button
            onClick={send}
            disabled={!text.trim()}
            className="px-4 text-white text-sm font-medium border border-white/30 rounded bg-white/5 active:bg-white/20 disabled:opacity-40"
          >
            Send
          </button>
        </div>
      </div>
    </div>
  );
}
