/**
 * MultiMx group chat — like ChatRoom but messages use multimx_group_id.
 * Free to chat. Creator can invite more members and delete the group.
 */
import { useEffect, useRef, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ArrowLeft, LogOut, UserPlus, Users, Pencil, UserMinus, Check, X } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { MxitHeader } from '@/components/MxitHeader';
import {
  ChatMessage, Composer, MessageBubble, Sender, TypingIndicator,
} from '@/components/ChatPrimitives';
import { sfx } from '@/lib/sfx';
import { toast } from 'sonner';
import { cacheKey, cacheMessages, getCachedMessages, getOutboxFor, enqueueOutbox } from '@/lib/offlineDb';
import { flushOutbox } from '@/lib/offlineQueue';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { PixelAvatar } from '@/components/PixelAvatar';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';

type Group = { id: string; name: string; created_by: string };

export default function MultiMxChat() {
  const { id: groupId } = useParams();
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [group, setGroup] = useState<Group | null>(null);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [members, setMembers] = useState<Sender[]>([]);
  const [typers, setTypers] = useState<Map<string, string>>(new Map());
  const [inviteOpen, setInviteOpen] = useState(false);
  const [candidates, setCandidates] = useState<Sender[]>([]);
  const [picked, setPicked] = useState<Set<string>>(new Set());
  const [renaming, setRenaming] = useState(false);
  const [newName, setNewName] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);
  const channelRef = useRef<ReturnType<typeof supabase.channel> | null>(null);
  const senderMap = useRef<Map<string, Sender>>(new Map());

  useEffect(() => {
    if (!groupId || !profile) return;
    let cancelled = false;
    (async () => {
      // Hydrate from cache instantly
      const ck = cacheKey('multimx', groupId);
      const cached = await getCachedMessages(ck);
      const queued = await getOutboxFor('multimx', groupId);
      const queuedAsMsgs: ChatMessage[] = queued.map((q) => ({
        id: q.tmp_id, sender_id: q.sender_id, content: q.content,
        delivery: 'queued' as ChatMessage['delivery'], created_at: q.created_at,
      }));
      if (!cancelled && (cached.length || queuedAsMsgs.length)) {
        setMessages([...cached, ...queuedAsMsgs]);
      }
      if (!navigator.onLine) return;

      const { data: g } = await supabase
        .from('multimx_groups')
        .select('id, name, created_by')
        .eq('id', groupId)
        .maybeSingle();
      if (!g) {
        if (!cached.length) { toast.error('Group not found'); navigate('/multimx'); }
        return;
      }
      if (!cancelled) setGroup(g as Group);

      const { data: ms } = await supabase
        .from('multimx_members')
        .select('user_id')
        .eq('group_id', groupId);
      const userIds = (ms ?? []).map((m: any) => m.user_id);
      if (userIds.length) {
        const { data: ps } = await supabase
          .from('profiles')
          .select('id, display_name, avatar_seed, avatar_url')
          .in('id', userIds);
        const list = (ps ?? []) as Sender[];
        if (!cancelled) setMembers(list);
        list.forEach((p) => senderMap.current.set(p.id, p));
      }

      const { data: msgs } = await supabase
        .from('messages')
        .select('id, sender_id, content, delivery, created_at')
        .eq('multimx_group_id', groupId)
        .order('created_at')
        .limit(200);
      if (msgs && !cancelled) {
        const remote = msgs as ChatMessage[];
        await cacheMessages(ck, remote);
        const stillQueued = await getOutboxFor('multimx', groupId);
        const queuedTail: ChatMessage[] = stillQueued.map((q) => ({
          id: q.tmp_id, sender_id: q.sender_id, content: q.content,
          delivery: 'queued' as ChatMessage['delivery'], created_at: q.created_at,
        }));
        setMessages([...remote, ...queuedTail]);
      }
      void flushOutbox();
    })();
    return () => { cancelled = true; };
  }, [groupId, profile, navigate]);

  useEffect(() => {
    if (!groupId || !profile) return;
    const ch = supabase
      .channel(`multimx-${groupId}`)
      .on('postgres_changes',
        { event: 'INSERT', schema: 'public', table: 'messages', filter: `multimx_group_id=eq.${groupId}` },
        async (payload) => {
          const m = payload.new as ChatMessage;
          setMessages((cur) => {
            if (cur.some((x) => x.id === m.id)) return cur;
            const filtered = cur.filter((x) =>
              !(x.id.startsWith('tmp-') && x.sender_id === m.sender_id && x.content === m.content),
            );
            return [...filtered, m];
          });
          if (groupId) await cacheMessages(cacheKey('multimx', groupId), [m]);
          if (m.sender_id !== profile.id) sfx.receive();
          if (!senderMap.current.has(m.sender_id)) {
            const { data } = await supabase
              .from('profiles')
              .select('id, display_name, avatar_seed, avatar_url')
              .eq('id', m.sender_id)
              .maybeSingle();
            if (data) senderMap.current.set(data.id, data as Sender);
          }
        })
      .on('postgres_changes',
        { event: 'DELETE', schema: 'public', table: 'messages', filter: `multimx_group_id=eq.${groupId}` },
        (payload) => setMessages((cur) => cur.filter((x) => x.id !== (payload.old as any).id)))
      .on('broadcast', { event: 'typing' }, (payload) => {
        const { user_id, name } = payload.payload as { user_id: string; name: string };
        if (user_id === profile.id) return;
        setTypers((m) => { const n = new Map(m); n.set(user_id, name); return n; });
        window.clearTimeout((channelRef as any)[`t_${user_id}`]);
        (channelRef as any)[`t_${user_id}`] = window.setTimeout(() => {
          setTypers((m) => { const n = new Map(m); n.delete(user_id); return n; });
        }, 2500);
      })
      .subscribe();
    channelRef.current = ch;
    return () => { supabase.removeChannel(ch); };
  }, [groupId, profile]);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' });
  }, [messages, typers]);

  const send = async (text: string) => {
    if (!profile || !groupId) return;
    const tmpId = `tmp-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const nowIso = new Date().toISOString();
    const offline = !navigator.onLine;
    const optimistic: ChatMessage = {
      id: tmpId, sender_id: profile.id, content: text,
      delivery: offline ? 'queued' : 'sending', created_at: nowIso,
    };
    setMessages((c) => [...c, optimistic]);
    if (offline) {
      await enqueueOutbox({ tmp_id: tmpId, target_kind: 'multimx', target_id: groupId, sender_id: profile.id, content: text, created_at: nowIso });
      return;
    }
    const { data, error } = await supabase.from('messages').insert({
      multimx_group_id: groupId, sender_id: profile.id, content: text, delivery: 'sent',
    }).select('id, sender_id, content, delivery, created_at').single();
    if (error) {
      await enqueueOutbox({ tmp_id: tmpId, target_kind: 'multimx', target_id: groupId, sender_id: profile.id, content: text, created_at: nowIso });
      setMessages((c) => c.map((m) => m.id === tmpId ? { ...m, delivery: 'queued' } : m));
      toast.message('Saved — will send when reconnected');
      return;
    }
    setMessages((c) => c.map((m) => m.id === tmpId ? (data as ChatMessage) : m));
    void import('@/lib/analytics').then(({ track }) => track('message_sent', { kind: 'multimx', group_id: groupId }));
  };

  const sendTyping = () => {
    channelRef.current?.send({
      type: 'broadcast', event: 'typing',
      payload: { user_id: profile?.id, name: profile?.display_name },
    });
  };

  const leave = async () => {
    if (!profile || !groupId) return;
    sfx.tap();
    await supabase.from('multimx_members').delete().eq('group_id', groupId).eq('user_id', profile.id);
    toast.success('Left the group');
    navigate('/multimx');
  };

  const remove = async (id: string) => { await supabase.from('messages').delete().eq('id', id); };

  const openInvite = async () => {
    if (!profile) return;
    sfx.tap();
    setInviteOpen(true);
    // Load my contacts not yet in group
    const { data: cs } = await supabase
      .from('contacts')
      .select('requester_id, addressee_id, status')
      .eq('status', 'accepted')
      .or(`requester_id.eq.${profile.id},addressee_id.eq.${profile.id}`);
    const otherIds = (cs ?? []).map((c: any) =>
      c.requester_id === profile.id ? c.addressee_id : c.requester_id,
    );
    const memberIds = new Set(members.map((m) => m.id));
    const eligible = otherIds.filter((id: string) => !memberIds.has(id));
    if (!eligible.length) { setCandidates([]); return; }
    const { data: ps } = await supabase
      .from('profiles')
      .select('id, display_name, avatar_seed, avatar_url')
      .in('id', eligible);
    setCandidates((ps ?? []) as Sender[]);
  };

  const sendInvites = async () => {
    if (!groupId || picked.size === 0) return;
    const rows = Array.from(picked).map((uid) => ({ group_id: groupId, user_id: uid }));
    const { error } = await supabase.from('multimx_members').insert(rows);
    if (error) { sfx.error(); toast.error(error.message); return; }
    toast.success(`Invited ${picked.size}`);
    setPicked(new Set());
    setInviteOpen(false);
    // refresh
    const { data: ms } = await supabase
      .from('multimx_members')
      .select('user_id')
      .eq('group_id', groupId);
    const userIds = (ms ?? []).map((m: any) => m.user_id);
    const { data: ps } = await supabase
      .from('profiles')
      .select('id, display_name, avatar_seed, avatar_url')
      .in('id', userIds);
    const list = (ps ?? []) as Sender[];
    setMembers(list);
    list.forEach((p) => senderMap.current.set(p.id, p));
  };

  const togglePick = (id: string) => {
    setPicked((p) => {
      const n = new Set(p);
      if (n.has(id)) n.delete(id); else n.add(id);
      return n;
    });
  };

  const isCreator = group?.created_by === profile?.id;
  const typingNames = Array.from(typers.values());

  const saveRename = async () => {
    if (!groupId || !isCreator) return;
    const trimmed = newName.trim();
    if (!trimmed || trimmed === group?.name) { setRenaming(false); return; }
    const { error } = await supabase.from('multimx_groups').update({ name: trimmed }).eq('id', groupId);
    if (error) { sfx.error(); toast.error(error.message); return; }
    setGroup((g) => g ? { ...g, name: trimmed } : g);
    setRenaming(false);
    toast.success('Group renamed');
  };

  const kickMember = async (uid: string, name: string) => {
    if (!groupId || !isCreator || uid === profile?.id) return;
    if (!confirm(`Remove ${name} from the group?`)) return;
    const { error } = await supabase.from('multimx_members').delete().eq('group_id', groupId).eq('user_id', uid);
    if (error) { sfx.error(); toast.error(error.message); return; }
    setMembers((m) => m.filter((x) => x.id !== uid));
    toast.success(`${name} removed`);
  };

  return (
    <div className="flex-1 flex flex-col">
      <MxitHeader
        left={
          <button
            onClick={() => { sfx.tap(); navigate('/multimx'); }}
            className="p-2 hover:bg-white/10 rounded-md tap-scale"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
        }
        right={
          <Sheet>
            <SheetTrigger asChild>
              <button
                onClick={() => sfx.tap()}
                className="p-2 hover:bg-white/10 rounded-md tap-scale flex items-center gap-1"
              >
                <Users className="w-4 h-4" /> <span className="text-xs">{members.length}</span>
              </button>
            </SheetTrigger>
            <SheetContent side="right" className="w-72">
              <SheetHeader><SheetTitle className="font-pixel text-sm">group</SheetTitle></SheetHeader>
              <div className="mt-3 mb-3 p-2 bg-secondary/50 rounded-md">
                {renaming ? (
                  <div className="flex items-center gap-1">
                    <input
                      autoFocus
                      value={newName}
                      onChange={(e) => setNewName(e.target.value)}
                      onKeyDown={(e) => { if (e.key === 'Enter') saveRename(); if (e.key === 'Escape') setRenaming(false); }}
                      maxLength={40}
                      className="flex-1 bg-background rounded px-2 py-1 text-sm focus:outline-none focus:ring-1 focus:ring-primary"
                    />
                    <button onClick={saveRename} className="p-1.5 text-primary tap-scale" aria-label="save"><Check className="w-4 h-4" /></button>
                    <button onClick={() => setRenaming(false)} className="p-1.5 text-muted-foreground tap-scale" aria-label="cancel"><X className="w-4 h-4" /></button>
                  </div>
                ) : (
                  <div className="flex items-center gap-2">
                    <span className="flex-1 text-sm font-medium truncate">{group?.name || '…'}</span>
                    {isCreator && (
                      <button onClick={() => { setNewName(group?.name || ''); setRenaming(true); }} className="p-1 text-muted-foreground hover:text-primary tap-scale" aria-label="rename">
                        <Pencil className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                )}
              </div>
              <div className="text-[10px] uppercase tracking-wider text-muted-foreground px-1 mb-1">members</div>
              <div className="space-y-2">
                {members.map((m) => (
                  <div key={m.id} className="flex items-center gap-2 p-2 bg-secondary/50 rounded-md">
                    <PixelAvatar seed={m.avatar_seed} url={m.avatar_url} size={32} />
                    <span className="text-sm flex-1 truncate">
                      {m.display_name}{m.id === profile?.id ? ' (you)' : ''}
                    </span>
                    {m.id === group?.created_by && (
                      <span className="text-[9px] bg-amber-400 text-black px-1.5 py-0.5 rounded">CREATOR</span>
                    )}
                    {isCreator && m.id !== profile?.id && (
                      <button
                        onClick={() => kickMember(m.id, m.display_name)}
                        className="p-1 text-destructive hover:bg-destructive/10 rounded tap-scale"
                        aria-label={`remove ${m.display_name}`}
                        title="Remove from group"
                      >
                        <UserMinus className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                ))}
                {isCreator && (
                  <button
                    onClick={openInvite}
                    className="w-full mt-2 p-3 bg-primary/10 text-primary rounded-md text-sm flex items-center justify-center gap-2 tap-scale"
                  >
                    <UserPlus className="w-4 h-4" /> invite contacts
                  </button>
                )}
                <button
                  onClick={leave}
                  className="w-full mt-2 p-3 bg-destructive/10 text-destructive rounded-md text-sm flex items-center justify-center gap-2 tap-scale"
                >
                  <LogOut className="w-4 h-4" /> leave group
                </button>
              </div>
            </SheetContent>
          </Sheet>
        }
        title={group?.name || '…'}
        subtitle={`${members.length} member${members.length === 1 ? '' : 's'} · MultiMx`}
      />

      <div ref={scrollRef} className="flex-1 overflow-y-auto mxit-screen-bg p-3 space-y-2 no-scrollbar">
        {messages.map((m, i) => {
          const isMe = m.sender_id === profile?.id;
          const prev = messages[i - 1];
          const newSender = !prev || prev.sender_id !== m.sender_id;
          return (
            <MessageBubble
              key={m.id}
              msg={m}
              isMe={isMe}
              sender={isMe ? undefined : senderMap.current.get(m.sender_id)}
              showAvatar={!isMe && newSender}
              showName={!isMe && newSender}
              onDelete={isMe ? () => remove(m.id) : undefined}
              lowData={!!profile?.low_data_mode}
            />
          );
        })}
        {typingNames.length > 0 && <TypingIndicator name={typingNames.join(', ')} />}
      </div>

      <Composer onSend={send} onTyping={sendTyping} />

      {/* Invite dialog */}
      <Dialog open={inviteOpen} onOpenChange={setInviteOpen}>
        <DialogContent>
          <DialogHeader><DialogTitle className="font-pixel text-sm">invite contacts</DialogTitle></DialogHeader>
          <div className="max-h-72 overflow-y-auto space-y-1 border rounded-md p-2">
            {candidates.length === 0 && (
              <div className="text-xs text-muted-foreground italic px-1 py-2">
                No more contacts to invite.
              </div>
            )}
            {candidates.map((c) => {
              const on = picked.has(c.id);
              return (
                <button
                  key={c.id}
                  onClick={() => togglePick(c.id)}
                  className={`w-full flex items-center gap-2 p-1.5 rounded ${
                    on ? 'bg-primary/15 ring-1 ring-primary' : 'hover:bg-muted'
                  }`}
                >
                  <PixelAvatar seed={c.avatar_seed} url={c.avatar_url} size={28} />
                  <span className="flex-1 text-left text-sm truncate">{c.display_name}</span>
                  <input type="checkbox" checked={on} onChange={() => togglePick(c.id)} className="w-4 h-4" />
                </button>
              );
            })}
          </div>
          <Button
            onClick={sendInvites}
            disabled={picked.size === 0}
            className="font-pixel text-[10px]"
          >
            Add {picked.size} to group
          </Button>
        </DialogContent>
      </Dialog>
    </div>
  );
}
