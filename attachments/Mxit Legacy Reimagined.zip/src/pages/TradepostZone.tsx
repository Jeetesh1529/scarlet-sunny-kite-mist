/**
 * Tradepost > Zone — numbered rooms (30 users each) with Quick Join + manual list.
 * Quick Join uses the join_best_room RPC which finds the first non-full room or creates the next one.
 */
import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { sfx } from '@/lib/sfx';
import { toast } from 'sonner';
import { ChevronRight, Users, Zap } from 'lucide-react';
import { awardAchievement } from '@/lib/achievements';

type Zone = { id: string; slug: string; name: string; description: string | null; min_age: number; category_id: string | null };
type Room = {
  id: string;
  name: string;
  room_number: number | null;
  max_users: number;
  member_count: number;
  joined: boolean;
};

export default function TradepostZone() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const { profile } = useAuth();
  const [zone, setZone] = useState<Zone | null>(null);
  const [rooms, setRooms] = useState<Room[]>([]);
  const [joining, setJoining] = useState(false);

  const load = async () => {
    if (!slug || !profile) return;
    const { data: z } = await supabase
      .from('chatroom_zones')
      .select('id, slug, name, description, min_age, category_id')
      .eq('slug', slug)
      .maybeSingle();
    if (!z) { toast.error('Zone not found'); navigate('/tradepost/chatrooms'); return; }
    setZone(z as Zone);

    const { data: rs } = await supabase
      .from('chatrooms')
      .select('id, name, room_number, max_users')
      .eq('zone_id', (z as Zone).id)
      .order('room_number');

    const ids = (rs ?? []).map((r: any) => r.id);
    if (!ids.length) { setRooms([]); return; }

    const { data: ms } = await supabase
      .from('room_members')
      .select('room_id, user_id')
      .in('room_id', ids);

    const counts = new Map<string, number>();
    const mine = new Set<string>();
    (ms ?? []).forEach((m: any) => {
      counts.set(m.room_id, (counts.get(m.room_id) ?? 0) + 1);
      if (m.user_id === profile.id) mine.add(m.room_id);
    });

    setRooms(
      (rs ?? []).map((r: any) => ({
        ...r,
        member_count: counts.get(r.id) ?? 0,
        joined: mine.has(r.id),
      })),
    );
  };

  useEffect(() => {
    load();
    if (!profile) return;
    const ch = supabase
      .channel(`zone-${slug}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'room_members' }, load)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'chatrooms' }, load)
      .subscribe();
    return () => { supabase.removeChannel(ch); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [slug, profile?.id]);

  const ageOk = (z: Zone | null) => {
    if (!z) return false;
    const min = z.min_age ?? 0;
    if (min <= 0) return true;
    const age = profile?.age ?? 0;
    if (age < min) {
      sfx.error();
      toast.error(`This zone is ${min}+. Update your age in Profile to enter.`);
      return false;
    }
    return true;
  };

  const quickJoin = async () => {
    if (!zone || joining) return;
    if (!ageOk(zone)) return;
    sfx.tap();
    setJoining(true);
    const { data, error } = await supabase.rpc('join_best_room', { _zone_id: zone.id });
    setJoining(false);
    if (error) { toast.error(error.message); return; }
    if (data) { void awardAchievement('chatroom_join'); navigate(`/room/${data as string}`); }
  };

  const enter = async (r: Room) => {
    if (!profile) return;
    if (!ageOk(zone)) return;
    sfx.tap();
    if (r.joined) { navigate(`/room/${r.id}`); return; }
    if (r.member_count >= r.max_users) { toast.error('Room is full — try Quick Join'); return; }
    const { error } = await supabase
      .from('room_members')
      .insert({ room_id: r.id, user_id: profile.id });
    if (error) {
      if (error.message?.includes('ROOM_FULL')) toast.error('Room is full — try Quick Join');
      else if (error.code !== '23505') toast.error(error.message);
      return;
    }
    void awardAchievement('chatroom_join');
    navigate(`/room/${r.id}`);
  };

  // Best room hint: lowest member_count under cap
  const best = [...rooms].filter((r) => r.member_count < r.max_users).sort((a, b) => b.member_count - a.member_count)[0];

  return (
    <div className="flex-1 min-h-0 flex flex-col mxit-classic-bg">
      <div className="mxit-titlebar h-9 flex items-center px-3 gap-2 shrink-0">
        <button
          onClick={() => { sfx.tap(); navigate(-1); }}
          className="text-[11px] px-2 py-0.5 rounded-sm bg-white/10 border border-white/20"
        >
          ‹ Back
        </button>
        <div className="flex-1 text-center font-semibold text-[15px] tracking-wide truncate">
          {zone?.name ?? '…'}
        </div>
        <span className="text-[10px] text-amber-200">30 / room</span>
      </div>

      <div className="relative flex-1 overflow-y-auto mxit-watermark min-h-0">
        <div className="relative z-10 py-2">
          {zone?.description && (
            <div className="px-3 pb-2 text-[11px] text-white/60 italic">{zone.description}</div>
          )}

          {/* Quick Join card */}
          <button
            onClick={quickJoin}
            disabled={joining}
            className="mx-3 mb-2 w-[calc(100%-1.5rem)] text-left flex items-center gap-3 px-3 py-2 rounded-md bg-amber-300/15 border border-amber-300/40 hover:bg-amber-300/25 active:bg-amber-300/30 disabled:opacity-50"
          >
            <Zap className="w-4 h-4 text-amber-200 shrink-0" />
            <span className="flex-1 min-w-0 text-white font-medium tracking-wide">
              Quick Join — best room available
              <span className="block text-[11px] font-normal text-white/70 truncate">
                {best
                  ? `${best.name} — ${best.member_count}/${best.max_users} online`
                  : 'All rooms full — a new one will be created'}
              </span>
            </span>
            <ChevronRight className="w-4 h-4 text-white/70" />
          </button>

          <div className="px-3 pb-1 text-[10px] uppercase tracking-wider text-white/40">Choose manually</div>

          {rooms.map((r) => {
            const full = r.member_count >= r.max_users;
            return (
              <button
                key={r.id}
                onClick={() => enter(r)}
                disabled={full && !r.joined}
                className={`w-full text-left flex items-center gap-3 pl-3 pr-3 py-2 ${
                  full && !r.joined ? 'opacity-50' : 'hover:bg-white/5 active:bg-white/10'
                }`}
              >
                <span className={`status-orb ${full ? 'orb-busy' : 'orb-online'}`} />
                <span
                  className="flex-1 min-w-0 truncate text-white font-medium tracking-wide"
                  style={{ textShadow: '0 1px 0 hsl(220 80% 8% / 0.6)' }}
                >
                  {r.name}
                  <span className="block text-[11px] font-normal text-white/60 truncate">
                    {full ? 'Full — try another' : r.joined ? 'You are in this room' : 'Tap to enter'}
                  </span>
                </span>
                <span className="text-[11px] text-white/70 flex items-center gap-1">
                  <Users className="w-3.5 h-3.5" /> {r.member_count}/{r.max_users}
                </span>
                <ChevronRight className="w-4 h-4 text-white/60 ml-1" />
              </button>
            );
          })}
        </div>
      </div>

      <div className="mxit-softkeys h-10 flex items-stretch text-sm font-medium shrink-0">
        <button onClick={() => { sfx.tap(); navigate(-1); }} className="flex-1 text-left pl-4 active:bg-black/30">Back</button>
        <button onClick={() => { sfx.tap(); navigate('/'); }} className="flex-1 text-right pr-4 active:bg-black/30">Home</button>
      </div>
    </div>
  );
}
