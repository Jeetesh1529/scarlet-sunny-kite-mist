/**
 * Meet People — opt-in dating/discovery zone. Browse other opted-in users
 * with a "Say Hi" action that opens (or creates) a conversation.
 */
import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { sfx } from '@/lib/sfx';
import { toast } from 'sonner';
import { ChevronLeft, Heart, MessageCircle, Sparkles, Filter } from 'lucide-react';
import { PixelAvatar } from '@/components/PixelAvatar';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { awardAchievement } from '@/lib/achievements';

type Meeter = {
  id: string;
  display_name: string;
  mxit_id: string;
  avatar_seed: string | null;
  avatar_url: string | null;
  age: number | null;
  gender: string | null;
  mood: string | null;
  meet_bio: string | null;
};

export default function Meet() {
  const navigate = useNavigate();
  const { profile, refreshProfile } = useAuth();
  const [people, setPeople] = useState<Meeter[]>([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState<'all' | 'm' | 'f' | 'other'>('all');
  const [editingBio, setEditingBio] = useState(false);
  const [bio, setBio] = useState('');

  useEffect(() => {
    if (profile) setBio(profile.meet_bio ?? '');
  }, [profile?.id]);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      const { data } = await supabase
        .from('profiles')
        .select('id, display_name, mxit_id, avatar_seed, avatar_url, age, gender, mood, meet_bio')
        .eq('meet_opt_in', true)
        .neq('id', profile?.id ?? '00000000-0000-0000-0000-000000000000')
        .order('updated_at', { ascending: false })
        .limit(60);
      if (!cancelled) {
        setPeople((data ?? []) as Meeter[]);
        setLoading(false);
      }
    })();
    return () => { cancelled = true; };
  }, [profile?.id]);

  const filtered = useMemo(() => {
    if (filter === 'all') return people;
    return people.filter((p) => (p.gender ?? '').toLowerCase().startsWith(filter));
  }, [people, filter]);

  const toggleOptIn = async () => {
    if (!profile) return;
    sfx.tap();
    const next = !profile.meet_opt_in;
    const { error } = await supabase.from('profiles').update({ meet_opt_in: next }).eq('id', profile.id);
    if (error) { toast.error(error.message); return; }
    await refreshProfile?.();
    if (next) {
      toast.success('You are visible in Meet People');
      void awardAchievement('meet_optin');
    } else {
      toast.success('You are hidden from Meet People');
    }
  };

  const saveBio = async () => {
    if (!profile) return;
    const { error } = await supabase.from('profiles').update({ meet_bio: bio.slice(0, 240) }).eq('id', profile.id);
    if (error) { toast.error(error.message); return; }
    await refreshProfile?.();
    setEditingBio(false);
    toast.success('Bio updated');
  };

  const sayHi = async (m: Meeter) => {
    if (!profile) return;
    sfx.tap();
    // Find or create conversation
    const { data: existing } = await supabase
      .from('conversations')
      .select('id')
      .or(`and(user_a.eq.${profile.id},user_b.eq.${m.id}),and(user_a.eq.${m.id},user_b.eq.${profile.id})`)
      .maybeSingle();
    let convId = existing?.id;
    if (!convId) {
      const a = profile.id < m.id ? profile.id : m.id;
      const b = profile.id < m.id ? m.id : profile.id;
      const { data: created, error } = await supabase
        .from('conversations')
        .insert({ user_a: a, user_b: b })
        .select('id')
        .single();
      if (error) { toast.error(error.message); return; }
      convId = created.id;
    }
    navigate(`/chat/${convId}`);
  };

  return (
    <div className="flex-1 min-h-0 flex flex-col mxit-classic-bg">
      <div className="mxit-titlebar h-9 flex items-center px-3 gap-2 shrink-0">
        <button
          onClick={() => { sfx.tap(); navigate('/tradepost'); }}
          className="text-[11px] px-2 py-0.5 rounded-sm bg-white/10 border border-white/20 flex items-center gap-1"
        >
          <ChevronLeft className="w-3 h-3" /> Back
        </button>
        <div className="flex-1 text-center font-semibold text-[15px] tracking-wide flex items-center justify-center gap-2">
          <Heart className="w-4 h-4 text-pink-300" /> Meet People
        </div>
        <Sparkles className="w-4 h-4 opacity-60" />
      </div>

      <div className="relative flex-1 overflow-y-auto mxit-watermark min-h-0">
        <div className="relative z-10 p-3 space-y-3">
          {/* Opt-in card */}
          <div className="rounded-md border border-white/20 bg-white/5 p-3 text-white">
            <div className="flex items-center justify-between gap-2">
              <div className="text-sm font-semibold flex items-center gap-2">
                <Heart className={`w-4 h-4 ${profile?.meet_opt_in ? 'text-pink-300' : 'text-white/40'}`} />
                {profile?.meet_opt_in ? 'You\'re in the Meet zone' : 'Join the Meet zone'}
              </div>
              <Button size="sm" variant={profile?.meet_opt_in ? 'secondary' : 'default'} onClick={toggleOptIn} className="h-7 text-[11px]">
                {profile?.meet_opt_in ? 'Hide me' : 'Show me'}
              </Button>
            </div>
            {profile?.meet_opt_in && (
              <div className="mt-2">
                {editingBio ? (
                  <div className="space-y-2">
                    <Textarea
                      value={bio}
                      onChange={(e) => setBio(e.target.value)}
                      maxLength={240}
                      placeholder="A short bio so people know what you're about…"
                      className="text-sm bg-white/10 border-white/20 text-white placeholder:text-white/40"
                      rows={2}
                    />
                    <div className="flex gap-2 justify-end">
                      <Button size="sm" variant="ghost" className="h-7 text-[11px] text-white/70" onClick={() => { setBio(profile.meet_bio ?? ''); setEditingBio(false); }}>Cancel</Button>
                      <Button size="sm" className="h-7 text-[11px]" onClick={saveBio}>Save</Button>
                    </div>
                  </div>
                ) : (
                  <button
                    onClick={() => setEditingBio(true)}
                    className="w-full text-left text-[12px] text-white/70 italic hover:text-white px-2 py-1 rounded bg-white/5 border border-white/10"
                  >
                    {profile.meet_bio || '+ Add a short bio'}
                  </button>
                )}
              </div>
            )}
          </div>

          {/* Filter */}
          <div className="flex items-center gap-1 text-[11px] text-white/70">
            <Filter className="w-3 h-3" />
            {(['all', 'm', 'f', 'other'] as const).map((k) => (
              <button
                key={k}
                onClick={() => { sfx.tap(); setFilter(k); }}
                className={`px-2 py-0.5 rounded ${filter === k ? 'bg-white/20 text-white' : 'bg-white/5'}`}
              >
                {k === 'all' ? 'All' : k === 'm' ? 'Male' : k === 'f' ? 'Female' : 'Other'}
              </button>
            ))}
          </div>

          {/* People grid */}
          {loading && <div className="text-white/60 text-sm text-center py-6">Loading…</div>}
          {!loading && filtered.length === 0 && (
            <div className="text-white/60 text-sm text-center py-6 italic">
              No one here yet. Be the first to opt in!
            </div>
          )}
          <div className="grid grid-cols-2 gap-2">
            {filtered.map((p) => (
              <div key={p.id} className="rounded-md border border-white/20 bg-white/5 p-2 flex flex-col gap-2">
                <button
                  onClick={() => navigate(`/u/${p.mxit_id}`)}
                  className="flex items-center gap-2"
                >
                  <PixelAvatar seed={p.avatar_seed} url={p.avatar_url} size={36} />
                  <div className="flex-1 min-w-0 text-left">
                    <div className="text-[12px] text-white font-semibold truncate">{p.display_name}</div>
                    <div className="text-[10px] text-white/60">
                      {p.age ? `${p.age} · ` : ''}{p.gender || 'no gender set'}
                    </div>
                  </div>
                </button>
                {p.meet_bio && (
                  <div className="text-[11px] text-white/70 italic line-clamp-2">{p.meet_bio}</div>
                )}
                {p.mood && (
                  <div className="text-[10px] text-white/50 truncate">😊 {p.mood}</div>
                )}
                <Button size="sm" className="h-7 text-[11px] gap-1" onClick={() => sayHi(p)}>
                  <MessageCircle className="w-3 h-3" /> Say Hi
                </Button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
