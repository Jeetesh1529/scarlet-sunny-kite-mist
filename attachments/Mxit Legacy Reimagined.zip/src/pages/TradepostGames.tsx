/**
 * Tradepost > Games — full nostalgic Mxit games hub.
 * Structure: Categories → Game list → Playable game (or "Coming Soon" stub).
 * Most games cost 1 Moola to play; wins pay 2 Moola.
 */
import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { spendMoola } from '@/lib/moola';
import { sfx } from '@/lib/sfx';
import { toast } from 'sonner';
import {
  Coins, Gamepad2, ChevronRight, Trophy, Users, BookOpen, Brain, Swords, Heart,
  Hash, Hand, Rocket, Crown, Calculator, Spade, Skull, Sparkles, Castle,
  Worm, Grid3x3, Layers,
} from 'lucide-react';

type Category = {
  slug: string;
  name: string;
  icon: React.ComponentType<{ className?: string }>;
  description: string;
  games: GameDef[];
};
type GameDef = {
  slug: string;
  name: string;
  desc: string;
  cost: number;
  icon: React.ComponentType<{ className?: string }>;
  playable: boolean;
};

const CATEGORIES: Category[] = [
  {
    slug: 'multiplayer', name: 'Multiplayer Games', icon: Users,
    description: 'The big classics. Strategy, board & competitive.',
    games: [
      { slug: 'moonbase', name: 'Moonbase', desc: 'Mine resources & build your base', cost: 1, icon: Rocket, playable: true },
      { slug: 'battletrivia', name: 'Battle Trivia', desc: 'Quick-fire trivia battle', cost: 1, icon: Trophy, playable: true },
      { slug: 'chess', name: 'Chess', desc: 'Quick mini-chess vs bot', cost: 1, icon: Crown, playable: true },
      { slug: 'mobiraba', name: 'Mobiraba', desc: 'African board classic', cost: 1, icon: Spade, playable: true },
      { slug: 'rps', name: 'Rock · Paper · Scissors', desc: 'Beat the bot', cost: 1, icon: Hand, playable: true },
    ],
  },
  {
    slug: 'word', name: 'Word Games', icon: BookOpen,
    description: 'Letters, sentences, mystery words.',
    games: [
      { slug: 'tixi', name: 'TiXi', desc: 'Unscramble the anagram', cost: 1, icon: Sparkles, playable: true },
      { slug: 'hangman', name: 'Hangman', desc: 'Guess the mystery word', cost: 1, icon: Skull, playable: true },
      { slug: 'cabango', name: 'Cabango', desc: 'Build a sentence from letters', cost: 1, icon: BookOpen, playable: true },
    ],
  },
  {
    slug: 'brain', name: 'Brain Games', icon: Brain,
    description: 'Trivia, maths and pure logic.',
    games: [
      { slug: 'trivit', name: 'TRIVit', desc: 'General knowledge quiz', cost: 1, icon: Brain, playable: true },
      { slug: 'hangmath', name: 'Hangmath', desc: 'Solve maths against the clock', cost: 1, icon: Calculator, playable: true },
      { slug: 'guess', name: 'Number Guess', desc: 'Guess 1–20 in 5 tries', cost: 1, icon: Hash, playable: true },
    ],
  },
  {
    slug: 'roleplay', name: 'Roleplay Games', icon: Swords,
    description: 'Adventures, kingdoms and survival.',
    games: [
      { slug: 'darkness', name: 'Darkness Falls', desc: 'Survive the Jozi outbreak', cost: 1, icon: Skull, playable: true },
      { slug: 'kingdom', name: 'Kingdom Quest', desc: 'Build & defend your realm', cost: 1, icon: Castle, playable: true },
      { slug: 'ogames', name: 'OGames MMORPG', desc: 'Fleet vs fleet skirmish', cost: 1, icon: Swords, playable: true },
    ],
  },
  {
    slug: 'social', name: 'Social Games', icon: Heart,
    description: 'Meet, judge, battle for clout.',
    games: [
      { slug: 'dating', name: 'Dating Game', desc: 'Pick your match', cost: 1, icon: Heart, playable: true },
      { slug: 'judgeme', name: 'JudgeMe', desc: 'Rate & be rated', cost: 1, icon: Trophy, playable: true },
      { slug: 'profilebattles', name: 'Profile Battles', desc: '1v1 profile showdown', cost: 1, icon: Swords, playable: true },
    ],
  },
  {
    slug: 'arcade', name: 'Arcade Games', icon: Gamepad2,
    description: 'Quick-play classics. Beat your high score.',
    games: [
      { slug: 'snake', name: 'Snake', desc: 'Eat dots, don\u2019t bite yourself', cost: 1, icon: Worm, playable: true },
      { slug: 'connect4', name: 'Connect 4', desc: 'Line up four vs the bot', cost: 1, icon: Grid3x3, playable: true },
      { slug: 'memory', name: 'Memory Match', desc: 'Pair up the emoji cards', cost: 1, icon: Layers, playable: true },
    ],
  },
];

type View =
  | { kind: 'home' }
  | { kind: 'cat'; cat: Category }
  | { kind: 'game'; cat: Category; game: GameDef };

export default function TradepostGames() {
  const { profile, refreshProfile } = useAuth();
  const navigate = useNavigate();
  const [view, setView] = useState<View>({ kind: 'home' });

  const award = async (amount: number, reason: string) => {
    if (!profile || amount <= 0) return;
    const newBal = profile.moola + amount;
    await supabase.from('profiles').update({ moola: newBal }).eq('id', profile.id);
    await supabase.from('moola_transactions').insert({
      user_id: profile.id, amount, reason, type: 'bonus',
      balance_before: profile.moola, balance_after: newBal,
    });
    await refreshProfile();
  };

  const charge = async (amount: number, reason: string) => {
    if (!profile) return false;
    return spendMoola({ userId: profile.id, currentBalance: profile.moola, amount, reason });
  };

  const back = () => {
    sfx.tap();
    if (view.kind === 'game') setView({ kind: 'cat', cat: view.cat });
    else if (view.kind === 'cat') setView({ kind: 'home' });
    else navigate('/tradepost');
  };

  const title =
    view.kind === 'home' ? 'Games' :
    view.kind === 'cat' ? view.cat.name :
    view.game.name;

  return (
    <div className="flex-1 min-h-0 flex flex-col mxit-classic-bg">
      <div className="mxit-titlebar h-9 flex items-center px-3 gap-2 shrink-0">
        <button onClick={back} className="text-[11px] px-2 py-0.5 rounded-sm bg-white/10 border border-white/20">‹ Back</button>
        <div className="flex-1 text-center font-semibold text-[15px] tracking-wide flex items-center justify-center gap-2 truncate">
          <Gamepad2 className="w-4 h-4" /> {title}
        </div>
        <span className="text-[10px] text-amber-200 flex items-center gap-1">
          <Coins className="w-3 h-3" /> {profile?.moola ?? 0}
        </span>
      </div>

      <div className="relative flex-1 overflow-y-auto mxit-watermark min-h-0">
        <div className="relative z-10 p-3">
          {view.kind === 'home' && (
            <>
              <div className="text-[11px] text-white/60 italic mb-2">
                Pick a category. 1 Moola to play, 2 Moola for wins.
              </div>
              {CATEGORIES.map((c) => {
                const Icon = c.icon;
                return (
                  <button
                    key={c.slug}
                    onClick={() => { sfx.tap(); setView({ kind: 'cat', cat: c }); }}
                    className="w-full mb-2 flex items-center gap-3 px-3 py-3 rounded-md bg-white/5 border border-white/15 hover:bg-white/10 active:bg-white/15 text-white"
                  >
                    <Icon className="w-5 h-5 text-amber-200 shrink-0" />
                    <span className="flex-1 text-left min-w-0">
                      <div className="font-semibold text-sm">{c.name}</div>
                      <div className="text-[11px] text-white/60 truncate">{c.description}</div>
                    </span>
                    <span className="text-[10px] text-white/50">{c.games.length}</span>
                    <ChevronRight className="w-4 h-4 text-white/60" />
                  </button>
                );
              })}
            </>
          )}

          {view.kind === 'cat' && (
            <>
              <div className="text-[11px] text-white/60 italic mb-2">{view.cat.description}</div>
              {view.cat.games.map((g) => {
                const Icon = g.icon;
                return (
                  <button
                    key={g.slug}
                    onClick={() => {
                      sfx.tap();
                      if (g.slug === 'moonbase') { navigate('/tradepost/games/moonbase'); return; }
                      setView({ kind: 'game', cat: view.cat, game: g });
                    }}
                    className="w-full mb-2 flex items-center gap-3 px-3 py-3 rounded-md bg-white/5 border border-white/15 hover:bg-white/10 active:bg-white/15 text-white"
                  >
                    <Icon className="w-5 h-5 text-amber-200 shrink-0" />
                    <span className="flex-1 text-left min-w-0">
                      <div className="font-semibold text-sm flex items-center gap-2">
                        {g.name}
                        {!g.playable && <span className="text-[9px] px-1 py-0.5 rounded bg-white/10 text-white/60 uppercase">Soon</span>}
                      </div>
                      <div className="text-[11px] text-white/60 truncate">{g.desc}</div>
                    </span>
                    <span className="text-[10px] text-amber-200 flex items-center gap-0.5">
                      <Coins className="w-3 h-3" /> {g.cost}
                    </span>
                    <ChevronRight className="w-4 h-4 text-white/60" />
                  </button>
                );
              })}
            </>
          )}

          {view.kind === 'game' && (
            <GameRunner
              game={view.game}
              charge={charge}
              award={award}
            />
          )}
        </div>
      </div>

      <div className="mxit-softkeys h-10 flex items-stretch text-sm font-medium shrink-0">
        <button onClick={back} className="flex-1 text-left pl-4 active:bg-black/30">Back</button>
        <button onClick={() => { sfx.tap(); navigate('/'); }} className="flex-1 text-right pr-4 active:bg-black/30">Home</button>
      </div>
    </div>
  );
}

/* ─────────────────────────  GAME RUNNER  ───────────────────────── */

function GameRunner({
  game, charge, award,
}: {
  game: GameDef;
  charge: (amount: number, reason: string) => Promise<boolean>;
  award: (amount: number, reason: string) => Promise<void>;
}) {
  if (!game.playable) {
    const Icon = game.icon;
    return (
      <div className="text-center text-white py-6">
        <Icon className="w-12 h-12 mx-auto text-amber-200" />
        <div className="font-semibold mt-2">{game.name}</div>
        <div className="text-[12px] text-white/60 mt-1 px-4">{game.desc}</div>
        <div className="mt-4 mx-auto max-w-xs rounded-md p-3 bg-white/5 border border-white/15 text-[12px] text-white/70">
          This nostalgic Mxit classic is being rebuilt. Check back soon!
        </div>
      </div>
    );
  }

  switch (game.slug) {
    case 'guess':         return <NumberGuess charge={charge} award={award} />;
    case 'rps':           return <RPS charge={charge} award={award} />;
    case 'hangman':       return <Hangman charge={charge} award={award} />;
    case 'hangmath':      return <Hangmath charge={charge} award={award} />;
    case 'tixi':          return <TiXi charge={charge} award={award} />;
    case 'trivit':        return <Trivia charge={charge} award={award} title="TRIVit" reason="TRIVit" />;
    case 'battletrivia':  return <Trivia charge={charge} award={award} title="Battle Trivia" reason="Battle Trivia" />;
    case 'moonbase':      return <Moonbase charge={charge} award={award} />;
    case 'darkness':      return <DarknessFalls charge={charge} award={award} />;
    case 'dating':        return <DatingGame charge={charge} award={award} />;
    case 'chess':         return <MiniChess charge={charge} award={award} />;
    case 'mobiraba':      return <Mobiraba charge={charge} award={award} />;
    case 'cabango':       return <Cabango charge={charge} award={award} />;
    case 'kingdom':       return <KingdomQuest charge={charge} award={award} />;
    case 'ogames':        return <OGames charge={charge} award={award} />;
    case 'judgeme':       return <JudgeMe charge={charge} award={award} />;
    case 'profilebattles':return <ProfileBattles charge={charge} award={award} />;
    case 'snake':         return <Snake charge={charge} award={award} />;
    case 'connect4':      return <Connect4 charge={charge} award={award} />;
    case 'memory':        return <Memory charge={charge} award={award} />;
    default:              return <div className="text-white/60 text-center py-6">Loading…</div>;
  }
}

/* ─────────────────────────  GAMES  ───────────────────────── */

function NumberGuess({ charge, award }: any) {
  const [target, setTarget] = useState<number | null>(null);
  const [guess, setGuess] = useState('');
  const [tries, setTries] = useState(0);
  const [hint, setHint] = useState('Press Start to play.');

  const start = async () => {
    if (!(await charge(1, 'Game: Number Guess'))) return;
    setTarget(1 + Math.floor(Math.random() * 20));
    setTries(0); setGuess(''); setHint('I picked 1–20. You have 5 tries.');
  };
  const submit = async () => {
    if (target === null) return;
    const n = parseInt(guess, 10);
    if (isNaN(n) || n < 1 || n > 20) { toast.error('Enter 1–20'); return; }
    const t = tries + 1; setTries(t); setGuess('');
    if (n === target) { setHint(`🎉 Correct! It was ${target}. +2 Moola`); await award(2, 'Number Guess win'); setTarget(null); return; }
    if (t >= 5) { setHint(`Out of tries. It was ${target}.`); setTarget(null); return; }
    setHint(n < target ? `Higher than ${n}. ${5 - t} left.` : `Lower than ${n}. ${5 - t} left.`);
  };

  return (
    <div className="space-y-3 text-white">
      <div className="text-center"><Hash className="w-10 h-10 mx-auto text-amber-200" /><div className="text-[11px] text-white/60">Tries: {tries}/5</div></div>
      <div className="rounded-md p-3 bg-white/5 border border-white/15 text-sm text-center">{hint}</div>
      {target !== null ? (
        <div className="flex gap-2">
          <input type="number" min={1} max={20} value={guess}
            onChange={(e) => setGuess(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && submit()}
            className="flex-1 px-3 py-2 rounded-md bg-white/10 border border-white/20 text-white text-center text-lg" placeholder="?" />
          <button onClick={submit} className="px-4 rounded-md bg-amber-300/20 border border-amber-300/40 text-white">Guess</button>
        </div>
      ) : (
        <button onClick={start} className="w-full rounded-md py-2 bg-amber-300/15 border border-amber-300/40 text-white">Start — 1 Moola</button>
      )}
    </div>
  );
}

function RPS({ charge, award }: any) {
  const [r, setR] = useState<{ you: string; cpu: string; outcome: 'win' | 'loss' | 'draw' } | null>(null);
  const emoji = (m: string) => m === 'rock' ? '✊' : m === 'paper' ? '✋' : '✌️';
  const play = async (you: string) => {
    if (!(await charge(1, 'Game: RPS'))) return;
    const moves = ['rock', 'paper', 'scissors'];
    const cpu = moves[Math.floor(Math.random() * 3)];
    let outcome: 'win' | 'loss' | 'draw' = 'draw';
    if (you !== cpu) outcome = (you === 'rock' && cpu === 'scissors') || (you === 'paper' && cpu === 'rock') || (you === 'scissors' && cpu === 'paper') ? 'win' : 'loss';
    setR({ you, cpu, outcome });
    if (outcome === 'win') await award(2, 'RPS win');
    if (outcome === 'draw') await award(1, 'RPS draw refund');
  };
  return (
    <div className="space-y-3 text-white text-center">
      <Hand className="w-10 h-10 mx-auto text-amber-200" />
      {!r ? (
        <div className="grid grid-cols-3 gap-2">
          {['rock', 'paper', 'scissors'].map((m) => (
            <button key={m} onClick={() => play(m)} className="aspect-square rounded-md bg-white/5 border border-white/15 hover:bg-white/10 text-4xl">{emoji(m)}</button>
          ))}
        </div>
      ) : (
        <>
          <div className="flex items-center justify-around text-5xl py-3">
            <div><div>{emoji(r.you)}</div><div className="text-[10px] text-white/60 uppercase mt-1">You</div></div>
            <div className="text-white/40 text-2xl">vs</div>
            <div><div>{emoji(r.cpu)}</div><div className="text-[10px] text-white/60 uppercase mt-1">Bot</div></div>
          </div>
          <div className={`rounded-md p-3 border ${r.outcome === 'win' ? 'bg-emerald-500/15 border-emerald-400/40' : r.outcome === 'loss' ? 'bg-rose-500/15 border-rose-400/40' : 'bg-white/5 border-white/15'}`}>
            <div className="font-semibold">{r.outcome === 'win' ? 'You win! +2 Moola' : r.outcome === 'loss' ? 'Bot wins.' : 'Draw — 1M refunded'}</div>
          </div>
          <button onClick={() => setR(null)} className="w-full rounded-md py-2 bg-amber-300/15 border border-amber-300/40 text-white">Play again — 1 Moola</button>
        </>
      )}
    </div>
  );
}

const HANGMAN_WORDS = ['MOOLA', 'TRADEPOST', 'EMOTICARD', 'SOUTHAFRICA', 'MOONBASE', 'CHATROOM', 'JOHANNESBURG', 'DURBAN', 'CAPETOWN', 'NOSTALGIA', 'KINGDOM', 'CABANGO'];
function Hangman({ charge, award }: any) {
  const [word, setWord] = useState<string | null>(null);
  const [guessed, setGuessed] = useState<string[]>([]);
  const [wrong, setWrong] = useState(0);

  const start = async () => {
    if (!(await charge(1, 'Game: Hangman'))) return;
    setWord(HANGMAN_WORDS[Math.floor(Math.random() * HANGMAN_WORDS.length)]);
    setGuessed([]); setWrong(0);
  };
  const pick = async (l: string) => {
    if (!word || guessed.includes(l)) return;
    sfx.tap();
    const ng = [...guessed, l]; setGuessed(ng);
    if (!word.includes(l)) {
      const w = wrong + 1; setWrong(w);
      if (w >= 6) { toast.error(`Hung! Word was ${word}`); setWord(null); }
    } else {
      const won = word.split('').every((c) => ng.includes(c));
      if (won) { toast.success('You saved them! +2 Moola'); await award(2, 'Hangman win'); setWord(null); }
    }
  };
  const display = word ? word.split('').map((c) => guessed.includes(c) ? c : '_').join(' ') : '— — —';
  const stick = ['😀', '😐', '😟', '😣', '😵', '💀', '☠️'][Math.min(wrong, 6)];

  return (
    <div className="space-y-3 text-white text-center">
      <div className="text-5xl">{stick}</div>
      <div className="text-[11px] text-white/60">Wrong: {wrong}/6</div>
      <div className="rounded-md p-3 bg-white/5 border border-white/15 text-xl tracking-[0.4em] font-mono">{display}</div>
      {word ? (
        <div className="grid grid-cols-7 gap-1">
          {'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('').map((l) => (
            <button key={l} disabled={guessed.includes(l)} onClick={() => pick(l)}
              className="aspect-square text-xs rounded bg-white/10 border border-white/20 disabled:opacity-30 active:bg-white/20">{l}</button>
          ))}
        </div>
      ) : (
        <button onClick={start} className="w-full rounded-md py-2 bg-amber-300/15 border border-amber-300/40 text-white">Start — 1 Moola</button>
      )}
    </div>
  );
}

function Hangmath({ charge, award }: any) {
  const [q, setQ] = useState<{ a: number; b: number; op: string; ans: number } | null>(null);
  const [val, setVal] = useState(''); const [streak, setStreak] = useState(0); const [time, setTime] = useState(0);

  const newQ = () => {
    const ops = ['+', '−', '×']; const op = ops[Math.floor(Math.random() * 3)];
    const a = 1 + Math.floor(Math.random() * (op === '×' ? 12 : 50));
    const b = 1 + Math.floor(Math.random() * (op === '×' ? 12 : 50));
    const ans = op === '+' ? a + b : op === '−' ? a - b : a * b;
    setQ({ a, b, op, ans }); setVal('');
  };
  useEffect(() => {
    if (!q || time <= 0) return;
    const t = setTimeout(() => setTime(time - 1), 1000);
    return () => clearTimeout(t);
  }, [q, time]);
  useEffect(() => {
    if (q && time === 0) { toast.error(`Time! Streak: ${streak}`); setQ(null); }
  }, [time, q, streak]);

  const start = async () => {
    if (!(await charge(1, 'Game: Hangmath'))) return;
    setStreak(0); setTime(60); newQ();
  };
  const submit = async () => {
    if (!q) return;
    const n = parseInt(val, 10);
    if (n === q.ans) {
      const s = streak + 1; setStreak(s);
      if (s === 5) { await award(2, 'Hangmath streak 5'); toast.success('Streak 5! +2 Moola'); }
      newQ();
    } else { sfx.error(); toast.error(`Wrong, was ${q.ans}`); setQ(null); }
  };

  return (
    <div className="space-y-3 text-white text-center">
      <Calculator className="w-10 h-10 mx-auto text-amber-200" />
      <div className="flex justify-around text-[11px] text-white/60"><span>Streak: {streak}</span><span>Time: {time}s</span></div>
      {q ? (
        <>
          <div className="text-3xl font-mono py-3">{q.a} {q.op} {q.b} = ?</div>
          <div className="flex gap-2">
            <input type="number" value={val} onChange={(e) => setVal(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && submit()}
              className="flex-1 px-3 py-2 rounded-md bg-white/10 border border-white/20 text-white text-center text-lg" />
            <button onClick={submit} className="px-4 rounded-md bg-amber-300/20 border border-amber-300/40">OK</button>
          </div>
        </>
      ) : (
        <button onClick={start} className="w-full rounded-md py-2 bg-amber-300/15 border border-amber-300/40 text-white">Start — 1 Moola · Reach streak 5 = +2M</button>
      )}
    </div>
  );
}

const TIXI_WORDS = ['MOOLA', 'CHATROOM', 'EMOTICARD', 'KINGDOM', 'SAFARI', 'BRAAI', 'BILTONG', 'RAINBOW', 'MOUNTAIN', 'TABLEBAY'];
function TiXi({ charge, award }: any) {
  const [word, setWord] = useState<string | null>(null);
  const [scrambled, setScrambled] = useState('');
  const [val, setVal] = useState('');

  const start = async () => {
    if (!(await charge(1, 'Game: TiXi'))) return;
    const w = TIXI_WORDS[Math.floor(Math.random() * TIXI_WORDS.length)];
    setWord(w); setVal('');
    setScrambled(w.split('').sort(() => Math.random() - 0.5).join(''));
  };
  const submit = async () => {
    if (!word) return;
    if (val.toUpperCase() === word) { toast.success('Sharp! +2 Moola'); await award(2, 'TiXi win'); setWord(null); }
    else { sfx.error(); toast.error(`Was ${word}`); setWord(null); }
  };
  return (
    <div className="space-y-3 text-white text-center">
      <Sparkles className="w-10 h-10 mx-auto text-amber-200" />
      <div className="text-[11px] text-white/60">Unscramble the word</div>
      {word ? (
        <>
          <div className="text-3xl tracking-[0.3em] font-mono py-3">{scrambled}</div>
          <div className="flex gap-2">
            <input value={val} onChange={(e) => setVal(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && submit()}
              className="flex-1 px-3 py-2 rounded-md bg-white/10 border border-white/20 text-white text-center uppercase" />
            <button onClick={submit} className="px-4 rounded-md bg-amber-300/20 border border-amber-300/40">OK</button>
          </div>
        </>
      ) : (
        <button onClick={start} className="w-full rounded-md py-2 bg-amber-300/15 border border-amber-300/40">Start — 1 Moola</button>
      )}
    </div>
  );
}

const TRIVIA_QS = [
  { q: 'Capital of South Africa (executive)?', a: ['Pretoria', 'Cape Town', 'Durban', 'Johannesburg'], c: 0 },
  { q: 'Mxit was created in which country?', a: ['South Africa', 'Kenya', 'India', 'USA'], c: 0 },
  { q: 'Currency of Mxit Tradepost?', a: ['Moola', 'Rands', 'Coins', 'Gems'], c: 0 },
  { q: 'Largest planet in our solar system?', a: ['Jupiter', 'Saturn', 'Earth', 'Mars'], c: 0 },
  { q: 'Who painted the Mona Lisa?', a: ['Da Vinci', 'Picasso', 'Van Gogh', 'Monet'], c: 0 },
  { q: 'H2O is the formula for?', a: ['Water', 'Salt', 'Oxygen', 'Acid'], c: 0 },
  { q: 'Mandela was president from?', a: ['1994', '1990', '1999', '1985'], c: 0 },
  { q: 'How many continents?', a: ['7', '5', '6', '8'], c: 0 },
];
function Trivia({ charge, award, title, reason }: any) {
  const [round, setRound] = useState<{ idx: number; score: number; qs: typeof TRIVIA_QS } | null>(null);

  const start = async () => {
    if (!(await charge(1, `Game: ${reason}`))) return;
    const qs = [...TRIVIA_QS].sort(() => Math.random() - 0.5).slice(0, 5).map((x) => {
      const c = x.a[x.c]; const a = [...x.a].sort(() => Math.random() - 0.5);
      return { ...x, a, c: a.indexOf(c) };
    });
    setRound({ idx: 0, score: 0, qs });
  };
  const pick = async (i: number) => {
    if (!round) return;
    sfx.tap();
    const correct = i === round.qs[round.idx].c;
    const score = round.score + (correct ? 1 : 0);
    if (round.idx + 1 >= round.qs.length) {
      if (score >= 4) { await award(2, `${reason} win`); toast.success(`${score}/5 — +2 Moola!`); }
      else if (score >= 3) { await award(1, `${reason} consolation`); toast.success(`${score}/5 — +1 Moola`); }
      else toast(`${score}/5 — try again!`);
      setRound(null);
    } else setRound({ ...round, idx: round.idx + 1, score });
  };
  return (
    <div className="space-y-3 text-white text-center">
      <Trophy className="w-10 h-10 mx-auto text-amber-200" />
      <div className="font-semibold">{title}</div>
      {round ? (
        <>
          <div className="text-[11px] text-white/60">Q {round.idx + 1}/5 · Score {round.score}</div>
          <div className="rounded-md p-3 bg-white/5 border border-white/15 text-sm font-medium">{round.qs[round.idx].q}</div>
          <div className="grid grid-cols-1 gap-2">
            {round.qs[round.idx].a.map((opt, i) => (
              <button key={i} onClick={() => pick(i)} className="px-3 py-2 rounded-md bg-white/10 border border-white/20 hover:bg-white/15 text-left text-sm">{opt}</button>
            ))}
          </div>
        </>
      ) : (
        <button onClick={start} className="w-full rounded-md py-2 bg-amber-300/15 border border-amber-300/40">Start — 1 Moola · 4/5 = +2M</button>
      )}
    </div>
  );
}

function Moonbase({ charge, award }: any) {
  const [active, setActive] = useState(false);
  const [res, setRes] = useState({ oxygen: 0, water: 0, iron: 0, helium: 0 });
  const [time, setTime] = useState(60);
  useEffect(() => {
    if (!active) return;
    if (time <= 0) {
      const total = res.oxygen + res.water + res.iron + res.helium;
      if (total >= 30) { award(2, 'Moonbase production'); toast.success(`Produced ${total} units! +2 Moola`); }
      else toast(`Only ${total} units. Need 30 for bonus.`);
      setActive(false); return;
    }
    const t = setTimeout(() => setTime(time - 1), 1000);
    return () => clearTimeout(t);
  }, [active, time, res, award]);

  const start = async () => {
    if (!(await charge(1, 'Game: Moonbase'))) return;
    setRes({ oxygen: 0, water: 0, iron: 0, helium: 0 }); setTime(60); setActive(true);
  };
  const mine = (k: keyof typeof res) => { sfx.tap(); setRes({ ...res, [k]: res[k] + 1 }); };

  return (
    <div className="space-y-3 text-white text-center">
      <Rocket className="w-10 h-10 mx-auto text-amber-200" />
      <div className="font-semibold">Moonbase</div>
      <div className="text-[11px] text-white/60">Tap to mine — gather 30+ units in 60s for +2 Moola</div>
      {active ? (
        <>
          <div className="text-amber-200 font-mono">⏱ {time}s</div>
          <div className="grid grid-cols-2 gap-2">
            {(['oxygen', 'water', 'iron', 'helium'] as const).map((k) => (
              <button key={k} onClick={() => mine(k)} className="rounded-md p-3 bg-white/5 border border-white/15 active:bg-white/15">
                <div className="text-xs uppercase text-white/60">{k}</div>
                <div className="text-2xl font-bold">{res[k]}</div>
              </button>
            ))}
          </div>
        </>
      ) : (
        <button onClick={start} className="w-full rounded-md py-2 bg-amber-300/15 border border-amber-300/40">Launch — 1 Moola</button>
      )}
    </div>
  );
}

const DARKNESS_NODES: Record<string, { text: string; choices?: { label: string; next: string }[]; end?: 'win' | 'loss' }> = {
  start: { text: 'Jozi, 02:14. Sirens. The outbreak began. You wake in a Hillbrow flat. The door rattles.', choices: [{ label: 'Open the door', next: 'door' }, { label: 'Hide under the bed', next: 'hide' }] },
  door: { text: 'A neighbour, bleeding. He grabs you — bitten. You pull away.', choices: [{ label: 'Run for the stairs', next: 'stairs' }, { label: 'Lock yourself in the bathroom', next: 'bath' }] },
  hide: { text: 'They burst in, sniff around, leave. You wait an hour, then sneak to the rooftop.', choices: [{ label: 'Climb to the next building', next: 'roof' }, { label: 'Signal a chopper', next: 'chopper' }] },
  stairs: { text: 'You sprint down 14 floors. Outside, a taxi waits.', choices: [{ label: 'Jump in', next: 'win' }, { label: 'Check the boot first', next: 'loss' }] },
  bath: { text: 'They claw at the door for hours. By dawn, silence — but no escape.', end: 'loss' },
  roof: { text: 'You leap. You make it. You find a survivors’ camp.', end: 'win' },
  chopper: { text: 'The chopper sees you — and the horde you just lit up.', end: 'loss' },
  win: { text: '🎉 You escaped Jozi alive. +2 Moola.', end: 'win' },
  loss: { text: '💀 The outbreak claimed you.', end: 'loss' },
};
function DarknessFalls({ charge, award }: any) {
  const [node, setNode] = useState<string | null>(null);
  const cur = node ? DARKNESS_NODES[node] : null;

  const start = async () => {
    if (!(await charge(1, 'Game: Darkness Falls'))) return;
    setNode('start');
  };
  useEffect(() => {
    if (cur?.end === 'win') award(2, 'Darkness Falls survival');
  }, [cur, award]);

  return (
    <div className="space-y-3 text-white text-center">
      <Skull className="w-10 h-10 mx-auto text-amber-200" />
      <div className="font-semibold">Darkness Falls: Jozi Outbreak</div>
      {cur ? (
        <>
          <div className="rounded-md p-3 bg-white/5 border border-white/15 text-sm text-left">{cur.text}</div>
          {cur.choices ? cur.choices.map((c, i) => (
            <button key={i} onClick={() => { sfx.tap(); setNode(c.next); }} className="w-full px-3 py-2 rounded-md bg-white/10 border border-white/20 hover:bg-white/15 text-sm">{c.label}</button>
          )) : (
            <button onClick={() => setNode(null)} className="w-full rounded-md py-2 bg-amber-300/15 border border-amber-300/40">Restart — 1 Moola</button>
          )}
        </>
      ) : (
        <button onClick={start} className="w-full rounded-md py-2 bg-amber-300/15 border border-amber-300/40">Begin — 1 Moola</button>
      )}
    </div>
  );
}

const DATES = [
  { name: 'Thandi, 22', a1: 'Beach picnic with biltong', a2: 'Sunset at Table Mountain', a3: 'Movies & popcorn', best: 1 },
  { name: 'Sipho, 25', a1: 'Loud club in Newtown', a2: 'Live jazz in Maboneng', a3: 'Stay home & game', best: 1 },
  { name: 'Lerato, 24', a1: 'Walk along Durban beach', a2: 'Fancy sushi spot', a3: 'Skydiving!', best: 0 },
  { name: 'Johan, 27', a1: 'Braai with friends', a2: 'Quiet wine farm', a3: 'Concert in Joburg', best: 1 },
];
function DatingGame({ charge, award }: any) {
  const [d, setD] = useState<typeof DATES[0] | null>(null);
  const [result, setResult] = useState<string | null>(null);

  const start = async () => {
    if (!(await charge(1, 'Game: Dating'))) return;
    setD(DATES[Math.floor(Math.random() * DATES.length)]); setResult(null);
  };
  const pick = async (i: number) => {
    if (!d) return;
    sfx.tap();
    if (i === d.best) { await award(2, 'Dating Game match'); setResult(`💖 ${d.name} loved it! +2 Moola`); }
    else setResult(`💔 ${d.name} wasn’t feeling it.`);
  };

  return (
    <div className="space-y-3 text-white text-center">
      <Heart className="w-10 h-10 mx-auto text-amber-200" />
      <div className="font-semibold">Dating Game</div>
      {d && !result ? (
        <>
          <div className="rounded-md p-3 bg-white/5 border border-white/15 text-sm">
            <div className="font-semibold text-amber-200">{d.name}</div>
            <div className="text-white/70 text-[12px] mt-1">Pick the perfect date idea:</div>
          </div>
          {[d.a1, d.a2, d.a3].map((opt, i) => (
            <button key={i} onClick={() => pick(i)} className="w-full px-3 py-2 rounded-md bg-white/10 border border-white/20 hover:bg-white/15 text-sm">{opt}</button>
          ))}
        </>
      ) : result ? (
        <>
          <div className="rounded-md p-3 bg-white/5 border border-white/15 text-sm">{result}</div>
          <button onClick={start} className="w-full rounded-md py-2 bg-amber-300/15 border border-amber-300/40">Try again — 1 Moola</button>
        </>
      ) : (
        <button onClick={start} className="w-full rounded-md py-2 bg-amber-300/15 border border-amber-300/40">Find a date — 1 Moola</button>
      )}
    </div>
  );
}

/* ─────────────────────────  NEW GAMES  ───────────────────────── */

// Mini-Chess: tap-to-capture puzzle. 4 white pieces vs 1 black king on 5x5.
// Capture the king in <=N moves to win. Simple but functional.
function MiniChess({ charge, award }: any) {
  type Cell = null | { p: 'K' | 'R' | 'B' | 'N' | 'P'; side: 'w' | 'b' };
  const start0 = (): Cell[][] => {
    const g: Cell[][] = Array.from({ length: 5 }, () => Array(5).fill(null));
    g[4][0] = { p: 'R', side: 'w' };
    g[4][2] = { p: 'B', side: 'w' };
    g[4][4] = { p: 'N', side: 'w' };
    g[3][2] = { p: 'P', side: 'w' };
    g[0][2] = { p: 'K', side: 'b' };
    return g;
  };
  const [grid, setGrid] = useState<Cell[][] | null>(null);
  const [sel, setSel] = useState<[number, number] | null>(null);
  const [moves, setMoves] = useState(0);

  const moves_for = (g: Cell[][], r: number, c: number): [number, number][] => {
    const cell = g[r][c]; if (!cell) return [];
    const out: [number, number][] = [];
    const inB = (r: number, c: number) => r >= 0 && r < 5 && c >= 0 && c < 5;
    const ray = (dr: number, dc: number) => {
      let nr = r + dr, nc = c + dc;
      while (inB(nr, nc)) {
        if (!g[nr][nc]) out.push([nr, nc]);
        else { if (g[nr][nc]!.side !== cell.side) out.push([nr, nc]); break; }
        nr += dr; nc += dc;
      }
    };
    if (cell.p === 'R') { ray(1,0); ray(-1,0); ray(0,1); ray(0,-1); }
    if (cell.p === 'B') { ray(1,1); ray(1,-1); ray(-1,1); ray(-1,-1); }
    if (cell.p === 'N') {
      [[-2,-1],[-2,1],[2,-1],[2,1],[-1,-2],[-1,2],[1,-2],[1,2]].forEach(([dr,dc]) => {
        const nr=r+dr,nc=c+dc;
        if (inB(nr,nc) && (!g[nr][nc] || g[nr][nc]!.side !== cell.side)) out.push([nr,nc]);
      });
    }
    if (cell.p === 'P') {
      const dr = cell.side === 'w' ? -1 : 1;
      if (inB(r+dr,c) && !g[r+dr][c]) out.push([r+dr,c]);
      [[dr,-1],[dr,1]].forEach(([d1,d2]) => {
        const nr=r+d1,nc=c+d2;
        if (inB(nr,nc) && g[nr][nc] && g[nr][nc]!.side !== cell.side) out.push([nr,nc]);
      });
    }
    return out;
  };

  const start = async () => {
    if (!(await charge(1, 'Game: Chess'))) return;
    setGrid(start0()); setSel(null); setMoves(0);
  };

  const tap = async (r: number, c: number) => {
    if (!grid) return;
    sfx.tap();
    const cell = grid[r][c];
    if (sel) {
      const opts = moves_for(grid, sel[0], sel[1]);
      if (opts.some(([a,b]) => a===r && b===c)) {
        const ng = grid.map((row) => row.slice());
        const captured = ng[r][c];
        ng[r][c] = ng[sel[0]][sel[1]]; ng[sel[0]][sel[1]] = null;
        setSel(null);
        const m = moves + 1; setMoves(m);
        if (captured?.p === 'K') {
          if (m <= 6) { await award(2, 'Chess win'); toast.success(`Checkmate in ${m}! +2 Moola`); }
          else toast(`Captured in ${m} — too slow for bonus`);
          setGrid(null); return;
        }
        // Bot: King moves randomly toward closest white piece
        let kr=-1, kc=-1;
        ng.forEach((row, ri) => row.forEach((cc, ci) => { if (cc?.p==='K') { kr=ri; kc=ci; }}));
        if (kr>=0) {
          const kmoves: [number,number][] = [];
          for (let dr=-1; dr<=1; dr++) for (let dc=-1; dc<=1; dc++) {
            if (!dr && !dc) continue;
            const nr=kr+dr, nc=kc+dc;
            if (nr>=0 && nr<5 && nc>=0 && nc<5 && (!ng[nr][nc] || ng[nr][nc]!.side==='w')) kmoves.push([nr,nc]);
          }
          if (kmoves.length) {
            const [nr,nc] = kmoves[Math.floor(Math.random()*kmoves.length)];
            ng[nr][nc] = ng[kr][kc]; ng[kr][kc] = null;
          }
        }
        setGrid(ng);
        if (m >= 12) { toast('Out of moves'); setGrid(null); }
        return;
      }
      setSel(null);
    }
    if (cell?.side === 'w') setSel([r,c]);
  };

  const sym = (cell: Cell) => {
    if (!cell) return '';
    const s = cell.side === 'w' ? { K:'♔', R:'♖', B:'♗', N:'♘', P:'♙' } : { K:'♚', R:'♜', B:'♝', N:'♞', P:'♟' };
    return s[cell.p];
  };

  return (
    <div className="space-y-3 text-white text-center">
      <Crown className="w-10 h-10 mx-auto text-amber-200" />
      <div className="font-semibold">Mini Chess — capture the King</div>
      <div className="text-[11px] text-white/60">≤6 moves = +2 Moola · 12 max</div>
      {grid ? (
        <>
          <div className="text-[11px] text-amber-200">Move {moves}/12</div>
          <div className="inline-grid grid-cols-5 gap-0.5 mx-auto">
            {grid.map((row, r) => row.map((cell, c) => {
              const dark = (r+c) % 2 === 1;
              const isSel = sel && sel[0]===r && sel[1]===c;
              const isOpt = sel && moves_for(grid, sel[0], sel[1]).some(([a,b])=>a===r&&b===c);
              return (
                <button key={`${r}-${c}`} onClick={() => tap(r,c)}
                  className={`w-12 h-12 text-3xl flex items-center justify-center ${dark?'bg-white/10':'bg-white/20'} ${isSel?'ring-2 ring-amber-300':''} ${isOpt?'ring-2 ring-emerald-400':''}`}>
                  {sym(cell)}
                </button>
              );
            }))}
          </div>
        </>
      ) : (
        <button onClick={start} className="w-full rounded-md py-2 bg-amber-300/15 border border-amber-300/40">Start — 1 Moola</button>
      )}
    </div>
  );
}

// Mobiraba: simplified mancala. 6 pits + 1 store per side, 3 stones each.
function Mobiraba({ charge, award }: any) {
  type S = { pits: number[]; turn: 0 | 1; over: boolean };
  const init = (): S => ({ pits: [3,3,3,3,3,3,0, 3,3,3,3,3,3,0], turn: 0, over: false });
  const [s, setS] = useState<S | null>(null);
  // 0..5 player A pits, 6 = A store, 7..12 player B pits, 13 = B store

  const sow = (st: S, idx: number): S => {
    const p = st.pits.slice();
    let stones = p[idx]; p[idx] = 0;
    let i = idx;
    const skip = st.turn === 0 ? 13 : 6;
    while (stones > 0) {
      i = (i + 1) % 14;
      if (i === skip) continue;
      p[i]++; stones--;
    }
    let turn: 0|1 = st.turn === 0 ? 1 : 0;
    if ((st.turn === 0 && i === 6) || (st.turn === 1 && i === 13)) turn = st.turn;
    const aEmpty = p.slice(0,6).every((x) => x === 0);
    const bEmpty = p.slice(7,13).every((x) => x === 0);
    let over = false;
    if (aEmpty || bEmpty) {
      for (let j=0;j<6;j++) { p[6] += p[j]; p[j]=0; p[13] += p[j+7]; p[j+7]=0; }
      over = true;
    }
    return { pits: p, turn, over };
  };

  const start = async () => {
    if (!(await charge(1, 'Game: Mobiraba'))) return;
    setS(init());
  };

  const play = async (idx: number) => {
    if (!s || s.over || s.turn !== 0 || s.pits[idx] === 0) return;
    sfx.tap();
    let next = sow(s, idx);
    setS(next);
    // Bot turns
    while (!next.over && next.turn === 1) {
      await new Promise(r => setTimeout(r, 400));
      const choices: number[] = [];
      for (let j=7;j<13;j++) if (next.pits[j] > 0) choices.push(j);
      if (!choices.length) break;
      const pick = choices[Math.floor(Math.random()*choices.length)];
      next = sow(next, pick);
      setS(next);
    }
    if (next.over) {
      if (next.pits[6] > next.pits[13]) { await award(2, 'Mobiraba win'); toast.success(`You ${next.pits[6]} - ${next.pits[13]} Bot. +2 Moola`); }
      else if (next.pits[6] === next.pits[13]) { await award(1, 'Mobiraba draw'); toast(`Draw ${next.pits[6]}-${next.pits[13]} — 1M back`); }
      else toast(`Lost ${next.pits[6]}-${next.pits[13]}`);
    }
  };

  return (
    <div className="space-y-3 text-white text-center">
      <Spade className="w-10 h-10 mx-auto text-amber-200" />
      <div className="font-semibold">Mobiraba</div>
      <div className="text-[11px] text-white/60">Tap your row (bottom). More stones in your store wins.</div>
      {s ? (
        <div className="space-y-1">
          <div className="text-[11px] text-amber-200">{s.over ? 'Game over' : s.turn === 0 ? 'Your turn' : 'Bot…'}</div>
          {/* Bot row reversed visually */}
          <div className="flex items-center gap-1 justify-center">
            <div className="w-10 h-16 rounded bg-white/15 border border-white/20 flex items-center justify-center text-lg font-bold">{s.pits[13]}</div>
            <div className="flex gap-1">
              {[12,11,10,9,8,7].map((i) => (
                <div key={i} className="w-9 h-9 rounded-full bg-white/10 border border-white/20 flex items-center justify-center text-sm">{s.pits[i]}</div>
              ))}
            </div>
            <div className="w-10 h-16" />
          </div>
          <div className="flex items-center gap-1 justify-center">
            <div className="w-10 h-16" />
            <div className="flex gap-1">
              {[0,1,2,3,4,5].map((i) => (
                <button key={i} onClick={() => play(i)} disabled={s.over || s.turn!==0 || s.pits[i]===0}
                  className="w-9 h-9 rounded-full bg-amber-300/20 border border-amber-300/40 disabled:opacity-30 text-sm">{s.pits[i]}</button>
              ))}
            </div>
            <div className="w-10 h-16 rounded bg-amber-300/30 border border-amber-300/50 flex items-center justify-center text-lg font-bold">{s.pits[6]}</div>
          </div>
          {s.over && <button onClick={() => setS(null)} className="w-full rounded-md py-2 bg-amber-300/15 border border-amber-300/40">Done</button>}
        </div>
      ) : (
        <button onClick={start} className="w-full rounded-md py-2 bg-amber-300/15 border border-amber-300/40">Start — 1 Moola</button>
      )}
    </div>
  );
}

// Cabango: build a sentence from a word bank, in a target order.
const CABANGO_ROUNDS = [
  { words: ['THE', 'DOG', 'CHASES', 'A', 'CAT'], target: 'THE DOG CHASES A CAT' },
  { words: ['MOOLA', 'IS', 'THE', 'BEST', 'CURRENCY'], target: 'MOOLA IS THE BEST CURRENCY' },
  { words: ['I', 'LOVE', 'OLD', 'SCHOOL', 'MXIT'], target: 'I LOVE OLD SCHOOL MXIT' },
  { words: ['MEET', 'ME', 'AT', 'THE', 'TRADEPOST'], target: 'MEET ME AT THE TRADEPOST' },
];
function Cabango({ charge, award }: any) {
  const [round, setRound] = useState<{ pool: string[]; picked: string[]; target: string } | null>(null);

  const start = async () => {
    if (!(await charge(1, 'Game: Cabango'))) return;
    const r = CABANGO_ROUNDS[Math.floor(Math.random()*CABANGO_ROUNDS.length)];
    setRound({ pool: [...r.words].sort(() => Math.random()-0.5), picked: [], target: r.target });
  };
  const pick = (w: string, i: number) => {
    if (!round) return; sfx.tap();
    const pool = round.pool.slice(); pool.splice(i,1);
    setRound({ ...round, pool, picked: [...round.picked, w] });
  };
  const undo = () => {
    if (!round || !round.picked.length) return;
    const picked = round.picked.slice(); const w = picked.pop()!;
    setRound({ ...round, pool: [...round.pool, w], picked });
  };
  const submit = async () => {
    if (!round) return;
    if (round.picked.join(' ') === round.target) { await award(2, 'Cabango win'); toast.success('Sentence! +2 Moola'); }
    else { sfx.error(); toast.error(`Was: ${round.target}`); }
    setRound(null);
  };

  return (
    <div className="space-y-3 text-white text-center">
      <BookOpen className="w-10 h-10 mx-auto text-amber-200" />
      <div className="font-semibold">Cabango — build the sentence</div>
      {round ? (
        <>
          <div className="rounded-md p-3 bg-white/5 border border-white/15 min-h-[3rem] text-sm">{round.picked.join(' ') || '…'}</div>
          <div className="flex flex-wrap gap-2 justify-center">
            {round.pool.map((w, i) => (
              <button key={`${w}-${i}`} onClick={() => pick(w, i)} className="px-3 py-1 rounded bg-white/10 border border-white/20">{w}</button>
            ))}
          </div>
          <div className="flex gap-2">
            <button onClick={undo} className="flex-1 py-2 rounded bg-white/10 border border-white/20">Undo</button>
            <button onClick={submit} disabled={round.pool.length>0} className="flex-1 py-2 rounded bg-amber-300/20 border border-amber-300/40 disabled:opacity-30">Submit</button>
          </div>
        </>
      ) : (
        <button onClick={start} className="w-full rounded-md py-2 bg-amber-300/15 border border-amber-300/40">Start — 1 Moola</button>
      )}
    </div>
  );
}

// Kingdom Quest: 5-turn resource manage. Build farms, soldiers; survive raids.
function KingdomQuest({ charge, award }: any) {
  type K = { gold: number; food: number; army: number; turn: number; log: string[] };
  const [k, setK] = useState<K | null>(null);

  const start = async () => {
    if (!(await charge(1, 'Game: Kingdom Quest'))) return;
    setK({ gold: 5, food: 5, army: 1, turn: 1, log: ['Your kingdom rises.'] });
  };

  const act = async (a: 'farm' | 'army' | 'tax') => {
    if (!k) return;
    let { gold, food, army, turn, log } = k;
    if (a === 'farm') { if (gold < 2) { toast.error('Need 2 gold'); return; } gold -= 2; food += 4; log = [...log, 'Built a farm (+4 food).']; }
    if (a === 'army') { if (gold < 3 || food < 2) { toast.error('Need 3g, 2f'); return; } gold -= 3; food -= 2; army += 2; log = [...log, 'Recruited 2 soldiers.']; }
    if (a === 'tax')  { gold += 3; food -= 1; log = [...log, 'Taxed peasants (+3g, -1f).']; }
    // Raid each turn
    const raidStrength = 1 + Math.floor(Math.random() * (turn + 1));
    if (army >= raidStrength) {
      log = [...log, `Turn ${turn}: raid of ${raidStrength} crushed.`];
    } else {
      const lost = raidStrength - army;
      gold = Math.max(0, gold - lost*2); army = 0;
      log = [...log, `Turn ${turn}: raid of ${raidStrength} broke through! Lost ${lost*2}g.`];
    }
    if (food < 0) { gold = Math.max(0, gold - 2); food = 0; log = [...log, 'Famine! -2g']; }
    turn++;
    if (turn > 5) {
      const score = gold + food + army*3;
      log = [...log, `Final score: ${score}`];
      if (score >= 20) { await award(2, 'Kingdom Quest win'); toast.success(`Mighty kingdom! +2 Moola`); }
      else toast(`Realm fades. Score ${score}`);
      setK({ gold, food, army, turn, log });
      setTimeout(() => setK(null), 2500);
      return;
    }
    setK({ gold, food, army, turn, log });
  };

  return (
    <div className="space-y-3 text-white text-center">
      <Castle className="w-10 h-10 mx-auto text-amber-200" />
      <div className="font-semibold">Kingdom Quest</div>
      {k ? (
        <>
          <div className="grid grid-cols-4 gap-2 text-[11px]">
            <div className="rounded bg-white/5 border border-white/15 p-2"><div className="text-white/60">Turn</div><div className="text-lg font-bold">{k.turn}/5</div></div>
            <div className="rounded bg-white/5 border border-white/15 p-2"><div className="text-white/60">Gold</div><div className="text-lg font-bold">{k.gold}</div></div>
            <div className="rounded bg-white/5 border border-white/15 p-2"><div className="text-white/60">Food</div><div className="text-lg font-bold">{k.food}</div></div>
            <div className="rounded bg-white/5 border border-white/15 p-2"><div className="text-white/60">Army</div><div className="text-lg font-bold">{k.army}</div></div>
          </div>
          <div className="grid grid-cols-3 gap-2">
            <button onClick={() => act('farm')} className="py-2 rounded bg-emerald-500/20 border border-emerald-400/40 text-xs">Farm<br/><span className="text-white/60">2g→4f</span></button>
            <button onClick={() => act('army')} className="py-2 rounded bg-rose-500/20 border border-rose-400/40 text-xs">Army<br/><span className="text-white/60">3g 2f→+2</span></button>
            <button onClick={() => act('tax')}  className="py-2 rounded bg-amber-300/20 border border-amber-300/40 text-xs">Tax<br/><span className="text-white/60">+3g -1f</span></button>
          </div>
          <div className="rounded p-2 bg-white/5 border border-white/15 text-[11px] text-left max-h-32 overflow-y-auto">
            {k.log.slice(-5).map((l, i) => <div key={i}>· {l}</div>)}
          </div>
        </>
      ) : (
        <button onClick={start} className="w-full rounded-md py-2 bg-amber-300/15 border border-amber-300/40">Begin reign — 1 Moola</button>
      )}
    </div>
  );
}

// OGames: simple fleet skirmish vs bot. Allocate fighters, bombers, shields.
function OGames({ charge, award }: any) {
  const [phase, setPhase] = useState<'idle' | 'pick' | 'result'>('idle');
  const [you, setYou] = useState({ f: 0, b: 0, s: 0 });
  const [result, setResult] = useState<string>('');

  const start = async () => {
    if (!(await charge(1, 'Game: OGames'))) return;
    setYou({ f: 0, b: 0, s: 0 }); setPhase('pick'); setResult('');
  };
  const total = you.f + you.b + you.s;
  const fight = async () => {
    if (total !== 10) { toast.error('Allocate exactly 10 ships'); return; }
    // Bot random allocation summing 10
    const r = [0,0,0]; for (let i=0;i<10;i++) r[Math.floor(Math.random()*3)]++;
    const bot = { f: r[0], b: r[1], s: r[2] };
    // Combat: fighters beat bombers, bombers beat shields, shields beat fighters
    const yScore = you.f * bot.b + you.b * bot.s + you.s * bot.f;
    const bScore = bot.f * you.b + bot.b * you.s + bot.s * you.f;
    let msg = `You: F${you.f} B${you.b} S${you.s}\nBot: F${bot.f} B${bot.b} S${bot.s}\nDamage you ${yScore} - ${bScore} bot.`;
    if (yScore > bScore) { await award(2, 'OGames win'); msg += '\n🚀 Victory! +2 Moola'; }
    else if (yScore === bScore) { await award(1, 'OGames draw'); msg += '\nStalemate — 1M refunded'; }
    else msg += '\n💥 Fleet lost.';
    setResult(msg); setPhase('result');
  };
  const adj = (k: 'f'|'b'|'s', d: number) => {
    const next = { ...you, [k]: Math.max(0, you[k] + d) };
    if (next.f + next.b + next.s > 10) return;
    setYou(next);
  };

  return (
    <div className="space-y-3 text-white text-center">
      <Swords className="w-10 h-10 mx-auto text-amber-200" />
      <div className="font-semibold">OGames Skirmish</div>
      <div className="text-[11px] text-white/60">10 ships. F&gt;B, B&gt;S, S&gt;F.</div>
      {phase === 'pick' && (
        <>
          <div className="text-[11px] text-amber-200">Allocated {total}/10</div>
          {(['f','b','s'] as const).map((k) => (
            <div key={k} className="flex items-center justify-between rounded bg-white/5 border border-white/15 p-2">
              <span className="font-semibold">{k==='f'?'Fighters':k==='b'?'Bombers':'Shields'}</span>
              <div className="flex items-center gap-2">
                <button onClick={() => adj(k,-1)} className="w-8 h-8 rounded bg-white/10 border border-white/20">−</button>
                <span className="w-6 text-center">{you[k]}</span>
                <button onClick={() => adj(k,1)} className="w-8 h-8 rounded bg-white/10 border border-white/20">+</button>
              </div>
            </div>
          ))}
          <button onClick={fight} className="w-full py-2 rounded bg-amber-300/20 border border-amber-300/40">Engage</button>
        </>
      )}
      {phase === 'result' && (
        <>
          <pre className="rounded p-3 bg-white/5 border border-white/15 text-[11px] text-left whitespace-pre-wrap">{result}</pre>
          <button onClick={() => setPhase('idle')} className="w-full py-2 rounded bg-white/10 border border-white/20">Done</button>
        </>
      )}
      {phase === 'idle' && (
        <button onClick={start} className="w-full rounded-md py-2 bg-amber-300/15 border border-amber-300/40">Launch fleet — 1 Moola</button>
      )}
    </div>
  );
}

// JudgeMe: rate 5 fictional profiles; +2M if your taste matches the crowd.
const JUDGE_PROFILES = [
  { name: 'PixelKing92', mood: '“Living on Moola”', vibe: 'classic', crowd: 4 },
  { name: 'durban_diva', mood: '“sushi & sunsets”', vibe: 'fresh', crowd: 5 },
  { name: 'jozi_jay', mood: '“hustle mode”', vibe: 'gritty', crowd: 3 },
  { name: 'BraaiMaster', mood: '“tongs in hand”', vibe: 'iconic', crowd: 5 },
  { name: 'mxit_4ever', mood: '“2008 forever”', vibe: 'nostalgic', crowd: 5 },
];
function JudgeMe({ charge, award }: any) {
  const [round, setRound] = useState<{ idx: number; matches: number } | null>(null);

  const start = async () => {
    if (!(await charge(1, 'Game: JudgeMe'))) return;
    setRound({ idx: 0, matches: 0 });
  };
  const rate = async (n: number) => {
    if (!round) return; sfx.tap();
    const cur = JUDGE_PROFILES[round.idx];
    const matches = round.matches + (Math.abs(n - cur.crowd) <= 1 ? 1 : 0);
    if (round.idx + 1 >= JUDGE_PROFILES.length) {
      if (matches >= 4) { await award(2, 'JudgeMe taste'); toast.success(`On point ${matches}/5! +2 Moola`); }
      else if (matches === 3) { await award(1, 'JudgeMe consolation'); toast(`${matches}/5 — +1M`); }
      else toast(`${matches}/5 — out of touch!`);
      setRound(null);
    } else setRound({ idx: round.idx + 1, matches });
  };

  return (
    <div className="space-y-3 text-white text-center">
      <Trophy className="w-10 h-10 mx-auto text-amber-200" />
      <div className="font-semibold">JudgeMe</div>
      {round ? (
        <>
          <div className="text-[11px] text-white/60">{round.idx+1}/5 · matches {round.matches}</div>
          <div className="rounded p-4 bg-white/5 border border-white/15">
            <div className="font-semibold text-amber-200">{JUDGE_PROFILES[round.idx].name}</div>
            <div className="text-[12px] text-white/70 mt-1">{JUDGE_PROFILES[round.idx].mood}</div>
            <div className="text-[10px] text-white/40 uppercase mt-2">{JUDGE_PROFILES[round.idx].vibe}</div>
          </div>
          <div className="flex gap-1 justify-center">
            {[1,2,3,4,5].map((n) => (
              <button key={n} onClick={() => rate(n)} className="w-10 h-10 rounded bg-white/10 border border-white/20 hover:bg-white/15 text-lg">⭐{n}</button>
            ))}
          </div>
          <div className="text-[10px] text-white/50">Match the crowd (±1) to score</div>
        </>
      ) : (
        <button onClick={start} className="w-full rounded-md py-2 bg-amber-300/15 border border-amber-300/40">Start — 1 Moola</button>
      )}
    </div>
  );
}

// Profile Battles: 5 rounds, pick the stronger profile. Get 4+ correct = +2M.
const BATTLE_PAIRS = [
  { a: { name: 'JoziJay', score: 87 }, b: { name: 'CapeKid', score: 64 }, winner: 0 },
  { a: { name: 'DurbanDee', score: 55 }, b: { name: 'PtaPro', score: 78 }, winner: 1 },
  { a: { name: 'MoolaMike', score: 91 }, b: { name: 'EmoEva', score: 72 }, winner: 0 },
  { a: { name: 'BraaiBoy', score: 60 }, b: { name: 'SushiSue', score: 60 }, winner: 0 },
  { a: { name: 'KingdomK', score: 44 }, b: { name: 'MoonbaseM', score: 88 }, winner: 1 },
  { a: { name: 'TiXiTom', score: 70 }, b: { name: 'HangmanHan', score: 71 }, winner: 1 },
];
function ProfileBattles({ charge, award }: any) {
  const round = useMemo(() => [...BATTLE_PAIRS].sort(() => Math.random()-0.5).slice(0,5), []);
  const [state, setState] = useState<{ idx: number; correct: number } | null>(null);
  const start = async () => {
    if (!(await charge(1, 'Game: Profile Battles'))) return;
    setState({ idx: 0, correct: 0 });
  };
  const pick = async (i: 0 | 1) => {
    if (!state) return; sfx.tap();
    const cur = round[state.idx];
    const correct = state.correct + (i === cur.winner ? 1 : 0);
    if (state.idx + 1 >= round.length) {
      if (correct >= 4) { await award(2, 'Profile Battles win'); toast.success(`${correct}/5 — +2 Moola!`); }
      else toast(`${correct}/5 — try again`);
      setState(null);
    } else setState({ idx: state.idx+1, correct });
  };
  return (
    <div className="space-y-3 text-white text-center">
      <Swords className="w-10 h-10 mx-auto text-amber-200" />
      <div className="font-semibold">Profile Battles</div>
      {state ? (
        <>
          <div className="text-[11px] text-white/60">Round {state.idx+1}/5 · {state.correct} right</div>
          <div className="grid grid-cols-2 gap-2">
            {[round[state.idx].a, round[state.idx].b].map((p, i) => (
              <button key={i} onClick={() => pick(i as 0|1)} className="p-3 rounded bg-white/5 border border-white/15 hover:bg-white/10">
                <div className="font-semibold text-amber-200">{p.name}</div>
                <div className="text-[10px] text-white/60 mt-1">tap to back</div>
              </button>
            ))}
          </div>
          <div className="text-[10px] text-white/40">Pick the stronger profile</div>
        </>
      ) : (
        <button onClick={start} className="w-full rounded-md py-2 bg-amber-300/15 border border-amber-300/40">Start — 1 Moola · 4/5 = +2M</button>
      )}
    </div>
  );
}

/* ─────────────  ARCADE: Snake / Connect4 / Memory  ───────────── */

function Snake({ charge, award }: any) {
  const SIZE = 14;
  const [snake, setSnake] = useState<{ x: number; y: number }[]>([]);
  const [dir, setDir] = useState<{ x: number; y: number }>({ x: 1, y: 0 });
  const [food, setFood] = useState<{ x: number; y: number }>({ x: 5, y: 5 });
  const [alive, setAlive] = useState(false);
  const [score, setScore] = useState(0);
  const tickRef = useRef<number | null>(null);
  const dirRef = useRef(dir);
  dirRef.current = dir;

  const start = async () => {
    if (!(await charge(1, 'Game: Snake'))) return;
    setSnake([{ x: 7, y: 7 }, { x: 6, y: 7 }, { x: 5, y: 7 }]);
    setDir({ x: 1, y: 0 });
    setFood({ x: 10, y: 7 });
    setScore(0); setAlive(true);
  };

  useEffect(() => {
    if (!alive) return;
    const id = window.setInterval(() => {
      setSnake((s) => {
        const head = { x: (s[0].x + dirRef.current.x + SIZE) % SIZE, y: (s[0].y + dirRef.current.y + SIZE) % SIZE };
        if (s.some((p) => p.x === head.x && p.y === head.y)) {
          setAlive(false);
          window.clearInterval(id);
          return s;
        }
        const ate = head.x === food.x && head.y === food.y;
        const next = [head, ...s];
        if (ate) {
          setScore((sc) => sc + 1);
          let nf: { x: number; y: number };
          do { nf = { x: Math.floor(Math.random() * SIZE), y: Math.floor(Math.random() * SIZE) }; }
          while (next.some((p) => p.x === nf.x && p.y === nf.y));
          setFood(nf);
        } else next.pop();
        return next;
      });
    }, 180);
    tickRef.current = id as any;
    return () => window.clearInterval(id);
  }, [alive, food.x, food.y]);

  useEffect(() => {
    if (!alive) return;
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'ArrowUp' && dirRef.current.y !== 1) setDir({ x: 0, y: -1 });
      if (e.key === 'ArrowDown' && dirRef.current.y !== -1) setDir({ x: 0, y: 1 });
      if (e.key === 'ArrowLeft' && dirRef.current.x !== 1) setDir({ x: -1, y: 0 });
      if (e.key === 'ArrowRight' && dirRef.current.x !== -1) setDir({ x: 1, y: 0 });
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [alive]);

  useEffect(() => {
    if (!alive && score > 0) {
      const reward = Math.min(10, Math.ceil(score / 3));
      if (reward > 0) award(reward, `Snake score ${score}`);
    }
  }, [alive]);

  const turn = (x: number, y: number) => {
    if (!alive) return;
    if (x !== 0 && dirRef.current.x === -x) return;
    if (y !== 0 && dirRef.current.y === -y) return;
    setDir({ x, y });
  };

  return (
    <div className="space-y-3 text-white">
      <div className="text-center text-[11px] text-white/60">Score: {score} · Arrow keys / D-pad</div>
      <div className="mx-auto bg-black/40 border border-white/15 rounded-md p-1" style={{ width: 'min(320px, 90vw)' }}>
        <div className="grid" style={{ gridTemplateColumns: `repeat(${SIZE}, 1fr)`, gap: 1 }}>
          {Array.from({ length: SIZE * SIZE }).map((_, i) => {
            const x = i % SIZE, y = Math.floor(i / SIZE);
            const isHead = snake[0]?.x === x && snake[0]?.y === y;
            const isBody = snake.some((p, idx) => idx > 0 && p.x === x && p.y === y);
            const isFood = food.x === x && food.y === y;
            return (
              <div
                key={i}
                className={`aspect-square rounded-sm ${isHead ? 'bg-emerald-400' : isBody ? 'bg-emerald-600' : isFood ? 'bg-amber-300' : 'bg-white/5'}`}
              />
            );
          })}
        </div>
      </div>
      <div className="grid grid-cols-3 gap-1 max-w-[180px] mx-auto">
        <span />
        <button onClick={() => turn(0, -1)} className="py-2 rounded bg-white/10 border border-white/20">▲</button>
        <span />
        <button onClick={() => turn(-1, 0)} className="py-2 rounded bg-white/10 border border-white/20">◀</button>
        <button onClick={() => turn(0, 1)} className="py-2 rounded bg-white/10 border border-white/20">▼</button>
        <button onClick={() => turn(1, 0)} className="py-2 rounded bg-white/10 border border-white/20">▶</button>
      </div>
      {!alive && (
        <button onClick={start} className="w-full rounded-md py-2 bg-amber-300/15 border border-amber-300/40">
          {score > 0 ? `Game over · score ${score}. Play again — 1 Moola` : 'Start — 1 Moola'}
        </button>
      )}
    </div>
  );
}

function Connect4({ charge, award }: any) {
  const ROWS = 6, COLS = 7;
  type Cell = 0 | 1 | 2; // 0 empty, 1 player, 2 bot
  const [board, setBoard] = useState<Cell[][]>(() => Array.from({ length: ROWS }, () => Array<Cell>(COLS).fill(0)));
  const [turn, setTurn] = useState<1 | 2>(1);
  const [active, setActive] = useState(false);
  const [winner, setWinner] = useState<0 | 1 | 2>(0);

  const checkWin = (b: Cell[][], p: Cell): boolean => {
    const dirs = [[0, 1], [1, 0], [1, 1], [1, -1]];
    for (let r = 0; r < ROWS; r++) for (let c = 0; c < COLS; c++) {
      if (b[r][c] !== p) continue;
      for (const [dr, dc] of dirs) {
        let k = 1;
        while (k < 4 && r + dr * k >= 0 && r + dr * k < ROWS && c + dc * k >= 0 && c + dc * k < COLS && b[r + dr * k][c + dc * k] === p) k++;
        if (k >= 4) return true;
      }
    }
    return false;
  };

  const drop = (b: Cell[][], col: number, p: Cell): Cell[][] | null => {
    for (let r = ROWS - 1; r >= 0; r--) {
      if (b[r][col] === 0) {
        const nb = b.map((row) => row.slice() as Cell[]);
        nb[r][col] = p;
        return nb;
      }
    }
    return null;
  };

  const start = async () => {
    if (!(await charge(1, 'Game: Connect 4'))) return;
    setBoard(Array.from({ length: ROWS }, () => Array<Cell>(COLS).fill(0)));
    setTurn(1); setWinner(0); setActive(true);
  };

  const play = (col: number) => {
    if (!active || turn !== 1 || winner) return;
    const nb = drop(board, col, 1);
    if (!nb) return;
    if (checkWin(nb, 1)) { setBoard(nb); setWinner(1); setActive(false); award(2, 'Connect4 win'); return; }
    setBoard(nb); setTurn(2);
    setTimeout(() => {
      // Bot: pick winning move > block > random valid
      let chosen = -1;
      for (let c = 0; c < COLS; c++) { const tb = drop(nb, c, 2); if (tb && checkWin(tb, 2)) { chosen = c; break; } }
      if (chosen < 0) for (let c = 0; c < COLS; c++) { const tb = drop(nb, c, 1); if (tb && checkWin(tb, 1)) { chosen = c; break; } }
      if (chosen < 0) {
        const valid = Array.from({ length: COLS }, (_, c) => c).filter((c) => nb[0][c] === 0);
        chosen = valid[Math.floor(Math.random() * valid.length)] ?? -1;
      }
      if (chosen < 0) { setActive(false); return; }
      const bb = drop(nb, chosen, 2)!;
      if (checkWin(bb, 2)) { setBoard(bb); setWinner(2); setActive(false); return; }
      setBoard(bb); setTurn(1);
    }, 350);
  };

  return (
    <div className="space-y-3 text-white">
      <div className="text-center text-[11px] text-white/60">{!active ? (winner ? (winner === 1 ? '🎉 You win! +2 Moola' : '🤖 Bot wins') : 'Press Start') : turn === 1 ? 'Your turn 🔴' : 'Bot thinking…'}</div>
      <div className="bg-blue-900/40 border border-blue-400/30 rounded-md p-1 mx-auto" style={{ width: 'min(320px, 92vw)' }}>
        <div className="grid gap-1" style={{ gridTemplateColumns: `repeat(${COLS}, 1fr)` }}>
          {Array.from({ length: COLS }).map((_, c) => (
            <button key={c} onClick={() => play(c)} disabled={!active || turn !== 1} className="text-[11px] py-1 rounded bg-white/10 hover:bg-white/20 disabled:opacity-40">▼</button>
          ))}
          {board.flatMap((row, r) => row.map((cell, c) => (
            <div key={`${r}-${c}`} className="aspect-square rounded-full bg-blue-950/60 flex items-center justify-center">
              {cell === 1 && <div className="w-[80%] h-[80%] rounded-full bg-rose-500" />}
              {cell === 2 && <div className="w-[80%] h-[80%] rounded-full bg-amber-300" />}
            </div>
          )))}
        </div>
      </div>
      {!active && (
        <button onClick={start} className="w-full rounded-md py-2 bg-amber-300/15 border border-amber-300/40">
          {winner ? 'Play again — 1 Moola' : 'Start — 1 Moola · win = +2M'}
        </button>
      )}
    </div>
  );
}

function Memory({ charge, award }: any) {
  const SYMBOLS = ['🍕','🚀','🌙','🐱','🎵','🌈','⚡','🌟'];
  const [cards, setCards] = useState<{ id: number; sym: string; flipped: boolean; matched: boolean }[]>([]);
  const [pick, setPick] = useState<number[]>([]);
  const [moves, setMoves] = useState(0);
  const [active, setActive] = useState(false);

  const start = async () => {
    if (!(await charge(1, 'Game: Memory'))) return;
    const deck = [...SYMBOLS, ...SYMBOLS]
      .map((sym, i) => ({ id: i, sym, flipped: false, matched: false }))
      .sort(() => Math.random() - 0.5)
      .map((c, i) => ({ ...c, id: i }));
    setCards(deck); setPick([]); setMoves(0); setActive(true);
  };

  const flip = (id: number) => {
    if (!active) return;
    if (pick.length === 2) return;
    if (cards[id].flipped || cards[id].matched) return;
    const next = cards.map((c) => c.id === id ? { ...c, flipped: true } : c);
    setCards(next);
    const np = [...pick, id];
    setPick(np);
    if (np.length === 2) {
      setMoves((m) => m + 1);
      const [a, b] = np;
      if (next[a].sym === next[b].sym) {
        setTimeout(() => {
          setCards((cs) => cs.map((c) => c.id === a || c.id === b ? { ...c, matched: true } : c));
          setPick([]);
          if (next.filter((c) => c.id !== a && c.id !== b).every((c) => c.matched)) {
            setActive(false);
            const reward = moves + 1 <= 12 ? 5 : moves + 1 <= 18 ? 3 : 2;
            award(reward, `Memory win in ${moves + 1} moves`);
          }
        }, 350);
      } else {
        setTimeout(() => {
          setCards((cs) => cs.map((c) => c.id === a || c.id === b ? { ...c, flipped: false } : c));
          setPick([]);
        }, 700);
      }
    }
  };

  const allMatched = cards.length > 0 && cards.every((c) => c.matched);

  return (
    <div className="space-y-3 text-white">
      <div className="text-center text-[11px] text-white/60">Moves: {moves}{allMatched ? ' · 🎉 Cleared!' : ''}</div>
      <div className="grid grid-cols-4 gap-2 mx-auto" style={{ width: 'min(320px, 92vw)' }}>
        {cards.map((c) => (
          <button
            key={c.id}
            onClick={() => flip(c.id)}
            className={`aspect-square rounded-md flex items-center justify-center text-2xl border ${c.matched ? 'bg-emerald-500/20 border-emerald-400/50' : c.flipped ? 'bg-white/15 border-white/30' : 'bg-white/5 border-white/15 hover:bg-white/10'}`}
          >
            {c.flipped || c.matched ? c.sym : '❓'}
          </button>
        ))}
      </div>
      {!active && (
        <button onClick={start} className="w-full rounded-md py-2 bg-amber-300/15 border border-amber-300/40">
          {cards.length === 0 ? 'Start — 1 Moola' : 'Play again — 1 Moola'}
        </button>
      )}
    </div>
  );
}
