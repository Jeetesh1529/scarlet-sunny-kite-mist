/**
 * Polls — community polls. Anyone can create, anyone can vote (1 vote per user).
 */
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { sfx } from '@/lib/sfx';
import { toast } from 'sonner';
import { BarChart3, Plus, X } from 'lucide-react';

type Poll = {
  id: string;
  question: string;
  options: string[];
  author_id: string;
  closes_at: string;
  created_at: string;
};
type VoteRow = { poll_id: string; option_index: number; user_id: string };

export default function Polls() {
  const navigate = useNavigate();
  const { profile } = useAuth();
  const [polls, setPolls] = useState<Poll[]>([]);
  const [votes, setVotes] = useState<VoteRow[]>([]);
  const [myVotes, setMyVotes] = useState<Record<string, number>>({});
  const [showNew, setShowNew] = useState(false);

  useEffect(() => { void load(); }, [profile?.id]);

  async function load() {
    const { data } = await (supabase as any).from('polls').select('*').order('created_at', { ascending: false }).limit(50);
    const items = (data ?? []).map((p: any) => ({ ...p, options: Array.isArray(p.options) ? p.options : [] })) as Poll[];
    setPolls(items);

    if (items.length) {
      const ids = items.map(p => p.id);
      const { data: vs } = await (supabase as any).from('poll_votes').select('poll_id,option_index,user_id').in('poll_id', ids);
      setVotes((vs ?? []) as VoteRow[]);
      const mine: Record<string, number> = {};
      (vs ?? []).filter((v: VoteRow) => v.user_id === profile?.id).forEach((v: VoteRow) => { mine[v.poll_id] = v.option_index; });
      setMyVotes(mine);
    }
  }

  async function vote(pollId: string, optionIndex: number) {
    if (!profile) return;
    sfx.tap();
    const existing = myVotes[pollId];
    if (existing === optionIndex) return;
    if (existing !== undefined) {
      await (supabase as any).from('poll_votes').update({ option_index: optionIndex }).eq('poll_id', pollId).eq('user_id', profile.id);
    } else {
      const { error } = await (supabase as any).from('poll_votes').insert({ poll_id: pollId, user_id: profile.id, option_index: optionIndex });
      if (error) { toast.error(error.message); return; }
    }
    setMyVotes({ ...myVotes, [pollId]: optionIndex });
    void load();
  }

  function tally(pollId: string, optIdx: number) {
    return votes.filter(v => v.poll_id === pollId && v.option_index === optIdx).length;
  }
  function total(pollId: string) {
    return votes.filter(v => v.poll_id === pollId).length;
  }

  return (
    <div className="flex-1 min-h-0 flex flex-col mxit-classic-bg">
      <div className="mxit-titlebar h-9 flex items-center px-3 gap-2 shrink-0">
        <button onClick={() => { sfx.tap(); navigate('/'); }} className="text-[11px] px-2 py-0.5 rounded-sm bg-white/10 border border-white/20">‹ Back</button>
        <div className="flex-1 text-center font-semibold text-[15px] tracking-wide flex items-center justify-center gap-2">
          <BarChart3 className="w-4 h-4" /> Polls
        </div>
        <button onClick={() => setShowNew(true)} className="text-[11px] px-2 py-0.5 rounded-sm bg-white/10 border border-white/20 flex items-center gap-1">
          <Plus className="w-3 h-3" /> New
        </button>
      </div>

      <div className="relative flex-1 overflow-y-auto mxit-watermark min-h-0">
        <div className="relative z-10 p-4 space-y-3">
          {polls.length === 0 && <div className="text-center text-white/50 text-sm py-8">No polls yet — create one ↑</div>}
          {polls.map(p => {
            const t = total(p.id);
            const myChoice = myVotes[p.id];
            return (
              <div key={p.id} className="bg-white/5 border border-white/10 rounded-lg p-3">
                <div className="text-white font-semibold text-sm mb-2">{p.question}</div>
                <div className="space-y-1.5">
                  {p.options.map((opt, i) => {
                    const c = tally(p.id, i);
                    const pct = t === 0 ? 0 : Math.round((c / t) * 100);
                    const isMine = myChoice === i;
                    return (
                      <button
                        key={i}
                        onClick={() => vote(p.id, i)}
                        className={`relative w-full text-left rounded overflow-hidden border ${isMine ? 'border-pink-400/70' : 'border-white/10'} bg-black/30 hover:bg-black/40`}
                      >
                        <div
                          className={`absolute inset-y-0 left-0 ${isMine ? 'bg-pink-500/30' : 'bg-white/10'}`}
                          style={{ width: `${pct}%` }}
                        />
                        <div className="relative px-3 py-1.5 flex items-center justify-between text-sm text-white">
                          <span>{opt}</span>
                          <span className="text-[11px] text-white/70">{pct}% · {c}</span>
                        </div>
                      </button>
                    );
                  })}
                </div>
                <div className="mt-2 text-[10px] text-white/40">{t} vote{t === 1 ? '' : 's'} · closes {new Date(p.closes_at).toLocaleDateString()}</div>
              </div>
            );
          })}
        </div>
      </div>

      {showNew && <NewPollDialog onClose={() => setShowNew(false)} onCreated={() => { setShowNew(false); void load(); }} />}
    </div>
  );
}

function NewPollDialog({ onClose, onCreated }: { onClose: () => void; onCreated: () => void }) {
  const { profile } = useAuth();
  const [q, setQ] = useState('');
  const [opts, setOpts] = useState<string[]>(['', '']);
  const [busy, setBusy] = useState(false);

  async function create() {
    if (!profile) return;
    const cleaned = opts.map(o => o.trim()).filter(Boolean);
    if (q.trim().length < 3 || cleaned.length < 2) {
      toast.error('Need a question and at least 2 options');
      return;
    }
    setBusy(true);
    const { error } = await (supabase as any).from('polls').insert({
      author_id: profile.id, question: q.trim(), options: cleaned,
    });
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    toast.success('Poll created');
    onCreated();
  }

  return (
    <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4" onClick={onClose}>
      <div className="bg-zinc-900 border border-white/10 rounded-lg p-4 w-full max-w-md" onClick={e => e.stopPropagation()}>
        <div className="flex items-center justify-between mb-3">
          <div className="text-white font-semibold">New poll</div>
          <button onClick={onClose}><X className="w-4 h-4 text-white/60" /></button>
        </div>
        <input
          value={q} onChange={e => setQ(e.target.value)}
          placeholder="Your question…"
          className="w-full bg-black/40 text-white rounded px-3 py-2 text-sm border border-white/10 outline-none"
        />
        <div className="mt-2 space-y-1.5">
          {opts.map((o, i) => (
            <input
              key={i} value={o}
              onChange={e => { const n = [...opts]; n[i] = e.target.value; setOpts(n); }}
              placeholder={`Option ${i + 1}`}
              className="w-full bg-black/40 text-white rounded px-3 py-1.5 text-sm border border-white/10 outline-none"
            />
          ))}
        </div>
        {opts.length < 6 && (
          <button onClick={() => setOpts([...opts, ''])} className="mt-2 text-[12px] text-pink-300 hover:text-pink-200">+ Add option</button>
        )}
        <button onClick={create} disabled={busy} className="mt-3 w-full py-2 rounded bg-pink-500 hover:bg-pink-400 text-white font-semibold disabled:opacity-50">
          Create poll
        </button>
      </div>
    </div>
  );
}
