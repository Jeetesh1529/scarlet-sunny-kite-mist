/**
 * Leaderboards — Top weekly Moola earners and longest streaks.
 */
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { sfx } from '@/lib/sfx';
import { ChevronLeft, BarChart3, Coins, Flame, Trophy } from 'lucide-react';
import { PixelAvatar } from '@/components/PixelAvatar';

type WeeklyRow = { user_id: string; display_name: string; mxit_id: string; avatar_seed: string | null; avatar_url: string | null; earned: number; spins: number; transfers: number };
type StreakRow = { id: string; display_name: string; mxit_id: string; avatar_seed: string | null; avatar_url: string | null; streak_days: number };
type RichRow   = { id: string; display_name: string; mxit_id: string; avatar_seed: string | null; avatar_url: string | null; moola: number };

const TABS = [
  { id: 'weekly',  label: 'Weekly',  icon: Coins },
  { id: 'streak',  label: 'Streaks', icon: Flame },
  { id: 'richest', label: 'Richest', icon: Trophy },
] as const;

export default function Leaderboards() {
  const navigate = useNavigate();
  const [tab, setTab] = useState<typeof TABS[number]['id']>('weekly');
  const [weekly, setWeekly] = useState<WeeklyRow[]>([]);
  const [streak, setStreak] = useState<StreakRow[]>([]);
  const [richest, setRichest] = useState<RichRow[]>([]);

  useEffect(() => {
    (async () => {
      const [w, s, r] = await Promise.all([
        supabase.from('moola_weekly_leaderboard').select('*').order('earned', { ascending: false }).limit(25),
        supabase.from('profiles').select('id, display_name, mxit_id, avatar_seed, avatar_url, streak_days').order('streak_days', { ascending: false }).limit(25),
        supabase.from('profiles').select('id, display_name, mxit_id, avatar_seed, avatar_url, moola').order('moola', { ascending: false }).limit(25),
      ]);
      setWeekly((w.data ?? []) as WeeklyRow[]);
      setStreak(((s.data ?? []) as StreakRow[]).filter((r) => (r.streak_days ?? 0) > 0));
      setRichest((r.data ?? []) as RichRow[]);
    })();
  }, []);

  const medal = (i: number) => i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `#${i + 1}`;

  const renderRow = (i: number, id: string, mxitId: string, name: string, seed: string | null, url: string | null, value: number, suffix: string) => (
    <button
      key={id + i}
      onClick={() => { sfx.tap(); navigate(`/u/${mxitId}`); }}
      className="w-full flex items-center gap-2 px-3 py-2 hover:bg-white/5 active:bg-white/10 border-b border-white/10"
    >
      <span className={`w-8 text-center font-bold ${i < 3 ? 'text-base' : 'text-[11px] text-white/60'}`}>{medal(i)}</span>
      <PixelAvatar seed={seed} url={url} size={28} />
      <span className="flex-1 text-left text-[13px] text-white truncate">{name}</span>
      <span className="text-[12px] text-amber-200 font-semibold">{value}{suffix}</span>
    </button>
  );

  return (
    <div className="flex-1 min-h-0 flex flex-col mxit-classic-bg">
      <div className="mxit-titlebar h-9 flex items-center px-3 gap-2 shrink-0">
        <button
          onClick={() => { sfx.tap(); navigate('/tradepost'); }}
          className="text-[11px] px-2 py-0.5 rounded-sm bg-white/10 border border-white/20 flex items-center gap-1"
        >
          <ChevronLeft className="w-3 h-3" /> Back
        </button>
        <div className="flex-1 text-center font-semibold text-[15px] tracking-wide flex items-center justify-center gap-2">
          <BarChart3 className="w-4 h-4" /> Leaderboards
        </div>
        <span className="w-10" />
      </div>

      <div className="flex shrink-0 border-b border-white/10">
        {TABS.map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            onClick={() => { sfx.tap(); setTab(id); }}
            className={`flex-1 flex items-center justify-center gap-1 py-2 text-[12px] ${tab === id ? 'bg-white/10 text-white border-b-2 border-amber-300' : 'text-white/60'}`}
          >
            <Icon className="w-3.5 h-3.5" /> {label}
          </button>
        ))}
      </div>

      <div className="relative flex-1 overflow-y-auto mxit-watermark min-h-0">
        <div className="relative z-10">
          {tab === 'weekly' && (weekly.length === 0
            ? <div className="text-white/60 text-sm text-center py-6 italic">No earnings this week yet.</div>
            : weekly.map((w, i) => renderRow(i, w.user_id, w.mxit_id, w.display_name, w.avatar_seed, w.avatar_url, w.earned, 'M')))}
          {tab === 'streak' && (streak.length === 0
            ? <div className="text-white/60 text-sm text-center py-6 italic">No active streaks yet.</div>
            : streak.map((s, i) => renderRow(i, s.id, s.mxit_id, s.display_name, s.avatar_seed, s.avatar_url, s.streak_days, '🔥')))}
          {tab === 'richest' && richest.map((r, i) => renderRow(i, r.id, r.mxit_id, r.display_name, r.avatar_seed, r.avatar_url, r.moola, 'M'))}
        </div>
      </div>
    </div>
  );
}
