/**
 * MultiMx — Mxit's private group chat list.
 * Shows the user's MultiMX groups. Lets them create a new group, name it, and pick contacts to invite.
 * Tapping a group navigates to /multimx/:id.
 */
import { useEffect, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { sfx } from '@/lib/sfx';
import { toast } from 'sonner';
import { ChevronRight, Plus, Users } from 'lucide-react';
import { awardAchievement } from '@/lib/achievements';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
} from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { PixelAvatar } from '@/components/PixelAvatar';

type Group = { id: string; name: string; created_by: string; last_message_at: string; member_count: number };
type ContactProfile = {
  id: string;
  display_name: string;
  mxit_id: string;
  avatar_seed: string | null;
  avatar_url: string | null;
};

export default function MultiMx() {
  const navigate = useNavigate();
  const { profile } = useAuth();
  const [groups, setGroups] = useState<Group[]>([]);
  const [contacts, setContacts] = useState<ContactProfile[]>([]);
  const [open, setOpen] = useState(false);
  const [name, setName] = useState('');
  const [picked, setPicked] = useState<Set<string>>(new Set());
  const [busy, setBusy] = useState(false);

  const load = async () => {
    if (!profile) return;
    const { data: mems } = await supabase
      .from('multimx_members')
      .select('group_id')
      .eq('user_id', profile.id);
    const ids = (mems ?? []).map((m: any) => m.group_id);
    if (!ids.length) { setGroups([]); return; }
    const { data: gs } = await supabase
      .from('multimx_groups')
      .select('id, name, created_by, last_message_at')
      .in('id', ids)
      .order('last_message_at', { ascending: false });
    const { data: allMems } = await supabase
      .from('multimx_members')
      .select('group_id')
      .in('group_id', ids);
    const counts = new Map<string, number>();
    (allMems ?? []).forEach((m: any) => counts.set(m.group_id, (counts.get(m.group_id) ?? 0) + 1));
    setGroups((gs ?? []).map((g: any) => ({ ...g, member_count: counts.get(g.id) ?? 1 })));
  };

  const loadContacts = async () => {
    if (!profile) return;
    const { data } = await supabase
      .from('contacts')
      .select('requester_id, addressee_id, status')
      .eq('status', 'accepted')
      .or(`requester_id.eq.${profile.id},addressee_id.eq.${profile.id}`);
    const otherIds = (data ?? []).map((c: any) =>
      c.requester_id === profile.id ? c.addressee_id : c.requester_id,
    );
    if (!otherIds.length) { setContacts([]); return; }
    const { data: ps } = await supabase
      .from('profiles')
      .select('id, display_name, mxit_id, avatar_seed, avatar_url')
      .in('id', otherIds);
    setContacts((ps ?? []) as ContactProfile[]);
  };

  useEffect(() => {
    load();
    loadContacts();
    if (!profile) return;
    const ch = supabase
      .channel('multimx-list')
      .on('postgres_changes', { event: '*', schema: 'public', table: 'multimx_members' }, load)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'multimx_groups' }, load)
      .subscribe();
    return () => { supabase.removeChannel(ch); };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [profile?.id]);

  const togglePick = (id: string) => {
    setPicked((p) => {
      const n = new Set(p);
      if (n.has(id)) n.delete(id); else n.add(id);
      return n;
    });
  };

  const createGroup = async () => {
    if (!profile || !name.trim()) return;
    setBusy(true);
    try {
      const { data: g, error } = await supabase
        .from('multimx_groups')
        .insert({ name: name.trim(), created_by: profile.id })
        .select('id')
        .single();
      if (error) throw error;
      // Add creator + invited contacts as members
      const memberRows = [
        { group_id: g.id, user_id: profile.id },
        ...Array.from(picked).map((uid) => ({ group_id: g.id, user_id: uid })),
      ];
      const { error: mErr } = await supabase.from('multimx_members').insert(memberRows);
      if (mErr) throw mErr;
      sfx.tap();
      toast.success('MultiMx group created');
      void awardAchievement('multimx_create');
      setOpen(false);
      setName('');
      setPicked(new Set());
      navigate(`/multimx/${g.id}`);
    } catch (e: any) {
      sfx.error();
      toast.error(e.message);
    } finally {
      setBusy(false);
    }
  };

  const sortedContacts = useMemo(
    () => [...contacts].sort((a, b) => a.display_name.localeCompare(b.display_name)),
    [contacts],
  );

  return (
    <div className="flex-1 min-h-0 flex flex-col mxit-classic-bg">
      <div className="mxit-titlebar h-9 flex items-center px-3 gap-2 shrink-0">
        <button
          onClick={() => { sfx.tap(); navigate('/'); }}
          className="text-[11px] px-2 py-0.5 rounded-sm bg-white/10 border border-white/20"
        >
          ‹ Back
        </button>
        <div className="flex-1 text-center font-semibold text-[15px] tracking-wide">MultiMx</div>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <button
              onClick={() => sfx.tap()}
              className="text-[11px] px-2 py-0.5 rounded-sm bg-white/10 border border-white/20 flex items-center gap-1"
            >
              <Plus className="w-3 h-3" /> New
            </button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="font-pixel text-sm">New MultiMx group</DialogTitle>
            </DialogHeader>
            <Input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="Group name (e.g. Maths Crew)"
              maxLength={40}
              autoFocus
            />
            <div className="text-[11px] text-muted-foreground">
              Pick contacts to invite. Free to chat — no Moola needed.
            </div>
            <div className="max-h-60 overflow-y-auto space-y-1 border rounded-md p-2">
              {sortedContacts.length === 0 && (
                <div className="text-xs text-muted-foreground italic px-1 py-2">
                  No contacts yet. Add some friends first.
                </div>
              )}
              {sortedContacts.map((c) => {
                const on = picked.has(c.id);
                return (
                  <button
                    key={c.id}
                    onClick={() => togglePick(c.id)}
                    className={`w-full flex items-center gap-2 p-1.5 rounded ${
                      on ? 'bg-primary/15 ring-1 ring-primary' : 'hover:bg-muted'
                    }`}
                  >
                    <PixelAvatar seed={c.avatar_seed} url={c.avatar_url} size={28} />
                    <span className="flex-1 text-left text-sm truncate">{c.display_name}</span>
                    <span className="text-[10px] text-muted-foreground">@{c.mxit_id}</span>
                    <input
                      type="checkbox"
                      checked={on}
                      onChange={() => togglePick(c.id)}
                      className="w-4 h-4"
                    />
                  </button>
                );
              })}
            </div>
            <Button
              onClick={createGroup}
              disabled={busy || !name.trim()}
              className="font-pixel text-[10px]"
            >
              Create group ({picked.size + 1} members)
            </Button>
          </DialogContent>
        </Dialog>
      </div>

      <div className="relative flex-1 overflow-y-auto mxit-watermark min-h-0">
        <div className="relative z-10 py-2">
          <div className="px-3 pb-2 text-[11px] text-white/60 italic">
            Private group chat. Invite your own contacts and chat with everyone in one thread — free.
          </div>
          {groups.length === 0 && (
            <div className="px-4 py-4 text-white/60 text-sm italic">
              No MultiMx groups yet. Tap <strong>New</strong> to create one.
            </div>
          )}
          {groups.map((g) => (
            <button
              key={g.id}
              onClick={() => { sfx.tap(); navigate(`/multimx/${g.id}`); }}
              className="w-full text-left flex items-center gap-3 pl-3 pr-3 py-2 hover:bg-white/5 active:bg-white/10"
            >
              <span className="status-orb orb-online" />
              <span
                className="flex-1 min-w-0 truncate text-white font-medium tracking-wide"
                style={{ textShadow: '0 1px 0 hsl(220 80% 8% / 0.6)' }}
              >
                {g.name}
                <span className="block text-[11px] font-normal text-white/60 truncate flex items-center gap-1">
                  <Users className="w-3 h-3" /> {g.member_count} members
                  {g.created_by === profile?.id && <span className="text-amber-200">· you created</span>}
                </span>
              </span>
              <ChevronRight className="w-4 h-4 text-white/60" />
            </button>
          ))}
        </div>
      </div>

      <div className="mxit-softkeys h-10 flex items-stretch text-sm font-medium shrink-0">
        <button
          onClick={() => { sfx.tap(); navigate('/'); }}
          className="flex-1 text-left pl-4 active:bg-black/30"
        >
          Back
        </button>
        <button
          onClick={() => { sfx.tap(); setOpen(true); }}
          className="flex-1 text-right pr-4 active:bg-black/30"
        >
          New group
        </button>
      </div>
    </div>
  );
}
