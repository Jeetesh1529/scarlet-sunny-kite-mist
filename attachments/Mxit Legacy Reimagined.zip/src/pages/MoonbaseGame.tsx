/**
 * Moonbase MVP1 + MVP2 (Alliances, Trade) + MVP3 (Research, Lasers, Shield, Bunker).
 * Menus: Base · Resources · Buildings · War Room · Scanner · Comm Station (alliances) ·
 *        Trade Pod · Research Lab · Reports.
 */
import { useEffect, useMemo, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { sfx } from '@/lib/sfx';
import { toast } from 'sonner';
import {
  Rocket, ChevronRight, Hammer, Swords, Radar, ScrollText,
  Droplets, Wind, Mountain, Flame, Shield, Crosshair, Trophy,
  Users, Store, FlaskConical, Zap, Send, ShieldCheck, Building2,
  Globe2, Plus, Check,
} from 'lucide-react';
import { awardAchievement } from '@/lib/achievements';

const COLONY_COST = { oxygen: 800, water: 800, iron: 1500, helium: 600 };
const COLONY_REQ_CMD_LEVEL = (n: number) => n + 2; // capital CC L3 → 2nd base, L4 → 3rd, etc.

type Base = {
  id: string; user_id: string | null; base_name: string;
  sector_x: number; sector_y: number; power_score: number; is_bot: boolean; last_tick: string;
};
type Resources = { base_id: string; oxygen: number; water: number; iron: number; helium: number; capacity: number; updated_at: string };
type Building = { id: string; base_id: string; building_type: string; level: number };
type Unit = { id: string; base_id: string; unit_type: string; quantity: number };
type Research = { id: string; user_id: string; research_type: string; level: number };

const BUILDING_LIST = [
  { type: 'command_centre',   name: 'Command Centre',   icon: Shield,        base: 'core' },
  { type: 'oxygen_plant',     name: 'Oxygen Plant',     icon: Wind,          base: 'mine' },
  { type: 'water_extractor',  name: 'Water Extractor',  icon: Droplets,      base: 'mine' },
  { type: 'iron_mine',        name: 'Iron Mine',        icon: Mountain,      base: 'mine' },
  { type: 'helium_drill',     name: 'Helium Drill',     icon: Flame,         base: 'mine' },
  { type: 'storage_depot',    name: 'Storage Depot',    icon: Hammer,        base: 'storage' },
  { type: 'war_room',         name: 'War Room',         icon: Swords,        base: 'war' },
  { type: 'scanner',          name: 'Scanner',          icon: Radar,         base: 'scan' },
  { type: 'shield_generator', name: 'Shield Generator', icon: ShieldCheck,   base: 'def' },
  { type: 'bunker',           name: 'Bunker',           icon: Building2,     base: 'def' },
  { type: 'research_lab',     name: 'Research Lab',     icon: FlaskConical,  base: 'tech' },
  { type: 'comm_station',     name: 'Comm Station',     icon: Users,         base: 'social' },
  { type: 'trade_pod',        name: 'Trade Pod',        icon: Store,         base: 'social' },
];

const UNIT_LIST = [
  { type: 'moonbuggy',    name: 'Moonbuggy',    attack: 5,   defence: 20, carry: 5,   cost: { iron: 50,    helium: 0    } },
  { type: 'gunship',      name: 'Gunship',      attack: 40,  defence: 15, carry: 50,  cost: { iron: 150,   helium: 100  } },
  { type: 'laser_cannon', name: 'Laser Cannon', attack: 200, defence: 5,  carry: 0,   cost: { iron: 1000,  helium: 500  } },
];

const RESEARCH_LIST = [
  { type: 'mining_efficiency', name: 'Mining Efficiency', desc: '+10% all production per level' },
  { type: 'gunship_attack',    name: 'Gunship Attack',    desc: '+15% Gunship attack per level' },
  { type: 'moonbuggy_defence', name: 'Moonbuggy Defence', desc: '+15% Moonbuggy defence per level' },
  { type: 'laser_tech',        name: 'Laser Tech',        desc: '+20% Laser Cannon attack per level' },
  { type: 'shield_tech',       name: 'Shield Tech',       desc: '+10% Shield bonus per level' },
];

const PROD_BASE = 10;
const STORAGE_BASE = 2000;
const STORAGE_PER_LEVEL = 1500;

const prodPerHour = (lvl: number) => Math.floor(PROD_BASE * Math.pow(Math.max(1, lvl), 1.25));
const upgradeCost = (lvl: number) => {
  const m = lvl + 1;
  return { oxygen: 40 * m, water: 40 * m, iron: 80 * m, helium: 10 * m };
};
const researchCost = (lvl: number) => {
  const m = lvl + 1;
  return { oxygen: 200 * m, water: 200 * m, iron: 500 * m, helium: 250 * m };
};

type View =
  | 'home' | 'resources' | 'buildings' | 'war' | 'scan' | 'attack'
  | 'comm' | 'trade' | 'research' | 'reports' | 'colonies';

export default function MoonbaseGame() {
  const { user, profile } = useAuth();
  const navigate = useNavigate();
  const [loading, setLoading] = useState(true);
  const [bases, setBases] = useState<Base[]>([]);
  const [base, setBase] = useState<Base | null>(null);
  const [res, setRes] = useState<Resources | null>(null);
  const [bldgs, setBldgs] = useState<Building[]>([]);
  const [units, setUnits] = useState<Unit[]>([]);
  const [research, setResearch] = useState<Research[]>([]);
  const [view, setView] = useState<View>('home');
  const [tick, setTick] = useState(0);

  // attack state
  const [target, setTarget] = useState<Base | null>(null);
  const [sendBuggy, setSendBuggy] = useState(0);
  const [sendShip, setSendShip] = useState(0);
  const [sendLaser, setSendLaser] = useState(0);

  /* ---------- bootstrap ---------- */
  useEffect(() => {
    if (!user) return;
    (async () => {
      const { data: list } = await supabase
        .from('moonbase_bases').select('*').eq('user_id', user.id).order('created_at');
      let myBases = (list ?? []) as Base[];
      if (myBases.length === 0) {
        const name = (profile?.display_name ?? 'Commander') + "'s Moonbase";
        const ins = await supabase.from('moonbase_bases').insert({
          user_id: user.id, base_name: name,
          sector_x: 1 + Math.floor(Math.random() * 20),
          sector_y: 1 + Math.floor(Math.random() * 20),
          power_score: 100,
        }).select('*').single();
        if (ins.error) { toast.error(ins.error.message); setLoading(false); return; }
        await supabase.from('moonbase_resources').insert({ base_id: ins.data.id });
        myBases = [ins.data as Base];
        toast.success('Welcome, Commander.');
        void awardAchievement('moonbase_first');
      }
      setBases(myBases);
      const active = myBases[0];
      setBase(active);
      await ensureRows(active.id);
      await loadAll(active.id);
      setLoading(false);
    })();
  }, [user]);

  const switchBase = async (b: Base) => {
    sfx.tap();
    setBase(b);
    setView('home');
    await ensureRows(b.id);
    await loadAll(b.id);
  };

  const reloadBases = async () => {
    if (!user) return;
    const { data } = await supabase
      .from('moonbase_bases').select('*').eq('user_id', user.id).order('created_at');
    setBases((data ?? []) as Base[]);
  };


  // Ensure every building/unit row exists for this base (backfill old MVP1 bases).
  const ensureRows = async (baseId: string) => {
    const [bExisting, uExisting] = await Promise.all([
      supabase.from('moonbase_buildings').select('building_type').eq('base_id', baseId),
      supabase.from('moonbase_units').select('unit_type').eq('base_id', baseId),
    ]);
    const have = new Set((bExisting.data ?? []).map((x: any) => x.building_type));
    const missingB = BUILDING_LIST
      .filter((x) => !have.has(x.type))
      .map((x) => ({
        base_id: baseId, building_type: x.type,
        // start mines & command centre at L1 if brand new base; otherwise default to 0
        level: ['command_centre', 'oxygen_plant', 'water_extractor', 'iron_mine', 'helium_drill', 'storage_depot', 'war_room', 'scanner'].includes(x.type) ? 1 : 0,
      }));
    if (missingB.length) await supabase.from('moonbase_buildings').insert(missingB);

    const haveU = new Set((uExisting.data ?? []).map((x: any) => x.unit_type));
    const missingU = UNIT_LIST
      .filter((x) => !haveU.has(x.type))
      .map((x) => ({ base_id: baseId, unit_type: x.type, quantity: x.type === 'moonbuggy' ? 10 : 0 }));
    if (missingU.length) await supabase.from('moonbase_units').insert(missingU);
  };

  const loadAll = async (baseId: string) => {
    const [r, bl, u, rs] = await Promise.all([
      supabase.from('moonbase_resources').select('*').eq('base_id', baseId).maybeSingle(),
      supabase.from('moonbase_buildings').select('*').eq('base_id', baseId),
      supabase.from('moonbase_units').select('*').eq('base_id', baseId),
      supabase.from('moonbase_research').select('*').eq('user_id', user!.id),
    ]);
    setRes(r.data as Resources | null);
    setBldgs((bl.data ?? []) as Building[]);
    setUnits((u.data ?? []) as Unit[]);
    setResearch((rs.data ?? []) as Research[]);
  };

  /* ---------- live tick ---------- */
  useEffect(() => {
    const t = setInterval(() => setTick((x) => x + 1), 5000);
    return () => clearInterval(t);
  }, []);

  const lvl = (type: string) => bldgs.find((b) => b.building_type === type)?.level ?? 0;
  const unitQty = (type: string) => units.find((u) => u.unit_type === type)?.quantity ?? 0;
  const resLvl = (type: string) => research.find((r) => r.research_type === type)?.level ?? 0;

  const miningBonus = 1 + 0.10 * resLvl('mining_efficiency');
  const capacity = useMemo(() => STORAGE_BASE + STORAGE_PER_LEVEL * Math.max(0, lvl('storage_depot') - 1), [bldgs]);
  const rates = useMemo(() => ({
    oxygen: Math.floor(prodPerHour(lvl('oxygen_plant')) * miningBonus),
    water:  Math.floor(prodPerHour(lvl('water_extractor')) * miningBonus),
    iron:   Math.floor(prodPerHour(lvl('iron_mine')) * miningBonus),
    helium: Math.floor(prodPerHour(lvl('helium_drill')) * miningBonus),
  }), [bldgs, miningBonus]);

  const displayed = useMemo(() => {
    if (!res) return null;
    const ageSec = (Date.now() - new Date(res.updated_at).getTime()) / 1000;
    const accrue = (cur: number, perHr: number) => Math.min(capacity, Math.floor(cur + (perHr / 3600) * ageSec));
    return {
      oxygen: accrue(res.oxygen, rates.oxygen),
      water:  accrue(res.water,  rates.water),
      iron:   accrue(res.iron,   rates.iron),
      helium: accrue(res.helium, rates.helium),
    };
  }, [res, rates, capacity, tick]);

  const flushResources = async () => {
    if (!res || !base || !displayed) return null;
    const upd = { ...displayed, capacity, updated_at: new Date().toISOString() };
    const { error } = await supabase.from('moonbase_resources').update(upd).eq('base_id', base.id);
    if (error) { toast.error(error.message); return null; }
    setRes({ ...res, ...upd });
    return displayed;
  };

  /* ---------- actions ---------- */
  const upgrade = async (type: string) => {
    if (!base) return;
    sfx.tap();
    const cur = await flushResources(); if (!cur) return;
    const curLvl = lvl(type); const cost = upgradeCost(curLvl);
    if (cur.oxygen < cost.oxygen || cur.water < cost.water || cur.iron < cost.iron || cur.helium < cost.helium) {
      sfx.error(); toast.error('Not enough resources'); return;
    }
    await supabase.from('moonbase_resources').update({
      oxygen: cur.oxygen - cost.oxygen, water: cur.water - cost.water,
      iron: cur.iron - cost.iron, helium: cur.helium - cost.helium,
      updated_at: new Date().toISOString(),
    }).eq('base_id', base.id);
    await supabase.from('moonbase_buildings').update({ level: curLvl + 1 })
      .eq('base_id', base.id).eq('building_type', type);
    const newPwr = base.power_score + 25;
    await supabase.from('moonbase_bases').update({ power_score: newPwr }).eq('id', base.id);
    setBase({ ...base, power_score: newPwr });
    toast.success(`Upgraded to L${curLvl + 1}`);
    await loadAll(base.id);
  };

  const train = async (type: string, count: number) => {
    if (!base || count <= 0) return;
    sfx.tap();
    const u = UNIT_LIST.find((x) => x.type === type)!;
    const cur = await flushResources(); if (!cur) return;
    if (lvl('war_room') < 1) { toast.error('Need a War Room'); return; }
    if (type === 'laser_cannon' && lvl('research_lab') < 2) { toast.error('Lasers need Research Lab L2'); return; }
    const totalIron = u.cost.iron * count, totalHe = u.cost.helium * count;
    if (cur.iron < totalIron || cur.helium < totalHe) { sfx.error(); toast.error('Not enough Iron / Helium'); return; }
    await supabase.from('moonbase_resources').update({
      iron: cur.iron - totalIron, helium: cur.helium - totalHe, updated_at: new Date().toISOString(),
    }).eq('base_id', base.id);
    const newQty = unitQty(type) + count;
    await supabase.from('moonbase_units').update({ quantity: newQty })
      .eq('base_id', base.id).eq('unit_type', type);
    const ppu = type === 'laser_cannon' ? 30 : type === 'gunship' ? 10 : 3;
    const newPwr = base.power_score + count * ppu;
    await supabase.from('moonbase_bases').update({ power_score: newPwr }).eq('id', base.id);
    setBase({ ...base, power_score: newPwr });
    toast.success(`Trained ${count} ${u.name}${count > 1 ? 's' : ''}`);
    await loadAll(base.id);
  };

  const upgradeResearch = async (type: string) => {
    if (!base || !user) return;
    sfx.tap();
    if (lvl('research_lab') < 1) { toast.error('Build a Research Lab first'); return; }
    const cur = await flushResources(); if (!cur) return;
    const curLvl = resLvl(type); const cost = researchCost(curLvl);
    if (cur.oxygen < cost.oxygen || cur.water < cost.water || cur.iron < cost.iron || cur.helium < cost.helium) {
      sfx.error(); toast.error('Not enough resources'); return;
    }
    await supabase.from('moonbase_resources').update({
      oxygen: cur.oxygen - cost.oxygen, water: cur.water - cost.water,
      iron: cur.iron - cost.iron, helium: cur.helium - cost.helium,
      updated_at: new Date().toISOString(),
    }).eq('base_id', base.id);
    if (curLvl === 0) {
      await supabase.from('moonbase_research').insert({ user_id: user.id, research_type: type, level: 1 });
    } else {
      await supabase.from('moonbase_research').update({ level: curLvl + 1 })
        .eq('user_id', user.id).eq('research_type', type);
    }
    toast.success(`Researched to L${curLvl + 1}`);
    await loadAll(base.id);
  };

  /* ---------- attack with bonuses ---------- */
  const launchAttack = async () => {
    if (!base || !target || !user) return;
    if (sendBuggy + sendShip + sendLaser <= 0) { toast.error('Select units to send'); return; }
    if (sendBuggy > unitQty('moonbuggy') || sendShip > unitQty('gunship') || sendLaser > unitQty('laser_cannon')) {
      toast.error('Not enough units'); return;
    }
    sfx.tap();

    const [dRes, dUnits, dBldgs] = await Promise.all([
      supabase.from('moonbase_resources').select('*').eq('base_id', target.id).maybeSingle(),
      supabase.from('moonbase_units').select('*').eq('base_id', target.id),
      supabase.from('moonbase_buildings').select('*').eq('base_id', target.id),
    ]);
    const defUnits: Record<string, number> = {};
    (dUnits.data ?? []).forEach((u: any) => { defUnits[u.unit_type] = u.quantity; });
    const defLvl = (t: string) => (dBldgs.data ?? []).find((x: any) => x.building_type === t)?.level ?? 0;

    // Attacker bonuses
    const buggyAtk = 5;
    const shipAtk = 40 * (1 + 0.15 * resLvl('gunship_attack'));
    const laserAtk = 200 * (1 + 0.20 * resLvl('laser_tech'));
    const atkP = Math.floor(sendBuggy * buggyAtk + sendShip * shipAtk + sendLaser * laserAtk);

    // Defender bonuses
    const buggyDef = 20 * (1 + 0.15 * (target.is_bot ? 0 : 0)); // bonuses tied to defender's own research—skipped for bots
    const shipDef = 15;
    const laserDef = 5;
    const shieldBonus = defLvl('shield_generator') * 50; // flat
    const bunkerBonus = defLvl('bunker') * 40;
    const defP = Math.floor(
      (defUnits.moonbuggy ?? 0) * buggyDef +
      (defUnits.gunship ?? 0) * shipDef +
      (defUnits.laser_cannon ?? 0) * laserDef
    ) + shieldBonus + bunkerBonus + 50;

    const win = atkP > defP;

    const lossRatio = win ? 0.05 + Math.random() * 0.25 : 0.5 + Math.random() * 0.3;
    const lostBuggy = Math.min(sendBuggy, Math.round(sendBuggy * lossRatio));
    const lostShip = Math.min(sendShip, Math.round(sendShip * lossRatio));
    const lostLaser = Math.min(sendLaser, Math.round(sendLaser * lossRatio));

    const defLossRatio = win ? 0.5 + Math.random() * 0.3 : 0.05 + Math.random() * 0.2;
    const lostDefBuggy = Math.round((defUnits.moonbuggy ?? 0) * defLossRatio);
    const lostDefShip = Math.round((defUnits.gunship ?? 0) * defLossRatio);
    const lostDefLaser = Math.round((defUnits.laser_cannon ?? 0) * defLossRatio);

    let plunder = { oxygen: 0, water: 0, iron: 0, helium: 0 };
    if (win && dRes.data) {
      const carry = (sendBuggy - lostBuggy) * 5 + (sendShip - lostShip) * 50;
      const total = dRes.data.oxygen + dRes.data.water + dRes.data.iron + dRes.data.helium;
      // Bunker protects 25% per level, capped 75%
      const protectedPct = Math.min(0.75, defLvl('bunker') * 0.25);
      const lootable = total * (1 - protectedPct);
      const looted = Math.min(carry, Math.floor(lootable * 0.3));
      const share = (k: keyof typeof plunder) =>
        Math.floor(looted * ((dRes.data as any)[k] / Math.max(1, total)));
      plunder = { oxygen: share('oxygen'), water: share('water'), iron: share('iron'), helium: share('helium') };
    }

    const cur = await flushResources(); if (!cur) return;
    await Promise.all([
      supabase.from('moonbase_units').update({ quantity: unitQty('moonbuggy') - lostBuggy })
        .eq('base_id', base.id).eq('unit_type', 'moonbuggy'),
      supabase.from('moonbase_units').update({ quantity: unitQty('gunship') - lostShip })
        .eq('base_id', base.id).eq('unit_type', 'gunship'),
      supabase.from('moonbase_units').update({ quantity: unitQty('laser_cannon') - lostLaser })
        .eq('base_id', base.id).eq('unit_type', 'laser_cannon'),
    ]);
    if (win) {
      await supabase.from('moonbase_resources').update({
        oxygen: Math.min(capacity, cur.oxygen + plunder.oxygen),
        water:  Math.min(capacity, cur.water  + plunder.water),
        iron:   Math.min(capacity, cur.iron   + plunder.iron),
        helium: Math.min(capacity, cur.helium + plunder.helium),
        updated_at: new Date().toISOString(),
      }).eq('base_id', base.id);
    }

    const result = { win, atkP, defP, lostBuggy, lostShip, lostLaser, lostDefBuggy, lostDefShip, lostDefLaser, plunder };
    await supabase.from('moonbase_attacks').insert({
      attacker_base_id: base.id, defender_base_id: target.id,
      units_sent: { moonbuggy: sendBuggy, gunship: sendShip, laser_cannon: sendLaser },
      result,
    });
    const body = [
      `Target: ${target.base_name}`,
      `Attack ${atkP} vs Defence ${defP}`,
      win ? '✅ Victory' : '❌ Defeat',
      `Your losses: ${lostBuggy} Buggy, ${lostShip} Gunship, ${lostLaser} Laser`,
      `Enemy losses: ${lostDefBuggy} Buggy, ${lostDefShip} Gunship, ${lostDefLaser} Laser`,
      win ? `Plunder: O ${plunder.oxygen} · W ${plunder.water} · Fe ${plunder.iron} · He ${plunder.helium}` : 'No plunder.',
    ].join('\n');
    await supabase.from('moonbase_reports').insert({
      user_id: user.id, kind: 'battle',
      title: (win ? '🎉 Victory at ' : '💥 Defeat at ') + target.base_name,
      body,
    });

    toast[win ? 'success' : 'error'](win ? 'Victory!' : 'Defeated.');
    setTarget(null); setSendBuggy(0); setSendShip(0); setSendLaser(0);
    await loadAll(base.id);
    setView('reports');
  };

  /* ---------- render ---------- */
  if (loading) return <div className="flex-1 flex items-center justify-center text-white/70 text-sm">Booting Moonbase…</div>;
  if (!base || !res || !displayed) return <div className="flex-1 flex items-center justify-center text-white/70 text-sm">No base.</div>;

  const back = () => {
    sfx.tap();
    if (view === 'home') navigate('/tradepost/games');
    else { setView('home'); setTarget(null); }
  };

  const titleMap: Record<View, string> = {
    home: 'Moonbase', resources: 'Resources', buildings: 'Buildings', war: 'War Room',
    scan: 'Scanner', attack: 'Attack', comm: 'Comm Station', trade: 'Trade Pod',
    research: 'Research Lab', reports: 'Reports', colonies: 'Colonies',
  };

  // Found a new colony (paid from CURRENT base, requires capital CC level).
  const foundColony = async () => {
    if (!user || !base || bases.length === 0) return;
    sfx.tap();
    const capital = bases[0];
    const capitalCC = capital.id === base.id
      ? lvl('command_centre')
      : (await supabase.from('moonbase_buildings').select('level')
          .eq('base_id', capital.id).eq('building_type', 'command_centre').maybeSingle()).data?.level ?? 0;
    const required = COLONY_REQ_CMD_LEVEL(bases.length); // need L3 for 2nd, L4 for 3rd...
    if (capitalCC < required) {
      toast.error(`Capital Command Centre L${required} required (currently L${capitalCC}).`);
      return;
    }
    const cur = await flushResources(); if (!cur) return;
    if (cur.oxygen < COLONY_COST.oxygen || cur.water < COLONY_COST.water
      || cur.iron < COLONY_COST.iron || cur.helium < COLONY_COST.helium) {
      sfx.error(); toast.error('Not enough resources to found colony'); return;
    }
    // Find a free sector
    const { data: occ } = await supabase.from('moonbase_bases').select('sector_x,sector_y');
    const taken = new Set((occ ?? []).map((o: any) => `${o.sector_x},${o.sector_y}`));
    let sx = 0, sy = 0;
    for (let i = 0; i < 200; i++) {
      const x = 1 + Math.floor(Math.random() * 50);
      const y = 1 + Math.floor(Math.random() * 50);
      if (!taken.has(`${x},${y}`)) { sx = x; sy = y; break; }
    }
    if (!sx) { toast.error('No empty sectors found'); return; }

    await supabase.from('moonbase_resources').update({
      oxygen: cur.oxygen - COLONY_COST.oxygen, water: cur.water - COLONY_COST.water,
      iron: cur.iron - COLONY_COST.iron, helium: cur.helium - COLONY_COST.helium,
      updated_at: new Date().toISOString(),
    }).eq('base_id', base.id);

    const colonyName = `${profile?.display_name ?? 'Commander'} Colony ${bases.length + 1}`;
    const ins = await supabase.from('moonbase_bases').insert({
      user_id: user.id, base_name: colonyName, sector_x: sx, sector_y: sy, power_score: 50,
    }).select('*').single();
    if (ins.error) { toast.error(ins.error.message); return; }
    await supabase.from('moonbase_resources').insert({ base_id: ins.data.id });
    await ensureRows(ins.data.id);
    await reloadBases();
    toast.success(`Colony founded at sector ${sx},${sy}`);
    // Switch to the new base
    await switchBase(ins.data as Base);
  };


  return (
    <div className="flex-1 min-h-0 flex flex-col mxit-classic-bg">
      <div className="mxit-titlebar h-9 flex items-center px-3 gap-2 shrink-0">
        <button onClick={back} className="text-[11px] px-2 py-0.5 rounded-sm bg-white/10 border border-white/20">‹ Back</button>
        <div className="flex-1 text-center font-semibold text-[15px] tracking-wide flex items-center justify-center gap-2 truncate">
          <Rocket className="w-4 h-4" /> {titleMap[view]}
        </div>
        <span className="text-[10px] text-amber-200">Pwr {base.power_score}</span>
      </div>

      <div className="px-3 py-2 text-[11px] text-white/80 grid grid-cols-4 gap-2 bg-black/20 border-b border-white/10 shrink-0">
        <Stat icon={Wind}     label="O₂"  v={displayed.oxygen} cap={capacity} rate={rates.oxygen} />
        <Stat icon={Droplets} label="H₂O" v={displayed.water}  cap={capacity} rate={rates.water} />
        <Stat icon={Mountain} label="Fe"  v={displayed.iron}   cap={capacity} rate={rates.iron} />
        <Stat icon={Flame}    label="He"  v={displayed.helium} cap={capacity} rate={rates.helium} />
      </div>

      <div className="relative flex-1 overflow-y-auto mxit-watermark min-h-0">
        <div className="relative z-10 p-3 text-white">
          {view === 'home' && (
            <>
              <div className="mb-3 rounded-md p-3 bg-white/5 border border-white/15">
                <div className="flex items-center gap-2">
                  <div className="flex-1 min-w-0">
                    <div className="font-semibold truncate">{base.base_name} {bases[0]?.id === base.id && <span className="text-[10px] text-amber-200">★ Capital</span>}</div>
                    <div className="text-[11px] text-white/60">Sector {base.sector_x},{base.sector_y} · Commander: {profile?.display_name}</div>
                  </div>
                  {bases.length > 1 && (
                    <select
                      value={base.id}
                      onChange={(e) => {
                        const b = bases.find((x) => x.id === e.target.value);
                        if (b) switchBase(b);
                      }}
                      className="text-[11px] bg-black/40 border border-white/20 rounded px-1 py-0.5 text-white max-w-[120px]"
                    >
                      {bases.map((b) => (
                        <option key={b.id} value={b.id}>{b.base_name}</option>
                      ))}
                    </select>
                  )}
                </div>
              </div>
              <MenuRow icon={Mountain}    label="Resources"     desc="View & upgrade mines"      onClick={() => setView('resources')} />
              <MenuRow icon={Hammer}      label="Buildings"     desc="Inspect & upgrade base"    onClick={() => setView('buildings')} />
              <MenuRow icon={Swords}      label="War Room"      desc="Train units & attack"      onClick={() => setView('war')} />
              <MenuRow icon={Radar}       label="Scanner"       desc="Find nearby bases"         onClick={() => setView('scan')} />
              <MenuRow icon={FlaskConical} label="Research Lab" desc="Boost economy & combat"    onClick={() => setView('research')} />
              <MenuRow icon={Globe2}      label="Colonies"      desc={`${bases.length} base${bases.length>1?'s':''} · found new`} onClick={() => setView('colonies')} />
              <MenuRow icon={Users}       label="Comm Station"  desc="Alliances & chat"          onClick={() => setView('comm')} />
              <MenuRow icon={Store}       label="Trade Pod"     desc="Market & player trades"    onClick={() => setView('trade')} />
              <MenuRow icon={ScrollText}  label="Reports"       desc="Battle, trade & system"    onClick={() => setView('reports')} />
            </>
          )}

          {view === 'resources' && BUILDING_LIST.filter((b) => b.base === 'mine').map((b) => {
            const Icon = b.icon, l = lvl(b.type), c = upgradeCost(l);
            return (
              <div key={b.type} className="mb-2 rounded-md p-3 bg-white/5 border border-white/15">
                <div className="flex items-center gap-2">
                  <Icon className="w-4 h-4 text-amber-200" />
                  <div className="flex-1 font-semibold text-sm">{b.name} <span className="text-white/50 text-[11px]">L{l}</span></div>
                  <span className="text-[11px] text-white/60">{Math.floor(prodPerHour(l) * miningBonus)}/hr</span>
                </div>
                <div className="text-[11px] text-white/60 mt-1">Cost: O {c.oxygen} · W {c.water} · Fe {c.iron} · He {c.helium}</div>
                <button onClick={() => upgrade(b.type)} className="mt-2 w-full rounded-md py-1.5 text-sm bg-amber-300/15 border border-amber-300/40">Upgrade to L{l + 1}</button>
              </div>
            );
          })}

          {view === 'buildings' && BUILDING_LIST.filter((b) => b.base !== 'mine').map((b) => {
            const Icon = b.icon, l = lvl(b.type), c = upgradeCost(l);
            const desc =
              b.type === 'storage_depot'    ? `Capacity: ${STORAGE_BASE + STORAGE_PER_LEVEL * Math.max(0, l - 1)}` :
              b.type === 'war_room'         ? 'Required to train units' :
              b.type === 'scanner'          ? 'Reveals nearby bases' :
              b.type === 'command_centre'   ? 'Boosts overall power' :
              b.type === 'shield_generator' ? `Defence +${l * 50} (flat)` :
              b.type === 'bunker'           ? `Defence +${l * 40} · protects ${Math.min(75, l * 25)}% loot` :
              b.type === 'research_lab'     ? 'Unlocks the Research Lab' :
              b.type === 'comm_station'     ? 'Unlocks Alliances (Comm)' :
              b.type === 'trade_pod'        ? 'Unlocks Trade Pod' : '';
            return (
              <div key={b.type} className="mb-2 rounded-md p-3 bg-white/5 border border-white/15">
                <div className="flex items-center gap-2">
                  <Icon className="w-4 h-4 text-amber-200" />
                  <div className="flex-1 font-semibold text-sm">{b.name} <span className="text-white/50 text-[11px]">L{l}</span></div>
                </div>
                <div className="text-[11px] text-white/60 mt-1">{desc}</div>
                <div className="text-[11px] text-white/60 mt-1">Cost: O {c.oxygen} · W {c.water} · Fe {c.iron} · He {c.helium}</div>
                <button onClick={() => upgrade(b.type)} className="mt-2 w-full rounded-md py-1.5 text-sm bg-amber-300/15 border border-amber-300/40">{l === 0 ? 'Build' : `Upgrade to L${l + 1}`}</button>
              </div>
            );
          })}

          {view === 'war' && (
            <>
              <div className="mb-3 text-[11px] text-white/60 italic">War Room L{lvl('war_room')}</div>
              {UNIT_LIST.map((u) => {
                const locked = u.type === 'laser_cannon' && lvl('research_lab') < 2;
                return (
                  <div key={u.type} className="mb-2 rounded-md p-3 bg-white/5 border border-white/15">
                    <div className="flex items-center gap-2">
                      <Swords className="w-4 h-4 text-amber-200" />
                      <div className="flex-1 font-semibold text-sm">{u.name} <span className="text-white/50 text-[11px]">×{unitQty(u.type)}</span></div>
                      <span className="text-[10px] text-white/60">A{u.attack}/D{u.defence}</span>
                    </div>
                    <div className="text-[11px] text-white/60 mt-1">Cost each: Fe {u.cost.iron} · He {u.cost.helium}</div>
                    {locked && <div className="text-[11px] text-rose-300 mt-1">Requires Research Lab L2</div>}
                    <div className="grid grid-cols-3 gap-2 mt-2">
                      {[1, 5, 25].map((n) => (
                        <button key={n} disabled={locked} onClick={() => train(u.type, n)}
                          className="rounded-md py-1.5 text-sm bg-amber-300/15 border border-amber-300/40 disabled:opacity-30">+{n}</button>
                      ))}
                    </div>
                  </div>
                );
              })}
              <button onClick={() => setView('scan')} className="w-full mt-2 rounded-md py-2 bg-rose-400/15 border border-rose-400/40 text-white flex items-center justify-center gap-2">
                <Crosshair className="w-4 h-4" /> Pick a target
              </button>
            </>
          )}

          {view === 'scan' && (
            <ScanList myX={base.sector_x} myY={base.sector_y}
              onAttack={(t) => { setTarget(t); setSendBuggy(0); setSendShip(0); setSendLaser(0); setView('attack'); }} />
          )}

          {view === 'attack' && target && (
            <div className="space-y-3">
              <div className="rounded-md p-3 bg-white/5 border border-white/15">
                <div className="font-semibold flex items-center gap-2"><Crosshair className="w-4 h-4 text-rose-300" /> {target.base_name}</div>
                <div className="text-[11px] text-white/60">Sector {target.sector_x},{target.sector_y} · Power {target.power_score}</div>
              </div>
              <UnitPicker label="Moonbuggy" max={unitQty('moonbuggy')} value={sendBuggy} onChange={setSendBuggy} />
              <UnitPicker label="Gunship" max={unitQty('gunship')} value={sendShip} onChange={setSendShip} />
              <UnitPicker label="Laser Cannon" max={unitQty('laser_cannon')} value={sendLaser} onChange={setSendLaser} />
              <button onClick={launchAttack} className="w-full rounded-md py-2 bg-rose-400/20 border border-rose-400/50 font-semibold">Launch attack</button>
              <button onClick={() => { setTarget(null); setView('scan'); }} className="w-full rounded-md py-2 bg-white/5 border border-white/15 text-sm">Cancel</button>
            </div>
          )}

          {view === 'research' && (
            <>
              {lvl('research_lab') < 1 ? (
                <div className="text-center text-white/60 text-sm py-6">Build a Research Lab in <b>Buildings</b> first.</div>
              ) : (
                RESEARCH_LIST.map((r) => {
                  const l = resLvl(r.type), c = researchCost(l);
                  return (
                    <div key={r.type} className="mb-2 rounded-md p-3 bg-white/5 border border-white/15">
                      <div className="flex items-center gap-2">
                        <FlaskConical className="w-4 h-4 text-amber-200" />
                        <div className="flex-1 font-semibold text-sm">{r.name} <span className="text-white/50 text-[11px]">L{l}</span></div>
                      </div>
                      <div className="text-[11px] text-white/60 mt-1">{r.desc}</div>
                      <div className="text-[11px] text-white/60 mt-1">Cost: O {c.oxygen} · W {c.water} · Fe {c.iron} · He {c.helium}</div>
                      <button onClick={() => upgradeResearch(r.type)} className="mt-2 w-full rounded-md py-1.5 text-sm bg-amber-300/15 border border-amber-300/40">Research L{l + 1}</button>
                    </div>
                  );
                })
              )}
            </>
          )}

          {view === 'comm' && (
            <CommStation
              userId={user!.id}
              hasBuilding={lvl('comm_station') >= 1}
              displayName={profile?.display_name ?? 'Commander'}
              power={base.power_score}
            />
          )}

          {view === 'trade' && (
            <TradePod
              userId={user!.id}
              baseId={base.id}
              hasBuilding={lvl('trade_pod') >= 1}
              currentRes={displayed}
              flushFirst={flushResources}
              reload={() => loadAll(base.id)}
            />
          )}

          {view === 'reports' && <Reports userId={user!.id} />}

          {view === 'colonies' && (
            <>
              <div className="text-[11px] text-white/60 italic mb-2">
                Your bases. Capital ★ is your first base. Founding pays from the <b>currently selected</b> base and requires capital Command Centre L{COLONY_REQ_CMD_LEVEL(bases.length)}.
              </div>
              {bases.map((b, i) => (
                <button key={b.id} onClick={() => switchBase(b)}
                  className="w-full mb-2 flex items-center gap-3 px-3 py-3 rounded-md bg-white/5 border border-white/15 hover:bg-white/10 active:bg-white/15 text-white">
                  <Globe2 className="w-5 h-5 text-amber-200 shrink-0" />
                  <span className="flex-1 text-left min-w-0">
                    <div className="font-semibold text-sm truncate">
                      {b.base_name} {i === 0 && <span className="text-[10px] text-amber-200">★</span>}
                    </div>
                    <div className="text-[11px] text-white/60">Sector {b.sector_x},{b.sector_y} · Pwr {b.power_score}</div>
                  </span>
                  {b.id === base.id ? <Check className="w-4 h-4 text-emerald-300" /> : <ChevronRight className="w-4 h-4 text-white/60" />}
                </button>
              ))}
              <div className="mt-3 rounded-md p-3 bg-white/5 border border-white/15">
                <div className="flex items-center gap-2 mb-1">
                  <Plus className="w-4 h-4 text-amber-200" />
                  <div className="font-semibold text-sm">Found new colony</div>
                </div>
                <div className="text-[11px] text-white/60">
                  Cost (from {base.base_name}): O {COLONY_COST.oxygen} · W {COLONY_COST.water} · Fe {COLONY_COST.iron} · He {COLONY_COST.helium}
                </div>
                <div className="text-[11px] text-white/60">
                  Requires Capital Command Centre L{COLONY_REQ_CMD_LEVEL(bases.length)}.
                </div>
                <button onClick={foundColony}
                  className="mt-2 w-full rounded-md py-1.5 text-sm bg-amber-300/15 border border-amber-300/40">
                  Found colony #{bases.length + 1}
                </button>
              </div>
            </>
          )}
        </div>
      </div>

      <div className="mxit-softkeys h-10 flex items-stretch text-sm font-medium shrink-0">
        <button onClick={back} className="flex-1 text-left pl-4 active:bg-black/30">Back</button>
        <button onClick={() => { sfx.tap(); navigate('/'); }} className="flex-1 text-right pr-4 active:bg-black/30">Home</button>
      </div>
    </div>
  );
}

/* ─── small subcomponents ─── */
function Stat({ icon: Icon, label, v, cap, rate }: any) {
  return (
    <div className="flex items-center gap-1 min-w-0">
      <Icon className="w-3 h-3 text-amber-200 shrink-0" />
      <div className="min-w-0">
        <div className="truncate text-[11px]"><b>{label}</b> {v}/{cap}</div>
        <div className="text-[9px] text-white/50">+{rate}/hr</div>
      </div>
    </div>
  );
}
function MenuRow({ icon: Icon, label, desc, onClick }: any) {
  return (
    <button onClick={onClick} className="w-full mb-2 flex items-center gap-3 px-3 py-3 rounded-md bg-white/5 border border-white/15 hover:bg-white/10 active:bg-white/15">
      <Icon className="w-5 h-5 text-amber-200 shrink-0" />
      <span className="flex-1 text-left min-w-0">
        <div className="font-semibold text-sm">{label}</div>
        <div className="text-[11px] text-white/60 truncate">{desc}</div>
      </span>
      <ChevronRight className="w-4 h-4 text-white/60" />
    </button>
  );
}
function UnitPicker({ label, max, value, onChange }: { label: string; max: number; value: number; onChange: (n: number) => void }) {
  return (
    <div className="rounded-md p-3 bg-white/5 border border-white/15">
      <div className="flex items-center justify-between text-sm mb-2"><span>{label}</span><span className="text-white/50">{value} / {max}</span></div>
      <input type="range" min={0} max={Math.max(0, max)} value={value} onChange={(e) => onChange(parseInt(e.target.value))} className="w-full" disabled={max === 0} />
    </div>
  );
}

function ScanList({ myX, myY, onAttack }: { myX: number; myY: number; onAttack: (b: Base) => void }) {
  const [list, setList] = useState<Base[]>([]);
  useEffect(() => {
    (async () => {
      const { data } = await supabase.from('moonbase_bases').select('*').eq('is_bot', true).order('power_score');
      setList(((data ?? []) as Base[])
        .map((b) => ({ ...b, _dist: Math.abs(b.sector_x - myX) + Math.abs(b.sector_y - myY) } as any))
        .sort((a: any, b: any) => a._dist - b._dist));
    })();
  }, [myX, myY]);
  return (
    <>
      <div className="text-[11px] text-white/60 italic mb-2">Nearby Moonbases (sorted by distance)</div>
      {list.map((b: any) => (
        <button key={b.id} onClick={() => onAttack(b)} className="w-full mb-2 flex items-center gap-3 px-3 py-2 rounded-md bg-white/5 border border-white/15 hover:bg-white/10 active:bg-white/15 text-white">
          <Radar className="w-4 h-4 text-amber-200 shrink-0" />
          <span className="flex-1 text-left min-w-0">
            <div className="font-semibold text-sm truncate">{b.base_name}</div>
            <div className="text-[11px] text-white/60">Dist {b._dist} · Pwr {b.power_score}</div>
          </span>
          <Crosshair className="w-4 h-4 text-rose-300" />
        </button>
      ))}
    </>
  );
}

function Reports({ userId }: { userId: string }) {
  const [rows, setRows] = useState<any[]>([]);
  useEffect(() => {
    (async () => {
      const { data } = await supabase.from('moonbase_reports').select('*').eq('user_id', userId).order('created_at', { ascending: false }).limit(40);
      setRows(data ?? []);
    })();
  }, [userId]);
  if (rows.length === 0) return <div className="text-center text-white/60 text-sm py-6">No reports yet.</div>;
  return (
    <>
      {rows.map((r) => (
        <div key={r.id} className="mb-2 rounded-md p-3 bg-white/5 border border-white/15">
          <div className="font-semibold text-sm flex items-center gap-2"><Trophy className="w-4 h-4 text-amber-200" /> {r.title}</div>
          <pre className="text-[11px] text-white/70 mt-1 whitespace-pre-wrap font-sans">{r.body}</pre>
          <div className="text-[10px] text-white/40 mt-1">{new Date(r.created_at).toLocaleString()}</div>
        </div>
      ))}
    </>
  );
}

/* ─── Comm Station / Alliances ─── */
function CommStation({ userId, hasBuilding, displayName, power }: { userId: string; hasBuilding: boolean; displayName: string; power: number }) {
  const [my, setMy] = useState<{ alliance_id: string; role: string } | null>(null);
  const [alli, setAlli] = useState<any | null>(null);
  const [list, setList] = useState<any[]>([]);
  const [members, setMembers] = useState<any[]>([]);
  const [name, setName] = useState(''); const [tag, setTag] = useState(''); const [desc, setDesc] = useState('');
  const [msgs, setMsgs] = useState<any[]>([]);
  const [text, setText] = useState('');
  const scrollRef = useRef<HTMLDivElement>(null);

  const reload = async () => {
    const { data: m } = await supabase.from('moonbase_alliance_members').select('alliance_id, role').eq('user_id', userId).maybeSingle();
    setMy(m as any);
    if (m) {
      const { data: a } = await supabase.from('moonbase_alliances').select('*').eq('id', (m as any).alliance_id).single();
      setAlli(a);
      const { data: mems } = await supabase.from('moonbase_alliance_members').select('user_id, role, joined_at').eq('alliance_id', (m as any).alliance_id);
      setMembers(mems ?? []);
      const { data: ms } = await supabase.from('moonbase_alliance_messages').select('*').eq('alliance_id', (m as any).alliance_id).order('created_at').limit(100);
      setMsgs(ms ?? []);
    } else {
      const { data: l } = await supabase.from('moonbase_alliances').select('*').order('power_score', { ascending: false }).limit(30);
      setList(l ?? []);
    }
  };
  useEffect(() => { if (hasBuilding) reload(); }, [hasBuilding, userId]);

  // Realtime alliance chat
  useEffect(() => {
    if (!my) return;
    const ch = supabase
      .channel(`alliance-${my.alliance_id}`)
      .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'moonbase_alliance_messages', filter: `alliance_id=eq.${my.alliance_id}` },
        (payload) => setMsgs((cur) => [...cur, payload.new as any]))
      .subscribe();
    return () => { supabase.removeChannel(ch); };
  }, [my?.alliance_id]);

  useEffect(() => { scrollRef.current?.scrollTo({ top: 1e9 }); }, [msgs.length]);

  if (!hasBuilding) return <div className="text-center text-white/60 text-sm py-6">Build a Comm Station in <b>Buildings</b> first.</div>;

  if (my && alli) {
    return (
      <div className="space-y-3">
        <div className="rounded-md p-3 bg-white/5 border border-white/15">
          <div className="font-semibold flex items-center gap-2"><Users className="w-4 h-4 text-amber-200" /> [{alli.tag}] {alli.name}</div>
          {alli.description && <div className="text-[11px] text-white/60 mt-1">{alli.description}</div>}
          <div className="text-[11px] text-white/60 mt-1">Members: {members.length} · Role: {my.role}</div>
        </div>

        <div className="rounded-md bg-white/5 border border-white/15 flex flex-col h-72">
          <div className="text-[11px] text-white/60 px-3 py-1 border-b border-white/10">Alliance Chat</div>
          <div ref={scrollRef} className="flex-1 overflow-y-auto p-2 space-y-1 text-[12px]">
            {msgs.length === 0 && <div className="text-white/40 text-center text-[11px] py-4">No messages yet.</div>}
            {msgs.map((m) => (
              <div key={m.id} className={`px-2 py-1 rounded ${m.user_id === userId ? 'bg-amber-300/10 ml-8' : 'bg-white/5 mr-8'}`}>
                <div className="text-[10px] text-white/40">{new Date(m.created_at).toLocaleTimeString()}</div>
                <div>{m.content}</div>
              </div>
            ))}
          </div>
          <div className="p-2 border-t border-white/10 flex gap-2">
            <input value={text} onChange={(e) => setText(e.target.value)}
              onKeyDown={async (e) => {
                if (e.key === 'Enter' && text.trim()) {
                  const t = text.trim(); setText('');
                  await supabase.from('moonbase_alliance_messages').insert({ alliance_id: my.alliance_id, user_id: userId, content: t });
                }
              }}
              placeholder="Message…"
              className="flex-1 bg-white/10 border border-white/20 rounded px-2 py-1 text-sm" />
            <button onClick={async () => {
              if (!text.trim()) return;
              const t = text.trim(); setText('');
              await supabase.from('moonbase_alliance_messages').insert({ alliance_id: my.alliance_id, user_id: userId, content: t });
            }} className="px-3 rounded bg-amber-300/20 border border-amber-300/40"><Send className="w-3 h-3" /></button>
          </div>
        </div>

        <button onClick={async () => {
          if (!confirm('Leave alliance?')) return;
          await supabase.from('moonbase_alliance_members').delete().eq('user_id', userId);
          toast.success('Left alliance'); reload();
        }} className="w-full rounded-md py-1.5 text-sm bg-rose-400/15 border border-rose-400/40">Leave alliance</button>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="rounded-md p-3 bg-white/5 border border-white/15">
        <div className="font-semibold text-sm mb-2">Create alliance</div>
        <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Alliance name" className="w-full mb-1 bg-white/10 border border-white/20 rounded px-2 py-1 text-sm" />
        <input value={tag} onChange={(e) => setTag(e.target.value.toUpperCase().slice(0, 5))} placeholder="Tag (e.g. WOLF)" className="w-full mb-1 bg-white/10 border border-white/20 rounded px-2 py-1 text-sm" />
        <input value={desc} onChange={(e) => setDesc(e.target.value)} placeholder="Description (optional)" className="w-full mb-2 bg-white/10 border border-white/20 rounded px-2 py-1 text-sm" />
        <button onClick={async () => {
          if (!name.trim() || !tag.trim()) { toast.error('Name & tag required'); return; }
          const ins = await supabase.from('moonbase_alliances').insert({
            name: name.trim(), tag: tag.trim(), description: desc.trim() || null, founder_user_id: userId, power_score: power,
          }).select('*').single();
          if (ins.error) { toast.error(ins.error.message); return; }
          await supabase.from('moonbase_alliance_members').insert({ alliance_id: ins.data.id, user_id: userId, role: 'founder' });
          toast.success('Alliance founded!'); reload();
        }} className="w-full rounded-md py-1.5 text-sm bg-amber-300/15 border border-amber-300/40">Found alliance</button>
      </div>

      <div className="text-[11px] text-white/60 italic">Or join an existing alliance</div>
      {list.length === 0 && <div className="text-center text-white/40 text-sm py-2">No alliances yet — be the first.</div>}
      {list.map((a) => (
        <div key={a.id} className="rounded-md p-3 bg-white/5 border border-white/15 flex items-center gap-2">
          <Users className="w-4 h-4 text-amber-200" />
          <div className="flex-1 min-w-0">
            <div className="font-semibold text-sm truncate">[{a.tag}] {a.name}</div>
            {a.description && <div className="text-[11px] text-white/60 truncate">{a.description}</div>}
          </div>
          <button onClick={async () => {
            const ins = await supabase.from('moonbase_alliance_members').insert({ alliance_id: a.id, user_id: userId, role: 'member' });
            if (ins.error) { toast.error(ins.error.message); return; }
            toast.success(`Joined [${a.tag}]`); reload();
          }} className="px-3 py-1 text-xs rounded bg-amber-300/15 border border-amber-300/40">Join</button>
        </div>
      ))}
    </div>
  );
}

/* ─── Trade Pod ─── */
function TradePod({ userId, baseId, hasBuilding, currentRes, flushFirst, reload }: {
  userId: string; baseId: string; hasBuilding: boolean;
  currentRes: { oxygen: number; water: number; iron: number; helium: number };
  flushFirst: () => Promise<any>;
  reload: () => Promise<void>;
}) {
  const [offers, setOffers] = useState<any[]>([]);
  const [give, setGive] = useState({ oxygen: 0, water: 0, iron: 0, helium: 0 });
  const [want, setWant] = useState({ oxygen: 0, water: 0, iron: 0, helium: 0 });

  const loadOffers = async () => {
    const { data } = await supabase.from('moonbase_trade_offers').select('*').eq('status', 'open').order('created_at', { ascending: false }).limit(40);
    setOffers(data ?? []);
  };
  useEffect(() => { if (hasBuilding) loadOffers(); }, [hasBuilding]);

  if (!hasBuilding) return <div className="text-center text-white/60 text-sm py-6">Build a Trade Pod in <b>Buildings</b> first.</div>;

  const totalGive = give.oxygen + give.water + give.iron + give.helium;
  const totalWant = want.oxygen + want.water + want.iron + want.helium;

  const create = async () => {
    if (totalGive === 0 || totalWant === 0) { toast.error('Set give & want amounts'); return; }
    const cur = await flushFirst(); if (!cur) return;
    if (cur.oxygen < give.oxygen || cur.water < give.water || cur.iron < give.iron || cur.helium < give.helium) {
      toast.error('Not enough to give'); return;
    }
    const ins = await supabase.from('moonbase_trade_offers').insert({
      seller_user_id: userId, seller_base_id: baseId,
      give_oxygen: give.oxygen, give_water: give.water, give_iron: give.iron, give_helium: give.helium,
      want_oxygen: want.oxygen, want_water: want.water, want_iron: want.iron, want_helium: want.helium,
    });
    if (ins.error) { toast.error(ins.error.message); return; }
    toast.success('Offer posted');
    setGive({ oxygen: 0, water: 0, iron: 0, helium: 0 });
    setWant({ oxygen: 0, water: 0, iron: 0, helium: 0 });
    loadOffers();
  };

  const accept = async (id: string) => {
    const { error } = await supabase.rpc('accept_moonbase_trade', { _offer: id });
    if (error) { toast.error(error.message); return; }
    toast.success('Trade complete!');
    await reload();
    loadOffers();
  };

  const cancel = async (id: string) => {
    await supabase.from('moonbase_trade_offers').update({ status: 'cancelled', resolved_at: new Date().toISOString() }).eq('id', id);
    toast('Offer cancelled'); loadOffers();
  };

  const fmt = (o: any, prefix: 'give' | 'want') => {
    const parts = [];
    if (o[`${prefix}_oxygen`]) parts.push(`O ${o[`${prefix}_oxygen`]}`);
    if (o[`${prefix}_water`])  parts.push(`W ${o[`${prefix}_water`]}`);
    if (o[`${prefix}_iron`])   parts.push(`Fe ${o[`${prefix}_iron`]}`);
    if (o[`${prefix}_helium`]) parts.push(`He ${o[`${prefix}_helium`]}`);
    return parts.join(' · ') || '—';
  };

  return (
    <div className="space-y-3">
      <div className="rounded-md p-3 bg-white/5 border border-white/15">
        <div className="font-semibold text-sm mb-2 flex items-center gap-2"><Store className="w-4 h-4 text-amber-200" /> New offer</div>
        <div className="text-[11px] text-white/60 mb-1">You give:</div>
        <ResRow values={give} setValues={setGive} max={currentRes} />
        <div className="text-[11px] text-white/60 mb-1 mt-2">You want:</div>
        <ResRow values={want} setValues={setWant} max={{ oxygen: 99999, water: 99999, iron: 99999, helium: 99999 }} />
        <button onClick={create} className="w-full mt-2 rounded-md py-1.5 text-sm bg-amber-300/15 border border-amber-300/40">Post offer</button>
      </div>

      <div className="text-[11px] text-white/60 italic">Open market</div>
      {offers.length === 0 && <div className="text-center text-white/40 text-sm py-2">No open offers.</div>}
      {offers.map((o) => {
        const mine = o.seller_user_id === userId;
        return (
          <div key={o.id} className="rounded-md p-3 bg-white/5 border border-white/15 text-sm">
            <div className="text-[11px] text-white/60">Give</div>
            <div className="text-amber-200">{fmt(o, 'give')}</div>
            <div className="text-[11px] text-white/60 mt-1">Want</div>
            <div className="text-emerald-200">{fmt(o, 'want')}</div>
            <button
              onClick={() => mine ? cancel(o.id) : accept(o.id)}
              className={`w-full mt-2 rounded-md py-1.5 text-sm border ${mine ? 'bg-rose-400/10 border-rose-400/40' : 'bg-emerald-400/10 border-emerald-400/40'}`}>
              {mine ? 'Cancel my offer' : 'Accept'}
            </button>
          </div>
        );
      })}
    </div>
  );
}

function ResRow({ values, setValues, max }: { values: any; setValues: (v: any) => void; max: any }) {
  const fields: { k: 'oxygen' | 'water' | 'iron' | 'helium'; label: string }[] = [
    { k: 'oxygen', label: 'O₂' }, { k: 'water', label: 'H₂O' }, { k: 'iron', label: 'Fe' }, { k: 'helium', label: 'He' },
  ];
  return (
    <div className="grid grid-cols-2 gap-2">
      {fields.map((f) => (
        <label key={f.k} className="flex items-center gap-1 text-[11px]">
          <span className="w-8 text-white/60">{f.label}</span>
          <input type="number" min={0} max={max[f.k]} value={values[f.k]}
            onChange={(e) => setValues({ ...values, [f.k]: Math.max(0, Math.min(max[f.k], parseInt(e.target.value || '0'))) })}
            className="flex-1 bg-white/10 border border-white/20 rounded px-1 py-0.5 text-xs" />
        </label>
      ))}
    </div>
  );
}
