/**
 * Tradepost > Weather — pick a SA city, see a 5-day forecast.
 * Forecast is deterministic per (city, date) so it's stable for the day.
 * Free to use; 1 Moola unlocks an "extended" 7-day view.
 */
import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { spendMoola } from '@/lib/moola';
import { sfx } from '@/lib/sfx';
import { toast } from 'sonner';
import { Coins, CloudSun, Cloud, CloudRain, Sun, CloudSnow, CloudLightning } from 'lucide-react';

const CITIES = [
  'Cape Town', 'Durban', 'Jozi', 'Pretoria', 'Gqeberha (PE)',
  'East London', 'Bloemfontein', 'Pietermaritzburg', 'Polokwane',
  'Nelspruit', 'Kimberley',
];

const ICONS = [Sun, CloudSun, Cloud, CloudRain, CloudLightning, CloudSnow] as const;
const CONDS = ['Sunny', 'Partly cloudy', 'Cloudy', 'Rain', 'Thunder', 'Cool & windy'];

function hash(str: string) {
  let h = 2166136261;
  for (let i = 0; i < str.length; i++) { h ^= str.charCodeAt(i); h = Math.imul(h, 16777619); }
  return Math.abs(h);
}

function dayForecast(city: string, dayOffset: number) {
  const d = new Date(); d.setDate(d.getDate() + dayOffset);
  const key = `${city}-${d.toISOString().slice(0, 10)}`;
  const h = hash(key);
  const ci = h % 6;
  const Hi = 12 + (h % 22);
  const Lo = Math.max(2, Hi - 6 - ((h >> 4) % 6));
  return {
    label: dayOffset === 0 ? 'Today' : d.toLocaleDateString(undefined, { weekday: 'short' }),
    Icon: ICONS[ci],
    cond: CONDS[ci],
    hi: Hi,
    lo: Lo,
    rain: (h >> 8) % 100,
  };
}

export default function TradepostWeather() {
  const { profile } = useAuth();
  const navigate = useNavigate();
  const [city, setCity] = useState<string | null>(null);
  const [extended, setExtended] = useState(false);

  const days = useMemo(
    () => city ? Array.from({ length: extended ? 7 : 5 }, (_, i) => dayForecast(city, i)) : [],
    [city, extended],
  );

  const unlock = async () => {
    if (!profile) return;
    const ok = await spendMoola({
      userId: profile.id,
      currentBalance: profile.moola,
      amount: 1,
      reason: 'Weather — 7-day extended',
      type: 'spend',
    });
    if (ok) { setExtended(true); toast.success('Extended forecast unlocked'); }
  };

  return (
    <div className="flex-1 min-h-0 flex flex-col mxit-classic-bg">
      <div className="mxit-titlebar h-9 flex items-center px-3 gap-2 shrink-0">
        <button onClick={() => { sfx.tap(); city ? setCity(null) : navigate('/tradepost'); }}
          className="text-[11px] px-2 py-0.5 rounded-sm bg-white/10 border border-white/20">‹ Back</button>
        <div className="flex-1 text-center font-semibold text-[15px] tracking-wide flex items-center justify-center gap-2">
          <CloudSun className="w-4 h-4" /> Weather
        </div>
        <span className="text-[10px] text-amber-200 flex items-center gap-1">
          <Coins className="w-3 h-3" /> {profile?.moola ?? 0}
        </span>
      </div>

      <div className="relative flex-1 overflow-y-auto mxit-watermark min-h-0">
        <div className="relative z-10 p-3">
          {!city ? (
            <>
              <div className="text-[11px] text-white/60 italic mb-2">Pick a city.</div>
              <div className="space-y-1">
                {CITIES.map((c) => (
                  <button
                    key={c}
                    onClick={() => { sfx.tap(); setCity(c); setExtended(false); }}
                    className="w-full text-left flex items-center gap-2 px-3 py-2 rounded-md bg-white/5 border border-white/15 hover:bg-white/10 active:bg-white/15 text-white"
                  >
                    <CloudSun className="w-4 h-4 text-sky-300" />
                    <span className="flex-1 text-sm">{c}</span>
                  </button>
                ))}
              </div>
            </>
          ) : (
            <div className="space-y-2">
              <div className="text-center text-white">
                <div className="text-lg font-semibold">{city}</div>
                <div className="text-[11px] text-white/50">{new Date().toLocaleDateString(undefined, { weekday: 'long', day: 'numeric', month: 'long' })}</div>
              </div>
              {days.map((d, i) => {
                const Icon = d.Icon;
                return (
                  <div
                    key={i}
                    className="flex items-center gap-3 px-3 py-2 rounded-md bg-white/5 border border-white/15 text-white"
                  >
                    <Icon className="w-6 h-6 text-amber-200" />
                    <div className="flex-1 min-w-0">
                      <div className="text-sm font-medium">{d.label}</div>
                      <div className="text-[11px] text-white/60">{d.cond} · {d.rain}% rain</div>
                    </div>
                    <div className="text-right text-sm">
                      <span className="font-semibold">{d.hi}°</span>
                      <span className="text-white/50"> / {d.lo}°</span>
                    </div>
                  </div>
                );
              })}
              {!extended && (
                <button
                  onClick={unlock}
                  className="w-full rounded-md py-2 text-[12px] flex items-center justify-center gap-2 bg-amber-300/15 border border-amber-300/40 text-white hover:bg-amber-300/25"
                >
                  Unlock 7-day forecast — 1 Moola
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      <div className="mxit-softkeys h-10 flex items-stretch text-sm font-medium shrink-0">
        <button onClick={() => { sfx.tap(); city ? setCity(null) : navigate('/tradepost'); }} className="flex-1 text-left pl-4 active:bg-black/30">Back</button>
        <button onClick={() => { sfx.tap(); navigate('/'); }} className="flex-1 text-right pr-4 active:bg-black/30">Home</button>
      </div>
    </div>
  );
}
