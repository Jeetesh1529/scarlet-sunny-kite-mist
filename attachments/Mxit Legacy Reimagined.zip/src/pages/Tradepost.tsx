/**
 * Tradepost — the classic Mxit shopping mall / service hub.
 * Lists default services (Chat Rooms, Games, Emoticards, Skinz, Horoscopes, Weather, Mobi).
 * Costs in Moola are advertised; chat rooms entry leads to /tradepost/chatrooms.
 */
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { sfx } from '@/lib/sfx';
import {
  MessagesSquare, Gamepad2, Sparkles, Palette, Stars, CloudSun, Bot,
  ChevronRight, Coins, Store, Music, MessageCircle, BarChart3, Grid3x3,
} from 'lucide-react';

const ICONS: Record<string, React.ComponentType<{ className?: string }>> = {
  MessagesSquare, Gamepad2, Sparkles, Palette, Stars, CloudSun, Bot,
  Music, MessageCircle, BarChart3, Grid3x3,
};

type Service = {
  id: string;
  slug: string;
  name: string;
  description: string | null;
  icon: string | null;
  route: string | null;
  cost_moola: number;
  position: number;
};

export default function Tradepost() {
  const navigate = useNavigate();
  const { profile } = useAuth();
  const [services, setServices] = useState<Service[]>([]);

  useEffect(() => {
    (async () => {
      const { data } = await supabase
        .from('tradepost_services')
        .select('*')
        .eq('enabled', true)
        .order('position');
      setServices((data ?? []) as Service[]);
    })();
  }, []);

  const open = (s: Service) => {
    sfx.tap();
    if (!s.route) return;
    navigate(s.route);
  };

  return (
    <div className="flex-1 min-h-0 flex flex-col mxit-classic-bg">
      {/* Title bar */}
      <div className="mxit-titlebar h-9 flex items-center px-3 gap-2 shrink-0">
        <button
          onClick={() => { sfx.tap(); navigate('/'); }}
          className="text-[11px] px-2 py-0.5 rounded-sm bg-white/10 border border-white/20"
        >
          ‹ Back
        </button>
        <div className="flex-1 text-center font-semibold text-[15px] tracking-wide flex items-center justify-center gap-2">
          <Store className="w-4 h-4" /> Tradepost
        </div>
        <span className="text-[11px] flex items-center gap-1 text-amber-200">
          <Coins className="w-3 h-3" /> {profile?.moola ?? 0}
        </span>
      </div>

      {/* List */}
      <div className="relative flex-1 overflow-y-auto mxit-watermark min-h-0">
        <div className="relative z-10 py-2">
          <div className="px-3 pb-2 text-[11px] text-white/60 italic">
            Welcome to the Tradepost. Spend Moola on chat zones, games, emoticards, skinz and more.
          </div>
          {services.map((s) => {
            const Icon = (s.icon && ICONS[s.icon]) || Sparkles;
            return (
              <button
                key={s.id}
                onClick={() => open(s)}
                className="w-full text-left flex items-center gap-3 pl-3 pr-3 py-2 hover:bg-white/5 active:bg-white/10"
              >
                <span className="w-8 h-8 rounded-md bg-white/10 border border-white/20 flex items-center justify-center text-white shrink-0">
                  <Icon className="w-4 h-4" />
                </span>
                <span
                  className="flex-1 min-w-0 truncate text-white font-medium tracking-wide"
                  style={{ textShadow: '0 1px 0 hsl(220 80% 8% / 0.6)' }}
                >
                  {s.name}
                  {s.description && (
                    <span className="block text-[11px] font-normal text-white/60 truncate">
                      {s.description}
                    </span>
                  )}
                </span>
                {s.cost_moola > 0 && (
                  <span className="text-[10px] text-amber-200 flex items-center gap-0.5 mr-1">
                    <Coins className="w-3 h-3" /> {s.cost_moola}
                  </span>
                )}
                <ChevronRight className="w-4 h-4 text-white/60" />
              </button>
            );
          })}
        </div>
      </div>

      {/* Soft-keys */}
      <div className="mxit-softkeys h-10 flex items-stretch text-sm font-medium shrink-0">
        <button
          onClick={() => { sfx.tap(); navigate('/'); }}
          className="flex-1 text-left pl-4 active:bg-black/30"
        >
          Back
        </button>
        <button
          onClick={() => { sfx.tap(); navigate('/portal/portal'); }}
          className="flex-1 text-right pr-4 active:bg-black/30"
        >
          Top up
        </button>
      </div>
    </div>
  );
}
