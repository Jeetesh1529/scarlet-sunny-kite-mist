import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';
import { PixelAvatar } from '@/components/PixelAvatar';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { ChevronLeft, Cake, MessageCircle, Trash2, QrCode } from 'lucide-react';
import { toast } from 'sonner';
import { sfx } from '@/lib/sfx';
import { QRCodeSVG } from 'qrcode.react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { AchievementsPanel } from '@/components/AchievementsPanel';

type ProfileRow = {
  id: string;
  mxit_id: string;
  display_name: string;
  mood: string | null;
  avatar_seed: string | null;
  avatar_url: string | null;
  tags: string[];
  birthday: string | null;
  presence: string;
};

type MoodEntry = { id: string; mood: string; created_at: string };
type Guest = { id: string; author_id: string; body: string; created_at: string; author_name?: string };

export default function ProfileView() {
  const { mxitId } = useParams();
  const { profile: me } = useAuth();
  const navigate = useNavigate();
  const [p, setP] = useState<ProfileRow | null>(null);
  const [moods, setMoods] = useState<MoodEntry[]>([]);
  const [guests, setGuests] = useState<Guest[]>([]);
  const [note, setNote] = useState('');
  const [busy, setBusy] = useState(false);
  const [qrOpen, setQrOpen] = useState(false);

  useEffect(() => {
    if (!mxitId) return;
    (async () => {
      const { data: prof } = await supabase
        .from('profiles')
        .select('id, mxit_id, display_name, mood, avatar_seed, avatar_url, tags, birthday, presence')
        .eq('mxit_id', mxitId.toLowerCase())
        .maybeSingle();
      if (!prof) { toast.error('User not found'); navigate('/'); return; }
      setP(prof as ProfileRow);

      const [{ data: mh }, { data: gb }] = await Promise.all([
        supabase.from('mood_history').select('id, mood, created_at').eq('user_id', prof.id).order('created_at', { ascending: false }).limit(20),
        supabase.from('guestbook_entries').select('id, author_id, body, created_at').eq('profile_id', prof.id).order('created_at', { ascending: false }).limit(50),
      ]);
      setMoods((mh ?? []) as MoodEntry[]);
      const entries = (gb ?? []) as Guest[];
      if (entries.length) {
        const ids = Array.from(new Set(entries.map((e) => e.author_id)));
        const { data: authors } = await supabase.from('profiles').select('id, display_name').in('id', ids);
        const map = new Map((authors ?? []).map((a) => [a.id, a.display_name]));
        setGuests(entries.map((e) => ({ ...e, author_name: map.get(e.author_id) ?? '…' })));
      } else {
        setGuests([]);
      }
    })();
  }, [mxitId, navigate]);

  const sign = async () => {
    if (!me || !p || !note.trim()) return;
    setBusy(true);
    const body = note.trim().slice(0, 280);
    const { data, error } = await supabase.from('guestbook_entries').insert({
      profile_id: p.id, author_id: me.id, body,
    }).select('id, author_id, body, created_at').single();
    setBusy(false);
    if (error) { toast.error(error.message); return; }
    setGuests((g) => [{ ...(data as Guest), author_name: me.display_name }, ...g]);
    setNote('');
    sfx.send();
    toast.success('Signed!');
  };

  const remove = async (id: string) => {
    await supabase.from('guestbook_entries').delete().eq('id', id);
    setGuests((g) => g.filter((x) => x.id !== id));
  };

  const startChat = async () => {
    if (!me || !p || me.id === p.id) return;
    const [a, b] = [me.id, p.id].sort();
    const { data: existing } = await supabase.from('conversations').select('id').eq('user_a', a).eq('user_b', b).maybeSingle();
    let convId = existing?.id;
    if (!convId) {
      const { data, error } = await supabase.from('conversations').insert({ user_a: a, user_b: b }).select('id').single();
      if (error) { toast.error(error.message); return; }
      convId = data.id;
    }
    navigate(`/chat/${convId}`);
  };

  if (!p) return <div className="p-6 text-center text-sm text-muted-foreground">Loading…</div>;

  const isMe = me?.id === p.id;
  const profileUrl = `${window.location.origin}/u/${p.mxit_id}`;
  const today = p.birthday && (() => {
    const d = new Date(p.birthday);
    const now = new Date();
    return d.getMonth() === now.getMonth() && d.getDate() === now.getDate();
  })();

  return (
    <div className="flex-1 min-h-0 flex flex-col bg-background overflow-y-auto">
      <div className="mxit-titlebar h-9 flex items-center px-3 gap-2 shrink-0">
        <button onClick={() => navigate(-1)} className="flex items-center gap-1"><ChevronLeft className="w-4 h-4" /> Back</button>
        <div className="flex-1 text-center font-semibold text-[15px] truncate">{p.display_name}</div>
        <button onClick={() => setQrOpen(true)} aria-label="QR card"><QrCode className="w-4 h-4" /></button>
      </div>

      <div className="p-4 space-y-4 max-w-md mx-auto w-full">
        {today && (
          <div className="bg-mxit-moola/20 border border-mxit-moola/40 rounded-lg p-3 flex items-center gap-2 text-sm">
            <Cake className="w-5 h-5 text-mxit-moola" />
            <span>It's <strong>{p.display_name}</strong>'s birthday today! 🎂</span>
          </div>
        )}

        <section className="bg-card rounded-lg p-4 mxit-shadow-pop flex items-center gap-3">
          <PixelAvatar seed={p.avatar_seed} url={p.avatar_url} size={72} />
          <div className="flex-1 min-w-0">
            <div className="font-pixel text-xs text-mxit-deep">@{p.mxit_id}</div>
            <div className="font-medium mt-1 truncate">{p.display_name}</div>
            {p.mood && <div className="text-xs text-muted-foreground italic mt-0.5">{p.mood}</div>}
          </div>
          {!isMe && (
            <Button onClick={startChat} size="sm" className="font-pixel text-[10px]">
              <MessageCircle className="w-3 h-3 mr-1" /> chat
            </Button>
          )}
        </section>

        {p.tags.length > 0 && (
          <section className="bg-card rounded-lg p-3 mxit-shadow-pop">
            <h3 className="font-pixel text-[10px] text-mxit-primary mb-2">TAGZ</h3>
            <div className="flex flex-wrap gap-1.5">
              {p.tags.map((t) => (
                <span key={t} className="text-xs px-2 py-1 rounded-full bg-mxit-primary/15 text-mxit-primary border border-mxit-primary/30">
                  #{t}
                </span>
              ))}
            </div>
          </section>
        )}

        {moods.length > 0 && (
          <section className="bg-card rounded-lg p-3 mxit-shadow-pop">
            <h3 className="font-pixel text-[10px] text-mxit-primary mb-2">MOOD HISTORY</h3>
            <ul className="space-y-1 text-xs">
              {moods.slice(0, 8).map((m) => (
                <li key={m.id} className="flex justify-between text-muted-foreground">
                  <span className="text-foreground">{m.mood}</span>
                  <span>{new Date(m.created_at).toLocaleDateString()}</span>
                </li>
              ))}
            </ul>
          </section>
        )}

        <section className="bg-card rounded-lg p-3 mxit-shadow-pop">
          <h3 className="font-pixel text-[10px] text-mxit-primary mb-2">ACHIEVEMENTS</h3>
          <AchievementsPanel userId={p.id} />
        </section>

        <section className="bg-card rounded-lg p-3 mxit-shadow-pop">
          <h3 className="font-pixel text-[10px] text-mxit-primary mb-2">GUESTBOOK ({guests.length})</h3>
          {!isMe && (
            <div className="flex gap-2 mb-3">
              <Textarea
                value={note}
                onChange={(e) => setNote(e.target.value)}
                placeholder={`Leave ${p.display_name} a note…`}
                rows={2}
                maxLength={280}
                className="text-sm"
              />
              <Button onClick={sign} disabled={!note.trim() || busy} size="sm">Sign</Button>
            </div>
          )}
          {guests.length === 0 ? (
            <p className="text-xs text-muted-foreground italic text-center py-2">No notes yet.</p>
          ) : (
            <ul className="space-y-2">
              {guests.map((g) => (
                <li key={g.id} className="text-sm border-b border-border pb-2 last:border-0">
                  <div className="flex items-center justify-between text-[10px] text-muted-foreground mb-0.5">
                    <span className="font-semibold text-mxit-primary">{g.author_name}</span>
                    <span className="flex items-center gap-2">
                      {new Date(g.created_at).toLocaleDateString()}
                      {(me?.id === g.author_id || isMe) && (
                        <button onClick={() => remove(g.id)} aria-label="delete"><Trash2 className="w-3 h-3 text-destructive" /></button>
                      )}
                    </span>
                  </div>
                  <p className="break-words">{g.body}</p>
                </li>
              ))}
            </ul>
          )}
        </section>
      </div>

      <Dialog open={qrOpen} onOpenChange={setQrOpen}>
        <DialogContent className="max-w-xs">
          <DialogHeader><DialogTitle className="font-pixel text-sm">scan to add</DialogTitle></DialogHeader>
          <div className="flex flex-col items-center gap-3 p-4 bg-white rounded">
            <QRCodeSVG value={profileUrl} size={200} />
            <div className="text-xs text-black/70">@{p.mxit_id}</div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
