export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      achievements: {
        Row: {
          created_at: string
          description: string
          icon: string
          id: string
          moola_reward: number
          name: string
          position: number
          tier: string
        }
        Insert: {
          created_at?: string
          description: string
          icon?: string
          id: string
          moola_reward?: number
          name: string
          position?: number
          tier?: string
        }
        Update: {
          created_at?: string
          description?: string
          icon?: string
          id?: string
          moola_reward?: number
          name?: string
          position?: number
          tier?: string
        }
        Relationships: []
      }
      analytics_events: {
        Row: {
          created_at: string
          event: string
          id: string
          properties: Json
          route: string | null
          session_id: string | null
          user_agent: string | null
          user_id: string | null
        }
        Insert: {
          created_at?: string
          event: string
          id?: string
          properties?: Json
          route?: string | null
          session_id?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Update: {
          created_at?: string
          event?: string
          id?: string
          properties?: Json
          route?: string | null
          session_id?: string | null
          user_agent?: string | null
          user_id?: string | null
        }
        Relationships: []
      }
      announcement_dismissals: {
        Row: {
          announcement_id: string
          dismissed_at: string
          id: string
          user_id: string
        }
        Insert: {
          announcement_id: string
          dismissed_at?: string
          id?: string
          user_id: string
        }
        Update: {
          announcement_id?: string
          dismissed_at?: string
          id?: string
          user_id?: string
        }
        Relationships: []
      }
      announcements: {
        Row: {
          author_id: string
          body: string
          created_at: string
          ends_at: string | null
          id: string
          severity: string
          starts_at: string
          title: string
        }
        Insert: {
          author_id: string
          body: string
          created_at?: string
          ends_at?: string | null
          id?: string
          severity?: string
          starts_at?: string
          title: string
        }
        Update: {
          author_id?: string
          body?: string
          created_at?: string
          ends_at?: string | null
          id?: string
          severity?: string
          starts_at?: string
          title?: string
        }
        Relationships: []
      }
      calls: {
        Row: {
          answer: Json | null
          callee_ice: Json
          callee_id: string
          caller_ice: Json
          caller_id: string
          ended_at: string | null
          id: string
          kind: string
          offer: Json | null
          started_at: string
          status: string
          updated_at: string
        }
        Insert: {
          answer?: Json | null
          callee_ice?: Json
          callee_id: string
          caller_ice?: Json
          caller_id: string
          ended_at?: string | null
          id?: string
          kind?: string
          offer?: Json | null
          started_at?: string
          status?: string
          updated_at?: string
        }
        Update: {
          answer?: Json | null
          callee_ice?: Json
          callee_id?: string
          caller_ice?: Json
          caller_id?: string
          ended_at?: string | null
          id?: string
          kind?: string
          offer?: Json | null
          started_at?: string
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      chat_categories: {
        Row: {
          created_at: string
          description: string | null
          id: string
          is_active: boolean
          min_age: number
          name: string
          position: number
          slug: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          min_age?: number
          name: string
          position?: number
          slug: string
        }
        Update: {
          created_at?: string
          description?: string | null
          id?: string
          is_active?: boolean
          min_age?: number
          name?: string
          position?: number
          slug?: string
        }
        Relationships: []
      }
      chatroom_zones: {
        Row: {
          category: string
          category_id: string | null
          created_at: string
          description: string | null
          id: string
          min_age: number
          name: string
          position: number
          slug: string
        }
        Insert: {
          category: string
          category_id?: string | null
          created_at?: string
          description?: string | null
          id?: string
          min_age?: number
          name: string
          position?: number
          slug: string
        }
        Update: {
          category?: string
          category_id?: string | null
          created_at?: string
          description?: string | null
          id?: string
          min_age?: number
          name?: string
          position?: number
          slug?: string
        }
        Relationships: [
          {
            foreignKeyName: "chatroom_zones_category_id_fkey"
            columns: ["category_id"]
            isOneToOne: false
            referencedRelation: "chat_categories"
            referencedColumns: ["id"]
          },
        ]
      }
      chatrooms: {
        Row: {
          cost_per_message: number
          created_at: string
          created_by: string | null
          id: string
          is_official: boolean
          max_users: number
          name: string
          room_number: number | null
          topic: string | null
          zone_id: string | null
        }
        Insert: {
          cost_per_message?: number
          created_at?: string
          created_by?: string | null
          id?: string
          is_official?: boolean
          max_users?: number
          name: string
          room_number?: number | null
          topic?: string | null
          zone_id?: string | null
        }
        Update: {
          cost_per_message?: number
          created_at?: string
          created_by?: string | null
          id?: string
          is_official?: boolean
          max_users?: number
          name?: string
          room_number?: number | null
          topic?: string | null
          zone_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "chatrooms_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "chatrooms_zone_id_fkey"
            columns: ["zone_id"]
            isOneToOne: false
            referencedRelation: "chatroom_zones"
            referencedColumns: ["id"]
          },
        ]
      }
      confession_likes: {
        Row: {
          confession_id: string
          created_at: string
          id: string
          user_id: string
        }
        Insert: {
          confession_id: string
          created_at?: string
          id?: string
          user_id: string
        }
        Update: {
          confession_id?: string
          created_at?: string
          id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "confession_likes_confession_id_fkey"
            columns: ["confession_id"]
            isOneToOne: false
            referencedRelation: "confessions"
            referencedColumns: ["id"]
          },
        ]
      }
      confessions: {
        Row: {
          author_id: string
          body: string
          created_at: string
          id: string
          is_hidden: boolean
          likes_count: number
        }
        Insert: {
          author_id: string
          body: string
          created_at?: string
          id?: string
          is_hidden?: boolean
          likes_count?: number
        }
        Update: {
          author_id?: string
          body?: string
          created_at?: string
          id?: string
          is_hidden?: boolean
          likes_count?: number
        }
        Relationships: []
      }
      contact_group_members: {
        Row: {
          contact_user_id: string
          created_at: string
          group_id: string
          id: string
          owner_id: string
        }
        Insert: {
          contact_user_id: string
          created_at?: string
          group_id: string
          id?: string
          owner_id: string
        }
        Update: {
          contact_user_id?: string
          created_at?: string
          group_id?: string
          id?: string
          owner_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "contact_group_members_group_id_fkey"
            columns: ["group_id"]
            isOneToOne: false
            referencedRelation: "contact_groups"
            referencedColumns: ["id"]
          },
        ]
      }
      contact_groups: {
        Row: {
          created_at: string
          id: string
          name: string
          owner_id: string
          position: number
        }
        Insert: {
          created_at?: string
          id?: string
          name: string
          owner_id: string
          position?: number
        }
        Update: {
          created_at?: string
          id?: string
          name?: string
          owner_id?: string
          position?: number
        }
        Relationships: []
      }
      contact_nicknames: {
        Row: {
          contact_user_id: string
          created_at: string
          id: string
          nickname: string
          owner_id: string
          updated_at: string
        }
        Insert: {
          contact_user_id: string
          created_at?: string
          id?: string
          nickname: string
          owner_id: string
          updated_at?: string
        }
        Update: {
          contact_user_id?: string
          created_at?: string
          id?: string
          nickname?: string
          owner_id?: string
          updated_at?: string
        }
        Relationships: []
      }
      contacts: {
        Row: {
          addressee_id: string
          created_at: string
          id: string
          requester_id: string
          status: Database["public"]["Enums"]["contact_status"]
          updated_at: string
        }
        Insert: {
          addressee_id: string
          created_at?: string
          id?: string
          requester_id: string
          status?: Database["public"]["Enums"]["contact_status"]
          updated_at?: string
        }
        Update: {
          addressee_id?: string
          created_at?: string
          id?: string
          requester_id?: string
          status?: Database["public"]["Enums"]["contact_status"]
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "contacts_addressee_id_fkey"
            columns: ["addressee_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "contacts_requester_id_fkey"
            columns: ["requester_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      conversations: {
        Row: {
          created_at: string
          disappearing_seconds: number
          id: string
          last_message_at: string
          user_a: string
          user_b: string
        }
        Insert: {
          created_at?: string
          disappearing_seconds?: number
          id?: string
          last_message_at?: string
          user_a: string
          user_b: string
        }
        Update: {
          created_at?: string
          disappearing_seconds?: number
          id?: string
          last_message_at?: string
          user_a?: string
          user_b?: string
        }
        Relationships: [
          {
            foreignKeyName: "conversations_user_a_fkey"
            columns: ["user_a"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "conversations_user_b_fkey"
            columns: ["user_b"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      guestbook_entries: {
        Row: {
          author_id: string
          body: string
          created_at: string
          id: string
          profile_id: string
        }
        Insert: {
          author_id: string
          body: string
          created_at?: string
          id?: string
          profile_id: string
        }
        Update: {
          author_id?: string
          body?: string
          created_at?: string
          id?: string
          profile_id?: string
        }
        Relationships: []
      }
      message_reactions: {
        Row: {
          created_at: string
          emoji: string
          id: string
          message_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          emoji: string
          id?: string
          message_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          emoji?: string
          id?: string
          message_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "message_reactions_message_id_fkey"
            columns: ["message_id"]
            isOneToOne: false
            referencedRelation: "messages"
            referencedColumns: ["id"]
          },
        ]
      }
      messages: {
        Row: {
          auto_flagged: boolean
          content: string
          conversation_id: string | null
          created_at: string
          delivery: Database["public"]["Enums"]["delivery_state"]
          expires_at: string | null
          forwarded_from: string | null
          hidden_by_mod: boolean
          hidden_reason: string | null
          id: string
          multimx_group_id: string | null
          nsfw_score: number | null
          reply_to_id: string | null
          room_id: string | null
          sender_id: string
        }
        Insert: {
          auto_flagged?: boolean
          content: string
          conversation_id?: string | null
          created_at?: string
          delivery?: Database["public"]["Enums"]["delivery_state"]
          expires_at?: string | null
          forwarded_from?: string | null
          hidden_by_mod?: boolean
          hidden_reason?: string | null
          id?: string
          multimx_group_id?: string | null
          nsfw_score?: number | null
          reply_to_id?: string | null
          room_id?: string | null
          sender_id: string
        }
        Update: {
          auto_flagged?: boolean
          content?: string
          conversation_id?: string | null
          created_at?: string
          delivery?: Database["public"]["Enums"]["delivery_state"]
          expires_at?: string | null
          forwarded_from?: string | null
          hidden_by_mod?: boolean
          hidden_reason?: string | null
          id?: string
          multimx_group_id?: string | null
          nsfw_score?: number | null
          reply_to_id?: string | null
          room_id?: string | null
          sender_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "messages_conversation_id_fkey"
            columns: ["conversation_id"]
            isOneToOne: false
            referencedRelation: "conversations"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "messages_forwarded_from_fkey"
            columns: ["forwarded_from"]
            isOneToOne: false
            referencedRelation: "messages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "messages_multimx_group_id_fkey"
            columns: ["multimx_group_id"]
            isOneToOne: false
            referencedRelation: "multimx_groups"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "messages_reply_to_id_fkey"
            columns: ["reply_to_id"]
            isOneToOne: false
            referencedRelation: "messages"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "messages_room_id_fkey"
            columns: ["room_id"]
            isOneToOne: false
            referencedRelation: "chatrooms"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "messages_sender_id_fkey"
            columns: ["sender_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      mood_history: {
        Row: {
          created_at: string
          id: string
          mood: string | null
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          mood?: string | null
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          mood?: string | null
          user_id?: string
        }
        Relationships: []
      }
      moola_daily_claims: {
        Row: {
          amount: number
          claim_date: string
          created_at: string
          id: string
          user_id: string
        }
        Insert: {
          amount: number
          claim_date?: string
          created_at?: string
          id?: string
          user_id: string
        }
        Update: {
          amount?: number
          claim_date?: string
          created_at?: string
          id?: string
          user_id?: string
        }
        Relationships: []
      }
      moola_products: {
        Row: {
          bonus_moola: number
          created_at: string
          enabled: boolean
          id: string
          label: string
          moola_amount: number
          position: number
          product_id: string
          zar_value: number
        }
        Insert: {
          bonus_moola?: number
          created_at?: string
          enabled?: boolean
          id?: string
          label: string
          moola_amount: number
          position?: number
          product_id: string
          zar_value: number
        }
        Update: {
          bonus_moola?: number
          created_at?: string
          enabled?: boolean
          id?: string
          label?: string
          moola_amount?: number
          position?: number
          product_id?: string
          zar_value?: number
        }
        Relationships: []
      }
      moola_spin_claims: {
        Row: {
          amount: number
          claim_date: string
          created_at: string
          id: string
          user_id: string
        }
        Insert: {
          amount: number
          claim_date?: string
          created_at?: string
          id?: string
          user_id: string
        }
        Update: {
          amount?: number
          claim_date?: string
          created_at?: string
          id?: string
          user_id?: string
        }
        Relationships: []
      }
      moola_tips: {
        Row: {
          amount: number
          created_at: string
          from_user: string
          id: string
          message_id: string | null
          to_user: string
        }
        Insert: {
          amount: number
          created_at?: string
          from_user: string
          id?: string
          message_id?: string | null
          to_user: string
        }
        Update: {
          amount?: number
          created_at?: string
          from_user?: string
          id?: string
          message_id?: string | null
          to_user?: string
        }
        Relationships: []
      }
      moola_transactions: {
        Row: {
          amount: number
          balance_after: number | null
          balance_before: number | null
          created_at: string
          id: string
          reason: string
          source: string | null
          store: string | null
          store_product_id: string | null
          store_transaction_id: string | null
          type: string
          user_id: string
        }
        Insert: {
          amount: number
          balance_after?: number | null
          balance_before?: number | null
          created_at?: string
          id?: string
          reason: string
          source?: string | null
          store?: string | null
          store_product_id?: string | null
          store_transaction_id?: string | null
          type?: string
          user_id: string
        }
        Update: {
          amount?: number
          balance_after?: number | null
          balance_before?: number | null
          created_at?: string
          id?: string
          reason?: string
          source?: string | null
          store?: string | null
          store_product_id?: string | null
          store_transaction_id?: string | null
          type?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "moola_transactions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      moonbase_alliance_members: {
        Row: {
          alliance_id: string
          id: string
          joined_at: string
          role: string
          user_id: string
        }
        Insert: {
          alliance_id: string
          id?: string
          joined_at?: string
          role?: string
          user_id: string
        }
        Update: {
          alliance_id?: string
          id?: string
          joined_at?: string
          role?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "moonbase_alliance_members_alliance_id_fkey"
            columns: ["alliance_id"]
            isOneToOne: false
            referencedRelation: "moonbase_alliances"
            referencedColumns: ["id"]
          },
        ]
      }
      moonbase_alliance_messages: {
        Row: {
          alliance_id: string
          content: string
          created_at: string
          id: string
          user_id: string
        }
        Insert: {
          alliance_id: string
          content: string
          created_at?: string
          id?: string
          user_id: string
        }
        Update: {
          alliance_id?: string
          content?: string
          created_at?: string
          id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "moonbase_alliance_messages_alliance_id_fkey"
            columns: ["alliance_id"]
            isOneToOne: false
            referencedRelation: "moonbase_alliances"
            referencedColumns: ["id"]
          },
        ]
      }
      moonbase_alliances: {
        Row: {
          created_at: string
          description: string | null
          founder_user_id: string
          id: string
          name: string
          power_score: number
          tag: string
        }
        Insert: {
          created_at?: string
          description?: string | null
          founder_user_id: string
          id?: string
          name: string
          power_score?: number
          tag: string
        }
        Update: {
          created_at?: string
          description?: string | null
          founder_user_id?: string
          id?: string
          name?: string
          power_score?: number
          tag?: string
        }
        Relationships: []
      }
      moonbase_attacks: {
        Row: {
          attacker_base_id: string
          created_at: string
          defender_base_id: string
          id: string
          result: Json
          units_sent: Json
        }
        Insert: {
          attacker_base_id: string
          created_at?: string
          defender_base_id: string
          id?: string
          result: Json
          units_sent: Json
        }
        Update: {
          attacker_base_id?: string
          created_at?: string
          defender_base_id?: string
          id?: string
          result?: Json
          units_sent?: Json
        }
        Relationships: [
          {
            foreignKeyName: "moonbase_attacks_attacker_base_id_fkey"
            columns: ["attacker_base_id"]
            isOneToOne: false
            referencedRelation: "moonbase_bases"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "moonbase_attacks_defender_base_id_fkey"
            columns: ["defender_base_id"]
            isOneToOne: false
            referencedRelation: "moonbase_bases"
            referencedColumns: ["id"]
          },
        ]
      }
      moonbase_bases: {
        Row: {
          base_name: string
          created_at: string
          id: string
          is_bot: boolean
          last_tick: string
          power_score: number
          sector_x: number
          sector_y: number
          user_id: string | null
        }
        Insert: {
          base_name: string
          created_at?: string
          id?: string
          is_bot?: boolean
          last_tick?: string
          power_score?: number
          sector_x: number
          sector_y: number
          user_id?: string | null
        }
        Update: {
          base_name?: string
          created_at?: string
          id?: string
          is_bot?: boolean
          last_tick?: string
          power_score?: number
          sector_x?: number
          sector_y?: number
          user_id?: string | null
        }
        Relationships: []
      }
      moonbase_buildings: {
        Row: {
          base_id: string
          building_type: string
          id: string
          level: number
        }
        Insert: {
          base_id: string
          building_type: string
          id?: string
          level?: number
        }
        Update: {
          base_id?: string
          building_type?: string
          id?: string
          level?: number
        }
        Relationships: [
          {
            foreignKeyName: "moonbase_buildings_base_id_fkey"
            columns: ["base_id"]
            isOneToOne: false
            referencedRelation: "moonbase_bases"
            referencedColumns: ["id"]
          },
        ]
      }
      moonbase_reports: {
        Row: {
          body: string
          created_at: string
          id: string
          is_read: boolean
          kind: string
          title: string
          user_id: string
        }
        Insert: {
          body: string
          created_at?: string
          id?: string
          is_read?: boolean
          kind?: string
          title: string
          user_id: string
        }
        Update: {
          body?: string
          created_at?: string
          id?: string
          is_read?: boolean
          kind?: string
          title?: string
          user_id?: string
        }
        Relationships: []
      }
      moonbase_research: {
        Row: {
          id: string
          level: number
          research_type: string
          user_id: string
        }
        Insert: {
          id?: string
          level?: number
          research_type: string
          user_id: string
        }
        Update: {
          id?: string
          level?: number
          research_type?: string
          user_id?: string
        }
        Relationships: []
      }
      moonbase_resources: {
        Row: {
          base_id: string
          capacity: number
          helium: number
          iron: number
          oxygen: number
          updated_at: string
          water: number
        }
        Insert: {
          base_id: string
          capacity?: number
          helium?: number
          iron?: number
          oxygen?: number
          updated_at?: string
          water?: number
        }
        Update: {
          base_id?: string
          capacity?: number
          helium?: number
          iron?: number
          oxygen?: number
          updated_at?: string
          water?: number
        }
        Relationships: [
          {
            foreignKeyName: "moonbase_resources_base_id_fkey"
            columns: ["base_id"]
            isOneToOne: true
            referencedRelation: "moonbase_bases"
            referencedColumns: ["id"]
          },
        ]
      }
      moonbase_trade_offers: {
        Row: {
          accepted_by: string | null
          created_at: string
          give_helium: number
          give_iron: number
          give_oxygen: number
          give_water: number
          id: string
          resolved_at: string | null
          seller_base_id: string
          seller_user_id: string
          status: string
          want_helium: number
          want_iron: number
          want_oxygen: number
          want_water: number
        }
        Insert: {
          accepted_by?: string | null
          created_at?: string
          give_helium?: number
          give_iron?: number
          give_oxygen?: number
          give_water?: number
          id?: string
          resolved_at?: string | null
          seller_base_id: string
          seller_user_id: string
          status?: string
          want_helium?: number
          want_iron?: number
          want_oxygen?: number
          want_water?: number
        }
        Update: {
          accepted_by?: string | null
          created_at?: string
          give_helium?: number
          give_iron?: number
          give_oxygen?: number
          give_water?: number
          id?: string
          resolved_at?: string | null
          seller_base_id?: string
          seller_user_id?: string
          status?: string
          want_helium?: number
          want_iron?: number
          want_oxygen?: number
          want_water?: number
        }
        Relationships: [
          {
            foreignKeyName: "moonbase_trade_offers_seller_base_id_fkey"
            columns: ["seller_base_id"]
            isOneToOne: false
            referencedRelation: "moonbase_bases"
            referencedColumns: ["id"]
          },
        ]
      }
      moonbase_units: {
        Row: {
          base_id: string
          id: string
          quantity: number
          unit_type: string
        }
        Insert: {
          base_id: string
          id?: string
          quantity?: number
          unit_type: string
        }
        Update: {
          base_id?: string
          id?: string
          quantity?: number
          unit_type?: string
        }
        Relationships: [
          {
            foreignKeyName: "moonbase_units_base_id_fkey"
            columns: ["base_id"]
            isOneToOne: false
            referencedRelation: "moonbase_bases"
            referencedColumns: ["id"]
          },
        ]
      }
      multimx_groups: {
        Row: {
          created_at: string
          created_by: string
          id: string
          last_message_at: string
          name: string
        }
        Insert: {
          created_at?: string
          created_by: string
          id?: string
          last_message_at?: string
          name: string
        }
        Update: {
          created_at?: string
          created_by?: string
          id?: string
          last_message_at?: string
          name?: string
        }
        Relationships: []
      }
      multimx_members: {
        Row: {
          group_id: string
          id: string
          joined_at: string
          user_id: string
        }
        Insert: {
          group_id: string
          id?: string
          joined_at?: string
          user_id: string
        }
        Update: {
          group_id?: string
          id?: string
          joined_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "multimx_members_group_id_fkey"
            columns: ["group_id"]
            isOneToOne: false
            referencedRelation: "multimx_groups"
            referencedColumns: ["id"]
          },
        ]
      }
      poll_votes: {
        Row: {
          created_at: string
          id: string
          option_index: number
          poll_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          option_index: number
          poll_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          option_index?: number
          poll_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "poll_votes_poll_id_fkey"
            columns: ["poll_id"]
            isOneToOne: false
            referencedRelation: "polls"
            referencedColumns: ["id"]
          },
        ]
      }
      polls: {
        Row: {
          author_id: string
          closes_at: string
          created_at: string
          id: string
          options: Json
          question: string
        }
        Insert: {
          author_id: string
          closes_at?: string
          created_at?: string
          id?: string
          options: Json
          question: string
        }
        Update: {
          author_id?: string
          closes_at?: string
          created_at?: string
          id?: string
          options?: Json
          question?: string
        }
        Relationships: []
      }
      profiles: {
        Row: {
          age: number | null
          appear_offline: boolean
          auto_away_minutes: number
          avatar_seed: string | null
          avatar_url: string | null
          birthday: string | null
          created_at: string
          display_name: string
          farewell: string | null
          gender: string | null
          hide_offline: boolean
          id: string
          is_suspended: boolean
          last_claim_date: string | null
          last_seen: string
          low_data_mode: boolean
          meet_bio: string | null
          meet_opt_in: boolean
          mood: string | null
          moola: number
          mxit_id: string
          presence: Database["public"]["Enums"]["presence_status"]
          read_receipts_enabled: boolean
          sound_enabled: boolean
          streak_days: number
          suspended_at: string | null
          suspended_reason: string | null
          tags: string[]
          theme: string
          updated_at: string
        }
        Insert: {
          age?: number | null
          appear_offline?: boolean
          auto_away_minutes?: number
          avatar_seed?: string | null
          avatar_url?: string | null
          birthday?: string | null
          created_at?: string
          display_name: string
          farewell?: string | null
          gender?: string | null
          hide_offline?: boolean
          id: string
          is_suspended?: boolean
          last_claim_date?: string | null
          last_seen?: string
          low_data_mode?: boolean
          meet_bio?: string | null
          meet_opt_in?: boolean
          mood?: string | null
          moola?: number
          mxit_id: string
          presence?: Database["public"]["Enums"]["presence_status"]
          read_receipts_enabled?: boolean
          sound_enabled?: boolean
          streak_days?: number
          suspended_at?: string | null
          suspended_reason?: string | null
          tags?: string[]
          theme?: string
          updated_at?: string
        }
        Update: {
          age?: number | null
          appear_offline?: boolean
          auto_away_minutes?: number
          avatar_seed?: string | null
          avatar_url?: string | null
          birthday?: string | null
          created_at?: string
          display_name?: string
          farewell?: string | null
          gender?: string | null
          hide_offline?: boolean
          id?: string
          is_suspended?: boolean
          last_claim_date?: string | null
          last_seen?: string
          low_data_mode?: boolean
          meet_bio?: string | null
          meet_opt_in?: boolean
          mood?: string | null
          moola?: number
          mxit_id?: string
          presence?: Database["public"]["Enums"]["presence_status"]
          read_receipts_enabled?: boolean
          sound_enabled?: boolean
          streak_days?: number
          suspended_at?: string | null
          suspended_reason?: string | null
          tags?: string[]
          theme?: string
          updated_at?: string
        }
        Relationships: []
      }
      room_members: {
        Row: {
          id: string
          joined_at: string
          room_id: string
          user_id: string
        }
        Insert: {
          id?: string
          joined_at?: string
          room_id: string
          user_id: string
        }
        Update: {
          id?: string
          joined_at?: string
          room_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "room_members_room_id_fkey"
            columns: ["room_id"]
            isOneToOne: false
            referencedRelation: "chatrooms"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "room_members_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      status_audience: {
        Row: {
          id: string
          status_id: string
          user_id: string
        }
        Insert: {
          id?: string
          status_id: string
          user_id: string
        }
        Update: {
          id?: string
          status_id?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "status_audience_status_id_fkey"
            columns: ["status_id"]
            isOneToOne: false
            referencedRelation: "statuses"
            referencedColumns: ["id"]
          },
        ]
      }
      status_reactions: {
        Row: {
          created_at: string
          emoji: string
          id: string
          status_id: string
          user_id: string
        }
        Insert: {
          created_at?: string
          emoji: string
          id?: string
          status_id: string
          user_id: string
        }
        Update: {
          created_at?: string
          emoji?: string
          id?: string
          status_id?: string
          user_id?: string
        }
        Relationships: []
      }
      status_views: {
        Row: {
          id: string
          status_id: string
          viewed_at: string
          viewer_id: string
        }
        Insert: {
          id?: string
          status_id: string
          viewed_at?: string
          viewer_id: string
        }
        Update: {
          id?: string
          status_id?: string
          viewed_at?: string
          viewer_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "status_views_status_id_fkey"
            columns: ["status_id"]
            isOneToOne: false
            referencedRelation: "statuses"
            referencedColumns: ["id"]
          },
        ]
      }
      statuses: {
        Row: {
          audience_mode: Database["public"]["Enums"]["status_audience_mode"]
          author_id: string
          background: string | null
          caption: string | null
          created_at: string
          expires_at: string
          id: string
          kind: Database["public"]["Enums"]["status_kind"]
          media_url: string | null
        }
        Insert: {
          audience_mode?: Database["public"]["Enums"]["status_audience_mode"]
          author_id: string
          background?: string | null
          caption?: string | null
          created_at?: string
          expires_at?: string
          id?: string
          kind: Database["public"]["Enums"]["status_kind"]
          media_url?: string | null
        }
        Update: {
          audience_mode?: Database["public"]["Enums"]["status_audience_mode"]
          author_id?: string
          background?: string | null
          caption?: string | null
          created_at?: string
          expires_at?: string
          id?: string
          kind?: Database["public"]["Enums"]["status_kind"]
          media_url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "statuses_author_id_fkey"
            columns: ["author_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
      tradepost_services: {
        Row: {
          cost_moola: number
          description: string | null
          enabled: boolean
          icon: string | null
          id: string
          name: string
          position: number
          route: string | null
          slug: string
        }
        Insert: {
          cost_moola?: number
          description?: string | null
          enabled?: boolean
          icon?: string | null
          id?: string
          name: string
          position?: number
          route?: string | null
          slug: string
        }
        Update: {
          cost_moola?: number
          description?: string | null
          enabled?: boolean
          icon?: string | null
          id?: string
          name?: string
          position?: number
          route?: string | null
          slug?: string
        }
        Relationships: []
      }
      user_achievements: {
        Row: {
          achievement_id: string
          id: string
          unlocked_at: string
          user_id: string
        }
        Insert: {
          achievement_id: string
          id?: string
          unlocked_at?: string
          user_id: string
        }
        Update: {
          achievement_id?: string
          id?: string
          unlocked_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "user_achievements_achievement_id_fkey"
            columns: ["achievement_id"]
            isOneToOne: false
            referencedRelation: "achievements"
            referencedColumns: ["id"]
          },
        ]
      }
      user_blocks: {
        Row: {
          blocked_id: string
          blocker_id: string
          created_at: string
          id: string
          reason: string | null
        }
        Insert: {
          blocked_id: string
          blocker_id: string
          created_at?: string
          id?: string
          reason?: string | null
        }
        Update: {
          blocked_id?: string
          blocker_id?: string
          created_at?: string
          id?: string
          reason?: string | null
        }
        Relationships: []
      }
      user_reports: {
        Row: {
          category: string
          created_at: string
          details: string | null
          id: string
          message_id: string | null
          reported_user_id: string
          reporter_id: string
          status: string
        }
        Insert: {
          category?: string
          created_at?: string
          details?: string | null
          id?: string
          message_id?: string | null
          reported_user_id: string
          reporter_id: string
          status?: string
        }
        Update: {
          category?: string
          created_at?: string
          details?: string | null
          id?: string
          message_id?: string | null
          reported_user_id?: string
          reporter_id?: string
          status?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      analytics_dau: {
        Row: {
          dau: number | null
          day: string | null
          events: number | null
        }
        Relationships: []
      }
      analytics_retention_d7: {
        Row: {
          active_today: number | null
          cohort_size: number | null
          retention_pct: number | null
        }
        Relationships: []
      }
      analytics_top_rooms: {
        Row: {
          messages: number | null
          room_id: string | null
          room_name: string | null
          unique_senders: number | null
        }
        Relationships: [
          {
            foreignKeyName: "messages_room_id_fkey"
            columns: ["room_id"]
            isOneToOne: false
            referencedRelation: "chatrooms"
            referencedColumns: ["id"]
          },
        ]
      }
      moola_weekly_leaderboard: {
        Row: {
          avatar_seed: string | null
          avatar_url: string | null
          display_name: string | null
          earned: number | null
          mxit_id: string | null
          spins: number | null
          transfers: number | null
          user_id: string | null
        }
        Relationships: [
          {
            foreignKeyName: "moola_transactions_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "profiles"
            referencedColumns: ["id"]
          },
        ]
      }
    }
    Functions: {
      accept_moonbase_trade: { Args: { _offer: string }; Returns: string }
      are_contacts: { Args: { _a: string; _b: string }; Returns: boolean }
      award_achievement: { Args: { _achievement: string }; Returns: Json }
      can_view_status: {
        Args: { _status_id: string; _viewer: string }
        Returns: boolean
      }
      claim_daily_moola: { Args: never; Returns: Json }
      delete_my_account: { Args: never; Returns: undefined }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      in_moonbase_alliance: {
        Args: { _alliance: string; _user: string }
        Returns: boolean
      }
      is_bot_base: { Args: { _base_id: string }; Returns: boolean }
      is_in_conversation: {
        Args: { _conv: string; _user: string }
        Returns: boolean
      }
      is_in_multimx: {
        Args: { _group: string; _user: string }
        Returns: boolean
      }
      is_in_room: { Args: { _room: string; _user: string }; Returns: boolean }
      join_best_room: { Args: { _zone_id: string }; Returns: string }
      moderate_user: {
        Args: { _reason?: string; _suspend: boolean; _user: string }
        Returns: undefined
      }
      owns_base: { Args: { _base_id: string }; Returns: boolean }
      purge_expired_messages: { Args: never; Returns: undefined }
      purge_expired_statuses: { Args: never; Returns: undefined }
      send_moola: {
        Args: {
          _amount: number
          _message_id?: string
          _note?: string
          _to: string
        }
        Returns: Json
      }
      spin_daily_wheel: { Args: never; Returns: Json }
      user_meets_min_age: {
        Args: { _min_age: number; _user: string }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "admin" | "moderator" | "user"
      contact_status: "pending" | "accepted" | "blocked"
      delivery_state: "sending" | "sent" | "delivered" | "read"
      presence_status: "online" | "away" | "offline" | "busy"
      status_audience_mode:
        | "everyone"
        | "contacts"
        | "contacts_except"
        | "only_share_with"
      status_kind: "text" | "image" | "video"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "moderator", "user"],
      contact_status: ["pending", "accepted", "blocked"],
      delivery_state: ["sending", "sent", "delivered", "read"],
      presence_status: ["online", "away", "offline", "busy"],
      status_audience_mode: [
        "everyone",
        "contacts",
        "contacts_except",
        "only_share_with",
      ],
      status_kind: ["text", "image", "video"],
    },
  },
} as const
