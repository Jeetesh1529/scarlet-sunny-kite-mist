import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes, useLocation } from "react-router-dom";
import { useEffect } from "react";
import { track } from "@/lib/analytics";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/contexts/AuthContext";
import { MxitShell } from "@/components/MxitShell";
import Index from "./pages/Index";
import Chat from "./pages/Chat";
import ChatRoom from "./pages/ChatRoom";
import MobiApp from "./pages/MobiApp";
import Tradepost from "./pages/Tradepost";
import TradepostChatrooms from "./pages/TradepostChatrooms";
import TradepostCategory from "./pages/TradepostCategory";
import TradepostZone from "./pages/TradepostZone";
import TradepostService from "./pages/TradepostService";

import TradepostEmoticards from "./pages/TradepostEmoticards";
import TradepostHoroscopes from "./pages/TradepostHoroscopes";
import TradepostWeather from "./pages/TradepostWeather";
import TradepostGames from "./pages/TradepostGames";
import MoonbaseGame from "./pages/MoonbaseGame";
import MultiMx from "./pages/MultiMx";
import MultiMxChat from "./pages/MultiMxChat";
import Legal from "./pages/Legal";
import ResetPassword from "./pages/ResetPassword";
import AdminAnalytics from "./pages/AdminAnalytics";
import StatusPage from "./pages/Status";
import ProfileView from "./pages/ProfileView";
import MoolaHub from "./pages/MoolaHub";
import MusicRoom from "./pages/MusicRoom";
import Confessions from "./pages/Confessions";
import Polls from "./pages/Polls";
import TicTacToe from "./pages/TicTacToe";
import Meet from "./pages/Meet";
import Leaderboards from "./pages/Leaderboards";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

function RouteTracker() {
  const loc = useLocation();
  useEffect(() => { void track('screen_view', { path: loc.pathname }); }, [loc.pathname]);
  return null;
}

const App = () => (
  <QueryClientProvider client={queryClient}>
    <TooltipProvider>
      <Toaster />
      <Sonner position="top-center" />
      <BrowserRouter>
        <AuthProvider>
          <RouteTracker />
          <MxitShell>
            <Routes>
              <Route path="/" element={<Index />} />
              <Route path="/chat/:id" element={<Chat />} />
              <Route path="/room/:id" element={<ChatRoom />} />
              <Route path="/portal/:app" element={<MobiApp />} />
              <Route path="/tradepost" element={<Tradepost />} />
              <Route path="/tradepost/chatrooms" element={<TradepostChatrooms />} />
              <Route path="/tradepost/category/:slug" element={<TradepostCategory />} />
              <Route path="/tradepost/zone/:slug" element={<TradepostZone />} />
              
              <Route path="/tradepost/emoticards" element={<TradepostEmoticards />} />
              <Route path="/tradepost/horoscopes" element={<TradepostHoroscopes />} />
              <Route path="/tradepost/weather" element={<TradepostWeather />} />
              <Route path="/tradepost/games" element={<TradepostGames />} />
              <Route path="/tradepost/games/moonbase" element={<MoonbaseGame />} />
              <Route path="/tradepost/:slug" element={<TradepostService />} />
              <Route path="/multimx" element={<MultiMx />} />
              <Route path="/multimx/:id" element={<MultiMxChat />} />
              <Route path="/legal/:kind" element={<Legal />} />
              <Route path="/reset-password" element={<ResetPassword />} />
              <Route path="/admin/analytics" element={<AdminAnalytics />} />
              <Route path="/status" element={<StatusPage />} />
              <Route path="/u/:mxitId" element={<ProfileView />} />
              <Route path="/moola" element={<MoolaHub />} />
              <Route path="/music" element={<MusicRoom />} />
              <Route path="/confessions" element={<Confessions />} />
              <Route path="/polls" element={<Polls />} />
              <Route path="/games/tictactoe" element={<TicTacToe />} />
              <Route path="/meet" element={<Meet />} />
              <Route path="/leaderboards" element={<Leaderboards />} />
              <Route path="*" element={<NotFound />} />
            </Routes>
          </MxitShell>
        </AuthProvider>
      </BrowserRouter>
    </TooltipProvider>
  </QueryClientProvider>
);

export default App;
