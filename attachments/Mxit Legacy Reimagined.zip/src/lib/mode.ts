/** Display mode: "normal" (theme default), "light", or "dark". Persisted in localStorage. */
export type DisplayMode = 'normal' | 'light' | 'dark';

const KEY = 'mxit-mode';

export function getMode(): DisplayMode {
  if (typeof window === 'undefined') return 'dark';
  const v = localStorage.getItem(KEY) as DisplayMode | null;
  return v === 'light' || v === 'dark' || v === 'normal' ? v : 'dark';
}

export function applyMode(mode: DisplayMode) {
  if (typeof document === 'undefined') return;
  if (mode === 'normal') {
    document.documentElement.removeAttribute('data-mode');
  } else {
    document.documentElement.setAttribute('data-mode', mode);
  }
}

export function setMode(mode: DisplayMode) {
  localStorage.setItem(KEY, mode);
  applyMode(mode);
}

// Apply at import time so it takes effect ASAP.
applyMode(getMode());
