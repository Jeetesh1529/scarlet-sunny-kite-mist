/** Helper to award an achievement (no-op if already unlocked). */
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { sfx } from '@/lib/sfx';

export type AchievementId =
  | 'first_message' | 'first_status' | 'streak_7' | 'streak_30'
  | 'chatroom_join' | 'multimx_create' | 'confession' | 'voice_note'
  | 'moola_tip' | 'meet_optin' | 'moonbase_first';

export async function awardAchievement(id: AchievementId) {
  try {
    const { data, error } = await (supabase as any).rpc('award_achievement', { _achievement: id });
    if (error || !data?.ok) return;
    sfx.send();
    toast.success(`${data.icon} Achievement unlocked: ${data.name}` + (data.reward ? ` · +${data.reward}M` : ''), { duration: 5000 });
  } catch {/* ignore */}
}
