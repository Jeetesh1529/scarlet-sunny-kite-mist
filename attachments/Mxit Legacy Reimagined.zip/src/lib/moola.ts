/**
 * Moola spend helper — deducts from profile, writes a ledger row.
 * Returns true on success, false if not enough Moola.
 */
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import { sfx } from '@/lib/sfx';

export async function spendMoola(opts: {
  userId: string;
  currentBalance: number;
  amount: number;
  reason: string;
  type?: string;
}): Promise<boolean> {
  const { userId, currentBalance, amount, reason, type = 'spend' } = opts;
  if (amount <= 0) return true;
  if (currentBalance < amount) {
    sfx.error();
    toast.error(`Not enough Moola — need ${amount}M, you have ${currentBalance}M`);
    return false;
  }
  const newBal = currentBalance - amount;
  const { error: e1 } = await supabase.from('profiles').update({ moola: newBal }).eq('id', userId);
  if (e1) { toast.error(e1.message); return false; }
  await supabase.from('moola_transactions').insert({
    user_id: userId,
    amount: -amount,
    reason,
    type,
    balance_before: currentBalance,
    balance_after: newBal,
  });
  return true;
}
