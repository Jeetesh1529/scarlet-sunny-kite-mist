import { supabase } from '@/integrations/supabase/client';
import { getOutbox, removeOutbox, type ChatKind } from './offlineDb';

let flushing = false;

function targetColumn(kind: ChatKind | undefined, legacyConvId?: string): { col: string; id: string } | null {
  if (kind === 'direct') return { col: 'conversation_id', id: '' };
  if (kind === 'multimx') return { col: 'multimx_group_id', id: '' };
  if (kind === 'room') return { col: 'room_id', id: '' };
  // legacy
  if (legacyConvId) return { col: 'conversation_id', id: legacyConvId };
  return null;
}

export async function flushOutbox(): Promise<{ sent: number; failed: number }> {
  if (flushing || !navigator.onLine) return { sent: 0, failed: 0 };
  flushing = true;
  let sent = 0;
  let failed = 0;
  try {
    const queued = await getOutbox();
    for (const m of queued) {
      const t = targetColumn(m.target_kind, m.conversation_id);
      if (!t) { await removeOutbox(m.tmp_id); continue; }
      const id = m.target_id || t.id;
      if (!id) { await removeOutbox(m.tmp_id); continue; }
      const row: Record<string, unknown> = {
        sender_id: m.sender_id,
        content: m.content,
        delivery: 'sent',
      };
      row[t.col] = id;
      const { error } = await supabase.from('messages').insert(row as never);
      if (error) { failed++; } else { await removeOutbox(m.tmp_id); sent++; }
    }
  } finally { flushing = false; }
  return { sent, failed };
}

let registered = false;
export function registerOnlineFlush() {
  if (registered) return;
  registered = true;
  window.addEventListener('online', () => { void flushOutbox(); });
  window.addEventListener('focus', () => { void flushOutbox(); });
  void flushOutbox();
}
