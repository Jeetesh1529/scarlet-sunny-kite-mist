import { openDB, type IDBPDatabase } from 'idb';
import type { ChatMessage } from '@/components/ChatPrimitives';

const DB_NAME = 'mxit-offline';
const DB_VERSION = 1;

export type ChatKind = 'direct' | 'multimx' | 'room';

export type QueuedMessage = {
  tmp_id: string;
  sender_id: string;
  content: string;
  created_at: string;
  target_kind: ChatKind;
  target_id: string;
  /** legacy field, kept for back-compat with previously queued items */
  conversation_id?: string;
};

let dbPromise: Promise<IDBPDatabase> | null = null;

function getDb() {
  if (!dbPromise) {
    dbPromise = openDB(DB_NAME, DB_VERSION, {
      upgrade(db) {
        if (!db.objectStoreNames.contains('messages')) {
          const s = db.createObjectStore('messages', { keyPath: 'id' });
          s.createIndex('by_conv', 'conversation_id');
        }
        if (!db.objectStoreNames.contains('outbox')) {
          db.createObjectStore('outbox', { keyPath: 'tmp_id' });
        }
        if (!db.objectStoreNames.contains('profiles')) {
          db.createObjectStore('profiles', { keyPath: 'id' });
        }
      },
    });
  }
  return dbPromise;
}

/** Build a stable cache key per chat surface so different kinds never collide. */
export function cacheKey(kind: ChatKind, id: string): string {
  return `${kind}:${id}`;
}

export async function cacheMessages(key: string, msgs: ChatMessage[]) {
  try {
    const db = await getDb();
    const tx = db.transaction('messages', 'readwrite');
    for (const m of msgs) {
      await tx.store.put({ ...m, conversation_id: key });
    }
    await tx.done;
  } catch { /* ignore */ }
}

export async function getCachedMessages(key: string): Promise<ChatMessage[]> {
  try {
    const db = await getDb();
    const all = await db.getAllFromIndex('messages', 'by_conv', key);
    return (all as ChatMessage[]).sort((a, b) =>
      new Date(a.created_at).getTime() - new Date(b.created_at).getTime(),
    );
  } catch { return []; }
}

export async function cacheProfile(p: { id: string } & Record<string, unknown>) {
  try { const db = await getDb(); await db.put('profiles', p); } catch { /* ignore */ }
}

export async function getCachedProfile<T = unknown>(id: string): Promise<T | null> {
  try { const db = await getDb(); return ((await db.get('profiles', id)) as T) ?? null; } catch { return null; }
}

export async function enqueueOutbox(m: QueuedMessage) {
  const db = await getDb();
  await db.put('outbox', m);
}

export async function getOutbox(): Promise<QueuedMessage[]> {
  try { const db = await getDb(); return (await db.getAll('outbox')) as QueuedMessage[]; } catch { return []; }
}

export async function getOutboxFor(kind: ChatKind, id: string): Promise<QueuedMessage[]> {
  const all = await getOutbox();
  return all.filter((m) => {
    if (m.target_kind && m.target_id) return m.target_kind === kind && m.target_id === id;
    // legacy fallback
    return kind === 'direct' && m.conversation_id === id;
  });
}

export async function removeOutbox(tmpId: string) {
  try { const db = await getDb(); await db.delete('outbox', tmpId); } catch { /* ignore */ }
}
