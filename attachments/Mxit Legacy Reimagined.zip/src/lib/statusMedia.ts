import { supabase } from '@/integrations/supabase/client';

export const STATUS_BUCKET = 'status-media';
export const VOICE_BUCKET = 'voice-notes';
export const VIDEO_BUCKET = 'chat-videos';
export const AVATAR_BUCKET = 'avatars';

export const MAX_STATUS_MEDIA_BYTES = 25 * 1024 * 1024;
export const MAX_VOICE_BYTES = 8 * 1024 * 1024;
export const MAX_VIDEO_BYTES = 25 * 1024 * 1024;
export const MAX_AVATAR_BYTES = 4 * 1024 * 1024;

const VOICE_TAG = /^\[voice\](.+?)\[\/voice\]$/;
const VIDEO_TAG = /^\[video\](.+?)\[\/video\]$/;

export const isVoiceMessage = (s: string) => s.trim().match(VOICE_TAG)?.[1] ?? null;
export const isVideoMessage = (s: string) => s.trim().match(VIDEO_TAG)?.[1] ?? null;
export const buildVoiceMessage = (url: string) => `[voice]${url}[/voice]`;
export const buildVideoMessage = (url: string) => `[video]${url}[/video]`;

export async function uploadToBucket(
  bucket: string,
  file: Blob,
  userId: string,
  ext: string,
  contentType?: string,
): Promise<{ url: string } | { error: string }> {
  const path = `${userId}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
  const { error } = await supabase.storage.from(bucket).upload(path, file, {
    contentType: contentType ?? file.type,
    upsert: bucket === AVATAR_BUCKET,
  });
  if (error) return { error: error.message };
  const { data } = supabase.storage.from(bucket).getPublicUrl(path);
  return { url: data.publicUrl };
}
