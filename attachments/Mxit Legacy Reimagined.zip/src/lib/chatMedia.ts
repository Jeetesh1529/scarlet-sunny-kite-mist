import { supabase } from '@/integrations/supabase/client';

export const ALLOWED_CHAT_MIME = ['image/png', 'image/jpeg', 'image/jpg', 'image/webp', 'image/gif'];
export const MAX_CHAT_FILE_BYTES = 5 * 1024 * 1024; // 5 MB
export const CHAT_FILE_ACCEPT = '.png,.jpg,.jpeg,.webp,.gif,image/png,image/jpeg,image/webp,image/gif';

const IMG_TAG = /^\[img\](.+?)\[\/img\]$/;

export function isImageMessage(content: string): string | null {
  const m = content.trim().match(IMG_TAG);
  return m ? m[1] : null;
}

export function buildImageMessage(url: string): string {
  return `[img]${url}[/img]`;
}

export type UploadResult = { url: string } | { error: string };

export async function uploadChatImage(file: File, userId: string): Promise<UploadResult> {
  if (!ALLOWED_CHAT_MIME.includes(file.type)) {
    return { error: 'Only images (PNG, JPG, WEBP, GIF) are allowed.' };
  }
  if (file.size > MAX_CHAT_FILE_BYTES) {
    return { error: 'File is too large. Max 5 MB.' };
  }
  const ext = (file.name.split('.').pop() || 'png').toLowerCase();
  const path = `${userId}/${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${ext}`;
  const { error } = await supabase.storage.from('chat-media').upload(path, file, {
    contentType: file.type,
    upsert: false,
  });
  if (error) return { error: error.message };
  const { data } = supabase.storage.from('chat-media').getPublicUrl(path);
  return { url: data.publicUrl };
}
