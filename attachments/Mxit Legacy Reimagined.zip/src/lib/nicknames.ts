/**
 * Local contact nicknames — owner-only renames.
 * Cached in-memory + via realtime so the UI updates instantly.
 */
import { useEffect, useState } from 'react';
import { supabase } from '@/integrations/supabase/client';
import { useAuth } from '@/contexts/AuthContext';

export type NicknameMap = Record<string, string>;

let cache: NicknameMap = {};
const subs = new Set<(m: NicknameMap) => void>();
let loadedFor: string | null = null;

function emit() { subs.forEach((cb) => cb({ ...cache })); }

async function loadAll(ownerId: string) {
  if (loadedFor === ownerId) return;
  loadedFor = ownerId;
  const { data } = await supabase.from('contact_nicknames')
    .select('contact_user_id, nickname').eq('owner_id', ownerId);
  cache = {};
  (data ?? []).forEach((r: any) => { cache[r.contact_user_id] = r.nickname; });
  emit();
}

export function useNicknames(): NicknameMap {
  const { profile } = useAuth();
  const [m, setM] = useState<NicknameMap>(cache);
  useEffect(() => {
    if (!profile) return;
    void loadAll(profile.id);
    const cb = (next: NicknameMap) => setM(next);
    subs.add(cb);
    const ch = supabase.channel(`nicks-${profile.id}`)
      .on('postgres_changes', { event: '*', schema: 'public', table: 'contact_nicknames', filter: `owner_id=eq.${profile.id}` }, () => {
        loadedFor = null; void loadAll(profile.id);
      }).subscribe();
    return () => { subs.delete(cb); supabase.removeChannel(ch); };
  }, [profile?.id]);
  return m;
}

export function nameWithNickname(map: NicknameMap, userId: string, fallback: string): string {
  return map[userId] || fallback;
}

export async function setNickname(ownerId: string, contactUserId: string, nickname: string) {
  const trimmed = nickname.trim().slice(0, 40);
  if (!trimmed) {
    await supabase.from('contact_nicknames').delete()
      .eq('owner_id', ownerId).eq('contact_user_id', contactUserId);
    delete cache[contactUserId];
  } else {
    await supabase.from('contact_nicknames').upsert(
      { owner_id: ownerId, contact_user_id: contactUserId, nickname: trimmed },
      { onConflict: 'owner_id,contact_user_id' },
    );
    cache[contactUserId] = trimmed;
  }
  emit();
}
