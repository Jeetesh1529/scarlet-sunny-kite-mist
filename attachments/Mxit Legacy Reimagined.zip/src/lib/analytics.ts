import { supabase } from '@/integrations/supabase/client';

// Lightweight, privacy-respecting analytics.
// - Writes directly to the `analytics_events` table (RLS allows anon insert).
// - Best-effort: failures are swallowed so they never break the UI.
// - Session id is per-tab, regenerated on reload, kept in sessionStorage.

const SESSION_KEY = 'mxit_session_id';

function getSessionId(): string {
  try {
    let s = sessionStorage.getItem(SESSION_KEY);
    if (!s) {
      s = `s_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
      sessionStorage.setItem(SESSION_KEY, s);
    }
    return s;
  } catch {
    return 'no-session';
  }
}

export type AnalyticsEvent =
  | 'app_open'
  | 'screen_view'
  | 'signup_started'
  | 'signup_completed'
  | 'login_completed'
  | 'logout'
  | 'message_sent'
  | 'chatroom_joined'
  | 'multimx_created'
  | 'moola_daily_claimed'
  | 'tradepost_purchase'
  | 'account_deleted'
  | 'user_reported'
  | 'user_blocked'
  | 'error'
  | (string & {});

export async function track(
  event: AnalyticsEvent,
  properties: Record<string, unknown> = {},
): Promise<void> {
  try {
    const { data: { user } } = await supabase.auth.getUser();
    await supabase.from('analytics_events').insert({
      user_id: user?.id ?? null,
      session_id: getSessionId(),
      event,
      properties: properties as never,
      route: typeof window !== 'undefined' ? window.location.pathname : null,
      user_agent: typeof navigator !== 'undefined' ? navigator.userAgent.slice(0, 255) : null,
    });
  } catch {
    // Never let analytics break the app
  }
}
