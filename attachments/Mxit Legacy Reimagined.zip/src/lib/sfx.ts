/** Lightweight beep / blip generator using WebAudio — no asset files needed. */
let ctx: AudioContext | null = null;
function getCtx() {
  if (typeof window === 'undefined') return null;
  if (!ctx) {
    try { ctx = new (window.AudioContext || (window as any).webkitAudioContext)(); }
    catch { return null; }
  }
  return ctx;
}

function tone(freq: number, durationMs: number, type: OscillatorType = 'square', gain = 0.04) {
  const c = getCtx();
  if (!c) return;
  const osc = c.createOscillator();
  const g = c.createGain();
  osc.type = type;
  osc.frequency.value = freq;
  g.gain.value = gain;
  osc.connect(g).connect(c.destination);
  osc.start();
  g.gain.exponentialRampToValueAtTime(0.0001, c.currentTime + durationMs / 1000);
  osc.stop(c.currentTime + durationMs / 1000);
}

let enabled = true;
export function setSoundEnabled(v: boolean) { enabled = v; }
export function getSoundEnabled() { return enabled; }

export const sfx = {
  send:    () => enabled && tone(880, 60, 'square', 0.03),
  receive: () => { if (!enabled) return; tone(660, 70, 'square', 0.04); setTimeout(() => tone(990, 90, 'square', 0.04), 80); },
  tap:     () => enabled && tone(1200, 25, 'square', 0.02),
  boot:    () => { if (!enabled) return; [523, 659, 784, 1046].forEach((f, i) => setTimeout(() => tone(f, 110, 'square', 0.05), i * 110)); },
  error:   () => enabled && tone(220, 200, 'sawtooth', 0.04),
};
