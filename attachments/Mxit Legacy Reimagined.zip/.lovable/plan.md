## Pre-launch QA + missing-Mxit deep dive

I scanned every screen, the route table, the DB schema, and the linter. The app is in good shape. There are a handful of real inconsistencies to fix and a small set of "classic Mxit" gaps worth closing before launch. Skipping anything that overlaps the deferred items you already nixed (push/Splash, Reach broadcast, ringtones store, camera tournaments).

---

### A. Inconsistencies to fix

1. **Broken Mobi Portal route from Tradepost.** `tradepost_services.route` for the Mobi Portal row is `/mobi`, but the actual route is `/portal/:app`. Tap currently lands on NotFound. Fix the seed row to `/portal/portal`.

2. **Softkey "Search" button is a 3rd middle button.** Right now the bottom bar is `Menu | Status | 🔍 | Chat`, which makes Chat narrow on small phones. Tighten layout: keep Menu and Chat as the two soft-keys (classic Mxit pattern), and put Status + Search as small icon buttons in the centre, equal width, with proper aria-labels.

3. **MultiMx in the Mxit system group.** The "MultiMx" row in the Contacts list is a system entry but the Menu also has "MultiMx (private groups)". Remove the duplicate from the Menu so the system row is the single entry-point (matches how Joe Banker / Tradepost work).

4. **No way back to Home from `/leaderboards`, `/meet`, `/moola`, `/music`, `/confessions`, `/polls`, `/games/tictactoe`.** Audit each — any page missing the classic title-bar `‹ Back` gets one (using the same `mxit-titlebar` pattern already in `Tradepost.tsx`).

5. **`AchievementsPanel` only on `/u/:mxitId` profile.** The owner can see it on their own profile via the same route, but the in-app "My profile" view (`HomeScreen` → ProfileView) doesn't render it. Add an "Achievements" card there too so users discover the system without leaving Home.

6. **Daily-claim streak shown only when claimable.** When already claimed, the streak number disappears. Show the streak as a small flame chip in the title-bar area whenever `streak_days > 0` so people see continuity.

7. **Global search is mounted but invisible to first-timers.** Add a one-time tooltip on the new softkey search icon ("Search any Mxit user — Ctrl+K") dismissed by tap. Stored in `localStorage`.

8. **Tradepost "Mobi Portal" duplicates the Contacts system row.** Either hide it from `tradepost_services` (set `enabled=false`) or rename to "Mobi Apps" so it doesn't read as a duplicate. Going with enabled=false — it's reachable from Contacts and the Menu already.

9. **Linter: 53 SECURITY DEFINER functions executable by `anon`/`authenticated`.** The functions all internally check `auth.uid()`, so they're not exploitable, but the linter is noisy and Apple/Google reviewers sometimes ask. Run `REVOKE EXECUTE … FROM anon` on every `public.*` RPC that requires a logged-in user (everything except `has_role`, `is_in_*`, `are_contacts`, `can_view_status`, `is_bot_base`, `owns_base`, `in_moonbase_alliance`, `user_meets_min_age` which are policy helpers). Cuts ~30 warnings without changing behavior.

10. **`tradepost_services.icon` for "Mobi Portal" missing icon mapping.** After step 8 it's hidden, no action needed.

---

### B. Missing classic-Mxit features worth shipping

These are the classic features still missing that don't fall under the deferred list:

1. **Read receipts toggle in Settings.** Schema already has `delivery` states. Add a `profiles.read_receipts_enabled` (default true) and gate the read-marker write behind it — classic Mxit always told you "read", but power-users today expect a toggle.

2. **"Typing…" indicator for 1-on-1 and MultiMx.** Use Supabase Realtime broadcast (no DB changes). Throttled to 1 ping/2s while the input has focus. Tiny but instantly makes chat feel "Mxit-alive".

3. **Skinz applied app-wide.** Skinz can be bought from `/tradepost/skinz`, but applying one only changes a wallpaper preview — it doesn't persist to `profiles.theme` and doesn't affect chat backgrounds globally. Wire purchases → set `profiles.theme` → `data-theme` already in `AuthContext` will pick it up.

4. **Contact-request notice in chrome.** When you have pending invites, the only signal is the orange dot in the title-bar. Add an inline banner (like the daily-claim banner) that says "N invites waiting" with an "Open" button that scrolls to the Invites group.

5. **In-chat Moola gift quick-action.** Today you can only gift via the contact row. Add a small Coins button next to the message composer that opens the same gift dialog targeted at the chat partner.

6. **Status seen-by counter in `/status`.** `status_views` table exists. Show "👁 12" on each of your own statuses.

7. **Block from chat header.** Blocking is in Settings only. Add a kebab menu in `Chat.tsx` header with Block / Report shortcuts (uses the existing `ReportBlockDialog`).

8. **App version + build info on `/help`.** Tiny but helpful for support; reads from `package.json` via Vite `import.meta.env`.

---

### C. Implementation order (single batch — small)

1. DB migration: `profiles.read_receipts_enabled` column + REVOKEs for security-definer RPCs.
2. Seed update via insert-tool: fix `/mobi` → `/portal/portal`, disable duplicate Mobi Portal Tradepost row.
3. `ContactsTab`: softkey reflow, drop MultiMx from menu, invites-waiting banner, persistent streak chip.
4. `HomeScreen` ProfileView: mount `AchievementsPanel`.
5. `Chat.tsx`: typing indicator + composer gift button + header kebab (block/report).
6. `MultiMxChat.tsx`: typing indicator.
7. `TradepostSkinz.tsx`: write `profiles.theme` on purchase.
8. `Status.tsx`: render `status_views` count on own statuses.
9. Add `‹ Back` title-bar to `/leaderboards`, `/meet`, `/moola`, `/music`, `/confessions`, `/polls`, `/games/tictactoe` where missing.
10. `Help` view in `HomeScreen`: append version line.
11. Search-icon first-time tooltip.

### D. Out of scope (already deferred per your call)
- PWA install prompt, push notifications, Splash horoscope on login
- Reach-style broadcast channels
- Ringtones / Wallpapers download store
- Camera quiz / trivia tournaments

### E. Risk
- All changes are additive or scoped to UI + one nullable column. The REVOKEs are reversible. No breaking schema changes; `types.ts` will refresh automatically.

If approved, I'll implement A + B in one go.