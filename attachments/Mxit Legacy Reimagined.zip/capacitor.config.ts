import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'app.lovable.9f204b9938cd4c669cb146422461a1c8',
  appName: 'mxit-the-legacy',
  webDir: 'dist',
  server: {
    url: 'https://9f204b99-38cd-4c66-9cb1-46422461a1c8.lovableproject.com?forceHideBadge=true',
    cleartext: true,
  },
  ios: {
    contentInset: 'always',
    backgroundColor: '#0A2A5E',
  },
  android: {
    backgroundColor: '#0A2A5E',
  },
};

export default config;
