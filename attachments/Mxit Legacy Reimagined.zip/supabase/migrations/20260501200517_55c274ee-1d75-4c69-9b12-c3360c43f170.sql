REVOKE ALL ON FUNCTION public.guard_message_recipient_read_update() FROM PUBLIC;
REVOKE ALL ON FUNCTION public.guard_message_recipient_read_update() FROM anon;
REVOKE ALL ON FUNCTION public.guard_message_recipient_read_update() FROM authenticated;