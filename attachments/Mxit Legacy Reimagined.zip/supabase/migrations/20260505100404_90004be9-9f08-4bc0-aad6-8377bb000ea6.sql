
-- Profile additions
ALTER TABLE public.profiles
  ADD COLUMN tags text[] NOT NULL DEFAULT '{}',
  ADD COLUMN birthday date,
  ADD COLUMN appear_offline boolean NOT NULL DEFAULT false;

CREATE INDEX idx_profiles_tags ON public.profiles USING GIN(tags);
CREATE INDEX idx_profiles_birthday ON public.profiles(birthday);

-- Mood history
CREATE TABLE public.mood_history (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  mood text,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_mood_history_user ON public.mood_history(user_id, created_at DESC);
ALTER TABLE public.mood_history ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Mood history visible to authenticated"
ON public.mood_history FOR SELECT TO authenticated USING (true);

CREATE POLICY "Insert own mood history"
ON public.mood_history FOR INSERT TO authenticated
WITH CHECK (user_id = auth.uid());

-- Trigger to auto-log mood changes
CREATE OR REPLACE FUNCTION public.log_mood_change()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NEW.mood IS DISTINCT FROM OLD.mood AND NEW.mood IS NOT NULL AND NEW.mood <> '' THEN
    INSERT INTO public.mood_history (user_id, mood) VALUES (NEW.id, NEW.mood);
  END IF;
  RETURN NEW;
END $$;

CREATE TRIGGER trg_log_mood_change
AFTER UPDATE OF mood ON public.profiles
FOR EACH ROW EXECUTE FUNCTION public.log_mood_change();

-- Guestbook
CREATE TABLE public.guestbook_entries (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  profile_id uuid NOT NULL,    -- whose guestbook
  author_id uuid NOT NULL,     -- who left it
  body text NOT NULL CHECK (char_length(body) <= 280),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX idx_guestbook_profile ON public.guestbook_entries(profile_id, created_at DESC);
ALTER TABLE public.guestbook_entries ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Guestbook visible to authenticated"
ON public.guestbook_entries FOR SELECT TO authenticated USING (true);

CREATE POLICY "Sign other people's guestbook (not your own)"
ON public.guestbook_entries FOR INSERT TO authenticated
WITH CHECK (author_id = auth.uid() AND author_id <> profile_id);

CREATE POLICY "Author or owner can delete"
ON public.guestbook_entries FOR DELETE TO authenticated
USING (author_id = auth.uid() OR profile_id = auth.uid());
