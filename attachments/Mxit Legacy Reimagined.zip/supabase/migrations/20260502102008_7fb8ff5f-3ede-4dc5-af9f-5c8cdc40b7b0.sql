-- Create public bucket for chat images/gifs only
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'chat-media',
  'chat-media',
  true,
  5242880,
  array['image/png','image/jpeg','image/jpg','image/webp','image/gif']
)
on conflict (id) do update set
  public = excluded.public,
  file_size_limit = excluded.file_size_limit,
  allowed_mime_types = excluded.allowed_mime_types;

-- Public read
create policy "Chat media public read"
on storage.objects for select
using (bucket_id = 'chat-media');

-- Authenticated upload into own folder (first path segment = user id)
create policy "Users upload own chat media"
on storage.objects for insert
to authenticated
with check (
  bucket_id = 'chat-media'
  and auth.uid()::text = (storage.foldername(name))[1]
);

-- Users update own files
create policy "Users update own chat media"
on storage.objects for update
to authenticated
using (
  bucket_id = 'chat-media'
  and auth.uid()::text = (storage.foldername(name))[1]
);

-- Users delete own files
create policy "Users delete own chat media"
on storage.objects for delete
to authenticated
using (
  bucket_id = 'chat-media'
  and auth.uid()::text = (storage.foldername(name))[1]
);