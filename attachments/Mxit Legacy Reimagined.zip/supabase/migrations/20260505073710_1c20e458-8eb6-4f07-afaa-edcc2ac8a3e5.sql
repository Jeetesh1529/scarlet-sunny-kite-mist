
-- Suspension columns
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS is_suspended boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS suspended_at timestamptz,
  ADD COLUMN IF NOT EXISTS suspended_reason text;

-- Allow admins to update any profile (for suspension actions)
DROP POLICY IF EXISTS "Admins update any profile" ON public.profiles;
CREATE POLICY "Admins update any profile"
ON public.profiles
FOR UPDATE
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));

-- Replace messages INSERT policy to block suspended senders
DROP POLICY IF EXISTS "Send messages as self" ON public.messages;
CREATE POLICY "Send messages as self"
ON public.messages
FOR INSERT
TO authenticated
WITH CHECK (
  auth.uid() = sender_id
  AND NOT EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND is_suspended = true)
  AND (
    (conversation_id IS NOT NULL AND is_in_conversation(conversation_id, auth.uid()))
    OR (room_id IS NOT NULL AND is_in_room(room_id, auth.uid()))
    OR (multimx_group_id IS NOT NULL AND is_in_multimx(multimx_group_id, auth.uid()))
  )
);

-- Allow admins to delete any message (in addition to senders deleting own)
DROP POLICY IF EXISTS "Admins delete any message" ON public.messages;
CREATE POLICY "Admins delete any message"
ON public.messages
FOR DELETE
TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));
