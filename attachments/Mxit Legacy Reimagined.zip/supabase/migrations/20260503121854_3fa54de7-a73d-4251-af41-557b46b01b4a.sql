
-- ============ TABLES ============
CREATE TABLE public.moonbase_bases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID UNIQUE,
  base_name TEXT NOT NULL,
  sector_x INTEGER NOT NULL,
  sector_y INTEGER NOT NULL,
  power_score INTEGER NOT NULL DEFAULT 100,
  is_bot BOOLEAN NOT NULL DEFAULT false,
  last_tick TIMESTAMPTZ NOT NULL DEFAULT now(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.moonbase_resources (
  base_id UUID PRIMARY KEY REFERENCES public.moonbase_bases(id) ON DELETE CASCADE,
  oxygen INTEGER NOT NULL DEFAULT 500,
  water INTEGER NOT NULL DEFAULT 500,
  iron INTEGER NOT NULL DEFAULT 800,
  helium INTEGER NOT NULL DEFAULT 300,
  capacity INTEGER NOT NULL DEFAULT 2000,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.moonbase_buildings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  base_id UUID NOT NULL REFERENCES public.moonbase_bases(id) ON DELETE CASCADE,
  building_type TEXT NOT NULL,
  level INTEGER NOT NULL DEFAULT 1,
  UNIQUE(base_id, building_type)
);

CREATE TABLE public.moonbase_units (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  base_id UUID NOT NULL REFERENCES public.moonbase_bases(id) ON DELETE CASCADE,
  unit_type TEXT NOT NULL,
  quantity INTEGER NOT NULL DEFAULT 0,
  UNIQUE(base_id, unit_type)
);

CREATE TABLE public.moonbase_attacks (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  attacker_base_id UUID NOT NULL REFERENCES public.moonbase_bases(id) ON DELETE CASCADE,
  defender_base_id UUID NOT NULL REFERENCES public.moonbase_bases(id) ON DELETE CASCADE,
  units_sent JSONB NOT NULL,
  result JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.moonbase_reports (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  title TEXT NOT NULL,
  body TEXT NOT NULL,
  kind TEXT NOT NULL DEFAULT 'system',
  is_read BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- ============ RLS ============
ALTER TABLE public.moonbase_bases ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.moonbase_resources ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.moonbase_buildings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.moonbase_units ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.moonbase_attacks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.moonbase_reports ENABLE ROW LEVEL SECURITY;

-- bases: own base + all bots visible to authenticated
CREATE POLICY "Bases viewable" ON public.moonbase_bases FOR SELECT TO authenticated
  USING (is_bot = true OR user_id = auth.uid());
CREATE POLICY "Insert own base" ON public.moonbase_bases FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());
CREATE POLICY "Update own base" ON public.moonbase_bases FOR UPDATE TO authenticated
  USING (user_id = auth.uid());

-- helper: is this base mine?
CREATE OR REPLACE FUNCTION public.owns_base(_base_id UUID)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.moonbase_bases WHERE id = _base_id AND user_id = auth.uid())
$$;

-- helper: is this base a bot?
CREATE OR REPLACE FUNCTION public.is_bot_base(_base_id UUID)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.moonbase_bases WHERE id = _base_id AND is_bot = true)
$$;

-- resources / buildings / units: visible if base is mine OR bot (so scout works)
CREATE POLICY "Resources viewable" ON public.moonbase_resources FOR SELECT TO authenticated
  USING (public.owns_base(base_id) OR public.is_bot_base(base_id));
CREATE POLICY "Resources mutate own" ON public.moonbase_resources FOR ALL TO authenticated
  USING (public.owns_base(base_id)) WITH CHECK (public.owns_base(base_id));

CREATE POLICY "Buildings viewable" ON public.moonbase_buildings FOR SELECT TO authenticated
  USING (public.owns_base(base_id) OR public.is_bot_base(base_id));
CREATE POLICY "Buildings mutate own" ON public.moonbase_buildings FOR ALL TO authenticated
  USING (public.owns_base(base_id)) WITH CHECK (public.owns_base(base_id));

CREATE POLICY "Units viewable" ON public.moonbase_units FOR SELECT TO authenticated
  USING (public.owns_base(base_id) OR public.is_bot_base(base_id));
CREATE POLICY "Units mutate own" ON public.moonbase_units FOR ALL TO authenticated
  USING (public.owns_base(base_id)) WITH CHECK (public.owns_base(base_id));

-- attacks: see if I'm attacker or defender; insert as my base only
CREATE POLICY "Attacks viewable" ON public.moonbase_attacks FOR SELECT TO authenticated
  USING (public.owns_base(attacker_base_id) OR public.owns_base(defender_base_id));
CREATE POLICY "Attacks insert as me" ON public.moonbase_attacks FOR INSERT TO authenticated
  WITH CHECK (public.owns_base(attacker_base_id));

-- reports: only mine
CREATE POLICY "Reports own select" ON public.moonbase_reports FOR SELECT TO authenticated
  USING (user_id = auth.uid());
CREATE POLICY "Reports own insert" ON public.moonbase_reports FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid());
CREATE POLICY "Reports own update" ON public.moonbase_reports FOR UPDATE TO authenticated
  USING (user_id = auth.uid());

-- ============ SEED BOT BASES ============
DO $$
DECLARE
  names TEXT[] := ARRAY['DarkWolf77','LunarKing','NoxBase','ZARaiders','ShadowBase','HeliumPit','IceRidge','MoonKingZA','CapeRaider','OrbitOne','VoidStar','RedSector'];
  n TEXT;
  bid UUID;
BEGIN
  FOREACH n IN ARRAY names LOOP
    INSERT INTO public.moonbase_bases (base_name, sector_x, sector_y, power_score, is_bot)
    VALUES (n, 1 + floor(random()*20)::int, 1 + floor(random()*20)::int, 200 + floor(random()*1500)::int, true)
    RETURNING id INTO bid;
    INSERT INTO public.moonbase_resources (base_id, oxygen, water, iron, helium, capacity)
    VALUES (bid,
      300 + floor(random()*1500)::int,
      300 + floor(random()*1500)::int,
      300 + floor(random()*1500)::int,
      100 + floor(random()*800)::int,
      3000);
    INSERT INTO public.moonbase_units (base_id, unit_type, quantity) VALUES
      (bid, 'moonbuggy', 10 + floor(random()*60)::int),
      (bid, 'gunship', floor(random()*15)::int);
  END LOOP;
END $$;
