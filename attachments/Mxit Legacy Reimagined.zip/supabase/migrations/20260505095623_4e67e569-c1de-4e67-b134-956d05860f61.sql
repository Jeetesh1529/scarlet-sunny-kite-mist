
-- Reactions
CREATE TABLE public.message_reactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  message_id uuid NOT NULL REFERENCES public.messages(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  emoji text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (message_id, user_id, emoji)
);
CREATE INDEX idx_reactions_msg ON public.message_reactions(message_id);
ALTER TABLE public.message_reactions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Reactions visible if message visible"
ON public.message_reactions FOR SELECT TO authenticated
USING (EXISTS (
  SELECT 1 FROM public.messages m
  WHERE m.id = message_reactions.message_id
    AND (
      (m.conversation_id IS NOT NULL AND public.is_in_conversation(m.conversation_id, auth.uid()))
      OR (m.room_id IS NOT NULL AND public.is_in_room(m.room_id, auth.uid()))
      OR (m.multimx_group_id IS NOT NULL AND public.is_in_multimx(m.multimx_group_id, auth.uid()))
    )
));

CREATE POLICY "React as self if can see message"
ON public.message_reactions FOR INSERT TO authenticated
WITH CHECK (
  user_id = auth.uid()
  AND EXISTS (
    SELECT 1 FROM public.messages m
    WHERE m.id = message_reactions.message_id
      AND (
        (m.conversation_id IS NOT NULL AND public.is_in_conversation(m.conversation_id, auth.uid()))
        OR (m.room_id IS NOT NULL AND public.is_in_room(m.room_id, auth.uid()))
        OR (m.multimx_group_id IS NOT NULL AND public.is_in_multimx(m.multimx_group_id, auth.uid()))
      )
  )
);

CREATE POLICY "Remove own reaction"
ON public.message_reactions FOR DELETE TO authenticated
USING (user_id = auth.uid());

-- Reply / forward / expiry on messages
ALTER TABLE public.messages
  ADD COLUMN reply_to_id uuid REFERENCES public.messages(id) ON DELETE SET NULL,
  ADD COLUMN forwarded_from uuid REFERENCES public.messages(id) ON DELETE SET NULL,
  ADD COLUMN expires_at timestamptz;

CREATE INDEX idx_messages_expires ON public.messages(expires_at) WHERE expires_at IS NOT NULL;

-- Per-conversation disappearing duration in seconds (0 = off)
ALTER TABLE public.conversations
  ADD COLUMN disappearing_seconds integer NOT NULL DEFAULT 0;

-- Purge function
CREATE OR REPLACE FUNCTION public.purge_expired_messages()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  DELETE FROM public.messages WHERE expires_at IS NOT NULL AND expires_at < now();
END $$;

-- Cron every 5 minutes
SELECT cron.schedule(
  'purge-expired-messages',
  '*/5 * * * *',
  $$ SELECT public.purge_expired_messages(); $$
);
