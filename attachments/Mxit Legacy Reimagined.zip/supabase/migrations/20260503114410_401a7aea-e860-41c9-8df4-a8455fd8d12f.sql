-- 1. Moola products catalog
CREATE TABLE IF NOT EXISTS public.moola_products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  product_id text NOT NULL UNIQUE,
  label text NOT NULL,
  moola_amount integer NOT NULL CHECK (moola_amount > 0),
  zar_value numeric(10,2) NOT NULL CHECK (zar_value > 0),
  bonus_moola integer NOT NULL DEFAULT 0,
  position integer NOT NULL DEFAULT 0,
  enabled boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.moola_products ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Moola products viewable by authenticated"
ON public.moola_products FOR SELECT TO authenticated USING (true);

INSERT INTO public.moola_products (product_id, label, moola_amount, zar_value, bonus_moola, position) VALUES
  ('moola_50',   '50 Moola',    50,    5.00,   0, 1),
  ('moola_100',  '100 Moola',   100,   10.00,  0, 2),
  ('moola_250',  '250 Moola',   250,   25.00,  10, 3),
  ('moola_500',  '500 Moola',   500,   50.00,  40, 4),
  ('moola_1000', '1,000 Moola', 1000,  100.00, 120, 5),
  ('moola_2500', '2,500 Moola', 2500,  250.00, 400, 6)
ON CONFLICT (product_id) DO NOTHING;

-- 2. Extend moola_transactions ledger
ALTER TABLE public.moola_transactions
  ADD COLUMN IF NOT EXISTS type text NOT NULL DEFAULT 'adjustment',
  ADD COLUMN IF NOT EXISTS balance_before integer,
  ADD COLUMN IF NOT EXISTS balance_after integer,
  ADD COLUMN IF NOT EXISTS source text,
  ADD COLUMN IF NOT EXISTS store text,
  ADD COLUMN IF NOT EXISTS store_product_id text,
  ADD COLUMN IF NOT EXISTS store_transaction_id text;

CREATE UNIQUE INDEX IF NOT EXISTS moola_tx_store_txid_unique
  ON public.moola_transactions (store_transaction_id)
  WHERE store_transaction_id IS NOT NULL;

-- 3. Reset everyone to 100 Moola starter under new economy
DO $$
DECLARE r record;
BEGIN
  FOR r IN SELECT id, moola FROM public.profiles LOOP
    UPDATE public.profiles SET moola = 100 WHERE id = r.id;
    INSERT INTO public.moola_transactions
      (user_id, amount, reason, type, balance_before, balance_after, source)
    VALUES
      (r.id, 100 - r.moola, 'New economy reset · welcome to the new Moola (1M = R0.10)',
       'bonus', r.moola, 100, 'system_reset');
  END LOOP;
END $$;