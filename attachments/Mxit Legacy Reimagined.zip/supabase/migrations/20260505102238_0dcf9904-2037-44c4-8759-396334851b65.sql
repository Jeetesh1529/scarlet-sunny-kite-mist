
-- Moderator role (in addition to existing 'admin')
DO $$ BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_enum WHERE enumlabel = 'moderator' AND enumtypid = 'app_role'::regtype) THEN
    ALTER TYPE app_role ADD VALUE 'moderator';
  END IF;
END $$;

-- Age-gate enforcement: ensure min_age column on zones is honored at app layer (already exists).
-- Profiles already track age. Add helper to check eligibility.
CREATE OR REPLACE FUNCTION public.user_meets_min_age(_user uuid, _min_age int)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT COALESCE((SELECT age FROM public.profiles WHERE id = _user), 0) >= COALESCE(_min_age, 0)
$$;

-- Moderation: hide messages without deleting (for context preservation)
ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS hidden_by_mod boolean NOT NULL DEFAULT false;
ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS hidden_reason text;

-- Allow moderators to hide messages
CREATE POLICY "Moderators can hide messages"
ON public.messages FOR UPDATE TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'moderator'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'moderator'::app_role));

-- NSFW flagging on messages with media
ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS nsfw_score numeric;
ALTER TABLE public.messages ADD COLUMN IF NOT EXISTS auto_flagged boolean NOT NULL DEFAULT false;

-- Site-wide announcements (admin broadcasts)
CREATE TABLE IF NOT EXISTS public.announcements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  author_id uuid NOT NULL,
  title text NOT NULL,
  body text NOT NULL,
  severity text NOT NULL DEFAULT 'info',
  starts_at timestamptz NOT NULL DEFAULT now(),
  ends_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.announcements ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Active announcements visible to all"
ON public.announcements FOR SELECT TO authenticated
USING (starts_at <= now() AND (ends_at IS NULL OR ends_at > now()));

CREATE POLICY "Admins manage announcements"
ON public.announcements FOR ALL TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role))
WITH CHECK (has_role(auth.uid(), 'admin'::app_role) AND author_id = auth.uid());

-- Track which announcements a user has dismissed
CREATE TABLE IF NOT EXISTS public.announcement_dismissals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  announcement_id uuid NOT NULL,
  dismissed_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, announcement_id)
);
ALTER TABLE public.announcement_dismissals ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users dismiss own" ON public.announcement_dismissals
  FOR ALL TO authenticated USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());

-- Moderators can also see/manage all reports
CREATE POLICY "Moderators view all reports"
ON public.user_reports FOR SELECT TO authenticated
USING (has_role(auth.uid(), 'moderator'::app_role));

CREATE POLICY "Moderators update reports"
ON public.user_reports FOR UPDATE TO authenticated
USING (has_role(auth.uid(), 'moderator'::app_role));

-- Suspend / unsuspend RPC for admins/mods
CREATE OR REPLACE FUNCTION public.moderate_user(_user uuid, _suspend boolean, _reason text DEFAULT NULL)
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  IF NOT (has_role(auth.uid(), 'admin'::app_role) OR has_role(auth.uid(), 'moderator'::app_role)) THEN
    RAISE EXCEPTION 'Not authorized';
  END IF;
  UPDATE public.profiles SET
    is_suspended = _suspend,
    suspended_at = CASE WHEN _suspend THEN now() ELSE NULL END,
    suspended_reason = CASE WHEN _suspend THEN _reason ELSE NULL END
  WHERE id = _user;
END $$;

-- Daily Active Users analytics view (last 30 days)
CREATE OR REPLACE VIEW public.analytics_dau AS
SELECT
  date_trunc('day', created_at)::date AS day,
  COUNT(DISTINCT user_id) FILTER (WHERE user_id IS NOT NULL) AS dau,
  COUNT(*) AS events
FROM public.analytics_events
WHERE created_at >= now() - interval '30 days'
GROUP BY 1
ORDER BY 1;
ALTER VIEW public.analytics_dau SET (security_invoker = true);
GRANT SELECT ON public.analytics_dau TO authenticated;

-- Top rooms by message volume in last 7 days
CREATE OR REPLACE VIEW public.analytics_top_rooms AS
SELECT
  m.room_id,
  c.name AS room_name,
  COUNT(*) AS messages,
  COUNT(DISTINCT m.sender_id) AS unique_senders
FROM public.messages m
JOIN public.chatrooms c ON c.id = m.room_id
WHERE m.room_id IS NOT NULL AND m.created_at >= now() - interval '7 days'
GROUP BY m.room_id, c.name
ORDER BY messages DESC
LIMIT 25;
ALTER VIEW public.analytics_top_rooms SET (security_invoker = true);
GRANT SELECT ON public.analytics_top_rooms TO authenticated;

-- Retention: percentage of users active today who were also active 7 days ago
CREATE OR REPLACE VIEW public.analytics_retention_d7 AS
WITH today AS (
  SELECT DISTINCT user_id FROM public.analytics_events
  WHERE created_at >= date_trunc('day', now()) AND user_id IS NOT NULL
),
seven_days_ago AS (
  SELECT DISTINCT user_id FROM public.analytics_events
  WHERE created_at >= date_trunc('day', now() - interval '7 days')
    AND created_at <  date_trunc('day', now() - interval '6 days')
    AND user_id IS NOT NULL
)
SELECT
  (SELECT COUNT(*) FROM today) AS active_today,
  (SELECT COUNT(*) FROM seven_days_ago) AS cohort_size,
  CASE WHEN (SELECT COUNT(*) FROM seven_days_ago) = 0 THEN 0
       ELSE ROUND(100.0 * (SELECT COUNT(*) FROM today t WHERE t.user_id IN (SELECT user_id FROM seven_days_ago))
                  / (SELECT COUNT(*) FROM seven_days_ago), 1)
  END AS retention_pct;
ALTER VIEW public.analytics_retention_d7 SET (security_invoker = true);
GRANT SELECT ON public.analytics_retention_d7 TO authenticated;
