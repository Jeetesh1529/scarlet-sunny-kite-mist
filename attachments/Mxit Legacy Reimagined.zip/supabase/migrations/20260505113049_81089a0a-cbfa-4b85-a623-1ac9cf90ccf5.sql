-- Batch E3: Achievements, Leaderboards, Meet/Dating opt-in

-- 1) Achievements catalog
CREATE TABLE public.achievements (
  id text PRIMARY KEY,
  name text NOT NULL,
  description text NOT NULL,
  icon text NOT NULL DEFAULT '🏆',
  tier text NOT NULL DEFAULT 'bronze',
  moola_reward integer NOT NULL DEFAULT 0,
  position integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.achievements ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Achievements readable by all"
  ON public.achievements FOR SELECT TO authenticated, anon USING (true);

-- 2) User unlocks
CREATE TABLE public.user_achievements (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  achievement_id text NOT NULL REFERENCES public.achievements(id) ON DELETE CASCADE,
  unlocked_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, achievement_id)
);
ALTER TABLE public.user_achievements ENABLE ROW LEVEL SECURITY;
CREATE POLICY "User achievements readable by all"
  ON public.user_achievements FOR SELECT TO authenticated USING (true);
-- Inserts/deletes only via SECURITY DEFINER award function below.

-- 3) Profile flag for "Meet People" zone (dating opt-in)
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS meet_opt_in boolean NOT NULL DEFAULT false;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS meet_bio text;
CREATE INDEX IF NOT EXISTS idx_profiles_meet_opt_in ON public.profiles(meet_opt_in) WHERE meet_opt_in = true;

-- 4) Award function (security definer, awards once + pays Moola)
CREATE OR REPLACE FUNCTION public.award_achievement(_achievement text)
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  uid uuid := auth.uid();
  a RECORD;
  cur integer;
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  SELECT * INTO a FROM public.achievements WHERE id = _achievement;
  IF a.id IS NULL THEN RETURN jsonb_build_object('ok', false, 'reason', 'not_found'); END IF;
  IF EXISTS (SELECT 1 FROM public.user_achievements WHERE user_id = uid AND achievement_id = _achievement) THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'already_unlocked');
  END IF;
  INSERT INTO public.user_achievements (user_id, achievement_id) VALUES (uid, _achievement);
  IF a.moola_reward > 0 THEN
    SELECT moola INTO cur FROM public.profiles WHERE id = uid FOR UPDATE;
    UPDATE public.profiles SET moola = cur + a.moola_reward WHERE id = uid;
    INSERT INTO public.moola_transactions (user_id, amount, reason, type, balance_before, balance_after, source)
      VALUES (uid, a.moola_reward, 'Achievement: ' || a.name, 'bonus', cur, cur + a.moola_reward, 'achievement');
  END IF;
  RETURN jsonb_build_object('ok', true, 'achievement', a.id, 'name', a.name, 'icon', a.icon, 'reward', a.moola_reward);
END $$;

-- 5) Seed catalog
INSERT INTO public.achievements (id, name, description, icon, tier, moola_reward, position) VALUES
  ('first_message', 'Saying Hello', 'Send your first chat message', '💬', 'bronze', 10, 10),
  ('first_status',  'Going Public', 'Post your first status', '📸', 'bronze', 10, 20),
  ('streak_7',      'On a Roll', 'Login 7 days in a row', '🔥', 'silver', 50, 30),
  ('streak_30',     'Mxit Loyalist', 'Login 30 days in a row', '👑', 'gold', 200, 40),
  ('chatroom_join', 'Roomie', 'Join your first chat room', '🚪', 'bronze', 10, 50),
  ('multimx_create','Group Founder', 'Start a MultiMx group', '👥', 'silver', 25, 60),
  ('confession',    'Off Your Chest', 'Post your first confession', '🤫', 'bronze', 10, 70),
  ('voice_note',    'Speak Up', 'Send your first voice note', '🎤', 'bronze', 10, 80),
  ('moola_tip',     'Generous Soul', 'Tip Moola to someone', '💰', 'silver', 25, 90),
  ('meet_optin',    'Looking to Meet', 'Join the Meet People zone', '💞', 'bronze', 20, 100),
  ('moonbase_first','Moon Pioneer', 'Build your first Moonbase', '🌖', 'silver', 50, 110)
ON CONFLICT (id) DO NOTHING;

-- 6) Add Tradepost service entries
INSERT INTO public.tradepost_services (slug, name, description, icon, route, cost_moola, position, enabled)
VALUES
  ('meet',        'Meet People', 'Browse singles & say hi',         'Sparkles',    '/meet',        0, 12, true),
  ('leaderboards','Leaderboards','See the top Moola earners & streaks','BarChart3','/leaderboards',0, 13, true)
ON CONFLICT (slug) DO NOTHING;