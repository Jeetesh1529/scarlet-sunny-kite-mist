CREATE OR REPLACE FUNCTION public.guard_message_recipient_read_update()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF auth.uid() IS NULL THEN
    RAISE EXCEPTION 'Not authenticated';
  END IF;

  IF OLD.sender_id <> auth.uid() THEN
    IF OLD.conversation_id IS NULL THEN
      RAISE EXCEPTION 'Only direct messages can be marked read by recipients';
    END IF;

    IF NEW.id IS DISTINCT FROM OLD.id
      OR NEW.conversation_id IS DISTINCT FROM OLD.conversation_id
      OR NEW.room_id IS DISTINCT FROM OLD.room_id
      OR NEW.sender_id IS DISTINCT FROM OLD.sender_id
      OR NEW.content IS DISTINCT FROM OLD.content
      OR NEW.created_at IS DISTINCT FROM OLD.created_at
      OR NEW.delivery IS DISTINCT FROM 'read'::public.delivery_state THEN
      RAISE EXCEPTION 'Recipients can only mark messages as read';
    END IF;
  END IF;

  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS guard_message_recipient_read_update ON public.messages;

CREATE TRIGGER guard_message_recipient_read_update
BEFORE UPDATE ON public.messages
FOR EACH ROW
EXECUTE FUNCTION public.guard_message_recipient_read_update();