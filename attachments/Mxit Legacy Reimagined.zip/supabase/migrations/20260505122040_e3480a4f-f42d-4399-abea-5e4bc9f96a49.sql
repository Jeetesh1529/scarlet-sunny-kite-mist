
-- 1) send_moola: add cooldown + daily cap
CREATE OR REPLACE FUNCTION public.send_moola(_to uuid, _amount integer, _note text DEFAULT NULL::text, _message_id uuid DEFAULT NULL::uuid)
 RETURNS jsonb
 LANGUAGE plpgsql
 SECURITY DEFINER
 SET search_path TO 'public'
AS $function$
DECLARE
  uid uuid := auth.uid();
  sender_bal integer;
  receiver_bal integer;
  last_send timestamptz;
  sent_today integer;
  daily_cap integer := 50000;
  cooldown_seconds integer := 3;
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  IF _to = uid THEN RAISE EXCEPTION 'Cannot send to yourself'; END IF;
  IF _amount IS NULL OR _amount <= 0 THEN RAISE EXCEPTION 'Amount must be positive'; END IF;
  IF _amount > daily_cap THEN RAISE EXCEPTION 'Amount exceeds daily limit (% Moola)', daily_cap; END IF;

  -- Cooldown: reject if last send less than N seconds ago
  SELECT MAX(created_at) INTO last_send
    FROM public.moola_transactions
    WHERE user_id = uid AND source = 'send' AND amount < 0;
  IF last_send IS NOT NULL AND last_send > now() - make_interval(secs => cooldown_seconds) THEN
    RAISE EXCEPTION 'Please wait a moment before sending again';
  END IF;

  -- Daily cap: sum of today's sends (positive amount of negative entries)
  SELECT COALESCE(SUM(-amount), 0) INTO sent_today
    FROM public.moola_transactions
    WHERE user_id = uid
      AND source = 'send'
      AND amount < 0
      AND created_at >= (now() AT TIME ZONE 'utc')::date;
  IF sent_today + _amount > daily_cap THEN
    RAISE EXCEPTION 'Daily transfer limit reached (% Moola/day)', daily_cap;
  END IF;

  SELECT moola INTO sender_bal FROM public.profiles WHERE id = uid FOR UPDATE;
  IF sender_bal IS NULL THEN RAISE EXCEPTION 'No profile'; END IF;
  IF sender_bal < _amount THEN RAISE EXCEPTION 'Insufficient Moola'; END IF;

  SELECT moola INTO receiver_bal FROM public.profiles WHERE id = _to FOR UPDATE;
  IF receiver_bal IS NULL THEN RAISE EXCEPTION 'Recipient not found'; END IF;

  UPDATE public.profiles SET moola = sender_bal - _amount WHERE id = uid;
  UPDATE public.profiles SET moola = receiver_bal + _amount WHERE id = _to;

  INSERT INTO public.moola_transactions (user_id, amount, reason, type, balance_before, balance_after, source)
  VALUES (uid, -_amount, COALESCE(_note, 'Sent Moola'), 'transfer', sender_bal, sender_bal - _amount, 'send');
  INSERT INTO public.moola_transactions (user_id, amount, reason, type, balance_before, balance_after, source)
  VALUES (_to, _amount, COALESCE(_note, 'Received Moola'), 'transfer', receiver_bal, receiver_bal + _amount, 'receive');

  IF _message_id IS NOT NULL THEN
    INSERT INTO public.moola_tips (from_user, to_user, message_id, amount) VALUES (uid, _to, _message_id, _amount);
  END IF;

  RETURN jsonb_build_object('ok', true, 'balance', sender_bal - _amount);
END $function$;

-- 2) Revoke EXECUTE from anon on user-only RPCs (these all check auth.uid() internally)
REVOKE EXECUTE ON FUNCTION public.send_moola(uuid, integer, text, uuid) FROM anon;
REVOKE EXECUTE ON FUNCTION public.claim_daily_moola() FROM anon;
REVOKE EXECUTE ON FUNCTION public.spin_daily_wheel() FROM anon;
REVOKE EXECUTE ON FUNCTION public.award_achievement(text) FROM anon;
REVOKE EXECUTE ON FUNCTION public.delete_my_account() FROM anon;
REVOKE EXECUTE ON FUNCTION public.accept_moonbase_trade(uuid) FROM anon;
REVOKE EXECUTE ON FUNCTION public.join_best_room(uuid) FROM anon;
REVOKE EXECUTE ON FUNCTION public.moderate_user(uuid, boolean, text) FROM anon;
REVOKE EXECUTE ON FUNCTION public.purge_expired_messages() FROM anon;
REVOKE EXECUTE ON FUNCTION public.purge_expired_statuses() FROM anon;
