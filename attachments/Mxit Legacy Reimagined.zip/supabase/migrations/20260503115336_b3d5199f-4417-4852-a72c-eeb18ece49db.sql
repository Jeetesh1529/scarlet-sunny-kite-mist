
-- 1. Categories
CREATE TABLE IF NOT EXISTS public.chat_categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text NOT NULL UNIQUE,
  description text,
  min_age integer NOT NULL DEFAULT 14,
  position integer NOT NULL DEFAULT 0,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.chat_categories ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Categories viewable by authenticated"
  ON public.chat_categories FOR SELECT TO authenticated USING (true);

-- 2. Zones get category + system slug
ALTER TABLE public.chatroom_zones
  ADD COLUMN IF NOT EXISTS category_id uuid REFERENCES public.chat_categories(id) ON DELETE CASCADE;

-- 3. Wipe existing zone-linked rooms/members and zones (clean reseed)
DELETE FROM public.room_members
  WHERE room_id IN (SELECT id FROM public.chatrooms WHERE zone_id IS NOT NULL);
DELETE FROM public.messages
  WHERE room_id IN (SELECT id FROM public.chatrooms WHERE zone_id IS NOT NULL);
DELETE FROM public.chatrooms WHERE zone_id IS NOT NULL;
DELETE FROM public.chatroom_zones;

-- 4. Bump default room cap
ALTER TABLE public.chatrooms ALTER COLUMN max_users SET DEFAULT 30;

-- 5. Seed categories
INSERT INTO public.chat_categories (name, slug, description, min_age, position) VALUES
  ('Flirt Chatzones',       'flirt',       'Meet new people and flirt',         18, 1),
  ('Grown-up Chatrooms',    'grownup',     'Adult general social rooms',        18, 2),
  ('Kingdom Chatzones',     'kingdom',     'Roleplay and fantasy realms',       16, 3),
  ('Topical Chatzones',     'topical',     'Talk about your favourite topics',  14, 4),
  ('Geographical Chatzones','geographic',  'Chat with people in your area',     14, 5);

-- 6. Seed zones
WITH cat AS (SELECT id, slug FROM public.chat_categories)
INSERT INTO public.chatroom_zones (name, slug, description, category, min_age, position, category_id)
SELECT z.name, z.slug, z.description, c.slug, z.min_age, z.position, c.id
FROM (VALUES
  -- Flirt
  ('flirt', 'AlphaCon',         'alphacon',         'High-energy flirt zone',       18, 1),
  ('flirt', 'Boondocks',        'boondocks',        'Off-the-grid hangout',         18, 2),
  ('flirt', 'Fantasy Island',   'fantasy-island',   'Imagination meets attraction', 18, 3),
  ('flirt', 'Crush Corner',     'crush-corner',     'Confess your crush',           18, 4),
  ('flirt', 'Single & Social',  'single-social',    'For singles only',             18, 5),
  ('flirt', 'Late Night Flirt', 'late-night-flirt', 'After-hours flirting',         18, 6),
  -- Grown-up
  ('grownup', '30 Something',     '30-something',     'Hangout for thirty-somethings', 18, 1),
  ('grownup', 'Single Parents',   'single-parents',   'For single moms and dads',      18, 2),
  ('grownup', 'Lisa''s Lounge',   'lisas-lounge',     'Chilled chat lounge',           18, 3),
  ('grownup', 'The Jazz Cafe',    'jazz-cafe',        'Smooth conversations',          18, 4),
  ('grownup', 'After Work Lounge','after-work',       'Unwind after work',             18, 5),
  ('grownup', 'Over 25s',         'over-25s',         'Strictly over 25',              25, 6),
  -- Kingdom
  ('kingdom', 'The Castle',     'the-castle',     'Royal grounds',           16, 1),
  ('kingdom', 'Dark Mountain',  'dark-mountain',  'Foreboding peaks',        16, 2),
  ('kingdom', 'Greggori''s Inn','greggoris-inn',  'Tavern roleplay',         16, 3),
  ('kingdom', 'Dragon Valley',  'dragon-valley',  'Where dragons roam',      16, 4),
  ('kingdom', 'Mystic Forest',  'mystic-forest',  'Enchanted woodlands',     16, 5),
  ('kingdom', 'Royal Court',    'royal-court',    'Audience with the crown', 16, 6),
  -- Topical
  ('topical', 'Cars',            'cars',         'Petrolheads unite',       14, 1),
  ('topical', 'Technology',      'tech',         'Gadgets and gear',        14, 2),
  ('topical', 'Fashion',         'fashion',      'Style and trends',        14, 3),
  ('topical', 'Music',           'music',        'All genres, all artists', 14, 4),
  ('topical', 'Gaming',          'gaming',       'Console and PC',          14, 5),
  ('topical', 'Sports',          'sports',       'Match talk',              14, 6),
  ('topical', 'Movies',          'movies',       'Films and series',        14, 7),
  ('topical', 'Business',        'business',     'Entrepreneurs corner',    18, 8),
  ('topical', 'Forex & Trading', 'forex',        'Markets and trading',     18, 9),
  ('topical', 'AI & Tech',       'ai-tech',      'AI, ML and the future',   14, 10),
  -- Geographical
  ('geographic', 'Cape Town',       'cape-town',       'Mother City chat',  14, 1),
  ('geographic', 'Durban',          'durban',          'eThekwini vibes',   14, 2),
  ('geographic', 'East London',     'east-london',     'Buffalo City',      14, 3),
  ('geographic', 'Gauteng',         'gauteng',         'Province-wide',     14, 4),
  ('geographic', 'Jozi',            'jozi',            'City of Gold',      14, 5),
  ('geographic', 'PE',              'pe',              'Gqeberha chat',     14, 6),
  ('geographic', 'Pietermaritzburg','pmb',             'Capital of KZN',    14, 7),
  ('geographic', 'Pretoria',        'pretoria',        'Jacaranda city',    14, 8),
  ('geographic', 'Bloemfontein',    'bloemfontein',    'City of Roses',     14, 9),
  ('geographic', 'Kimberley',       'kimberley',       'Diamond city',      14, 10),
  ('geographic', 'Polokwane',       'polokwane',       'Limpopo chat',      14, 11),
  ('geographic', 'Nelspruit',       'nelspruit',       'Mbombela chat',     14, 12)
) AS z(cat_slug, name, slug, description, min_age, position)
JOIN cat c ON c.slug = z.cat_slug;

-- 7. Seed 4 starter rooms per zone, 30 users each, named "ZoneName{N}"
INSERT INTO public.chatrooms (name, topic, zone_id, room_number, max_users, cost_per_message, is_official)
SELECT z.name || n.n::text, z.description, z.id, n.n, 30, 0, true
FROM public.chatroom_zones z
CROSS JOIN generate_series(1, 4) AS n(n);

-- 8. Auto-join RPC: returns the first room with capacity in a zone, creating one if needed.
CREATE OR REPLACE FUNCTION public.join_best_room(_zone_id uuid)
RETURNS uuid
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  uid uuid := auth.uid();
  z RECORD;
  r RECORD;
  next_n integer;
  zname text;
  new_room_id uuid;
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  SELECT id, name INTO z FROM public.chatroom_zones WHERE id = _zone_id;
  IF z.id IS NULL THEN RAISE EXCEPTION 'Zone not found'; END IF;

  -- Already a member of any room in this zone? Reuse it.
  SELECT c.id INTO new_room_id
  FROM public.chatrooms c
  JOIN public.room_members rm ON rm.room_id = c.id AND rm.user_id = uid
  WHERE c.zone_id = z.id
  ORDER BY c.room_number
  LIMIT 1;
  IF new_room_id IS NOT NULL THEN RETURN new_room_id; END IF;

  -- Find first non-full room
  FOR r IN
    SELECT c.id, c.max_users, c.room_number,
           (SELECT count(*) FROM public.room_members rm WHERE rm.room_id = c.id) AS members
    FROM public.chatrooms c
    WHERE c.zone_id = z.id
    ORDER BY c.room_number
  LOOP
    IF r.members < r.max_users THEN
      INSERT INTO public.room_members (room_id, user_id) VALUES (r.id, uid)
      ON CONFLICT DO NOTHING;
      RETURN r.id;
    END IF;
  END LOOP;

  -- All full: create the next numbered room
  SELECT COALESCE(MAX(room_number), 0) + 1 INTO next_n
    FROM public.chatrooms WHERE zone_id = z.id;
  zname := z.name || next_n::text;
  INSERT INTO public.chatrooms (name, topic, zone_id, room_number, max_users, cost_per_message, is_official)
  VALUES (zname, NULL, z.id, next_n, 30, 0, true)
  RETURNING id INTO new_room_id;

  INSERT INTO public.room_members (room_id, user_id) VALUES (new_room_id, uid);
  RETURN new_room_id;
END $$;

GRANT EXECUTE ON FUNCTION public.join_best_room(uuid) TO authenticated;
