ALTER TABLE public.messages DROP CONSTRAINT IF EXISTS messages_check;

ALTER TABLE public.messages ADD CONSTRAINT messages_target_check CHECK (
  (
    (CASE WHEN conversation_id IS NOT NULL THEN 1 ELSE 0 END)
  + (CASE WHEN room_id IS NOT NULL THEN 1 ELSE 0 END)
  + (CASE WHEN multimx_group_id IS NOT NULL THEN 1 ELSE 0 END)
  ) = 1
);

ALTER PUBLICATION supabase_realtime ADD TABLE public.multimx_groups;
ALTER PUBLICATION supabase_realtime ADD TABLE public.multimx_members;