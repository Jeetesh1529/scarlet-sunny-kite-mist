
-- CALLS (signaling)
CREATE TABLE public.calls (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  caller_id uuid NOT NULL,
  callee_id uuid NOT NULL,
  kind text NOT NULL DEFAULT 'voice', -- 'voice' | 'video'
  status text NOT NULL DEFAULT 'ringing', -- ringing|accepted|declined|ended|missed
  offer jsonb,
  answer jsonb,
  caller_ice jsonb NOT NULL DEFAULT '[]'::jsonb,
  callee_ice jsonb NOT NULL DEFAULT '[]'::jsonb,
  started_at timestamptz NOT NULL DEFAULT now(),
  ended_at timestamptz,
  updated_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.calls ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Participants view calls" ON public.calls FOR SELECT TO authenticated
  USING (auth.uid() = caller_id OR auth.uid() = callee_id);
CREATE POLICY "Caller creates call" ON public.calls FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = caller_id);
CREATE POLICY "Participants update call" ON public.calls FOR UPDATE TO authenticated
  USING (auth.uid() = caller_id OR auth.uid() = callee_id);
CREATE TRIGGER tg_calls_updated BEFORE UPDATE ON public.calls
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();
ALTER PUBLICATION supabase_realtime ADD TABLE public.calls;
ALTER TABLE public.calls REPLICA IDENTITY FULL;

-- STATUS REACTIONS
CREATE TABLE public.status_reactions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  status_id uuid NOT NULL,
  user_id uuid NOT NULL,
  emoji text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(status_id, user_id)
);
ALTER TABLE public.status_reactions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "React if can view status" ON public.status_reactions FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid() AND public.can_view_status(status_id, auth.uid()));
CREATE POLICY "Reactions visible to author and reactor" ON public.status_reactions FOR SELECT TO authenticated
  USING (
    user_id = auth.uid()
    OR EXISTS (SELECT 1 FROM public.statuses s WHERE s.id = status_id AND s.author_id = auth.uid())
  );
CREATE POLICY "Remove own reaction on status" ON public.status_reactions FOR DELETE TO authenticated
  USING (user_id = auth.uid());
CREATE POLICY "Update own reaction" ON public.status_reactions FOR UPDATE TO authenticated
  USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
ALTER PUBLICATION supabase_realtime ADD TABLE public.status_reactions;
