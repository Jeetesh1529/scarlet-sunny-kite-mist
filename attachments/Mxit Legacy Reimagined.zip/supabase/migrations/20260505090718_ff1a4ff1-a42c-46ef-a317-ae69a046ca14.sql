
-- =============== STATUS TABLES ===============
CREATE TYPE public.status_kind AS ENUM ('text', 'image', 'video');
CREATE TYPE public.status_audience_mode AS ENUM ('everyone', 'contacts', 'contacts_except', 'only_share_with');

CREATE TABLE public.statuses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  author_id UUID NOT NULL REFERENCES public.profiles(id) ON DELETE CASCADE,
  kind public.status_kind NOT NULL,
  media_url TEXT,
  caption TEXT,
  background TEXT DEFAULT '#0A2A5E',
  audience_mode public.status_audience_mode NOT NULL DEFAULT 'contacts',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  expires_at TIMESTAMPTZ NOT NULL DEFAULT (now() + INTERVAL '24 hours')
);
CREATE INDEX idx_statuses_author ON public.statuses(author_id);
CREATE INDEX idx_statuses_expires ON public.statuses(expires_at);

CREATE TABLE public.status_audience (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  status_id UUID NOT NULL REFERENCES public.statuses(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  UNIQUE (status_id, user_id)
);
CREATE INDEX idx_status_audience_status ON public.status_audience(status_id);

CREATE TABLE public.status_views (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  status_id UUID NOT NULL REFERENCES public.statuses(id) ON DELETE CASCADE,
  viewer_id UUID NOT NULL,
  viewed_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (status_id, viewer_id)
);
CREATE INDEX idx_status_views_status ON public.status_views(status_id);

-- =============== HELPER: are users mutual contacts? ===============
CREATE OR REPLACE FUNCTION public.are_contacts(_a uuid, _b uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.contacts
    WHERE status = 'accepted'
      AND ((requester_id = _a AND addressee_id = _b)
        OR (requester_id = _b AND addressee_id = _a))
  )
$$;

-- =============== HELPER: can user view this status? ===============
CREATE OR REPLACE FUNCTION public.can_view_status(_status_id uuid, _viewer uuid)
RETURNS boolean
LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  s RECORD;
BEGIN
  SELECT * INTO s FROM public.statuses WHERE id = _status_id;
  IF s.id IS NULL THEN RETURN false; END IF;
  IF s.expires_at < now() THEN RETURN false; END IF;
  IF s.author_id = _viewer THEN RETURN true; END IF;

  IF s.audience_mode = 'everyone' THEN
    RETURN true;
  ELSIF s.audience_mode = 'contacts' THEN
    RETURN public.are_contacts(s.author_id, _viewer);
  ELSIF s.audience_mode = 'contacts_except' THEN
    RETURN public.are_contacts(s.author_id, _viewer)
      AND NOT EXISTS (SELECT 1 FROM public.status_audience WHERE status_id = _status_id AND user_id = _viewer);
  ELSIF s.audience_mode = 'only_share_with' THEN
    RETURN EXISTS (SELECT 1 FROM public.status_audience WHERE status_id = _status_id AND user_id = _viewer);
  END IF;
  RETURN false;
END $$;

-- =============== RLS: statuses ===============
ALTER TABLE public.statuses ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authors manage own statuses"
  ON public.statuses FOR ALL TO authenticated
  USING (auth.uid() = author_id) WITH CHECK (auth.uid() = author_id);

CREATE POLICY "Authorized viewers read statuses"
  ON public.statuses FOR SELECT TO authenticated
  USING (
    expires_at > now() AND (
      auth.uid() = author_id OR public.can_view_status(id, auth.uid())
    )
  );

-- =============== RLS: status_audience ===============
ALTER TABLE public.status_audience ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Author manages audience"
  ON public.status_audience FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.statuses s WHERE s.id = status_id AND s.author_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM public.statuses s WHERE s.id = status_id AND s.author_id = auth.uid()));

-- =============== RLS: status_views ===============
ALTER TABLE public.status_views ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Viewers record own view"
  ON public.status_views FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = viewer_id AND public.can_view_status(status_id, auth.uid()));

CREATE POLICY "Author sees viewers, viewer sees self"
  ON public.status_views FOR SELECT TO authenticated
  USING (
    auth.uid() = viewer_id OR
    EXISTS (SELECT 1 FROM public.statuses s WHERE s.id = status_id AND s.author_id = auth.uid())
  );

-- =============== STORAGE BUCKETS ===============
INSERT INTO storage.buckets (id, name, public) VALUES
  ('status-media', 'status-media', true),
  ('voice-notes', 'voice-notes', true),
  ('chat-videos', 'chat-videos', true)
ON CONFLICT (id) DO NOTHING;

-- Status media: anyone authenticated can read (RLS on statuses table gates discovery)
CREATE POLICY "Status media readable by authed"
  ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'status-media');

CREATE POLICY "Status media uploaded by owner"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'status-media' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "Status media deleted by owner"
  ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'status-media' AND (storage.foldername(name))[1] = auth.uid()::text);

-- Voice notes & chat videos: same pattern
CREATE POLICY "Voice notes readable by authed"
  ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'voice-notes');

CREATE POLICY "Voice notes uploaded by owner"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'voice-notes' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "Voice notes deleted by owner"
  ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'voice-notes' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "Chat videos readable by authed"
  ON storage.objects FOR SELECT TO authenticated
  USING (bucket_id = 'chat-videos');

CREATE POLICY "Chat videos uploaded by owner"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'chat-videos' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "Chat videos deleted by owner"
  ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'chat-videos' AND (storage.foldername(name))[1] = auth.uid()::text);

-- =============== AVATAR BUCKET (profile pics) ===============
INSERT INTO storage.buckets (id, name, public) VALUES ('avatars', 'avatars', true)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "Avatars publicly readable"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'avatars');

CREATE POLICY "Avatar uploaded by owner"
  ON storage.objects FOR INSERT TO authenticated
  WITH CHECK (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "Avatar updated by owner"
  ON storage.objects FOR UPDATE TO authenticated
  USING (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "Avatar deleted by owner"
  ON storage.objects FOR DELETE TO authenticated
  USING (bucket_id = 'avatars' AND (storage.foldername(name))[1] = auth.uid()::text);

-- =============== PURGE FUNCTION ===============
CREATE OR REPLACE FUNCTION public.purge_expired_statuses()
RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  DELETE FROM public.statuses WHERE expires_at < now();
END $$;

-- Realtime
ALTER PUBLICATION supabase_realtime ADD TABLE public.statuses;
ALTER PUBLICATION supabase_realtime ADD TABLE public.status_views;
