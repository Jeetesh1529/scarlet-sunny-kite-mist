CREATE EXTENSION IF NOT EXISTS pg_cron;
CREATE EXTENSION IF NOT EXISTS pg_net;

DO $outer$
BEGIN
  IF EXISTS (SELECT 1 FROM cron.job WHERE jobname = 'purge-expired-statuses-daily') THEN
    PERFORM cron.unschedule('purge-expired-statuses-daily');
  END IF;
  PERFORM cron.schedule(
    'purge-expired-statuses-daily',
    '0 3 * * *',
    'SELECT public.purge_expired_statuses();'
  );
END
$outer$;