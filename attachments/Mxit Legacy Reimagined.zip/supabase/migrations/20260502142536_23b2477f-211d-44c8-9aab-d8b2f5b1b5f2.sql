
-- =============================================
-- 1. MULTIMX GROUPS (private group chat)
-- =============================================
CREATE TABLE public.multimx_groups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  created_by uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  last_message_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE public.multimx_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  group_id uuid NOT NULL REFERENCES public.multimx_groups(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  joined_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (group_id, user_id)
);

CREATE INDEX idx_multimx_members_user ON public.multimx_members(user_id);
CREATE INDEX idx_multimx_members_group ON public.multimx_members(group_id);

ALTER TABLE public.multimx_groups ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.multimx_members ENABLE ROW LEVEL SECURITY;

-- Security definer to avoid RLS recursion
CREATE OR REPLACE FUNCTION public.is_in_multimx(_group uuid, _user uuid)
RETURNS boolean
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.multimx_members WHERE group_id = _group AND user_id = _user
  )
$$;

-- multimx_groups policies
CREATE POLICY "Members view own multimx groups"
  ON public.multimx_groups FOR SELECT TO authenticated
  USING (public.is_in_multimx(id, auth.uid()) OR created_by = auth.uid());

CREATE POLICY "Authenticated create multimx group"
  ON public.multimx_groups FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = created_by);

CREATE POLICY "Creator updates multimx group"
  ON public.multimx_groups FOR UPDATE TO authenticated
  USING (auth.uid() = created_by);

CREATE POLICY "Creator deletes multimx group"
  ON public.multimx_groups FOR DELETE TO authenticated
  USING (auth.uid() = created_by);

-- multimx_members policies
CREATE POLICY "Group members visible to other members"
  ON public.multimx_members FOR SELECT TO authenticated
  USING (public.is_in_multimx(group_id, auth.uid()));

CREATE POLICY "Creator invites members"
  ON public.multimx_members FOR INSERT TO authenticated
  WITH CHECK (
    EXISTS (SELECT 1 FROM public.multimx_groups g WHERE g.id = group_id AND g.created_by = auth.uid())
    OR user_id = auth.uid()
  );

CREATE POLICY "Members leave or creator removes"
  ON public.multimx_members FOR DELETE TO authenticated
  USING (
    user_id = auth.uid()
    OR EXISTS (SELECT 1 FROM public.multimx_groups g WHERE g.id = group_id AND g.created_by = auth.uid())
  );

-- =============================================
-- 2. MESSAGES — add multimx_group_id
-- =============================================
ALTER TABLE public.messages
  ADD COLUMN multimx_group_id uuid REFERENCES public.multimx_groups(id) ON DELETE CASCADE;

CREATE INDEX idx_messages_multimx ON public.messages(multimx_group_id);

-- Replace the messages SELECT and INSERT policies to include multimx
DROP POLICY IF EXISTS "View messages in own conversation or joined room" ON public.messages;
DROP POLICY IF EXISTS "Send messages as self" ON public.messages;

CREATE POLICY "View messages in own conversation, room, or multimx"
  ON public.messages FOR SELECT TO authenticated
  USING (
    (conversation_id IS NOT NULL AND public.is_in_conversation(conversation_id, auth.uid()))
    OR (room_id IS NOT NULL AND public.is_in_room(room_id, auth.uid()))
    OR (multimx_group_id IS NOT NULL AND public.is_in_multimx(multimx_group_id, auth.uid()))
  );

CREATE POLICY "Send messages as self"
  ON public.messages FOR INSERT TO authenticated
  WITH CHECK (
    auth.uid() = sender_id
    AND (
      (conversation_id IS NOT NULL AND public.is_in_conversation(conversation_id, auth.uid()))
      OR (room_id IS NOT NULL AND public.is_in_room(room_id, auth.uid()))
      OR (multimx_group_id IS NOT NULL AND public.is_in_multimx(multimx_group_id, auth.uid()))
    )
  );

-- Bump multimx group last_message_at on new message
CREATE OR REPLACE FUNCTION public.bump_multimx()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  IF NEW.multimx_group_id IS NOT NULL THEN
    UPDATE public.multimx_groups SET last_message_at = NEW.created_at WHERE id = NEW.multimx_group_id;
  END IF;
  RETURN NEW;
END $$;

CREATE TRIGGER trg_bump_multimx
AFTER INSERT ON public.messages
FOR EACH ROW EXECUTE FUNCTION public.bump_multimx();

-- =============================================
-- 3. CHATROOM ZONES + restructure chatrooms
-- =============================================
CREATE TABLE public.chatroom_zones (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  slug text NOT NULL UNIQUE,
  description text,
  category text NOT NULL,
  min_age integer NOT NULL DEFAULT 14,
  position integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.chatroom_zones ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Zones viewable by authenticated"
  ON public.chatroom_zones FOR SELECT TO authenticated USING (true);

ALTER TABLE public.chatrooms
  ADD COLUMN zone_id uuid REFERENCES public.chatroom_zones(id) ON DELETE CASCADE,
  ADD COLUMN room_number integer,
  ADD COLUMN max_users integer NOT NULL DEFAULT 7,
  ADD COLUMN cost_per_message integer NOT NULL DEFAULT 2;

CREATE INDEX idx_chatrooms_zone ON public.chatrooms(zone_id);

-- Cap room joins at max_users (server-enforced)
CREATE OR REPLACE FUNCTION public.enforce_room_cap()
RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  cap integer;
  current_count integer;
BEGIN
  SELECT max_users INTO cap FROM public.chatrooms WHERE id = NEW.room_id;
  IF cap IS NULL THEN RETURN NEW; END IF;
  SELECT count(*) INTO current_count FROM public.room_members WHERE room_id = NEW.room_id;
  IF current_count >= cap THEN
    RAISE EXCEPTION 'ROOM_FULL';
  END IF;
  RETURN NEW;
END $$;

CREATE TRIGGER trg_enforce_room_cap
BEFORE INSERT ON public.room_members
FOR EACH ROW EXECUTE FUNCTION public.enforce_room_cap();

-- =============================================
-- 4. TRADEPOST SERVICES catalog
-- =============================================
CREATE TABLE public.tradepost_services (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  name text NOT NULL,
  description text,
  icon text,
  route text,
  cost_moola integer NOT NULL DEFAULT 0,
  position integer NOT NULL DEFAULT 0,
  enabled boolean NOT NULL DEFAULT true
);

ALTER TABLE public.tradepost_services ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Tradepost services viewable by authenticated"
  ON public.tradepost_services FOR SELECT TO authenticated USING (true);

-- =============================================
-- 5. SEED DATA
-- =============================================
INSERT INTO public.tradepost_services (slug, name, description, icon, route, cost_moola, position) VALUES
  ('chatrooms',   'Chat Rooms',   'Public chat zones — Teen, Flirt, Geographic, Celebrity',  'MessagesSquare', '/tradepost/chatrooms', 0, 1),
  ('games',       'Games',        'Mxit games and Trivit',                                    'Gamepad2',       '/tradepost/games',       5, 2),
  ('emoticards',  'Emoticards',   'Send animated emoticards',                                 'Sparkles',       '/tradepost/emoticards',  3, 3),
  ('skinz',       'Skinz',        'Skin your Mxit with new themes',                           'Palette',        '/tradepost/skinz',      10, 4),
  ('horoscopes',  'Horoscopes',   'Daily horoscopes',                                         'Stars',          '/tradepost/horoscopes',  2, 5),
  ('weather',     'Weather',      'Local weather forecast',                                   'CloudSun',       '/tradepost/weather',     1, 6),
  ('mobi',        'Mobi Portal',  'AI-powered Mobi assistant',                                'Bot',            '/mobi',                  0, 7);

INSERT INTO public.chatroom_zones (slug, name, description, category, min_age, position) VALUES
  ('teen-talk',   'Teen Talk',     'Chat with other teens (14+)',          'teen',       14, 1),
  ('flirt-zone',  'Flirt Zone',    'Meet and flirt (18+)',                 'flirt',      18, 2),
  ('geographic',  'Geographic',    'Find people from your area',           'geographic', 14, 3),
  ('topical',     'Topical',       'Music, movies, sport, school',         'topical',    14, 4),
  ('celebrity',   'Celebrity',     'Talk about your favourite celebs',     'celebrity',  14, 5);

-- 4 numbered rooms per zone, system-owned (created_by = NULL won't satisfy RLS check, so use a seed approach without created_by)
-- We need created_by NOT NULL? Looking at schema: created_by uuid Nullable: Yes. Good.
INSERT INTO public.chatrooms (name, topic, is_official, zone_id, room_number, max_users, cost_per_message)
SELECT
  z.name || ' — Room ' || n,
  z.description,
  true,
  z.id,
  n,
  7,
  2
FROM public.chatroom_zones z
CROSS JOIN generate_series(1, 4) AS n;
