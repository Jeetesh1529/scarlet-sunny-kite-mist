-- Contact nicknames: rename your friends locally
CREATE TABLE public.contact_nicknames (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL,
  contact_user_id uuid NOT NULL,
  nickname text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (owner_id, contact_user_id)
);
ALTER TABLE public.contact_nicknames ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Owners read own nicknames" ON public.contact_nicknames
  FOR SELECT TO authenticated USING (owner_id = auth.uid());
CREATE POLICY "Owners write own nicknames" ON public.contact_nicknames
  FOR INSERT TO authenticated WITH CHECK (owner_id = auth.uid());
CREATE POLICY "Owners update own nicknames" ON public.contact_nicknames
  FOR UPDATE TO authenticated USING (owner_id = auth.uid());
CREATE POLICY "Owners delete own nicknames" ON public.contact_nicknames
  FOR DELETE TO authenticated USING (owner_id = auth.uid());
CREATE TRIGGER touch_contact_nicknames BEFORE UPDATE ON public.contact_nicknames
  FOR EACH ROW EXECUTE FUNCTION public.touch_updated_at();

-- Streak tracking on profiles
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS streak_days integer NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS last_claim_date date;

-- Replace claim_daily_moola to track streak with milestone bonuses
CREATE OR REPLACE FUNCTION public.claim_daily_moola()
RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  uid uuid := auth.uid();
  today date := (now() AT TIME ZONE 'utc')::date;
  base_bonus integer := 20;
  streak_bonus integer := 0;
  total integer;
  cur_balance integer;
  new_balance integer;
  prev_date date;
  new_streak integer;
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  IF EXISTS (SELECT 1 FROM public.moola_daily_claims WHERE user_id = uid AND claim_date = today) THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'already_claimed');
  END IF;

  SELECT moola, last_claim_date, streak_days INTO cur_balance, prev_date, new_streak
    FROM public.profiles WHERE id = uid FOR UPDATE;
  IF cur_balance IS NULL THEN RAISE EXCEPTION 'No profile'; END IF;

  IF prev_date = today - 1 THEN
    new_streak := COALESCE(new_streak, 0) + 1;
  ELSE
    new_streak := 1;
  END IF;

  -- Milestone bonuses
  IF new_streak % 30 = 0 THEN streak_bonus := 200;
  ELSIF new_streak % 7 = 0 THEN streak_bonus := 50;
  ELSIF new_streak >= 3 THEN streak_bonus := 10;
  END IF;

  total := base_bonus + streak_bonus;
  new_balance := cur_balance + total;
  UPDATE public.profiles SET moola = new_balance, last_claim_date = today, streak_days = new_streak WHERE id = uid;

  INSERT INTO public.moola_daily_claims (user_id, claim_date, amount) VALUES (uid, today, total);
  INSERT INTO public.moola_transactions (user_id, amount, reason, type, balance_before, balance_after, source)
  VALUES (uid, total, 'Daily login bonus (' || new_streak || '-day streak)', 'bonus', cur_balance, new_balance, 'daily_claim');

  RETURN jsonb_build_object('ok', true, 'amount', total, 'base', base_bonus, 'streak_bonus', streak_bonus, 'streak', new_streak, 'balance', new_balance);
END $$;