DROP POLICY IF EXISTS "Update own messages" ON public.messages;

CREATE POLICY "Senders can update own messages and recipients can mark read"
ON public.messages
FOR UPDATE
TO authenticated
USING (
  auth.uid() = sender_id
  OR (
    conversation_id IS NOT NULL
    AND public.is_in_conversation(conversation_id, auth.uid())
    AND auth.uid() <> sender_id
  )
)
WITH CHECK (
  auth.uid() = sender_id
  OR (
    conversation_id IS NOT NULL
    AND public.is_in_conversation(conversation_id, auth.uid())
    AND auth.uid() <> sender_id
    AND delivery = 'read'
  )
);