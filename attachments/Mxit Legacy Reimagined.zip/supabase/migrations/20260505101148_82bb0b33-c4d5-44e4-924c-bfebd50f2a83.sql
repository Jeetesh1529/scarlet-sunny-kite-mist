
-- Spin wheel daily claims (separate from joe banker)
CREATE TABLE IF NOT EXISTS public.moola_spin_claims (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  claim_date date NOT NULL DEFAULT ((now() AT TIME ZONE 'utc')::date),
  amount integer NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE(user_id, claim_date)
);
ALTER TABLE public.moola_spin_claims ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users view own spin claims" ON public.moola_spin_claims
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

-- Tips on messages (audit)
CREATE TABLE IF NOT EXISTS public.moola_tips (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  from_user uuid NOT NULL,
  to_user uuid NOT NULL,
  message_id uuid,
  amount integer NOT NULL CHECK (amount > 0),
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.moola_tips ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Tips visible to participants" ON public.moola_tips
  FOR SELECT TO authenticated USING (auth.uid() = from_user OR auth.uid() = to_user);

-- Send Moola to another user
CREATE OR REPLACE FUNCTION public.send_moola(_to uuid, _amount integer, _note text DEFAULT NULL, _message_id uuid DEFAULT NULL)
RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  uid uuid := auth.uid();
  sender_bal integer;
  receiver_bal integer;
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  IF _to = uid THEN RAISE EXCEPTION 'Cannot send to yourself'; END IF;
  IF _amount IS NULL OR _amount <= 0 THEN RAISE EXCEPTION 'Amount must be positive'; END IF;

  SELECT moola INTO sender_bal FROM public.profiles WHERE id = uid FOR UPDATE;
  IF sender_bal IS NULL THEN RAISE EXCEPTION 'No profile'; END IF;
  IF sender_bal < _amount THEN RAISE EXCEPTION 'Insufficient Moola'; END IF;

  SELECT moola INTO receiver_bal FROM public.profiles WHERE id = _to FOR UPDATE;
  IF receiver_bal IS NULL THEN RAISE EXCEPTION 'Recipient not found'; END IF;

  UPDATE public.profiles SET moola = sender_bal - _amount WHERE id = uid;
  UPDATE public.profiles SET moola = receiver_bal + _amount WHERE id = _to;

  INSERT INTO public.moola_transactions (user_id, amount, reason, type, balance_before, balance_after, source)
  VALUES (uid, -_amount, COALESCE(_note, 'Sent Moola'), 'transfer', sender_bal, sender_bal - _amount, 'send');
  INSERT INTO public.moola_transactions (user_id, amount, reason, type, balance_before, balance_after, source)
  VALUES (_to, _amount, COALESCE(_note, 'Received Moola'), 'transfer', receiver_bal, receiver_bal + _amount, 'receive');

  IF _message_id IS NOT NULL THEN
    INSERT INTO public.moola_tips (from_user, to_user, message_id, amount) VALUES (uid, _to, _message_id, _amount);
  END IF;

  RETURN jsonb_build_object('ok', true, 'balance', sender_bal - _amount);
END $$;

-- Spin the wheel: random reward 5..100
CREATE OR REPLACE FUNCTION public.spin_daily_wheel()
RETURNS jsonb
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public
AS $$
DECLARE
  uid uuid := auth.uid();
  today date := (now() AT TIME ZONE 'utc')::date;
  reward integer;
  cur_balance integer;
  new_balance integer;
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;
  IF EXISTS (SELECT 1 FROM public.moola_spin_claims WHERE user_id = uid AND claim_date = today) THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'already_spun');
  END IF;

  -- Weighted reward
  reward := (ARRAY[5,10,10,15,20,20,25,30,50,100])[1 + floor(random()*10)::int];

  SELECT moola INTO cur_balance FROM public.profiles WHERE id = uid FOR UPDATE;
  new_balance := cur_balance + reward;
  UPDATE public.profiles SET moola = new_balance WHERE id = uid;

  INSERT INTO public.moola_spin_claims (user_id, claim_date, amount) VALUES (uid, today, reward);
  INSERT INTO public.moola_transactions (user_id, amount, reason, type, balance_before, balance_after, source)
  VALUES (uid, reward, 'Spin-the-Wheel daily bonus', 'bonus', cur_balance, new_balance, 'spin_wheel');

  RETURN jsonb_build_object('ok', true, 'amount', reward, 'balance', new_balance);
END $$;

-- Weekly leaderboard view (top earners by net positive moola_transactions in last 7 days)
CREATE OR REPLACE VIEW public.moola_weekly_leaderboard AS
SELECT
  t.user_id,
  p.display_name,
  p.mxit_id,
  p.avatar_url,
  p.avatar_seed,
  COALESCE(SUM(t.amount) FILTER (WHERE t.amount > 0), 0)::int AS earned,
  COUNT(*) FILTER (WHERE t.source = 'spin_wheel')::int AS spins,
  COUNT(*) FILTER (WHERE t.source IN ('send','receive'))::int AS transfers
FROM public.moola_transactions t
JOIN public.profiles p ON p.id = t.user_id
WHERE t.created_at >= (now() - interval '7 days')
GROUP BY t.user_id, p.display_name, p.mxit_id, p.avatar_url, p.avatar_seed
ORDER BY earned DESC
LIMIT 50;

GRANT SELECT ON public.moola_weekly_leaderboard TO authenticated;
