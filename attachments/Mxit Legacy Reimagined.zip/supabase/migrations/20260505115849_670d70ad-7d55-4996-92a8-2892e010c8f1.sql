
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS read_receipts_enabled boolean NOT NULL DEFAULT true;

-- Revoke EXECUTE from anon on user-only RPCs (kept callable for authenticated)
REVOKE EXECUTE ON FUNCTION public.send_moola(uuid, integer, text, uuid) FROM anon;
REVOKE EXECUTE ON FUNCTION public.claim_daily_moola() FROM anon;
REVOKE EXECUTE ON FUNCTION public.spin_daily_wheel() FROM anon;
REVOKE EXECUTE ON FUNCTION public.award_achievement(text) FROM anon;
REVOKE EXECUTE ON FUNCTION public.delete_my_account() FROM anon;
REVOKE EXECUTE ON FUNCTION public.accept_moonbase_trade(uuid) FROM anon;
REVOKE EXECUTE ON FUNCTION public.join_best_room(uuid) FROM anon;
REVOKE EXECUTE ON FUNCTION public.moderate_user(uuid, boolean, text) FROM anon;
REVOKE EXECUTE ON FUNCTION public.purge_expired_messages() FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.purge_expired_statuses() FROM anon, authenticated;
