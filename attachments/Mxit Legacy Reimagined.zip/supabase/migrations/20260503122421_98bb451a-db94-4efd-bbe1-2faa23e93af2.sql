
-- ============ ALLIANCES ============
CREATE TABLE public.moonbase_alliances (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL UNIQUE,
  tag TEXT NOT NULL,
  description TEXT,
  founder_user_id UUID NOT NULL,
  power_score INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.moonbase_alliance_members (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  alliance_id UUID NOT NULL REFERENCES public.moonbase_alliances(id) ON DELETE CASCADE,
  user_id UUID NOT NULL UNIQUE,
  role TEXT NOT NULL DEFAULT 'member',
  joined_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE public.moonbase_alliance_messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  alliance_id UUID NOT NULL REFERENCES public.moonbase_alliances(id) ON DELETE CASCADE,
  user_id UUID NOT NULL,
  content TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.moonbase_alliances ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.moonbase_alliance_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.moonbase_alliance_messages ENABLE ROW LEVEL SECURITY;

-- helper: am I in this alliance?
CREATE OR REPLACE FUNCTION public.in_moonbase_alliance(_alliance UUID, _user UUID)
RETURNS BOOLEAN LANGUAGE SQL STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.moonbase_alliance_members WHERE alliance_id = _alliance AND user_id = _user)
$$;

CREATE POLICY "Alliances public read" ON public.moonbase_alliances FOR SELECT TO authenticated USING (true);
CREATE POLICY "Alliances create" ON public.moonbase_alliances FOR INSERT TO authenticated WITH CHECK (founder_user_id = auth.uid());
CREATE POLICY "Alliances founder update" ON public.moonbase_alliances FOR UPDATE TO authenticated USING (founder_user_id = auth.uid());

CREATE POLICY "Alliance members public read" ON public.moonbase_alliance_members FOR SELECT TO authenticated USING (true);
CREATE POLICY "Alliance join self" ON public.moonbase_alliance_members FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "Alliance leave self" ON public.moonbase_alliance_members FOR DELETE TO authenticated USING (user_id = auth.uid());

CREATE POLICY "Alliance msg read members" ON public.moonbase_alliance_messages FOR SELECT TO authenticated
  USING (public.in_moonbase_alliance(alliance_id, auth.uid()));
CREATE POLICY "Alliance msg send members" ON public.moonbase_alliance_messages FOR INSERT TO authenticated
  WITH CHECK (user_id = auth.uid() AND public.in_moonbase_alliance(alliance_id, auth.uid()));

ALTER PUBLICATION supabase_realtime ADD TABLE public.moonbase_alliance_messages;

-- ============ TRADE ============
CREATE TABLE public.moonbase_trade_offers (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  seller_user_id UUID NOT NULL,
  seller_base_id UUID NOT NULL REFERENCES public.moonbase_bases(id) ON DELETE CASCADE,
  give_oxygen INTEGER NOT NULL DEFAULT 0,
  give_water  INTEGER NOT NULL DEFAULT 0,
  give_iron   INTEGER NOT NULL DEFAULT 0,
  give_helium INTEGER NOT NULL DEFAULT 0,
  want_oxygen INTEGER NOT NULL DEFAULT 0,
  want_water  INTEGER NOT NULL DEFAULT 0,
  want_iron   INTEGER NOT NULL DEFAULT 0,
  want_helium INTEGER NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'open',
  accepted_by UUID,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  resolved_at TIMESTAMPTZ
);

ALTER TABLE public.moonbase_trade_offers ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Trade public read"  ON public.moonbase_trade_offers FOR SELECT TO authenticated USING (true);
CREATE POLICY "Trade create own"   ON public.moonbase_trade_offers FOR INSERT TO authenticated WITH CHECK (seller_user_id = auth.uid());
CREATE POLICY "Trade cancel own"   ON public.moonbase_trade_offers FOR UPDATE TO authenticated
  USING (seller_user_id = auth.uid()) WITH CHECK (seller_user_id = auth.uid());

-- Atomic accept: buyer pays "want" from their base, seller pays "give" from theirs (already validated when offer created — re-validate now).
CREATE OR REPLACE FUNCTION public.accept_moonbase_trade(_offer UUID)
RETURNS UUID LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE
  uid UUID := auth.uid();
  o RECORD;
  seller_res RECORD;
  buyer_base UUID;
  buyer_res RECORD;
  cap INTEGER;
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;

  SELECT * INTO o FROM public.moonbase_trade_offers WHERE id = _offer FOR UPDATE;
  IF o.id IS NULL THEN RAISE EXCEPTION 'Offer not found'; END IF;
  IF o.status <> 'open' THEN RAISE EXCEPTION 'Offer not open'; END IF;
  IF o.seller_user_id = uid THEN RAISE EXCEPTION 'Cannot accept own offer'; END IF;

  SELECT id INTO buyer_base FROM public.moonbase_bases WHERE user_id = uid;
  IF buyer_base IS NULL THEN RAISE EXCEPTION 'You have no base'; END IF;

  SELECT * INTO buyer_res FROM public.moonbase_resources WHERE base_id = buyer_base FOR UPDATE;
  SELECT * INTO seller_res FROM public.moonbase_resources WHERE base_id = o.seller_base_id FOR UPDATE;

  -- Buyer must afford 'want' (what seller wants from buyer)
  IF buyer_res.oxygen < o.want_oxygen OR buyer_res.water < o.want_water
     OR buyer_res.iron < o.want_iron OR buyer_res.helium < o.want_helium THEN
    RAISE EXCEPTION 'Not enough resources to accept';
  END IF;

  -- Seller must still have 'give'
  IF seller_res.oxygen < o.give_oxygen OR seller_res.water < o.give_water
     OR seller_res.iron < o.give_iron OR seller_res.helium < o.give_helium THEN
    RAISE EXCEPTION 'Seller no longer has goods';
  END IF;

  -- Apply (cap at each base's capacity)
  UPDATE public.moonbase_resources SET
    oxygen = LEAST(capacity, oxygen - o.want_oxygen + o.give_oxygen),
    water  = LEAST(capacity, water  - o.want_water  + o.give_water),
    iron   = LEAST(capacity, iron   - o.want_iron   + o.give_iron),
    helium = LEAST(capacity, helium - o.want_helium + o.give_helium),
    updated_at = now()
  WHERE base_id = buyer_base;

  UPDATE public.moonbase_resources SET
    oxygen = LEAST(capacity, oxygen - o.give_oxygen + o.want_oxygen),
    water  = LEAST(capacity, water  - o.give_water  + o.want_water),
    iron   = LEAST(capacity, iron   - o.give_iron   + o.want_iron),
    helium = LEAST(capacity, helium - o.give_helium + o.want_helium),
    updated_at = now()
  WHERE base_id = o.seller_base_id;

  UPDATE public.moonbase_trade_offers
     SET status = 'accepted', accepted_by = uid, resolved_at = now()
   WHERE id = _offer;

  -- Reports for both sides
  INSERT INTO public.moonbase_reports (user_id, kind, title, body) VALUES
   (uid, 'trade', '🤝 Trade accepted',
    'You received O ' || o.give_oxygen || ' · W ' || o.give_water || ' · Fe ' || o.give_iron || ' · He ' || o.give_helium ||
    E'\nYou paid O ' || o.want_oxygen || ' · W ' || o.want_water || ' · Fe ' || o.want_iron || ' · He ' || o.want_helium),
   (o.seller_user_id, 'trade', '🤝 Your offer was accepted',
    'You sent O ' || o.give_oxygen || ' · W ' || o.give_water || ' · Fe ' || o.give_iron || ' · He ' || o.give_helium ||
    E'\nYou received O ' || o.want_oxygen || ' · W ' || o.want_water || ' · Fe ' || o.want_iron || ' · He ' || o.want_helium);

  RETURN _offer;
END $$;

-- ============ RESEARCH ============
CREATE TABLE public.moonbase_research (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL,
  research_type TEXT NOT NULL,
  level INTEGER NOT NULL DEFAULT 0,
  UNIQUE(user_id, research_type)
);

ALTER TABLE public.moonbase_research ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Research own read"   ON public.moonbase_research FOR SELECT TO authenticated USING (user_id = auth.uid());
CREATE POLICY "Research own write"  ON public.moonbase_research FOR ALL    TO authenticated
  USING (user_id = auth.uid()) WITH CHECK (user_id = auth.uid());
