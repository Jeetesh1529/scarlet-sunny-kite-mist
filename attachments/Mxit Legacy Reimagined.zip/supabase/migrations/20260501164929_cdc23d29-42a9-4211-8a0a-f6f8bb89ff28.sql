
-- 1) Extend presence_status enum with 'busy'
ALTER TYPE public.presence_status ADD VALUE IF NOT EXISTS 'busy';

-- 2) Add new profile columns
ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS farewell text DEFAULT 'Catch ya later! ✌️',
  ADD COLUMN IF NOT EXISTS auto_away_minutes integer NOT NULL DEFAULT 5,
  ADD COLUMN IF NOT EXISTS hide_offline boolean NOT NULL DEFAULT false;

-- 3) Contact groups table (per-user custom categories)
CREATE TABLE IF NOT EXISTS public.contact_groups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL,
  name text NOT NULL,
  position integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (owner_id, name)
);

ALTER TABLE public.contact_groups ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Owners view own groups"
  ON public.contact_groups FOR SELECT TO authenticated
  USING (auth.uid() = owner_id);

CREATE POLICY "Owners create own groups"
  ON public.contact_groups FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = owner_id);

CREATE POLICY "Owners update own groups"
  ON public.contact_groups FOR UPDATE TO authenticated
  USING (auth.uid() = owner_id);

CREATE POLICY "Owners delete own groups"
  ON public.contact_groups FOR DELETE TO authenticated
  USING (auth.uid() = owner_id);

-- 4) Per-viewer contact-to-group mapping (each user files contacts into their own groups)
CREATE TABLE IF NOT EXISTS public.contact_group_members (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  owner_id uuid NOT NULL,
  contact_user_id uuid NOT NULL,
  group_id uuid NOT NULL REFERENCES public.contact_groups(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (owner_id, contact_user_id)
);

ALTER TABLE public.contact_group_members ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Owners view own mappings"
  ON public.contact_group_members FOR SELECT TO authenticated
  USING (auth.uid() = owner_id);

CREATE POLICY "Owners create own mappings"
  ON public.contact_group_members FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = owner_id);

CREATE POLICY "Owners update own mappings"
  ON public.contact_group_members FOR UPDATE TO authenticated
  USING (auth.uid() = owner_id);

CREATE POLICY "Owners delete own mappings"
  ON public.contact_group_members FOR DELETE TO authenticated
  USING (auth.uid() = owner_id);
