
DO $$
DECLARE
  r RECORD;
BEGIN
  FOR r IN
    SELECT n.nspname, p.proname,
           pg_get_function_identity_arguments(p.oid) AS args
    FROM pg_proc p
    JOIN pg_namespace n ON n.oid = p.pronamespace
    WHERE n.nspname = 'public'
      AND p.prosecdef = true
      AND p.proname NOT IN ('has_role', 'are_contacts', 'is_in_conversation',
                            'is_in_room', 'is_in_multimx', 'in_moonbase_alliance',
                            'is_bot_base', 'owns_base', 'can_view_status',
                            'user_meets_min_age', 'bump_conversation', 'bump_multimx',
                            'bump_confession_likes', 'enforce_room_cap',
                            'guard_message_recipient_read_update', 'log_mood_change')
  LOOP
    EXECUTE format('REVOKE EXECUTE ON FUNCTION %I.%I(%s) FROM PUBLIC, anon',
                   r.nspname, r.proname, r.args);
  END LOOP;
END $$;
