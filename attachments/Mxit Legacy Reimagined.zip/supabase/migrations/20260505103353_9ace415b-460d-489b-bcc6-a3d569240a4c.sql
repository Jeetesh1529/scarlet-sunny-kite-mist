
-- Confessions (anonymous wall)
CREATE TABLE public.confessions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  author_id uuid NOT NULL,
  body text NOT NULL CHECK (char_length(body) BETWEEN 1 AND 500),
  likes_count integer NOT NULL DEFAULT 0,
  is_hidden boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.confessions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Confessions readable when not hidden" ON public.confessions FOR SELECT TO authenticated USING (is_hidden = false OR author_id = auth.uid() OR has_role(auth.uid(),'admin'::app_role) OR has_role(auth.uid(),'moderator'::app_role));
CREATE POLICY "Users post own confessions" ON public.confessions FOR INSERT TO authenticated WITH CHECK (author_id = auth.uid());
CREATE POLICY "Authors delete own" ON public.confessions FOR DELETE TO authenticated USING (author_id = auth.uid() OR has_role(auth.uid(),'admin'::app_role) OR has_role(auth.uid(),'moderator'::app_role));
CREATE POLICY "Mods hide" ON public.confessions FOR UPDATE TO authenticated USING (has_role(auth.uid(),'admin'::app_role) OR has_role(auth.uid(),'moderator'::app_role)) WITH CHECK (has_role(auth.uid(),'admin'::app_role) OR has_role(auth.uid(),'moderator'::app_role));

CREATE TABLE public.confession_likes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  confession_id uuid NOT NULL REFERENCES public.confessions(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (confession_id, user_id)
);
ALTER TABLE public.confession_likes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Likes readable" ON public.confession_likes FOR SELECT TO authenticated USING (true);
CREATE POLICY "Like as self" ON public.confession_likes FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "Unlike own" ON public.confession_likes FOR DELETE TO authenticated USING (user_id = auth.uid());

CREATE OR REPLACE FUNCTION public.bump_confession_likes() RETURNS trigger LANGUAGE plpgsql SECURITY DEFINER SET search_path=public AS $$
BEGIN
  IF TG_OP='INSERT' THEN UPDATE public.confessions SET likes_count = likes_count + 1 WHERE id = NEW.confession_id;
  ELSIF TG_OP='DELETE' THEN UPDATE public.confessions SET likes_count = GREATEST(0, likes_count - 1) WHERE id = OLD.confession_id;
  END IF;
  RETURN COALESCE(NEW, OLD);
END $$;
CREATE TRIGGER trg_confession_likes_count AFTER INSERT OR DELETE ON public.confession_likes FOR EACH ROW EXECUTE FUNCTION public.bump_confession_likes();

-- Polls
CREATE TABLE public.polls (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  author_id uuid NOT NULL,
  question text NOT NULL CHECK (char_length(question) BETWEEN 3 AND 200),
  options jsonb NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  closes_at timestamptz NOT NULL DEFAULT (now() + interval '7 days')
);
ALTER TABLE public.polls ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Polls public read" ON public.polls FOR SELECT TO authenticated USING (true);
CREATE POLICY "Polls create own" ON public.polls FOR INSERT TO authenticated WITH CHECK (author_id = auth.uid());
CREATE POLICY "Polls delete own or mod" ON public.polls FOR DELETE TO authenticated USING (author_id = auth.uid() OR has_role(auth.uid(),'admin'::app_role) OR has_role(auth.uid(),'moderator'::app_role));

CREATE TABLE public.poll_votes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  poll_id uuid NOT NULL REFERENCES public.polls(id) ON DELETE CASCADE,
  user_id uuid NOT NULL,
  option_index integer NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (poll_id, user_id)
);
ALTER TABLE public.poll_votes ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Votes public read" ON public.poll_votes FOR SELECT TO authenticated USING (true);
CREATE POLICY "Vote as self" ON public.poll_votes FOR INSERT TO authenticated WITH CHECK (user_id = auth.uid());
CREATE POLICY "Change own vote" ON public.poll_votes FOR UPDATE TO authenticated USING (user_id = auth.uid());
