
-- Move Music Room, Confessions, Polls, Tic-Tac-Toe into Tradepost service list
INSERT INTO public.tradepost_services (slug, name, description, icon, route, cost_moola, position, enabled) VALUES
  ('music',       'Music Room',  'AERAKII radio + public chatroom', 'Music',       '/music',           0, 8, true),
  ('confessions', 'Confessions', 'Anonymous wall · spill the tea',  'MessageCircle','/confessions',     0, 9, true),
  ('polls',       'Polls',       'Vote · create your own',          'BarChart3',    '/polls',           0, 10, true),
  ('tictactoe',   'Tic-Tac-Toe', 'Play vs the computer',            'Grid3x3',      '/games/tictactoe', 0, 11, true)
ON CONFLICT (slug) DO UPDATE
SET name = EXCLUDED.name, description = EXCLUDED.description, icon = EXCLUDED.icon,
    route = EXCLUDED.route, position = EXCLUDED.position, enabled = true;

-- Create a single public Music Room chatroom (free, large capacity)
INSERT INTO public.chatrooms (name, topic, is_official, max_users, cost_per_message)
VALUES ('Music Room', 'Chat while AERAKII plays. Free room.', true, 500, 0)
ON CONFLICT (name) DO UPDATE
SET topic = EXCLUDED.topic, max_users = 500, cost_per_message = 0, is_official = true;
