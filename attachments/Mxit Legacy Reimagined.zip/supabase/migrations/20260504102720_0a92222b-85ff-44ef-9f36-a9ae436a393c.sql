-- ===== USER BLOCKS =====
CREATE TABLE IF NOT EXISTS public.user_blocks (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  blocker_id uuid NOT NULL,
  blocked_id uuid NOT NULL,
  reason text,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (blocker_id, blocked_id),
  CHECK (blocker_id <> blocked_id)
);
ALTER TABLE public.user_blocks ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users view own blocks" ON public.user_blocks
  FOR SELECT TO authenticated USING (auth.uid() = blocker_id);
CREATE POLICY "Users create own blocks" ON public.user_blocks
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = blocker_id);
CREATE POLICY "Users delete own blocks" ON public.user_blocks
  FOR DELETE TO authenticated USING (auth.uid() = blocker_id);

CREATE INDEX IF NOT EXISTS idx_user_blocks_blocker ON public.user_blocks(blocker_id);
CREATE INDEX IF NOT EXISTS idx_user_blocks_blocked ON public.user_blocks(blocked_id);

-- ===== USER REPORTS =====
CREATE TABLE IF NOT EXISTS public.user_reports (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reporter_id uuid NOT NULL,
  reported_user_id uuid NOT NULL,
  message_id uuid,
  category text NOT NULL DEFAULT 'other',
  details text,
  status text NOT NULL DEFAULT 'open',
  created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.user_reports ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users view own reports" ON public.user_reports
  FOR SELECT TO authenticated USING (auth.uid() = reporter_id OR public.has_role(auth.uid(), 'admin'::app_role));
CREATE POLICY "Users create reports" ON public.user_reports
  FOR INSERT TO authenticated WITH CHECK (auth.uid() = reporter_id AND reporter_id <> reported_user_id);
CREATE POLICY "Admins update reports" ON public.user_reports
  FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'admin'::app_role));

-- ===== MOOLA DAILY CLAIMS =====
CREATE TABLE IF NOT EXISTS public.moola_daily_claims (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  claim_date date NOT NULL DEFAULT (now() AT TIME ZONE 'utc')::date,
  amount integer NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, claim_date)
);
ALTER TABLE public.moola_daily_claims ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users view own claims" ON public.moola_daily_claims
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

-- ===== CLAIM DAILY MOOLA (atomic, once per UTC day, +20M) =====
CREATE OR REPLACE FUNCTION public.claim_daily_moola()
RETURNS jsonb
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  uid uuid := auth.uid();
  today date := (now() AT TIME ZONE 'utc')::date;
  bonus integer := 20;
  cur_balance integer;
  new_balance integer;
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;

  IF EXISTS (SELECT 1 FROM public.moola_daily_claims WHERE user_id = uid AND claim_date = today) THEN
    RETURN jsonb_build_object('ok', false, 'reason', 'already_claimed');
  END IF;

  SELECT moola INTO cur_balance FROM public.profiles WHERE id = uid FOR UPDATE;
  IF cur_balance IS NULL THEN RAISE EXCEPTION 'No profile'; END IF;

  new_balance := cur_balance + bonus;
  UPDATE public.profiles SET moola = new_balance WHERE id = uid;

  INSERT INTO public.moola_daily_claims (user_id, claim_date, amount) VALUES (uid, today, bonus);
  INSERT INTO public.moola_transactions (user_id, amount, reason, type, balance_before, balance_after, source)
  VALUES (uid, bonus, 'Joe Banker daily bonus', 'bonus', cur_balance, new_balance, 'daily_claim');

  RETURN jsonb_build_object('ok', true, 'amount', bonus, 'balance', new_balance);
END $$;

-- ===== DELETE MY ACCOUNT (App Store requirement) =====
CREATE OR REPLACE FUNCTION public.delete_my_account()
RETURNS void
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  uid uuid := auth.uid();
BEGIN
  IF uid IS NULL THEN RAISE EXCEPTION 'Not authenticated'; END IF;

  -- Wipe user-owned data. Messages stay (anonymized) so chat history isn't full of holes.
  DELETE FROM public.contacts WHERE requester_id = uid OR addressee_id = uid;
  DELETE FROM public.contact_groups WHERE owner_id = uid;
  DELETE FROM public.contact_group_members WHERE owner_id = uid OR contact_user_id = uid;
  DELETE FROM public.room_members WHERE user_id = uid;
  DELETE FROM public.multimx_members WHERE user_id = uid;
  DELETE FROM public.user_blocks WHERE blocker_id = uid OR blocked_id = uid;
  DELETE FROM public.user_reports WHERE reporter_id = uid;
  DELETE FROM public.moola_daily_claims WHERE user_id = uid;
  DELETE FROM public.moola_transactions WHERE user_id = uid;
  DELETE FROM public.user_roles WHERE user_id = uid;
  -- Anonymize messages so threads remain readable
  UPDATE public.messages SET content = '[deleted user]' WHERE sender_id = uid;
  -- Finally, drop the profile and auth user
  DELETE FROM public.profiles WHERE id = uid;
  DELETE FROM auth.users WHERE id = uid;
END $$;