// NSFW image scan via Lovable AI Gateway.
// POST { image_url, message_id? } -> { nsfw: boolean, score: 0..1, label: string }
// If message_id is supplied AND caller is the message sender, persists nsfw_score + auto_flagged.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type, x-supabase-client-platform, x-supabase-client-platform-version, x-supabase-client-runtime, x-supabase-client-runtime-version",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response(null, { headers: corsHeaders });
  try {
    const { image_url, message_id } = await req.json();
    if (!image_url || typeof image_url !== "string") {
      return new Response(JSON.stringify({ error: "image_url required" }), {
        status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" },
      });
    }

    const LOVABLE_API_KEY = Deno.env.get("LOVABLE_API_KEY");
    if (!LOVABLE_API_KEY) throw new Error("LOVABLE_API_KEY not configured");

    const ai = await fetch("https://ai.gateway.lovable.dev/v1/chat/completions", {
      method: "POST",
      headers: { Authorization: `Bearer ${LOVABLE_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "google/gemini-3-flash-preview",
        messages: [
          {
            role: "system",
            content:
              "You are an image content classifier. Reply with the classify_image tool. Mark NSFW=true for sexual nudity, explicit sexual content, graphic violence/gore, or hateful imagery. Mild swimsuits, art, and ordinary photos are SAFE.",
          },
          {
            role: "user",
            content: [
              { type: "text", text: "Classify this image." },
              { type: "image_url", image_url: { url: image_url } },
            ],
          },
        ],
        tools: [{
          type: "function",
          function: {
            name: "classify_image",
            description: "Return the NSFW classification.",
            parameters: {
              type: "object",
              properties: {
                nsfw: { type: "boolean" },
                score: { type: "number", description: "0..1 confidence that the image is unsafe" },
                label: { type: "string", enum: ["safe", "suggestive", "explicit", "violence", "hate", "other"] },
              },
              required: ["nsfw", "score", "label"],
              additionalProperties: false,
            },
          },
        }],
        tool_choice: { type: "function", function: { name: "classify_image" } },
      }),
    });

    if (!ai.ok) {
      if (ai.status === 429) return new Response(JSON.stringify({ error: "Rate limited" }), { status: 429, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      if (ai.status === 402) return new Response(JSON.stringify({ error: "Payment required" }), { status: 402, headers: { ...corsHeaders, "Content-Type": "application/json" } });
      const t = await ai.text();
      console.error("nsfw-scan AI error", ai.status, t);
      return new Response(JSON.stringify({ error: "AI gateway error" }), { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } });
    }

    const data = await ai.json();
    const args = data?.choices?.[0]?.message?.tool_calls?.[0]?.function?.arguments;
    const parsed = args ? JSON.parse(args) : { nsfw: false, score: 0, label: "safe" };

    if (message_id) {
      const SUPABASE_URL = Deno.env.get("SUPABASE_URL")!;
      const SERVICE = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
      const admin = createClient(SUPABASE_URL, SERVICE);
      await admin.from("messages").update({
        nsfw_score: parsed.score,
        auto_flagged: parsed.nsfw,
        hidden_by_mod: parsed.nsfw,
        hidden_reason: parsed.nsfw ? `Auto-flag: ${parsed.label}` : null,
      }).eq("id", message_id);
    }

    return new Response(JSON.stringify(parsed), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (e) {
    console.error("nsfw-scan error", e);
    return new Response(JSON.stringify({ error: e instanceof Error ? e.message : "unknown" }), {
      status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  }
});
